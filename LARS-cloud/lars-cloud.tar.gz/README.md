
# LARS Cloud - Облачная платформа обучения моделей сегментации

- **Назначение**: Веб-приложение для обработки видео и сегментации дорожного покрытия
- **Основные возможности**: Загрузка видео → извлечение кадров → сегментация → обучение модели

---

## 🌲 Структура проекта
```
LARS-cloud/
├── app/
│   ├── main.py                  # FastAPI + Gradio, только роутинг/интерфейсы
│   ├── core/                    # Общие утилиты и конфиги
│   │   ├── config.py            # Пути, глобальные переменные
│   │   ├── utils.py             # Общие функции
│   │   └── ffmpeg_utils.py      # Обёртки для ffmpeg (извлечение кадров, конвертация)
│   │
│   ├── modules/                 # Три независимые подсистемы
│   │   ├── segmentation/        # 1️⃣ Сегментация (SAM, SegFormer)
│   │   │   ├── sam_service.py
│   │   │   ├── training_service.py
│   │   │   ├── overlay_service.py
│   │   │   └── inference.py     # Запуск сегментации без GUI
│   │   │
│   │   ├── slam/                # 2️⃣ SLAM / SFM реконструкция
│   │   │   ├── sfm_reconstruction.py  # Запуск SFM реконструкции
│   │   │   ├── vda_slam_service.py           # pipeline -> VDA + SLAM
│   │   │   └── pointcloud_fusion.py # Слияние облаков точек
│   │   │
│   │   ├── video_processing/    # 3️⃣ Обработка видео стандартными моделями
│   │   │   ├── quad_video_service.py 
│   │   │   ├── video_processor.py
│   │   │   └── depth_overlay_service.py    # сервис для работы VDA v2
│   │
│   ├── interfaces/              # UI (Gradio) по модулям
│   │   ├── segmentation_ui.py
│   │   ├── slam_ui.py
│   │   ├── depth_overlay_ui.py
│   │   └── video_ui.py
│   │
│   └── api/                     # REST API ручки
│       ├── segmentation_api.py
│       ├── slam_api.py
│       └── video_api.py
│
├── data/                        # Данные
│   ├── segformer_model/          # веса модели Segformer
│   ├── segformer_model_trained/  # веса дообученной модели Segformer
│   ├── ultralytics_models/        # Модели YOLOnv11 и другие
│   ├── extracted_frames/          # Извлечённые кадры из видео
│   ├── sam_masks/                 # Маски, созданные с помощью SAM
│   ├── sfm_results/               # Результаты 3D реконструкции (облака точек, модели)
│   └── output/                  # Итоговые видео с сегментацией и наложением масок и видео с YOLO обнаружением + segformer cityspaces
│
├── scripts/
│   ├── build_and_prepare.py # Скрипт подготовки окружения и построения образа Docker
│   ├── install.py      # распоковка архива с кодом сервера и запуск скрипта build_and_prepare.py
├── docs/
│   ├── README_linux.md
│   └── README_windows.md
│
├── requirements.txt                # Список Python-зависимостей
├── Dockerfile                   # Docker образ приложения
├── docker-compose.yml               # Конфигурация для Docker Compose
├── docker-bake.hcl               # Конфигурация для сборки Docker образов
└── README.md                   # Основная документация проекта
```
---

## Основные компоненты

### Веб-интерфейс (`app/`)
- **main.py** — Gradio-интерфейс с тремя вкладками: загрузка видео, сегментация, тестирование
- **callbacks.py** — Обработчики событий интерфейса и логика работы с SAM/Segformer

### Модели (`model/`)
- **SAM2** — Для интерактивной сегментации и создания обучающих масок
- **Segformer** — Для обучения и инференса модели сегментации дорожного покрытия

---

## 💡 Рабочий процесс

1. **Загрузка видео** → извлечение кадров
2. **Интерактивная сегментация** → создание масок с помощью SAM
3. **Обучение модели** → дообучение Segformer на созданных масках
4. **Тестирование** → применение обученной модели к новому видео

---
## Примечание

Видео обрабатывается с помощью `ffmpeg` в формате H.264, поэтому для чтения и записи видео использовать `opencv` не требуется.
---
## 📚 Документация

Подробные инструкции по установке и запуску доступны в папке [`docs/`](./docs):

- [Инструкция по установке и запуску на Linux](docs/README_linux.md)
- [Инструкция по установке и запусу на Windows](docs/README_windows.md)
