# Установка и запуск LARS-cloud на Windows

---
Посмотрев на документацию SAM2 и структуру проекта, вот реальные требования:

## Системные требования для Windows

### Минимальные требования:
- **ОС**: Windows 10/11 (64-bit)
- **RAM**: 8 GB
- **Диск**: 15 GB свободного места
- **Docker Desktop** 4.0+ с WSL 2 backend
- **WSL 2** (включен)
- **Интернет** для загрузки образов

### Для GPU ускорения:
- **NVIDIA GPU** (любая с поддержкой CUDA)
- **NVIDIA Drivers** (последние)
- **Docker Desktop** с поддержкой GPU (WSL 2 backend)

### Проверка:
```powershell
docker --version
wsl --list --verbose
docker run --rm --gpus all nvidia/cuda:11.8-base nvidia-smi
```

**Важно**: SAM2 работает и на CPU, но медленнее. GPU ускоряет обработку видео и сегментацию.

### 1. Установка Docker Desktop для Windows

**Скачать Docker Desktop:**
- Перейдите на https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe

**Запустить Docker Desktop:**
- Найти "Docker Desktop" в меню Пуск и запустить

**Включить WSL 2 integration (обязательно для GPU):**
1. **Settings** → **General** → **Use WSL 2 based engine** (включить)
2. **Settings** → **Resources** → **WSL Integration** → **Enable integration**

**Проверить установку:**
```powershell
docker --version
docker compose version
docker buildx version
```

**Тест работы Docker:**
```powershell
docker run hello-world
```

---

### 2. Настройка GPU поддержки (опционально)

**Для использования NVIDIA GPU в контейнерах на Windows:**

> **Важно:** GPU поддержка в Docker Desktop для Windows доступна только с WSL 2 backend.

**Настройка GPU поддержки:**

1. **Обновить WSL 2 ядро:**
```powershell
wsl --update
```

2. **Проверить наличие NVIDIA GPU:**
```powershell
nvidia-smi
```

3. **Включить WSL 2 backend в Docker Desktop:**
   - Открыть Docker Desktop
   - **Settings** → **General** → **Use the WSL 2 based engine** (включить)
   - **Settings** → **Resources** → **WSL Integration** → **Enable integration**

4. **Docker Desktop автоматически поддерживает GPU** - дополнительная установка не требуется

5. **Перезапустить Docker Desktop**

**Проверить GPU поддержку:**

Запустить GPU benchmark:
```powershell
docker run --rm -it --gpus=all nvcr.io/nvidia/k8s/cuda-sample:nbody nbody -gpu -benchmark
```

Тест с простым CUDA контейнером:
```powershell
docker run --rm --gpus all nvidia/cuda:11.8-base nvidia-smi
```

**Проверить GPU в LARS-server:**
```powershell
docker compose exec lars-server nvidia-smi
```

---

### 3. Автоматическая подготовка проекта

**Создание Docker buildx builder:**
```powershell
docker buildx create --name lars_server --use --bootstrap
```

**Проверка созданных билдов:**
```powershell
docker buildx ls
```

**Запуск установочного скрипта:**
```powershell
python scripts/build_and_prepare.py
```

Скрипт автоматически:
- Создаст необходимые папки (`models/`, `data/`)
- Соберет Docker образ
- Скачает модели SAM

---

### 4. Запуск сервера

**Запуск в обычном режиме:**
```powershell
docker compose up
```

**Доступ к интерфейсу:** http://localhost:7860

---

### 5. Управление сервером

**Остановка сервера:**
```powershell
docker compose down
```

**Проверка статуса:**
```powershell
docker compose ps
```

**Просмотр логов:**
```powershell
docker compose logs -f lars-server
```

**Удаление образов проекта:**
```powershell
docker rmi lars-server:latest
```

**Очистка Docker кэша:**
```powershell
docker buildx prune -f
```

**Полная очистка:**
```powershell
docker system prune -af
```

---

### Примечание

- Файл с **изночальными** весами модели `sam2.1_hiera_base_plus.pt` лежит в папкек `models`
- Файл c **обновленными** весами модели `sam2.1_hiera_base_plus.pt` должен находиться в папке `data/segformer_roadsidewalk_model`
