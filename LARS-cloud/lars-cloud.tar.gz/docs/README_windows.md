# Установка и запуск LARS-cloud на Windows

---

### 1. Установка Docker Desktop для Windows

**Скачать Docker Desktop:**
- Перейдите на https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe
- Или используйте winget:
```powershell
winget install Docker.DockerDesktop
```

**Запустить Docker Desktop:**
- Найти "Docker Desktop" в меню Пуск и запустить
- Или использовать PowerShell:
```powershell
start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe"
```

**Включить WSL 2 integration (рекомендуется):**
1. **Settings** → **General** → **Use WSL 2 based engine**
2. **Settings** → **Resources** → **WSL Integration** → **Enable integration**

**Проверить установку:**
```powershell
docker --version
docker compose version
docker buildx version
```

**Тест работы Docker:**
```powershell
docker run hello-world
```

---

### 2. Автоматическая подготовка проекта

**Используя PowerShell (рекомендуется):**
Запустить скрипт подготовки
```powershell
../
python scripts/build_and_prepare.py
```

Скрипт автоматически:
- Создаст необходимые папки (`models/`, `data/`)
- Соберет Docker образ
- Скачает модели SAM 

---

### 2. Запуск сервера

**Запуск в обычном режиме:**
```powershell
docker compose up
```

**Доступ к интерфейсу:** http://localhost:7860

---

### 3. Управление сервером

**Остановка сервера:**
```powershell
docker compose down
```

**Проверка статуса:**
```powershell
docker compose ps
```

**Просмотр логов:**
```powershell
docker compose logs -f lars-server
```

**Пересборка при изменениях:**
```powershell
python scripts/build_and_prepare.py
```

---

#### Очистка Docker кэша
Очистка build кэша
```powershell
docker buildx prune -f
```

Полная очистка
```powershell
docker system prune -af
```
---

### Примечание

Файл с обновленными весами моделей `sam2.1_hiera_base_plus.pt` должен находиться в папке `data/segformer_roadsidewalk_model` 
