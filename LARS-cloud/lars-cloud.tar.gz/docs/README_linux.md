## Установка и запуск LARS-cloud на Linux

---
### 1. Установка Docker и Docker Compose

## **Ubuntu/Debian:**
Обновить список пакетов
```bash
sudo apt update
```
Установить зависимости для HTTPS репозиториев
```bash
sudo apt install apt-transport-https ca-certificates curl software-properties-common
```

Добавить официальный GPG ключ Docker
```bash
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
```

Добавить репозиторий Docker
```bash
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

Обновить список пакетов с новым репозиторием
```bash
sudo apt update
```

Установить Docker Engine и Docker Compose
```bash
sudo apt install docker-ce docker-ce-cli containerd.io docker-compose-plugin
```
Добавить текущего пользователя в группу docker (чтобы не использовать sudo)
```bash
sudo usermod -aG docker $USER
```
Активировать изменения группы (или перезайти в систему)
```bash
newgrp docker
```

Вот инструкции по установке Docker для Arch Linux в том же стиле:

## **Arch Linux:**

Обновить систему
```bash
sudo pacman -Syu
```

Установить Docker из официального репозитория
```bash
sudo pacman -S docker
```

Установить Docker Compose
```bash
sudo pacman -S docker-compose
```

Установить docker bake
```bash
sudo pacman -S docker-bake
```

Запустить службу Docker
```bash
sudo systemctl start docker.service
```

Включить автозапуск службы Docker при загрузке системы
```bash
sudo systemctl enable docker.service
```

Добавить текущего пользователя в группу docker (чтобы не использовать sudo)
```bash
sudo usermod -aG docker $USER
```

Активировать изменения группы (или перезайти в систему)
```bash
newgrp docker
```

**Проверка установки:**
```bash
docker --version
docker compose version
dcoker bake version
```

**Тест работы Docker (опционально):**
```bash
docker run hello-world
```
---

### 2. Сборка образа LARS-server

Создаем docker buildx builder `lars_server`
```bash
../
docker buildx create --name lars_server --use --bootstrap
```

**Проверка созданных билдов:**
```bash
../
docker buildx ls
```
должно быть что-то вроде:
```
NAME/NODE       DRIVER/ENDPOINT             STATUS  BUILDER                  PLATFORM
lars_server *   docker-container+linux      running lars_server (default) linux/
x86_64, linux/arm64, linux/arm/v7
```
Запускаем установочный скрипт
```bash
../
python scripts/build_and_prepare.py
```

---

### 3. Запуск сервера

**Запуск** в фоновом режиме
```bash
../
docker compose up
```
**Доступ к интерфейсу:** http://localhost:7860

**Остановка** сервера
```bash
docker compose down
```

Проверка статуса сервера
```bash
docker compose ps
```

### Примечание

Файл с обновленными весами моделей `sam2.1_hiera_base_plus.pt` должен находиться в папке `data/segformer_roadsidewalk_model` 
