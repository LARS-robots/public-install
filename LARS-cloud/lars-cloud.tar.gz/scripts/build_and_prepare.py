import subprocess
import os
import sys
import requests
from pathlib import Path


def run_command_with_streaming(cmd, description):
    """Выполняет команду и выводит результат в реальном времени"""
    print(f"🔨 {description}")
    try:
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )

        # Выводим логи в реальном времени
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())

        return_code = process.poll()
        if return_code == 0:
            print(f"✅ {description} - успешно")
        else:
            print(f"❌ Ошибка при {description.lower()}")
            sys.exit(1)

    except Exception as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        sys.exit(1)


def run_command(cmd, description):
    """Обычная команда без streaming для быстрых операций"""
    print(f"🔨 {description}")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} - успешно")
        return result
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
        sys.exit(1)


def main():
    # Создаем необходимые директории
#    os.makedirs("models", exist_ok=True)
#    os.makedirs("data/extracted_frames", exist_ok=True)
#    os.makedirs("data/output", exist_ok=True)
#    os.makedirs("data/sam_masks", exist_ok=True)

    # Используем docker bake для сборки образа с потоковыми логами
    run_command_with_streaming(
        "docker buildx bake --progress=plain --load",
        "Сборка Docker образа LARS Server"
    )

    # Загружаем чекпойнты в локальную директорию models
    print("\n📥 Загрузка чекпойнтов...")

    checkpoints = [
        {
            "url": "https://dl.fbaipublicfiles.com/segment_anything_2/092824/sam2.1_hiera_base_plus.pt",
            "filename": "sam2.1_hiera_base_plus.pt"
        },
    ]
    for checkpoint in checkpoints:
        checkpoint_path = Path("models") / checkpoint["filename"]
        if not checkpoint_path.exists():
            print(f"🔨 Загрузка {checkpoint['filename']}")
            try:
                response = requests.get(checkpoint['url'], stream=True)
                response.raise_for_status()

                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0

                with open(checkpoint_path, 'wb') as file:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            file.write(chunk)
                            downloaded += len(chunk)
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f"\r📥 {percent:.1f}% ({downloaded}/{total_size} bytes)", end='', flush=True)

                print(f"\n✅ {checkpoint['filename']} - успешно загружен")
            except Exception as e:
                print(f"\n❌ Ошибка при загрузке {checkpoint['filename']}: {e}")
                if checkpoint_path.exists():
                    checkpoint_path.unlink()  # Удаляем частично загруженный файл
                sys.exit(1)
        else:
            print(f"✅ {checkpoint['filename']} уже существует, пропускаем")

    print("\n🎉 Подготовка завершена! Теперь можно запускать docker-compose up")


if __name__ == "__main__":
    main()