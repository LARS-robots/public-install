import subprocess
import os
import sys
import requests
from pathlib import Path


def run_command_with_streaming(cmd, description):
    """Выполняет команду и выводит результат в реальном времени"""
    print(f"🔨 {description}")
    try:
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )

        # Выводим логи в реальном времени
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())

        return_code = process.poll()
        if return_code == 0:
            print(f"✅ {description} - успешно")
        else:
            print(f"❌ Ошибка при {description.lower()}")
            sys.exit(1)

    except Exception as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        sys.exit(1)


def run_command(cmd, description):
    """Обычная команда без streaming для быстрых операций"""
    print(f"🔨 {description}")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} - успешно")
        return result
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
        sys.exit(1)


def check_docker():
    """Проверяет доступность Docker"""
    try:
        subprocess.run(["docker", "--version"], check=True, capture_output=True)
        subprocess.run(["docker", "buildx", "version"], check=True, capture_output=True)
        print("✅ Docker и buildx доступны")
    except subprocess.CalledProcessError:
        print("❌ Docker или docker buildx недоступны")
        sys.exit(1)
    except FileNotFoundError:
        print("❌ Docker не установлен")
        sys.exit(1)


def main():
    print("🏗️ Подготовка LARS Cloud...")
    
    # Проверяем что мы в правильной директории
    if not Path("docker-bake.hcl").exists():
        print("❌ Файл docker-bake.hcl не найден. Убедитесь, что вы в корне проекта LARS-cloud")
        sys.exit(1)
    
    # Проверяем Docker
    check_docker()

    # Создаем необходимые директории
    dirs_to_create = [
        "data/frames",
        "data/masks", 
        "data/sfm",
        "data/output",
        "data/segformer",
        "data/segformer_trained",
        "data/eis_output",
        "data/ultralytics"
    ]
    
    for dir_path in dirs_to_create:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
        print(f"📁 Создана директория: {dir_path}")

    # Используем docker bake для сборки образа с потоковыми логами
    run_command_with_streaming(
        'docker buildx bake --progress=plain --load --set "*.args.GPU=all"',
        "Сборка Docker образа LARS Server"
    )

    print("""
🎉 Подготовка завершена! 

🚀 Для запуска выполните:
   docker-compose up

🌐 После запуска откройте: http://localhost:7860
    """)

if __name__ == "__main__":
    main()