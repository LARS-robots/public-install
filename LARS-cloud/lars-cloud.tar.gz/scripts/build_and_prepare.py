import subprocess
import os
import sys
import requests
from pathlib import Path


def run_command_with_streaming(cmd, description):
    """Выполняет команду и выводит результат в реальном времени"""
    print(f"🔨 {description}")
    try:
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )

        # Выводим логи в реальном времени
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())

        return_code = process.poll()
        if return_code == 0:
            print(f"✅ {description} - успешно")
        else:
            print(f"❌ Ошибка при {description.lower()}")
            sys.exit(1)

    except Exception as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        sys.exit(1)


def run_command(cmd, description):
    """Обычная команда без streaming для быстрых операций"""
    print(f"🔨 {description}")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} - успешно")
        return result
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка при {description.lower()}: {e}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
        sys.exit(1)


def main():
    # Создаем необходимые директории

    # Используем docker bake для сборки образа с потоковыми логами
    run_command_with_streaming(
        "docker buildx bake --progress=plain --load",
        "Сборка Docker образа LARS Server"
    )

    print("\n🎉 Подготовка завершена! Теперь можно запускать docker-compose up")


if __name__ == "__main__":
    main()