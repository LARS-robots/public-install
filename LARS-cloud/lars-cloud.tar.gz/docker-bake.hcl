group "default" {
  targets = ["lars-server"]
}

target "lars-server" {
  context = "."
  dockerfile = "Dockerfile"
  tags = ["lars-server:latest"]
  output = ["type=docker"]
  args = {
    GPU = "all"
  }
}
