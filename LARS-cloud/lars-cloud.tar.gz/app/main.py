import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

import matplotlib
matplotlib.use('Agg')
'''
Поскольку FastAPI + Uvicorn создают окружение,
в котором не инициализируется GUI, нам нужно 
отключить GIU backend у matplotlib поскольку
по умолчанию matplotlib всё равно пробует GUI backend
'''
import gradio as gr
from app.services.sam_service import SAMService
from app.services.video_processor import VideoProcessor
from app.services.training_service import TrainingService
from app.services.overlay_service import OverlayService
from fastapi import FastAPI
import uvicorn
import torch

def create_sam_interface(sam_service: SAMService):
    """Create SAM segmentation interface"""

    def handle_click(evt: gr.SelectData):
        if evt is None or evt.index is None:
            return sam_service.load_image(sam_service.current_idx)
        return sam_service.add_point(evt.index[0], evt.index[1])

    def change_current_video_frame(video_idx):
        """Изменить кадр в текущем видео"""
        if not sam_service.current_video_frames:
            return sam_service.load_image(0) if sam_service.frame_files else None
            
        if video_idx >= len(sam_service.current_video_frames):
            return sam_service.load_current_video_image(0)
            
        sam_service.reset_points()
        return sam_service.load_current_video_image(video_idx)

    def reset_points_handler(current_idx):
        """Reset points and return current image"""
        sam_service.reset_points()
        if sam_service.current_video_frames:
            return sam_service.load_current_video_image(current_idx)
        return sam_service.load_image(current_idx) if sam_service.frame_files else None

    def set_mode_handler(mode):
        """Set mode and return status message"""
        return sam_service.set_mode(mode)

    # Изначально слайдер для пустого видео
    initial_max = 0

    with gr.Column():
        with gr.Row():
            with gr.Column(scale=1):
                img = gr.Image(interactive=True, label="Кликай для сегментации", height=500)
            with gr.Column(scale=2):
                with gr.Row():
                    # Слайдер только для текущего видео
                    video_idx = gr.Slider(
                        minimum=0,
                        maximum=initial_max,
                        value=0,
                        step=1,
                        label="Кадр текущего видео (загрузите видео)"
                    )
                    status = gr.Textbox(label="Статус", max_lines=2)

                with gr.Row():
                    with gr.Column():
                        mode_add = gr.Button("Добавить")
                        mode_sub = gr.Button("Вычесть")
                        calc_btn = gr.Button("Рассчитать")
                    with gr.Column():
                        save_btn = gr.Button("Сохранить маску")
                        reset_btn = gr.Button("Сбросить разметку")

        # Привязка событий для работы с текущим видео
        video_idx.change(fn=change_current_video_frame, inputs=video_idx, outputs=img)
        img.select(fn=handle_click, inputs=None, outputs=img)
        mode_add.click(fn=lambda: set_mode_handler(1), outputs=status)
        mode_sub.click(fn=lambda: set_mode_handler(0), outputs=status)
        calc_btn.click(fn=sam_service.calculate_mask, outputs=img)
        save_btn.click(fn=sam_service.save_mask, outputs=status)
        reset_btn.click(fn=reset_points_handler, inputs=video_idx, outputs=img)

    return img, video_idx, status


def create_main_interface():
    """Create the complete application interface"""

    # Get absolute path to project root
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)  # LARS-cloud/
    sam_model_path = os.path.join(project_root, "models", "sam2.1_hiera_base_plus.pt")

    # Use absolute paths for data directories
    data_dir = os.path.join(project_root, "data")
    frames_dir = os.path.join(data_dir, "extracted_frames")
    masks_dir = os.path.join(data_dir, "sam_masks")
    output_dir_default = os.path.join(project_root, "fine_tuned_model")

    # Configuration for services
    config = {
        'sam_checkpoint': sam_model_path
    }

    try:
        # Check if model exists before initializing
        if not os.path.exists(sam_model_path):
            raise FileNotFoundError(f"SAM model not found at {sam_model_path}")

        # Initialize services
        sam_service = SAMService(config)
        video_processor = VideoProcessor()

        # Create directories if they don't exist
        os.makedirs(frames_dir, exist_ok=True)
        os.makedirs(masks_dir, exist_ok=True)

        # Initialize SAM session with ABSOLUTE paths
        sam_service.initialize_session(frames_dir, masks_dir)

    except Exception as e:
        # Fallback interface if services fail to initialize
        with gr.Blocks(title="LARS Cloud - Error") as demo:
            gr.Markdown("# ❌ Ошибка инициализации")
            gr.Markdown(f"Ошибка: {str(e)}")
            gr.Markdown("**Проверьте:**")
            gr.Markdown(f"- Модель SAM должна быть в: `{sam_model_path}`")
            gr.Markdown("- Скачайте модель командой:")
            gr.Code("wget https://dl.fbaipublicfiles.com/segment_anything_2/092824/sam2.1_hiera_base_plus.pt -O models/sam2.1_hiera_base_plus.pt")
            return demo
    # Функция для получения информации о GPU
    def get_gpu_info():
        if torch.cuda.is_available():
            device_count = torch.cuda.device_count()
            current_device = torch.cuda.current_device()
            device_name = torch.cuda.get_device_name(current_device)
            return f"✅ GPU доступен: {device_name} (устройство {current_device}/{device_count-1})"
        else:
            return "❌ GPU недоступен, используется CPU"

    with gr.Blocks(title="LARS Cloud", theme=gr.themes.Soft()) as demo:
        gr.Markdown("# LARS Cloud - Облачная платформа обучения моделей сегментации")

        gpu_status = gr.Textbox(
            label="Статус GPU",
            value=get_gpu_info(),
            interactive=False,
            max_lines=1
        )

        with gr.Tabs():
            # Tab 1: Video Upload
            with gr.Tab("Загрузка видео"):
                with gr.Row():
                    with gr.Column():
                        video_input = gr.Video(label="Загрузить видео")
                    with gr.Column():
                        status_upload = gr.Textbox(label="Статус", interactive=False)
                        fps_slider = gr.Slider(
                            minimum=1,
                            maximum=10,
                            value=1,
                            step=1,
                            label="Кадров в секунду для извлечения"
                        )
                        extract_btn = gr.Button("Извлечь кадры", variant="primary")

            # Tab 2: SAM Segmentation - создаем idx здесь, ПЕРЕД использовании
            with gr.Tab("Интерактивная сегментация"):
                img, idx, status = create_sam_interface(sam_service)

                # Обновляем слайдер после загрузки видео
                def update_frame_slider():
                    max_frames = max(0, len(sam_service.frame_files) - 1) if sam_service.frame_files else 0
                    return gr.update(
                        minimum=0,
                        maximum=max_frames,
                        value=max_frames,
                        # value=0,
                        step=1,
                        label=f"Кадр (0-{max_frames})" if max_frames > 0 else "Кадр (загрузите видео)"
                    )


            # Tab 3: train the model - дообучаем модель
            with gr.Tab("Дообучение модели"):
                with gr.Row():
                    with gr.Column(scale=1):
                        log_box = gr.Textbox(label="Логи обучения", lines=15, interactive=False)
                    with gr.Column(scale=1):
                        batch_slider = gr.Slider(1, 16, value=4, step=1, label="Размер выборки")
                        epoch_slider = gr.Slider(1, 100, value=30, step=1, label="Эпохи")
                        train_btn = gr.Button("Запустить дообучение", variant="primary")

                # Замыкание для дообучения
                def run_finetune_wrapper(bs, ne):
                    img_dir = str(frames_dir)
                    mask_dir = str(masks_dir)
                    out_dir = os.path.join(project_root, "data")

                    svc = TrainingService(img_dir, mask_dir, out_dir)
                    logs = svc.train(batch_size=bs, num_epochs=ne)
                    return "\n".join(logs)

                train_btn.click(
                    fn=run_finetune_wrapper,
                    inputs=[batch_slider, epoch_slider],  # Только слайдеры
                    outputs=log_box
                )

            with gr.Tab("Тестирование модели"):
                with gr.Row():
                    with gr.Column(scale=1):
                        input_video_upload = gr.Video(label="Загрузить видео для тестирования")
                        run_btn = gr.Button("Наложить маску", variant="primary")

                    with gr.Column(scale=1):
                        output_video_display = gr.Video(
                            label="Обработанное видео",
                            interactive=False
                        )
                        out_link = gr.Textbox(label="Путь к готовому файлу", interactive=False)

                # Создаем замыкание с захваченными переменными
                def run_overlay_wrapper(input_video_file):
                    model_dir = os.path.join(project_root, "data", "segformer_roadsidewalk_model")
                    out_vid = os.path.join(project_root, "data", "output", "overlay.mp4")

                    if not input_video_file:
                        return "❌ Загрузите видео", None

                    if not os.path.exists(model_dir):
                        return f"❌ Модель не найдена в {model_dir}", None

                    required_files = ["preprocessor_config.json", "config.json"]
                    missing_files = [f for f in required_files if
                                     not os.path.exists(os.path.join(model_dir, f))]

                    if missing_files:
                        return f"❌ Отсутствуют файлы: {', '.join(missing_files)} в {model_dir}", None

                    try:
                        os.makedirs(os.path.dirname(out_vid), exist_ok=True)
                        svc = OverlayService(model_dir)
                        result_msg = svc.apply_overlay(input_video_file, out_vid, alpha=0.4)

                        if os.path.exists(out_vid) and os.path.getsize(out_vid) > 0:
                            return f"✅ Видео сохранено: {out_vid}", out_vid
                        else:
                            return "❌ Файл не был создан", None

                    except Exception as e:
                        return f"❌ Ошибка: {str(e)}", None

                run_btn.click(
                    fn=run_overlay_wrapper,
                    inputs=[input_video_upload],  # Только один вход
                    outputs=[out_link, output_video_display]
                )

            def process_video_and_update_slider(video_path, fps_rate):
                if not video_path:
                    return "Выберите видео", gr.update()

                # Извлекаем кадры с инкрементальной нумерацией
                result = video_processor.extract_frames(video_path, fps=fps_rate, frames_dir=frames_dir)

                # Получить кадры текущего видео
                current_frames = video_processor.get_current_video_frames()

                # Обновить SAM service
                sam_service.initialize_session(frames_dir, masks_dir)
                sam_service.set_current_video_frames(current_frames)

                # Обновить слайдер только для текущего видео
                max_video_frames = max(0, len(current_frames) - 1) if current_frames else 0
                slider_update = gr.update(
                    minimum=0,
                    maximum=max_video_frames,
                    value=0,  # Начинаем с первого кадра текущего видео
                    step=1,
                    label=f"Кадр текущего видео (0-{max_video_frames})" if max_video_frames > 0 else "Кадр текущего видео (загрузите видео)"
                )

                return f"✅ {result} | Кадры текущего видео: {len(current_frames)}", slider_update

            # Привязываем автоматическое обновление к кнопке извлечения кадров (ПОСЛЕ создания idx)
            extract_btn.click(
                fn=process_video_and_update_slider,
                inputs=[video_input, fps_slider],
                outputs=[status_upload, idx]  # Теперь idx уже определен
            )
        return demo





def main():
    demo = create_main_interface()
    app = gr.mount_gradio_app(FastAPI(), demo, path="//")
    return app

app = main()

if __name__ == "__main__":
    # reload=True для разработки, False для продакшн
    uvicorn.run("app.main:app", host="0.0.0.0", port=7860, reload=True)
