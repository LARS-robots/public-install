# app/main.py
import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir_ = start_dir
    while dir_ != os.path.dirname(dir_):
        if os.path.isfile(os.path.join(dir_, marker)):
            return dir_
        dir_ = os.path.dirname(dir_)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from fastapi import FastAPI
import gradio as gr

from app.core.config import FRAMES_DIR, MASKS_DIR, SFM_DIR, OUTPUT_DIR, SEGFORMER_DIR, SEGFORMER_DIR_TRAINED
from app.core.utils import get_gpu_info
from app.interfaces.segmentation_ui import create_segmentation_ui
from app.interfaces.slam_ui import create_slam_ui
from app.interfaces.video_ui import create_video_ui
from app.interfaces.depth_overlay_ui import create_depth_overlay_ui  # <-- импорт depth UI
from app.api.segmentation_api import router as segmentation_router
from app.api.slam_api import router as slam_router
from app.api.video_api import router as video_router
from app.api.depth_overlay_api import router as depth_overlay_router
from app.modules.video_processing.video_processor import VideoProcessor

# Создаём необходимые папки
for d in [FRAMES_DIR, MASKS_DIR, SFM_DIR, OUTPUT_DIR, SEGFORMER_DIR, SEGFORMER_DIR_TRAINED]:
    os.makedirs(d, exist_ok=True)

# Инициализация VideoProcessor
video_processor = VideoProcessor()

# Создаём Gradio интерфейс
with gr.Blocks(title="LARS Cloud", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# ИИ-облако флотов роботов ЛАРС")
    gr.Textbox(label="Статус GPU", value=get_gpu_info(), interactive=False, max_lines=1)

    # Состояние для хранения пути к видео
    video_path_state = gr.State(value="")

    with gr.Row():
        with gr.Column(scale=1, min_width=200) as sidebar:
            gr.Markdown("### Меню")
            video_button = gr.Button("Загрузка видео и обработка", variant="secondary")
            segment_button = gr.Button("Интерактивная разметка", variant="secondary")
            reconstruct_button = gr.Button("3D реконструкция", variant="secondary")
            process_button = gr.Button("Обработанное видео", variant="secondary")
            depth_button = gr.Button("Наложение глубины", variant="secondary")

        with gr.Column(scale=4) as main_content:
            # Video upload и кадры
            with gr.Group() as video_ui:
                gr.Markdown("## Загрузка видео")
                with gr.Row():
                    with gr.Column(scale=2):
                        video_input = gr.Video(label="Загрузите видео")
                    with gr.Column(scale=1, min_width=100):
                        status = gr.Textbox(label="Статус", interactive=False)
                        extract_button = gr.Button("Извлечь кадры", variant="primary")

                def extract_frames(video_path):
                    if not video_path:
                        return "Ошибка: Видео не загружено", ""

                    # Очистка старых масок и кадров
                    try:
                        for folder, ext in [(MASKS_DIR, '.png'), (FRAMES_DIR, ('.jpg','.png'))]:
                            if os.path.exists(folder):
                                for f in os.listdir(folder):
                                    if f.endswith(ext):
                                        os.remove(os.path.join(folder, f))
                    except Exception as e:
                        print(f"⚠️ Ошибка при удалении старых файлов: {str(e)}")

                    result = video_processor.extract_frames(video_path, fps=1)
                    if video_processor.get_frame_count() > 0:
                        num_frames = video_processor.get_frame_count()
                        return (f"{result}. Извлечено {num_frames} кадров. "
                                f"Теперь можно перейти к другим разделам."), video_path
                    return "Ошибка: Не удалось извлечь кадры", ""

                extract_button.click(
                    fn=extract_frames,
                    inputs=video_input,
                    outputs=[status, video_path_state]
                )

            # Segmentation UI
            with gr.Group(visible=False) as segment_ui:
                create_segmentation_ui()

            # 3D Reconstruction UI
            with gr.Group(visible=False) as slam_ui:
                create_slam_ui()

            # Processed Video UI
            video_process_ui, run_quad_btn, quad_status, quad_video_display, run_quad_wrapper = create_video_ui()
            video_process_ui.visible = False

            # Depth Overlay UI
            with gr.Group(visible=False) as depth_ui:
                create_depth_overlay_ui(video_path_state)  # <-- видео берётся напрямую из состояния
            depth_ui.visible = False

    # Функции переключения вкладок
    def show_video(): return (gr.update(visible=True), gr.update(visible=False), gr.update(visible=False),
                              gr.update(visible=False), gr.update(visible=False),
                              gr.update(variant="primary"), gr.update(variant="secondary"),
                              gr.update(variant="secondary"), gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_segment(): return (gr.update(visible=False), gr.update(visible=True), gr.update(visible=False),
                                gr.update(visible=False), gr.update(visible=False),
                                gr.update(variant="secondary"), gr.update(variant="primary"),
                                gr.update(variant="secondary"), gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_slam(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=True),
                             gr.update(visible=False), gr.update(visible=False),
                             gr.update(variant="secondary"), gr.update(variant="secondary"),
                             gr.update(variant="primary"), gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_process(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                                gr.update(visible=True), gr.update(visible=False),
                                gr.update(variant="secondary"), gr.update(variant="secondary"),
                                gr.update(variant="secondary"), gr.update(variant="primary"), gr.update(variant="secondary"))

    def show_depth(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                              gr.update(visible=False), gr.update(visible=True),
                              gr.update(variant="secondary"), gr.update(variant="secondary"),
                              gr.update(variant="secondary"), gr.update(variant="secondary"), gr.update(variant="primary"))

    # Button handlers
    video_button.click(fn=show_video, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui,
                                               video_button, segment_button, reconstruct_button, process_button, depth_button])

    segment_button.click(fn=show_segment, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui,
                                                   video_button, segment_button, reconstruct_button, process_button, depth_button])

    reconstruct_button.click(fn=show_slam, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui,
                                                    video_button, segment_button, reconstruct_button, process_button, depth_button])

    process_button.click(fn=show_process, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui,
                                                  video_button, segment_button, reconstruct_button, process_button, depth_button])

    depth_button.click(fn=show_depth, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui,
                                               video_button, segment_button, reconstruct_button, process_button, depth_button])

    # Wiring run_quad_btn
    run_quad_btn.click(fn=run_quad_wrapper, inputs=[video_path_state], outputs=[quad_status, quad_video_display])

def main():
    app = FastAPI()
    # API роутеры
    app.include_router(segmentation_router, prefix="/api/segmentation")
    app.include_router(slam_router, prefix="/api/slam")
    app.include_router(video_router, prefix="/api/video")
    app.include_router(depth_overlay_router, prefix="/api/depth-overlay")
    # Монтируем Gradio
    app = gr.mount_gradio_app(app, demo, path="//")
    return app

app = main()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=7860, reload=True)
