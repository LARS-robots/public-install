# app/main.py
import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir_ = start_dir
    while dir_ != os.path.dirname(dir_):
        if os.path.isfile(os.path.join(dir_, marker)):
            return dir_
        dir_ = os.path.dirname(dir_)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from fastapi import FastAPI
import gradio as gr

from app.core.config import FRAMES_DIR, MASKS_DIR, SFM_DIR, OUTPUT_DIR, SEGFORMER_DIR, SEGFORMER_DIR_TRAINED, EIS_OUTPUT_DIR, ULTRALYTICS_DIR
from app.core.utils import get_gpu_info
from app.interfaces.segmentation_ui import create_segmentation_ui
from app.interfaces.slam_ui import create_slam_ui
from app.interfaces.video_ui import create_video_ui
from app.interfaces.depth_overlay_ui import create_depth_overlay_ui
from app.interfaces.eis_ui import create_eis_ui
from app.api.segmentation_api import router as segmentation_router
from app.api.slam_api import router as slam_router
from app.api.video_api import router as video_router
from app.api.depth_overlay_api import router as depth_overlay_router
from app.api.eis_api import router as eis_router
from app.modules.video_processing.video_processor import VideoProcessor
from app.modules.video_processing.eis.splitter import SplitMode
from app.modules.video_processing.quad_video_service import QuadVideoService

# Создаём необходимые папки
for d in [FRAMES_DIR, MASKS_DIR, SFM_DIR, OUTPUT_DIR, SEGFORMER_DIR, SEGFORMER_DIR_TRAINED, EIS_OUTPUT_DIR]:
    os.makedirs(d, exist_ok=True)

# Создаём Gradio интерфейс
with gr.Blocks(title="LARS Cloud", theme=gr.themes.Soft()) as demo:
    # Инициализация VideoProcessor
    video_processor = VideoProcessor()
    gr.Markdown("# ИИ-облако флотов роботов ЛАРС")
    gr.Textbox(label="Статус GPU", value=get_gpu_info(), interactive=False, max_lines=1)

    # Состояние для хранения пути к видео
    video_path_state = gr.State(value="")
    camera_type_state = gr.State("Моно")  # Добавлено
    
    # Add a refresh trigger state
    refresh_trigger = gr.State(value=0)

    with gr.Row():
        with gr.Column(scale=1, min_width=200) as sidebar:
            gr.Markdown("### Меню")
            video_button = gr.Button("Загрузка видео", variant="secondary")
            segment_button = gr.Button("Разметка рабочих областей", variant="secondary")
            reconstruct_button = gr.Button("3D реконструкция", variant="secondary")
            process_button = gr.Button("Тестирование и экспорт моделей", variant="secondary")
            depth_button = gr.Button("Наложение глубины", variant="secondary")
            eis_button = gr.Button("Стабилизация (EIS)", variant="secondary")

        with gr.Column(scale=4) as main_content:
            # Video upload и кадры
            with gr.Group() as video_ui:
                gr.Markdown("## Загрузка видео")
                with gr.Row():
                    with gr.Column(scale=2):
                        video_input = gr.Video(label="Загрузите видео")
                    with gr.Column(scale=1, min_width=100):
                        status = gr.Textbox(label="Статус", interactive=False)
                        camera_type = gr.Dropdown(choices=["Моно", "Стерео"], value="Моно", label="Тип камеры")
                        extract_button = gr.Button("Извлечь кадры", variant="primary")

                def extract_frames(video_path, camera_type_ui, current_trigger):
                    if not video_path:
                        return "Ошибка: Видео не загружено", "", current_trigger

                    # Convert UI choice to explicit layout
                    layout_mapping = {
                        "моно": SplitMode.MONO,
                        "стерео": SplitMode.STEREO_H,  # Явно стерео горизонтальное
                    }
                    
                    explicit_layout = layout_mapping.get(camera_type_ui.lower(), SplitMode.MONO)
                    
                    # ВАЖНО: Устанавливаем layout в video_processor
                    video_processor.selected_layout = explicit_layout  # Прямое присвоение
                    video_processor.camera_type = camera_type_ui
                    
                    print(f"🎬 Setting layout to: {explicit_layout} for camera type: {camera_type_ui}")

                    # Очистка старых масок и кадров
                    try:
                        for folder, ext in [(MASKS_DIR, '.png'), (FRAMES_DIR, ('.jpg','.png'))]:
                            if os.path.exists(folder):
                                for f in os.listdir(folder):
                                    if f.endswith(ext):
                                        os.remove(os.path.join(folder, f))
                    except Exception as e:
                        print(f"⚠️ Ошибка при удалении старых файлов: {str(e)}")

                    # Извлечение кадров с учетом типа камеры
                    result = video_processor.extract_frames_by_camera_type(
                        video_path, camera_type_ui, fps=1, layout=explicit_layout
                    )
                    
                    if video_processor.get_frame_count() > 0:
                        num_frames = video_processor.get_frame_count()
                        new_trigger = current_trigger + 1
                        print(f"✅ Extracted {num_frames} frames using {explicit_layout}, triggering refresh (trigger: {new_trigger})")
                        return (f"{result}. Извлечено {num_frames} кадров ({camera_type_ui} камера, режим: {explicit_layout.value}). "
                                f"Теперь можно перейти к другим разделам."), video_path, new_trigger
                    return "Ошибка: Не удалось извлечь кадры", "", current_trigger

                extract_button.click(
                    fn=extract_frames,
                    inputs=[video_input, camera_type, refresh_trigger],
                    outputs=[status, video_path_state, refresh_trigger]
                )

            # ЕДИНСТВЕННЫЙ Segmentation UI (убираем дубликат!)
            with gr.Group(visible=False) as segment_ui:
                # Передаем refresh_trigger в segmentation UI
                seg_components = create_segmentation_ui(refresh_trigger)

            # 3D Reconstruction UI
            with gr.Group(visible=False) as slam_ui:
                create_slam_ui()

            # Processed Video UI
            video_process_ui, run_quad_btn, quad_status, quad_video_display, run_quad_wrapper = create_video_ui()
            video_process_ui.visible = False

            # Depth Overlay UI
            with gr.Group(visible=False) as depth_ui:
                create_depth_overlay_ui(video_path_state, camera_type_state)  # Передаём camera_type_state
            depth_ui.visible = False

            # EIS UI
            with gr.Group(visible=False) as eis_ui:
                create_eis_ui()
            eis_ui.visible = False

    # Функции переключения вкладок
    def show_video(): return (gr.update(visible=True), gr.update(visible=False), gr.update(visible=False),
                              gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                              gr.update(variant="primary"), gr.update(variant="secondary"),
                              gr.update(variant="secondary"), gr.update(variant="secondary"),
                              gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_segment(): return (gr.update(visible=False), gr.update(visible=True), gr.update(visible=False),
                                gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                                gr.update(variant="secondary"), gr.update(variant="primary"),
                                gr.update(variant="secondary"), gr.update(variant="secondary"),
                                gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_slam(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=True),
                             gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                             gr.update(variant="secondary"), gr.update(variant="secondary"),
                             gr.update(variant="primary"), gr.update(variant="secondary"),
                             gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_process(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                                gr.update(visible=True), gr.update(visible=False), gr.update(visible=False),
                                gr.update(variant="secondary"), gr.update(variant="secondary"),
                                gr.update(variant="secondary"), gr.update(variant="primary"),
                                gr.update(variant="secondary"), gr.update(variant="secondary"))

    def show_depth(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                              gr.update(visible=False), gr.update(visible=True), gr.update(visible=False),
                              gr.update(variant="secondary"), gr.update(variant="secondary"),
                              gr.update(variant="secondary"), gr.update(variant="secondary"),
                              gr.update(variant="primary"), gr.update(variant="secondary"))

    def show_eis(): return (gr.update(visible=False), gr.update(visible=False), gr.update(visible=False),
                            gr.update(visible=False), gr.update(visible=False), gr.update(visible=True),
                            gr.update(variant="secondary"), gr.update(variant="secondary"),
                            gr.update(variant="secondary"), gr.update(variant="secondary"),
                            gr.update(variant="secondary"), gr.update(variant="primary"))

    # Button handlers
    video_button.click(fn=show_video, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                               video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    segment_button.click(fn=show_segment, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                                   video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    reconstruct_button.click(fn=show_slam, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                                    video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    process_button.click(fn=show_process, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                                  video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    depth_button.click(fn=show_depth, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                               video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    eis_button.click(fn=show_eis, outputs=[video_ui, segment_ui, slam_ui, video_process_ui, depth_ui, eis_ui,
                                           video_button, segment_button, reconstruct_button, process_button, depth_button, eis_button])

    # Wiring run_quad_btn
    # Make sure video_path_state has a valid value before calling run_quad_wrapper
    def handle_quad_processing(video_path_state_value):
        if not video_path_state_value:
            return "❌ Пожалуйста, сначала загрузите видео и извлеките кадры", None
        
        try:
            # Убеждаемся что у video_processor есть корректный layout
            current_layout = video_processor.get_selected_layout()
            current_camera_type = getattr(video_processor, 'camera_type', 'Моно')
            
            print(f"🎥 Processing video with layout: {current_layout} (camera type: {current_camera_type})")
            
            svc = QuadVideoService(
                output_dir=OUTPUT_DIR,
                ultralytics_dir=ULTRALYTICS_DIR,
                video_processor=video_processor
            )
            out_path = svc.process_video_quad(
                input_video_path=video_path_state_value,
                output_name=f"quad_video_{current_layout.value}.mp4",
                fps=None,
                progress_cb=None,                
            )
            return f"✅ Видео обработано в режиме {current_layout.value}!", out_path
        except Exception as e:
            import traceback
            traceback.print_exc()
            return f"❌ Ошибка: {str(e)}", None
        

    def set_camera_type(ct):
        video_processor.camera_type = ct
        return ct

    camera_type.change(
        fn=set_camera_type,
        inputs=camera_type,
        outputs=camera_type_state
    )

    run_quad_btn.click(
        fn=handle_quad_processing,
        inputs=[video_path_state], 
        outputs=[quad_status, quad_video_display]
    )

def main():
    app = FastAPI()
    # API роутеры
    app.include_router(segmentation_router, prefix="/api/segmentation")
    app.include_router(slam_router, prefix="/api/slam")
    app.include_router(video_router, prefix="/api/video")
    app.include_router(depth_overlay_router, prefix="/api/depth-overlay")
    app.include_router(eis_router, prefix="/api/eis")
    # Монтируем Gradio
    app = gr.mount_gradio_app(
        app, 
        demo, 
        path="//", 
        max_file_size="4096MB",
    )
    return app

app = main()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=7860, reload=True)
