import os
import sys
from typing import Callable, Any, Optional

def find_project_root(start_dir, marker="requirements.txt"):
    d = start_dir
    while d != os.path.dirname(d):
        if os.path.isfile(os.path.join(d, marker)):
            return d
        d = os.path.dirname(d)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import cv2
from PIL import Image
import torch
import numpy as np
import open3d as o3d
from transformers import AutoImageProcessor, DepthAnythingForDepthEstimation
from app.modules.slam.sfm_reconstruction import SFMReconstruction
from app.core.ffmpeg_utils import extract_frames
from app.modules.slam.pointcloud_fusion import PointcloudFusion
from app.core.config import (
    SFM_DIR,
    POINTS_CLOUD_SFM_DIR,
    MESH_SFM_DIR,
    TRAJECTORY_SFM_DIR,
)
# Default segmentation fallback
from app.modules.segmentation.inference import run_inference as seg_run


class VDASLAMService:
    def __init__(
            self,
            model_name: str = "depth-anything/Depth-Anything-V2-Small-hf",
            slam_dir: str | None = None,
            fps: int = 10,
            device: str | None = None,
            target_max_depth_m: float = 12.0,
            fov_deg: float = 60.0,
            align_frames: bool = True,
            invert_depth: bool = False,
    ):
        self.slam_dir = slam_dir or SFM_DIR
        os.makedirs(self.slam_dir, exist_ok=True)
        os.makedirs(POINTS_CLOUD_SFM_DIR, exist_ok=True)
        os.makedirs(MESH_SFM_DIR, exist_ok=True)
        os.makedirs(TRAJECTORY_SFM_DIR, exist_ok=True)

        self.fps = int(fps)
        self.device = self._select_device_safely(device)
        self.target_max_depth_m = float(target_max_depth_m)
        self.fov_deg = float(fov_deg)
        self.align_frames = bool(align_frames)
        self.invert_depth = bool(invert_depth)

        # Auto-select model based on available memory
        model_name = self._select_model_by_memory(model_name)
        print(f"🔧 Using model: {model_name} on device: {self.device}")

        # Clear GPU memory before loading
        if self.device == "cuda":
            torch.cuda.empty_cache()

        try:
            self.processor = AutoImageProcessor.from_pretrained(model_name)
            self.model = DepthAnythingForDepthEstimation.from_pretrained(model_name).to(self.device)
        except torch.cuda.OutOfMemoryError:
            print("🔧 GPU OOM, falling back to CPU")
            self.device = "cpu"
            self.model = DepthAnythingForDepthEstimation.from_pretrained(model_name).to(self.device)

        # Initialize SLAM and fusion components
        self.slam = SFMReconstruction(
            results_dir=self.slam_dir,
            fov_deg=self.fov_deg,
            align_frames=self.align_frames,
            use_tsdf=True,
            voxel_length=0.02,
            sdf_trunc=0.04
        )

        self.fusion = PointcloudFusion(
            voxel_length=0.015,
            sdf_trunc=0.03,
            fov_deg=self.fov_deg,
            ground_every=5,
            target_cam_height=1.6
        )

        self._scale_s = None
        self._offset_b = 0.0
        self.save_pointcloud_every = 25

    def _select_device_safely(self, device: str | None) -> str:
        """Safely select device with memory check"""
        if device is not None:
            return device
        if not torch.cuda.is_available():
            return "cpu"
        try:
            total_memory = torch.cuda.get_device_properties(0).total_memory
            allocated_memory = torch.cuda.memory_allocated(0)
            free_memory = total_memory - allocated_memory
            free_memory_gb = free_memory / (1024 ** 3)
            if free_memory_gb < 1.0:
                return "cpu"
            return "cuda"
        except Exception:
            return "cpu"

    def _select_model_by_memory(self, preferred_model: str) -> str:
        """Select model based on available memory"""
        if self.device == "cpu":
            return "depth-anything/Depth-Anything-V2-Small-hf"
        try:
            total_memory = torch.cuda.get_device_properties(0).total_memory
            free_memory_gb = (total_memory - torch.cuda.memory_allocated(0)) / (1024 ** 3)
            if free_memory_gb < 2.0:
                return "depth-anything/Depth-Anything-V2-Small-hf"
            elif free_memory_gb < 4.0:
                return "depth-anything/Depth-Anything-V2-Base-hf"
            else:
                return preferred_model
        except Exception:
            return "depth-anything/Depth-Anything-V2-Small-hf"

    def _depth_to_meters(self, depth_raw) -> np.ndarray:
        """Convert raw depth to meters with proper scaling"""
        # Convert tensor to numpy if needed
        if isinstance(depth_raw, torch.Tensor):
            depth = depth_raw.detach().cpu().numpy()
        else:
            depth = depth_raw.copy()

        # Handle invalid values
        depth = np.nan_to_num(depth, nan=0.0, posinf=0.0, neginf=0.0)

        # Invert if needed (some models output inverted depth)
        if self.invert_depth:
            depth = np.max(depth) - depth

        # Normalize to [0, 1] range
        if depth.max() > depth.min():
            depth = (depth - depth.min()) / (depth.max() - depth.min())

        # Scale to target range
        depth_m = depth * self.target_max_depth_m

        # Apply adaptive scaling if available
        if self._scale_s is not None:
            depth_m = self._scale_s * depth_m + self._offset_b

        return depth_m.astype(np.float32)

    def _extract_road_mask(self, seg_result, frame_shape) -> Optional[np.ndarray]:
        """Extract road mask from segmentation result"""
        if seg_result is None:
            return None

        try:
            # Assume seg_result is a segmentation map with class IDs
            if isinstance(seg_result, np.ndarray):
                # Common road/ground class IDs in different segmentation models
                road_classes = [0, 1, 2, 6, 7, 8, 9, 11, 12, 13]  # road, sidewalk, parking, etc.
                mask = np.isin(seg_result, road_classes)

                # Ensure mask has correct shape
                if mask.shape != frame_shape[:2]:
                    mask = cv2.resize(mask.astype(np.uint8),
                                      (frame_shape[1], frame_shape[0]),
                                      interpolation=cv2.INTER_NEAREST).astype(bool)

                return mask.astype(np.uint8) * 255
        except Exception as e:
            print(f"⚠️ Error extracting road mask: {e}")

        return None

    def process_video(
            self,
            video_path: str,
            output_dir: str | None = None,
            seg_fn: Optional[Callable[[str], Any]] = None,
    ) -> str:
        """Process video with enhanced point cloud density"""
        run_name = os.path.splitext(os.path.basename(video_path))[0]
        base_out = output_dir or self.slam_dir
        os.makedirs(base_out, exist_ok=True)

        run_root = os.path.join(base_out, run_name)
        os.makedirs(run_root, exist_ok=True)
        frames_dir = os.path.join(run_root, "frames_temp")
        os.makedirs(frames_dir, exist_ok=True)

        # Extract frames
        extract_result = extract_frames(video_path, frames_dir, fps=self.fps)
        frame_files = sorted([
            os.path.join(frames_dir, f) for f in os.listdir(frames_dir)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ])

        if not frame_files:
            raise RuntimeError(f"Failed to extract frames: {extract_result}")

        print(f"🎬 Processing {len(frame_files)} frames at {self.fps} FPS")

        self.slam.reset()
        self.slam.set_total_frames(len(frame_files))
        self._scale_s, self._offset_b = None, 0.0

        for idx, frame_file in enumerate(frame_files):
            # Periodic memory cleanup
            if idx % 20 == 0 and self.device == "cuda":
                torch.cuda.empty_cache()

            frame = Image.open(frame_file).convert("RGB")
            frame_np = np.array(frame)

            # Process depth
            inputs = self.processor(images=frame, return_tensors="pt").to(self.device)

            with torch.no_grad():
                outputs = self.model(**inputs)

            post = self.processor.post_process_depth_estimation(
                outputs, target_sizes=[frame.size[::-1]]
            )
            depth_raw = post[0]["predicted_depth"]
            depth_m = self._depth_to_meters(depth_raw)

            # Segmentation (optional)
            seg_result = None
            if seg_fn is None:
                try:
                    seg_result = seg_run(frame_file, SFM_DIR)
                except Exception:
                    pass
            else:
                try:
                    seg_result = seg_fn(frame_file, SFM_DIR)
                except Exception:
                    pass

            road_mask = self._extract_road_mask(seg_result, frame_np.shape)

            # SLAM processing
            try:
                self.slam.process_frame(frame_np, depth_m)
            except Exception as e:
                print(f"⚠️ SLAM error at frame {idx}: {e}")

            # Fusion processing
            try:
                ground_applied, ground_info = self.fusion.estimate_and_apply_ground(
                    road_mask, depth_m, idx
                )
                self.fusion.integrate_frame(frame_np, depth_m, road_mask, idx)
            except Exception as e:
                print(f"⚠️ Fusion error at frame {idx}: {e}")

        # Finalize
        self.slam.finalize()

        # Extract results
        out_mesh = os.path.join(MESH_SFM_DIR, f"{run_name}_fusion_mesh.ply")
        out_pcd = os.path.join(POINTS_CLOUD_SFM_DIR, f"{run_name}_fusion_pointcloud.ply")

        try:
            self.fusion.extract_map(out_mesh, out_pcd)
        finally:
            # Cleanup temporary files
            import shutil
            shutil.rmtree(frames_dir, ignore_errors=True)

        return out_mesh if os.path.exists(out_mesh) else out_pcd
