import torch
import cv2
from moge.model.v2 import MoGeModel


class MoGe2Service:
    def __init__(self, device="cuda"):
        self.device = torch.device(device)
        # Загружаем MoGe2
        self.model = MoGeModel.from_pretrained("Ruicheng/moge-2-vitl-normal").to(self.device)
        self.model.eval()

    def run_inference(self, frame_files):
        """
        Прогоняем список кадров через MoGe2.
        Возвращает список словарей: depth, points, intrinsics
        """
        results = []
        with torch.no_grad():
            for frame_path in frame_files:
                frame = cv2.imread(frame_path)
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                # Нормализация и преобразование в тензор
                input_tensor = torch.tensor(
                    frame_rgb / 255.0,
                    dtype=torch.float32,
                    device=self.device
                ).permute(2, 0, 1).unsqueeze(0)

                # Запуск MoGe2
                output = self.model.infer(input_tensor)

                depth = output["depth"].cpu().numpy()[0]
                points = output["points"].cpu().numpy()[0]  # (H,W,3)
                intrinsics = output["intrinsics"].cpu().numpy()

                results.append({
                    "depth": depth,
                    "points": points,
                    "intrinsics": intrinsics
                })

        return results

    def extract_point_clouds(self, results):
        """
        Достаёт только облака точек (H,W,3) → список
        """
        pcs = []
        for r in results:
            pcs.append(r["points"])
        return pcs
