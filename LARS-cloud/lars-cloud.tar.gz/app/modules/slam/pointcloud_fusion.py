import os
import numpy as np
import cv2
import open3d as o3d
from typing import Optional, Tuple, Dict

def fx_from_fov(width: int, fov_deg: float) -> float:
    fov = np.deg2rad(fov_deg)
    return 0.5 * width / np.tan(0.5 * fov)

def estimate_intrinsics_from_fov(w: int, h: int, fov_deg: float):
    fx = fy = fx_from_fov(w, fov_deg)
    cx = w / 2.0
    cy = h / 2.0
    intr = o3d.camera.PinholeCameraIntrinsic(int(w), int(h), float(fx), float(fy), float(cx), float(cy))
    return intr, fx, fy, cx, cy

def backproject(depth_m: np.ndarray, fx: float, fy: float, cx: float, cy: float, mask: Optional[np.ndarray]=None):
    """
    Возвращает Nx3 точки в системе координат камеры из depth (в метрах).
    mask: бинарная маска 0/255. Если mask=None — используем все валидные depth>0.
    """
    h, w = depth_m.shape
    valid = (depth_m > 0)
    if mask is not None:
        # гарантируем одинаковый размер и бинаризацию
        if mask.shape != depth_m.shape:
            mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
        valid &= (mask > 0)
    ys, xs = np.where(valid)
    if xs.size == 0:
        return np.zeros((0,3), dtype=np.float32)
    z = depth_m[ys, xs]
    x = (xs - cx) * z / fx
    y = (ys - cy) * z / fy
    return np.stack([x, y, z], axis=1).astype(np.float32)

def fit_plane_ransac(pts: np.ndarray, thresh=0.03, max_iters=400, min_inliers=400):
    """
    RANSAC для плоскости n^T x + d = 0.
    Возвращает (n, d, inliers_idx) или (None, None, None).
    """
    if pts.shape[0] < 50:
        return None, None, None
    rng = np.random.default_rng(0)
    best = None
    best_count = 0
    for _ in range(max_iters):
        idx = rng.choice(pts.shape[0], size=3, replace=False)
        p0, p1, p2 = pts[idx]
        n = np.cross(p1 - p0, p2 - p0)
        n_norm = np.linalg.norm(n)
        if n_norm < 1e-6:
            continue
        n = n / n_norm
        d = -np.dot(n, p0)
        dist = np.abs(pts @ n + d)
        inliers = np.where(dist < thresh)[0]
        if inliers.size > best_count:
            best_count = inliers.size
            best = (n.copy(), float(d), inliers)
    if best is None or best_count < min_inliers:
        return None, None, None
    # уточним по SVD на инлайнерах
    P = pts[best[2]]
    centroid = P.mean(axis=0)
    _, _, Vt = np.linalg.svd(P - centroid)
    n_ref = Vt[-1]
    n_ref = n_ref / (np.linalg.norm(n_ref) + 1e-12)
    d_ref = -n_ref.dot(centroid)
    return n_ref.astype(np.float32), float(d_ref), best[2]

def rotation_from_a_to_b(a: np.ndarray, b: np.ndarray):
    """
    Минимальный поворот, переводящий единичный вектор a в b.
    Возвращает матрицу 3x3.
    """
    a = a / (np.linalg.norm(a)+1e-12); b = b / (np.linalg.norm(b)+1e-12)
    v = np.cross(a,b); c = np.dot(a,b)
    if np.linalg.norm(v) < 1e-9:
        return np.eye(3)
    vx = np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
    R = np.eye(3) + vx + vx @ vx * (1.0/(1.0+c+1e-12))
    return R

class Sim3EMA:
    """
    Очень простая EMA для параметров Sim(3): scale, rotation, translation.
    """
    def __init__(self, alpha_scale=0.15, alpha_trans=0.15):
        self.s = 1.0
        self.R = np.eye(3)
        self.t = np.zeros(3)
        self.alpha_scale = alpha_scale
        self.alpha_trans = alpha_trans
        self.inited = False

    def update(self, s_new: float, R_new: np.ndarray, t_new: np.ndarray):
        if not self.inited:
            self.s = float(s_new)
            self.R = R_new.copy()
            self.t = t_new.copy()
            self.inited = True
            return self.s, self.R, self.t
        # интерполяция масштаба и трансляции
        self.s = (1.0 - self.alpha_scale) * self.s + self.alpha_scale * float(s_new)
        self.t = (1.0 - self.alpha_trans) * self.t + self.alpha_trans * t_new
        # простая коррекция ротации: корректируем преимущественно Z-ось
        self.R = rotation_from_a_to_b(self.R[:,2], (self.R @ R_new.T)[:,2]) @ self.R
        return self.s, self.R, self.t

def build_sim3_align_to_ground(n: np.ndarray, d: float, target_height: float = 1.6) -> Tuple[float, np.ndarray, np.ndarray]:
    """
    Строит Sim(3) (s, R, t), чтобы:
      - нормаль n выровнялась с +Z,
      - плоскость n^T x + d = 0 оказалась близко к Z=0,
      - масштаб s подогнан так, чтобы расстояние камеры->плоскость соответствовало target_height (если возможно).
    Возвращает (s, R, t) где t подобран так, что точка на плоскости X0 = -d*n после X' = s R X0 + t имеет z'=0.
    """
    # нормализуем n
    n = n / (np.linalg.norm(n) + 1e-12)
    up = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    R = rotation_from_a_to_b(n, up)  # поворот, отправляющий n в +Z

    # опорная точка на плоскости (перпендикуляр от камеры)
    X0 = -d * n  # в системе камеры
    # поворачиваем точку
    X0p = R @ X0
    # текущая дистанция вдоль Z' до плоскости (может быть отрицательной)
    dist_z = X0p[2]  # если положительна, означает плоскость под камерой по +Z
    if abs(dist_z) < 1e-6:
        s = 1.0
    else:
        s = float(target_height / abs(dist_z)) if target_height is not None else 1.0

    # хотим t_z так, чтобы s * X0p[2] + t_z = 0 -> t_z = -s * X0p[2]
    t_z = -s * X0p[2]
    t = np.array([0.0, 0.0, t_z], dtype=np.float32)

    return s, R.astype(np.float32), t

class PointcloudFusion:
    def __init__(self, voxel_length=0.015, sdf_trunc=0.03, fov_deg=60.0, ground_every:int = 5, target_cam_height: float = 1.6):
        self.voxel_length = float(voxel_length)
        self.sdf_trunc = float(sdf_trunc)
        self.fov_deg = float(fov_deg)
        self.tsdf = o3d.pipelines.integration.ScalableTSDFVolume(
            voxel_length=voxel_length,
            sdf_trunc=sdf_trunc,
            color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8,
        )
        self.intrinsic: Optional[o3d.camera.PinholeCameraIntrinsic] = None
        self.fx = self.fy = self.cx = self.cy = None
        self.prev_rgbd = None
        self.T_w_c = np.eye(4)        # world <- cam transform (world = cam_0 after sim3)
        self.sim3 = Sim3EMA()
        self.ground_every = int(ground_every)
        self.target_cam_height = float(target_cam_height)
        # для логов/отладки
        self.last_ground_info: Optional[Dict] = None

    def ensure_intrinsic(self, w:int, h:int):
        if self.intrinsic is None:
            intr, fx, fy, cx, cy = estimate_intrinsics_from_fov(w, h, self.fov_deg)
            self.intrinsic = intr
            self.fx, self.fy, self.cx, self.cy = fx, fy, cx, cy

    def estimate_and_apply_ground(self, road_mask: Optional[np.ndarray], depth_m: np.ndarray, frame_idx:int) -> Tuple[bool, Optional[Dict]]:
        """
        Попытка оценить плоскость дороги и обновить Sim(3) (self.T_w_c) через EMA.
        Возвращает (applied: bool, info: dict|None)
        info содержит: n, d, s, (R,t) и число инлайнов для диагностики.
        """
        # Условия: есть маска и периодичность
        if road_mask is None:
            return False, None
        if frame_idx % self.ground_every != 0:
            return False, None

        h, w = depth_m.shape[:2]
        self.ensure_intrinsic(w, h)

        pts = backproject(depth_m, self.fx, self.fy, self.cx, self.cy, mask=road_mask)
        if pts.shape[0] < 200:
            return False, None

        n, d, inliers = fit_plane_ransac(pts, thresh=0.04, max_iters=400, min_inliers=300)
        if n is None:
            return False, None

        # Гарантируем, что нормаль направлена вверх (z>0 в мировой системе после поворота)
        if n[2] < 0:
            n = -n
            d = -d

        # Строим candidate Sim3
        s, R, t = build_sim3_align_to_ground(n, d, target_height=self.target_cam_height)

        # Обновляем EMA и применяем
        s_e, R_e, t_e = self.sim3.update(s, R, t)

        # Формируем матрицу Sim(3) как 4x4 (X_world = s_e * R_e * X_cam + t_e)
        T = np.eye(4, dtype=np.float64)
        T[:3, :3] = (s_e * R_e).astype(np.float64)
        T[:3, 3] = t_e.astype(np.float64)

        # ВАЖНО: мы **не** компонуем с предыдущими T_w_c: тут логика — фиксируем карту в системе, где плоскость лежит в Z=0.
        # Если ты предпочитаешь накапливать корректирующие трансформации — можно сделать: self.T_w_c = T @ self.T_w_c
        self.T_w_c = T

        info = {
            "frame_idx": int(frame_idx),
            "n": n.tolist(),
            "d": float(d),
            "inliers": int(inliers.shape[0]) if inliers is not None else 0,
            "s": float(s_e),
            "t": t_e.tolist(),
        }
        self.last_ground_info = info
        return True, info

    def integrate_frame(self, rgb_np: np.ndarray, depth_m: np.ndarray, keep_mask: Optional[np.ndarray], frame_idx:int = -1):
        """
        Интегрируем кадр в текущий TSDF, применяя текущую self.T_w_c как world<-cam (Open3D ожидает extrinsic world_to_cam).
        """
        h, w = depth_m.shape[:2]
        self.ensure_intrinsic(w, h)

        # Подготовка RGBD для Open3D
        color_o3d = o3d.geometry.Image(rgb_np.astype(np.uint8))
        depth_o3d = o3d.geometry.Image(depth_m.astype(np.float32))
        rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
            color_o3d, depth_o3d, depth_scale=1.0, depth_trunc=50.0, convert_rgb_to_intensity=False
        )

        # Open3D TSDF.integrate ожидает extrinsic_w2c (4x4 матрицу world -> camera)
        extrinsic_w2c = np.linalg.inv(self.T_w_c)
        self.tsdf.integrate(rgbd, self.intrinsic, extrinsic_w2c)

    def extract_map(self, out_mesh_path: str, out_pcd_path: str):
        mesh = self.tsdf.extract_triangle_mesh()
        mesh.compute_vertex_normals()
        os.makedirs(os.path.dirname(out_mesh_path) or ".", exist_ok=True)
        os.makedirs(os.path.dirname(out_pcd_path) or ".", exist_ok=True)
        o3d.io.write_triangle_mesh(out_mesh_path, mesh)
        pcd = self.tsdf.extract_point_cloud()
        o3d.io.write_point_cloud(out_pcd_path, pcd)
        return out_mesh_path, out_pcd_path
