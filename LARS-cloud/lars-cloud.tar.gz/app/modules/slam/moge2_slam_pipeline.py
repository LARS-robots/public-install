import os
import sys
import tempfile
import subprocess
import shutil
from typing import Generator, Optional, Tuple
import numpy as np
import cv2
import open3d as o3d
import traceback
import gc

from app.modules.slam.moge2_service import MoGe2Service
from app.core.config import SFM_DIR

# ----------------------
# Find project root
# ----------------------
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# ----------------------
# Очистка прошлых результатов
# ----------------------
def _safe_clear_dir(dir_path, exts=(".ply", ".glb")):
    if not os.path.isdir(dir_path):
        return
    for root, _, files in os.walk(dir_path):
        for f in files:
            if f.lower().endswith(exts):
                try:
                    os.remove(os.path.join(root, f))
                except Exception as e:
                    print(f"⚠️ Cannot remove {f}: {e}")

def _prepare_clean_environment():
    os.makedirs(SFM_DIR, exist_ok=True)
    _safe_clear_dir(SFM_DIR)

# ----------------------
# Трансформация точек MoGe2 в мировую систему
# ----------------------
def transform_points_to_world(points, pose_matrix):
    H, W, _ = points.shape
    # sanitize points
    points = np.nan_to_num(points, nan=0.0, posinf=0.0, neginf=0.0)
    pts_h = np.concatenate(
        [points.reshape(-1,3).astype(np.float32), np.ones((H*W,1), dtype=np.float32)],
        axis=1
    )
    if not np.all(np.isfinite(pose_matrix)):
        print("⚠️ Pose matrix invalid (NaN/Inf), skipping transform.")
        return np.zeros((H*W, 3), dtype=np.float32)
    pts_world = (pose_matrix @ pts_h.T).T[:, :3]
    return pts_world


def safe_intrinsics(K, w, h):
    """
    Ensure K is 3x3 intrinsic matrix and scale if normalized
    """
    if K is None:
        return o3d.camera.PinholeCameraIntrinsic(w, h, w*0.7, h*0.7, w/2, h/2)

    K = np.array(K)

    # Flatten 3D arrays
    if K.ndim == 3:
        K = K[:, :, 0]

    # Flat array of size 9
    if K.ndim == 1 and K.size == 9:
        K = K.reshape(3, 3)

    # Row or column vector? fallback to identity
    if K.shape == (1, 3) or K.shape == (3, 1) or K.shape != (3, 3):
        K = np.eye(3, dtype=np.float32)

    # Scale normalized intrinsics if needed
    if K[0, 0] < 10:  # likely normalized
        K[0, :] *= w
        K[1, :] *= h

    return K


# ----------------------
# Главная функция пайплайна с Python SLAM
# ----------------------
def run_moge2_python_slam(video_path: str, downsample_voxel: float = 0.01,
                          max_frames: int = 100, fps: int = 2) -> Generator[str, None, str]:
    """
    MoGe-2 SLAM pipeline with improved stability:
    - transform validation
    - point sanitization
    - STREAMING voxel-grid merge with periodic yields (prevents disconnects)
    """
    _prepare_clean_environment()
    yield "🎬 Starting MoGe-2 SLAM pipeline..."

    tmp_dir = tempfile.mkdtemp(prefix="frames_")
    try:
        # --- Extract frames ---
        yield "📹 Extracting frames..."
        cmd = f"ffmpeg -i {video_path} -vf fps={fps} -frames:v {max_frames} {tmp_dir}/frame_%05d.png"
        result = subprocess.run(cmd.split(), capture_output=True, timeout=60)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg failed: {result.stderr.decode()}")
        frame_files = sorted([os.path.join(tmp_dir, f) for f in os.listdir(tmp_dir) if f.endswith(".png")])
        if not frame_files:
            raise RuntimeError("❌ No frames extracted")
        if len(frame_files) > max_frames:
            frame_files = frame_files[:max_frames]
        yield f"✅ Extracted {len(frame_files)} frames"

        # --- Init model ---
        yield "🤖 Initializing MoGe-2 model..."
        moge_service = MoGe2Service(device='cuda')

        # Base camera intrinsics
        first_img = cv2.imread(frame_files[0])
        h, w = first_img.shape[:2]
        intrinsic = o3d.camera.PinholeCameraIntrinsic(width=w, height=h, fx=w*0.7, fy=h*0.7, cx=w/2, cy=h/2)

        # State
        camera_pose = np.eye(4, dtype=np.float64)
        MAX_POINTS_PER_CHUNK = 500_000
        SAVE_INTERVAL = 20
        current_points, saved_chunks = [], []

        # --- First frame ---
        prev_result = moge_service.run_inference([frame_files[0]])[0]
        prev_depth = prev_result["depth"]
        if prev_depth is None or not np.any(np.isfinite(prev_depth)):
            raise RuntimeError("❌ Invalid depth for first frame")
        prev_rgb = cv2.cvtColor(first_img, cv2.COLOR_BGR2RGB)
        prev_depth_resized = cv2.resize(prev_depth, (w, h))
        prev_rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
            o3d.geometry.Image(prev_rgb),
            o3d.geometry.Image(prev_depth_resized.astype(np.float32)),
            depth_scale=1.0, depth_trunc=50.0
        )

        total_frames = len(frame_files) - 1
        processed_count = 0
        color_jacobian = o3d.pipelines.odometry.RGBDOdometryJacobianFromColorTerm()
        odo_option = o3d.pipelines.odometry.OdometryOption()

        # --- Process frames ---
        for i, frame_file in enumerate(frame_files[1:], 1):
            try:
                curr_bgr = cv2.imread(frame_file)
                if curr_bgr is None:
                    yield f"⚠️ Skipping unreadable frame {i}"
                    continue
                curr_rgb = cv2.cvtColor(curr_bgr, cv2.COLOR_BGR2RGB)

                curr_result = moge_service.run_inference([frame_file])[0]
                curr_depth = curr_result["depth"]
                if curr_depth is None or not np.any(np.isfinite(curr_depth)):
                    yield f"⚠️ Skipping frame {i} due to invalid depth"
                    continue

                curr_depth_resized = cv2.resize(curr_depth, (w, h))
                curr_rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
                    o3d.geometry.Image(curr_rgb),
                    o3d.geometry.Image(curr_depth_resized.astype(np.float32)),
                    depth_scale=1.0, depth_trunc=50.0
                )

                # Update intrinsics if provided
                if "intrinsics" in curr_result and curr_result["intrinsics"] is not None:
                    K = safe_intrinsics(curr_result["intrinsics"], w, h)
                    intrinsic.set_intrinsics(w, h, float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

                # --- Odometry ---
                odo_init = np.eye(4, dtype=np.float64)
                odo_res = o3d.pipelines.odometry.compute_rgbd_odometry(
                    curr_rgbd, prev_rgbd, intrinsic, odo_init, color_jacobian, odo_option
                )
                success, trans = False, None
                if hasattr(odo_res, "success"):
                    success, trans = odo_res.success, np.asarray(odo_res.transformation)
                elif isinstance(odo_res, tuple) and len(odo_res) >= 2:
                    success, trans = odo_res[0], np.asarray(odo_res[1])

                if success and trans is not None and np.all(np.isfinite(trans)):
                    det = np.linalg.det(trans[:3, :3])
                    if 0.1 < det < 10:  # sanity check
                        camera_pose = camera_pose @ trans
                    else:
                        yield f"⚠️ Skipping frame {i} due to invalid transform det={det:.4f}"
                        prev_rgbd = curr_rgbd
                        continue
                else:
                    yield f"⚠️ Odometry failed for frame {i}"
                    prev_rgbd = curr_rgbd
                    continue

                # --- Point cloud ---
                pcd = o3d.geometry.PointCloud.create_from_rgbd_image(curr_rgbd, intrinsic)
                pcd.transform(camera_pose)  # apply global pose

                # Downsample + sanitize
                if not pcd.is_empty():
                    if downsample_voxel > 0:
                        pcd = pcd.voxel_down_sample(downsample_voxel)
                    pts = np.asarray(pcd.points)
                    if pts.size > 0:
                        pts = pts[np.isfinite(pts).all(axis=1)]
                        if pts.size > 0:
                            current_points.append(pts)

                # Save chunks
                total_current_points = sum(len(pts) for pts in current_points)
                if total_current_points > MAX_POINTS_PER_CHUNK or (i % SAVE_INTERVAL == 0):
                    if current_points:
                        chunk_points = np.vstack(current_points)
                        chunk_pcd = o3d.geometry.PointCloud()
                        chunk_pcd.points = o3d.utility.Vector3dVector(chunk_points)
                        chunk_path = os.path.join(SFM_DIR, f"chunk_{len(saved_chunks):03d}.ply")
                        o3d.io.write_point_cloud(chunk_path, chunk_pcd)  # binary by default
                        saved_chunks.append(chunk_path)
                        current_points = []
                        del chunk_pcd, chunk_points
                        gc.collect()

                # Advance
                prev_rgbd = curr_rgbd
                processed_count += 1
                if i % 5 == 0 or i == total_frames:
                    yield f"🔄 Processed {processed_count}/{total_frames} frames | Chunks: {len(saved_chunks)}"

            except Exception as e:
                yield f"⚠️ Frame {i} failed: {str(e)}"
                continue

        # --- Finalize last chunk ---
        if current_points:
            chunk_points = np.vstack(current_points)
            chunk_pcd = o3d.geometry.PointCloud()
            chunk_pcd.points = o3d.utility.Vector3dVector(chunk_points)
            chunk_path = os.path.join(SFM_DIR, f"chunk_{len(saved_chunks):03d}.ply")
            o3d.io.write_point_cloud(chunk_path, chunk_pcd)
            saved_chunks.append(chunk_path)
            del chunk_pcd, chunk_points
            current_points = []
            gc.collect()

        # --------------------------
        # STREAMING MERGE (incremental voxel grid)
        # --------------------------
        if not saved_chunks:
            return "❌ No chunks to merge"

        yield f"🔗 Merging {len(saved_chunks)} chunks (streaming voxel merge)..."

        MERGE_VOXEL = max(downsample_voxel, 0.02)  # coarser voxel for merge = fewer points, faster & lighter
        FLUSH_UNIQUE_VOXELS = 1_000_000           # flush aggregator at ~1M unique voxels
        TEMP_MERGE_PARTS = []
        agg = {}  # (ix,iy,iz) -> [sumx,sumy,sumz,count]

        def flush_aggregator(part_idx: int):
            if not agg:
                return None
            centers = np.empty((len(agg), 3), dtype=np.float32)
            for k_idx, ((ix, iy, iz), acc) in enumerate(agg.items()):
                sx, sy, sz, c = acc
                centers[k_idx, :] = (sx / c, sy / c, sz / c)
            p = o3d.geometry.PointCloud()
            p.points = o3d.utility.Vector3dVector(centers)
            out_path = os.path.join(SFM_DIR, f"merge_part_{part_idx:03d}.ply")
            o3d.io.write_point_cloud(out_path, p)
            return out_path

        # Pass 1: read chunk -> aggregate into voxels with periodic yields & flushes
        for idx, chunk_path in enumerate(saved_chunks, 1):
            try:
                chunk = o3d.io.read_point_cloud(chunk_path)
                pts = np.asarray(chunk.points)
                if pts.size == 0:
                    yield f"ℹ️ Merging {idx}/{len(saved_chunks)}: empty chunk"
                    continue
                pts = pts[np.isfinite(pts).all(axis=1)]
                if pts.size == 0:
                    yield f"ℹ️ Merging {idx}/{len(saved_chunks)}: no finite points"
                    continue

                # Quantize to voxels
                vox = np.floor(pts / MERGE_VOXEL).astype(np.int64)

                # Unique voxel IDs within this chunk + sums per voxel (vectorized)
                vox_struct = vox.view([('x', np.int64), ('y', np.int64), ('z', np.int64)]).reshape(-1)
                uniq, inv = np.unique(vox_struct, return_inverse=True)
                counts = np.bincount(inv)
                sumx = np.bincount(inv, weights=pts[:, 0])
                sumy = np.bincount(inv, weights=pts[:, 1])
                sumz = np.bincount(inv, weights=pts[:, 2])

                # Update global aggregator (loop over unique voxels only)
                ux, uy, uz = uniq['x'], uniq['y'], uniq['z']
                for j in range(len(uniq)):
                    key = (int(ux[j]), int(uy[j]), int(uz[j]))
                    acc = agg.get(key)
                    if acc is None:
                        agg[key] = [float(sumx[j]), float(sumy[j]), float(sumz[j]), int(counts[j])]
                    else:
                        acc[0] += float(sumx[j]); acc[1] += float(sumy[j]); acc[2] += float(sumz[j]); acc[3] += int(counts[j])

                # Periodic progress + conditional flush
                if idx % 2 == 0:
                    yield f"🧪 Merging {idx}/{len(saved_chunks)} | aggregator voxels: {len(agg):,}"

                if len(agg) >= FLUSH_UNIQUE_VOXELS:
                    part_path = flush_aggregator(len(TEMP_MERGE_PARTS))
                    TEMP_MERGE_PARTS.append(part_path)
                    agg.clear()
                    gc.collect()
                    yield f"🗂️ Flushed aggregator to {part_path} | parts={len(TEMP_MERGE_PARTS)}"

            except Exception as me:
                yield f"⚠️ Merge warning on {chunk_path}: {me}"

        # Flush remainder
        if agg:
            part_path = flush_aggregator(len(TEMP_MERGE_PARTS))
            TEMP_MERGE_PARTS.append(part_path)
            agg.clear()
            gc.collect()
            yield f"🗂️ Flushed final aggregator part | parts={len(TEMP_MERGE_PARTS)}"

        # Cleanup chunk files early to free space
        for pth in saved_chunks:
            try:
                os.remove(pth)
            except:
                pass
        saved_chunks = []

        # Pass 2: combine merge parts (usually already small) with another light aggregator
        yield "🧮 Finalizing merged cloud..."
        agg2 = {}
        for i, part in enumerate(TEMP_MERGE_PARTS, 1):
            try:
                pc = o3d.io.read_point_cloud(part)
                pts = np.asarray(pc.points)
                if pts.size == 0:
                    yield f"ℹ️ Final pass {i}/{len(TEMP_MERGE_PARTS)}: empty part"
                    continue
                pts = pts[np.isfinite(pts).all(axis=1)]
                if pts.size == 0:
                    yield f"ℹ️ Final pass {i}/{len(TEMP_MERGE_PARTS)}: no finite points"
                    continue

                vox = np.floor(pts / MERGE_VOXEL).astype(np.int64)
                vox_struct = vox.view([('x', np.int64), ('y', np.int64), ('z', np.int64)]).reshape(-1)
                uniq, inv = np.unique(vox_struct, return_inverse=True)
                counts = np.bincount(inv)
                sumx = np.bincount(inv, weights=pts[:, 0])
                sumy = np.bincount(inv, weights=pts[:, 1])
                sumz = np.bincount(inv, weights=pts[:, 2])

                ux, uy, uz = uniq['x'], uniq['y'], uniq['z']
                for j in range(len(uniq)):
                    key = (int(ux[j]), int(uy[j]), int(uz[j]))
                    acc = agg2.get(key)
                    if acc is None:
                        agg2[key] = [float(sumx[j]), float(sumy[j]), float(sumz[j]), int(counts[j])]
                    else:
                        acc[0] += float(sumx[j]); acc[1] += float(sumy[j]); acc[2] += float(sumz[j]); acc[3] += int(counts[j])

                if i % 2 == 0:
                    yield f"🔁 Final pass {i}/{len(TEMP_MERGE_PARTS)} | voxels: {len(agg2):,}"

            except Exception as e2:
                yield f"⚠️ Final merge warning on {part}: {e2}"

        # Convert agg2 to final point cloud
        if not agg2:
            return "❌ Final cloud empty"

        final_centers = np.empty((len(agg2), 3), dtype=np.float32)
        for k_idx, ((ix, iy, iz), acc) in enumerate(agg2.items()):
            sx, sy, sz, c = acc
            final_centers[k_idx, :] = (sx / c, sy / c, sz / c)
        final_pcd = o3d.geometry.PointCloud()
        final_pcd.points = o3d.utility.Vector3dVector(final_centers)

        # Optional: very light outlier removal only if reasonably small
        if len(final_centers) < 2_000_000:
            try:
                final_pcd, _ = final_pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
            except Exception:
                pass

        # Optional: final light downsample
        if downsample_voxel > 0:
            try:
                final_pcd = final_pcd.voxel_down_sample(downsample_voxel)
            except Exception:
                pass

        final_path = os.path.join(SFM_DIR, "final_pointcloud.ply")
        o3d.io.write_point_cloud(final_path, final_pcd)

        # Cleanup temp parts
        for part in TEMP_MERGE_PARTS:
            try:
                os.remove(part)
            except:
                pass

        yield f"✅ Success! {len(final_pcd.points):,} points -> {final_path}"
        return final_path

    except Exception as e:
        return f"❌ Pipeline failed: {str(e)}"
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
