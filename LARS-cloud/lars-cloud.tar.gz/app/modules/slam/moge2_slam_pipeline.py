import os
import sys
import tempfile
import subprocess
import shutil
from typing import Generator, Optional, Tuple
import numpy as np
import cv2
import open3d as o3d
import traceback
import gc

from app.modules.slam.moge2_service import MoGe2Service
from app.core.config import SFM_DIR

# ----------------------
# Find project root
# ----------------------
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# ----------------------
# Очистка прошлых результатов
# ----------------------
def _safe_clear_dir(dir_path, exts=(".ply", ".glb")):
    if not os.path.isdir(dir_path):
        return
    for root, _, files in os.walk(dir_path):
        for f in files:
            if f.lower().endswith(exts):
                try:
                    os.remove(os.path.join(root, f))
                except Exception as e:
                    print(f"⚠️ Cannot remove {f}: {e}")

def _prepare_clean_environment():
    os.makedirs(SFM_DIR, exist_ok=True)
    _safe_clear_dir(SFM_DIR)

# ----------------------
# Трансформация точек MoGe2 в мировую систему
# ----------------------
def transform_points_to_world(points, pose_matrix):
    H, W, _ = points.shape
    # sanitize points
    points = np.nan_to_num(points, nan=0.0, posinf=0.0, neginf=0.0)
    pts_h = np.concatenate(
        [points.reshape(-1,3).astype(np.float32), np.ones((H*W,1), dtype=np.float32)],
        axis=1
    )
    if not np.all(np.isfinite(pose_matrix)):
        print("⚠️ Pose matrix invalid (NaN/Inf), skipping transform.")
        return np.zeros((H*W, 3), dtype=np.float32)
    pts_world = (pose_matrix @ pts_h.T).T[:, :3]
    return pts_world


def safe_intrinsics(K, w, h):
    """
    Ensure K is 3x3 intrinsic matrix and scale if normalized
    """
    if K is None:
        return o3d.camera.PinholeCameraIntrinsic(w, h, w*0.7, h*0.7, w/2, h/2)

    K = np.array(K)

    # Flatten 3D arrays
    if K.ndim == 3:
        K = K[:, :, 0]

    # Flat array of size 9
    if K.ndim == 1 and K.size == 9:
        K = K.reshape(3, 3)

    # Row or column vector? fallback to identity
    if K.shape == (1, 3) or K.shape == (3, 1) or K.shape != (3, 3):
        K = np.eye(3, dtype=np.float32)

    # Scale normalized intrinsics if needed
    if K[0, 0] < 10:  # likely normalized
        K[0, :] *= w
        K[1, :] *= h

    return K


# ----------------------
# Главная функция пайплайна с Python SLAM
# ----------------------
def run_moge2_python_slam(video_path: str, downsample_voxel: float = 0.01,
                          max_frames: int = 100, fps: int = 2) -> Generator[str, None, str]:
    """
    MoGe-2 SLAM pipeline with streaming progress updates for Gradio.
    """
    _prepare_clean_environment()
    yield "🎬 Starting MoGe-2 SLAM pipeline..."

    tmp_dir = tempfile.mkdtemp(prefix="frames_")
    try:
        yield "📹 Extracting frames from video..."
        cmd = f"ffmpeg -i {video_path} -vf fps={fps} -frames:v {max_frames} {tmp_dir}/frame_%05d.png"
        result = subprocess.run(cmd.split(), capture_output=True, timeout=60)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg failed: {result.stderr.decode()}")

        frame_files = sorted([os.path.join(tmp_dir, f) for f in os.listdir(tmp_dir) if f.endswith(".png")])
        if not frame_files:
            raise RuntimeError("❌ No frames extracted from video")
        if len(frame_files) > max_frames:
            frame_files = frame_files[:max_frames]
        yield f"✅ Extracted {len(frame_files)} frames"

        # Init model
        yield "🤖 Initializing MoGe-2 model..."
        moge_service = MoGe2Service(device='cuda')

        # Base camera info from first frame
        first_img = cv2.imread(frame_files[0])
        if first_img is None:
            raise RuntimeError("❌ Failed to read the first frame.")
        h, w = first_img.shape[:2]

        # Default intrinsics (updated when MoGe-2 provides K)
        intrinsic = o3d.camera.PinholeCameraIntrinsic(width=w, height=h, fx=w*0.7, fy=h*0.7, cx=w/2, cy=h/2)

        camera_pose = np.eye(4, dtype=np.float64)  # Open3D often expects float64

        # Memory mgmt
        MAX_POINTS_PER_CHUNK = 500000
        SAVE_INTERVAL = 20
        current_points = []
        saved_chunks = []

        yield "🔄 Processing frames with MoGe-2..."

        # ---- First frame preprocessing ----
        prev_rgb_bgr = cv2.imread(frame_files[0])
        prev_rgb = cv2.cvtColor(prev_rgb_bgr, cv2.COLOR_BGR2RGB)

        prev_result = moge_service.run_inference([frame_files[0]])[0]
        prev_depth = prev_result["depth"]
        if prev_depth is None or not np.any(np.isfinite(prev_depth)):
            raise RuntimeError("❌ Invalid depth for the first frame")
        # Resize depth to match color
        prev_depth_resized = cv2.resize(prev_depth, (w, h), interpolation=cv2.INTER_LINEAR)

        # Convert to Open3D types
        prev_depth_o3d = o3d.geometry.Image(prev_depth_resized.astype(np.float32))
        prev_color_o3d = o3d.geometry.Image(prev_rgb.astype(np.uint8))
        prev_rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
            prev_color_o3d, prev_depth_o3d, depth_scale=1.0, depth_trunc=50.0
        )

        total_frames = len(frame_files) - 1
        processed_count = 0

        # Pre-create Jacobian & options for odometry (avoids “incompatible function arg”)
        color_jacobian = o3d.pipelines.odometry.RGBDOdometryJacobianFromColorTerm()
        odo_option = o3d.pipelines.odometry.OdometryOption()

        for i, frame_file in enumerate(frame_files[1:], 1):
            try:
                # Read and prepare current frame
                curr_bgr = cv2.imread(frame_file)
                if curr_bgr is None:
                    yield f"⚠️ Warning: Could not read frame {frame_file}"
                    continue
                curr_rgb = cv2.cvtColor(curr_bgr, cv2.COLOR_BGR2RGB)

                curr_result = moge_service.run_inference([frame_file])[0]
                curr_depth = curr_result["depth"]
                if curr_depth is None or not np.any(np.isfinite(curr_depth)):
                    yield f"⚠️ Warning: Invalid depth data for frame {i}"
                    continue

                # Resize depth to match RGB size (w,h)
                curr_depth_resized = cv2.resize(curr_depth, (w, h), interpolation=cv2.INTER_LINEAR)

                # To Open3D images
                curr_depth_o3d = o3d.geometry.Image(curr_depth_resized.astype(np.float32))
                curr_color_o3d = o3d.geometry.Image(curr_rgb.astype(np.uint8))
                curr_rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
                    curr_color_o3d, curr_depth_o3d, depth_scale=1.0, depth_trunc=50.0
                )

                # Validate dimensions using getters (Image has no .width/.height attributes)
                if (prev_rgbd.color.get_width() != curr_rgbd.color.get_width() or
                    prev_rgbd.color.get_height() != curr_rgbd.color.get_height()):
                    yield f"⚠️ Warning: Skipping frame {i} due to RGBD size mismatch"
                    # Update prev_* to current to try to recover on next iteration
                    prev_rgbd = curr_rgbd
                    prev_color_o3d = curr_color_o3d
                    prev_depth_o3d = curr_depth_o3d
                    continue

                # Update intrinsics from model if available
                if "intrinsics" in curr_result and curr_result["intrinsics"] is not None:
                    K = safe_intrinsics(curr_result.get("intrinsics", None), w, h)
                    intrinsic.set_intrinsics(w, h, float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

                # ---- Odometry ----
                odo_init = np.eye(4, dtype=np.float64)
                try:
                    # Open3D signature: source, target, intrinsic, odo_init, jacobian, option
                    # Here source = curr, target = prev (align curr to prev)
                    odo_res = o3d.pipelines.odometry.compute_rgbd_odometry(
                        curr_rgbd, prev_rgbd, intrinsic, odo_init, color_jacobian, odo_option
                    )

                    # Handle new & old API return types
                    if hasattr(odo_res, "success"):
                        success = bool(odo_res.success)
                        trans = np.asarray(odo_res.transformation)
                    elif isinstance(odo_res, tuple) and len(odo_res) >= 2:
                        success = bool(odo_res[0])
                        trans = np.asarray(odo_res[1])
                    else:
                        success, trans = False, None

                    if success and trans is not None and np.all(np.isfinite(trans)) and np.linalg.det(trans[:3, :3]) > 0.1:
                        camera_pose = camera_pose @ trans
                    else:
                        yield f"⚠️ Warning: Odometry failed or invalid transform for frame {i}"
                        # Still advance prev to keep pipeline moving
                        prev_rgbd = curr_rgbd
                        prev_color_o3d = curr_color_o3d
                        prev_depth_o3d = curr_depth_o3d
                        continue

                except Exception as e:
                    yield f"⚠️ Warning: Odometry computation failed for frame {i}: {str(e)[:80]}"
                    # Advance prev anyway
                    prev_rgbd = curr_rgbd
                    prev_color_o3d = curr_color_o3d
                    prev_depth_o3d = curr_depth_o3d
                    continue

                # ---- Point cloud for current frame ----
                try:
                    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(curr_rgbd, intrinsic, camera_pose)
                    if not pcd.is_empty() and downsample_voxel > 0:
                        pcd = pcd.voxel_down_sample(downsample_voxel)

                    points = np.asarray(pcd.points)
                    if points.size > 0 and np.all(np.isfinite(points)):
                        current_points.append(points)
                    else:
                        yield f"⚠️ Warning: Invalid points generated for frame {i}"

                except Exception as e:
                    yield f"⚠️ Warning: Point cloud generation failed for frame {i}: {str(e)[:80]}"

                # ---- Save chunks / memory mgmt ----
                total_current_points = sum(len(pts) for pts in current_points)
                if total_current_points > MAX_POINTS_PER_CHUNK or (i % SAVE_INTERVAL == 0):
                    if current_points:
                        try:
                            chunk_points = np.vstack(current_points)
                            chunk_pcd = o3d.geometry.PointCloud()
                            chunk_pcd.points = o3d.utility.Vector3dVector(chunk_points)
                            if len(chunk_points) > MAX_POINTS_PER_CHUNK:
                                chunk_pcd = chunk_pcd.voxel_down_sample(downsample_voxel * 1.5)
                            chunk_path = os.path.join(SFM_DIR, f"chunk_{len(saved_chunks):03d}.ply")
                            o3d.io.write_point_cloud(chunk_path, chunk_pcd)
                            saved_chunks.append(chunk_path)
                        except Exception as e:
                            yield f"⚠️ Warning: Chunk saving failed: {str(e)[:80]}"
                        finally:
                            current_points = []
                            try:
                                del chunk_pcd, chunk_points
                            except:
                                pass
                            gc.collect()

                # ---- Advance previous frame ----
                prev_rgbd = curr_rgbd
                prev_color_o3d = curr_color_o3d
                prev_depth_o3d = curr_depth_o3d

                # Progress
                processed_count += 1
                if i % 5 == 0 or i == total_frames:
                    progress_percent = int((processed_count / total_frames) * 100)
                    yield f"🔄 Processed {processed_count}/{total_frames} frames ({progress_percent}%) | Chunks: {len(saved_chunks)}"

            except Exception as e:
                yield f"⚠️ Warning: Frame {i} failed: {str(e)[:100]}...\n{traceback.format_exc()}"
                continue

        # -------- Final merge --------
        yield "🔗 Merging point cloud chunks..."
        if current_points:
            try:
                chunk_points = np.vstack(current_points)
                chunk_pcd = o3d.geometry.PointCloud()
                chunk_pcd.points = o3d.utility.Vector3dVector(chunk_points)
                chunk_path = os.path.join(SFM_DIR, f"chunk_{len(saved_chunks):03d}.ply")
                o3d.io.write_point_cloud(chunk_path, chunk_pcd)
                saved_chunks.append(chunk_path)
            except Exception as e:
                yield f"⚠️ Warning: Final chunk write failed: {str(e)[:80]}"

        if saved_chunks:
            yield f"📦 Merging {len(saved_chunks)} chunks..."
            final_pcd = o3d.geometry.PointCloud()
            for chunk_path in saved_chunks:
                try:
                    chunk = o3d.io.read_point_cloud(chunk_path)
                    if not chunk.is_empty():
                        final_pcd += chunk
                except Exception as e:
                    yield f"⚠️ Warning: Failed to load chunk {chunk_path}: {str(e)[:80]}"

            if not final_pcd.is_empty():
                yield "🎯 Applying final processing..."
                try:
                    final_pcd, _ = final_pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
                except Exception:
                    pass
                if downsample_voxel > 0:
                    try:
                        final_pcd = final_pcd.voxel_down_sample(downsample_voxel)
                    except Exception:
                        pass

                final_path = os.path.join(SFM_DIR, "final_pointcloud.ply")
                o3d.io.write_point_cloud(final_path, final_pcd)

                for chunk_path in saved_chunks:
                    try:
                        os.remove(chunk_path)
                    except:
                        pass

                point_count = len(np.asarray(final_pcd.points))
                yield f"✅ Success! Generated point cloud with {point_count:,} points"
                return (f"✅ MoGe-2 SLAM completed successfully!\n"
                        f"📁 Output: {final_path}\n"
                        f"📊 Points: {point_count:,}\n"
                        f"🎬 Frames processed: {processed_count}/{total_frames}")
            else:
                return "❌ Failed to generate point cloud - no valid points found"
        else:
            return "❌ Failed to process any frames successfully"

    except subprocess.TimeoutExpired:
        return "❌ Video processing timed out - try a shorter video or reduce max_frames"
    except Exception as e:
        return f"❌ Pipeline failed: {str(e)}"
    finally:
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir, ignore_errors=True)

