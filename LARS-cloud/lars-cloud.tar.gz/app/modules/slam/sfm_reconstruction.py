import os
import numpy as np
import open3d as o3d
from tqdm import tqdm


def fx_from_fov(width: int, fov_deg: float) -> float:
    """fx для заданного FOV (по ширине)."""
    fov = np.deg2rad(fov_deg)
    return 0.5 * width / np.tan(0.5 * fov)


class SFMReconstruction:
    """
    Интеграция RGB+Depth в глобальную сцену.
    - Межкадровое выравнивание через ICP Point-to-Plane.
    - TSDF-фьюжн (по умолчанию) или простое объединение PC.
    """

    def __init__(
            self,
            results_dir: str = "sfm_results",
            fov_deg: float = 60.0,
            depth_trunc: float = 8.0,
            depth_scale: float = 1.0,
            depth_is_relative: bool = False,
            use_tsdf: bool = True,
            align_frames: bool = True,
            voxel_length: float = 0.04,
            sdf_trunc: float = 0.08,
    ):
        self.results_dir = results_dir
        self.fov_deg = fov_deg
        self.depth_trunc = depth_trunc
        self.depth_scale = depth_scale
        self.depth_is_relative = depth_is_relative
        self.use_tsdf = use_tsdf
        self.align_frames = align_frames

        os.makedirs(results_dir, exist_ok=True)

        self.intrinsic = None
        self.T_w_c = np.eye(4)  # world <- camera transform
        self.prev_pcd_cam = None

        # Progress tracking
        self.frame_count = 0
        self.total_frames = 0
        self.progress_bar = None

        if use_tsdf:
            self.volume = o3d.pipelines.integration.ScalableTSDFVolume(
                voxel_length=voxel_length,
                sdf_trunc=sdf_trunc,
                color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8,
            )
        else:
            self.volume = None
            self.accumulated_pcd = o3d.geometry.PointCloud()

    def set_total_frames(self, total: int):
        """Set total number of frames for progress tracking"""
        self.total_frames = total
        if self.progress_bar is not None:
            self.progress_bar.close()
        self.progress_bar = tqdm(
            total=total,
            desc="🎥 Processing frames",
            unit="frame",
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} frames [{elapsed}<{remaining}, {rate_fmt}]"
        )

    def _ensure_intrinsic(self, w: int, h: int):
        if self.intrinsic is None:
            fx = fy = fx_from_fov(w, self.fov_deg)
            cx, cy = w / 2.0, h / 2.0
            self.intrinsic = o3d.camera.PinholeCameraIntrinsic(
                int(w), int(h), float(fx), float(fy), float(cx), float(cy)
            )

    def _rgbd(self, rgb_frame: np.ndarray, depth_m: np.ndarray) -> o3d.geometry.RGBDImage:
        # Ensure RGB is uint8 and contiguous
        if rgb_frame.dtype != np.uint8:
            rgb = (np.clip(rgb_frame, 0, 1) * 255).astype(np.uint8)
        else:
            rgb = rgb_frame

        # Ensure RGB has correct shape and channels
        if rgb.ndim == 2:
            rgb = cv2.cvtColor(rgb, cv2.COLOR_GRAY2RGB)
        elif rgb.ndim == 3 and rgb.shape[2] == 4:
            rgb = cv2.cvtColor(rgb, cv2.COLOR_RGBA2RGB)
        elif rgb.ndim == 3 and rgb.shape[2] != 3:
            rgb = rgb[:, :, :3]

        # Make contiguous for Open3D
        color_o3d = o3d.geometry.Image(np.ascontiguousarray(rgb))

        # Process depth
        depth = depth_m.astype(np.float32)
        if depth.ndim == 3:
            depth = depth[:, :, 0]

        # Clean depth data
        depth = np.nan_to_num(depth, nan=0.0, posinf=0.0, neginf=0.0)
        np.clip(depth, 0.0, self.depth_trunc, out=depth)

        # Ensure depth is contiguous
        depth_o3d = o3d.geometry.Image(np.ascontiguousarray(depth))

        h, w = depth.shape
        self._ensure_intrinsic(w, h)

        # Validate dimensions match
        if rgb.shape[:2] != depth.shape:
            print(f"⚠️ RGB shape {rgb.shape[:2]} != depth shape {depth.shape}")
            # Resize depth to match RGB
            depth_resized = cv2.resize(depth, (rgb.shape[1], rgb.shape[0]))
            depth_o3d = o3d.geometry.Image(np.ascontiguousarray(depth_resized))

        return o3d.geometry.RGBDImage.create_from_color_and_depth(
            color_o3d, depth_o3d,
            depth_scale=self.depth_scale,
            depth_trunc=self.depth_trunc,
            convert_rgb_to_intensity=False
        )

    @staticmethod
    def _pcd_from_rgbd(rgbd: o3d.geometry.RGBDImage,
                       intrinsic: o3d.camera.PinholeCameraIntrinsic) -> o3d.geometry.PointCloud:
        return o3d.geometry.PointCloud.create_from_rgbd_image(rgbd, intrinsic)

    def process_frame(self, rgb_frame: np.ndarray, depth_m: np.ndarray):
        """Process a single frame with progress tracking"""
        try:
            rgbd = self._rgbd(rgb_frame, depth_m)
            pcd_cam = self._pcd_from_rgbd(rgbd, self.intrinsic)

            # Update progress
            self.frame_count += 1
            if self.progress_bar:
                self.progress_bar.update(1)
                self.progress_bar.set_postfix({
                    'ICP': 'processing...' if self.align_frames and self.prev_pcd_cam is not None else 'disabled',
                    'Points': len(pcd_cam.points)
                })

            if len(pcd_cam.points) == 0:
                if self.progress_bar:
                    self.progress_bar.set_postfix({'Status': 'No valid points'})
                return

            # ICP alignment
            if self.align_frames and self.prev_pcd_cam is not None:
                try:
                    with tqdm(desc="🔄 ICP alignment", leave=False, disable=True) as icp_bar:
                        reg = o3d.pipelines.registration.registration_icp(
                            pcd_cam, self.prev_pcd_cam,
                            max_correspondence_distance=0.3,
                            estimation_method=o3d.pipelines.registration.TransformationEstimationPointToPlane(),
                            criteria=o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=30)
                        )
                        if reg.fitness > 0.1:
                            self.T_w_c = self.T_w_c @ reg.transformation
                            if self.progress_bar:
                                self.progress_bar.set_postfix({
                                    'ICP': f'fitness: {reg.fitness:.3f}',
                                    'Points': len(pcd_cam.points)
                                })
                        else:
                            if self.progress_bar:
                                self.progress_bar.set_postfix({
                                    'ICP': 'failed (low fitness)',
                                    'Points': len(pcd_cam.points)
                                })
                except Exception as e:
                    if self.progress_bar:
                        self.progress_bar.set_postfix({
                            'ICP': f'error: {str(e)[:20]}...',
                            'Points': len(pcd_cam.points)
                        })

            # Integration
            if self.use_tsdf:
                extrinsic_w2c = np.linalg.inv(self.T_w_c)
                self.volume.integrate(rgbd, self.intrinsic, extrinsic_w2c)
            else:
                pcd_world = pcd_cam.transform(self.T_w_c)
                self.accumulated_pcd += pcd_world

            self.prev_pcd_cam = pcd_cam

        except Exception as e:
            if self.progress_bar:
                self.progress_bar.set_postfix({'Error': str(e)[:30]})
            raise

    def reset(self):
        """Reset reconstruction state"""
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None

        self.frame_count = 0
        self.total_frames = 0
        self.T_w_c = np.eye(4)
        self.prev_pcd_cam = None

        if self.use_tsdf:
            v = self.volume
            self.volume = o3d.pipelines.integration.ScalableTSDFVolume(
                voxel_length=v.voxel_length, sdf_trunc=v.sdf_trunc,
                color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8,
            )
        else:
            self.accumulated_pcd = o3d.geometry.PointCloud()

    def get_point_cloud(self) -> o3d.geometry.PointCloud:
        """Extract final point cloud with progress indication"""
        if self.use_tsdf:
            with tqdm(desc="🔄 Extracting point cloud from TSDF", leave=False):
                return self.volume.extract_point_cloud()
        else:
            return self.accumulated_pcd

    def get_mesh(self) -> o3d.geometry.TriangleMesh:
        """Extract triangle mesh (TSDF only) with progress indication"""
        if not self.use_tsdf:
            raise ValueError("Mesh extraction requires TSDF mode")

        with tqdm(desc="🔄 Extracting mesh from TSDF", leave=False):
            mesh = self.volume.extract_triangle_mesh()
            mesh.compute_vertex_normals()
            return mesh

    def save_point_cloud(self, pcd: o3d.geometry.PointCloud, path: str):
        """Save point cloud with progress indication"""
        with tqdm(desc=f"💾 Saving point cloud", leave=False):
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            o3d.io.write_point_cloud(path, pcd)

    def save_mesh(self, mesh: o3d.geometry.TriangleMesh, path: str):
        """Save mesh with progress indication"""
        with tqdm(desc=f"💾 Saving mesh", leave=False):
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            o3d.io.write_triangle_mesh(path, mesh)

    def finalize(self):
        """Close progress bars and cleanup"""
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
