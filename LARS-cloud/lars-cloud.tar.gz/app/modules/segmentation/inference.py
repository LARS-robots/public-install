import os
import sys
import tempfile
from typing import Any, Dict, Optional, Union

import numpy as np

try:
    from PIL import Image
except ImportError:
    Image = None  # Optional; only needed for PIL inputs

# Resolve project root (mirrors other modules)
_current_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(os.path.dirname(_current_dir))
if _project_root not in sys.path:
    sys.path.append(_project_root)

# Try to import SAMService (must exist at app/modules/segmentation/sam_service.py)
try:
    from app.modules.segmentation.sam_service import SAMService
except Exception as e:
    SAMService = None
    _import_error = e
else:
    _import_error = None

# Singleton cache
_sam_instance: Optional[SAMService] = None
_sam_config_cache: Optional[Dict[str, Any]] = None


def _init_sam(config: Optional[Dict[str, Any]] = None) -> SAMService:
    """
    Initialize (or reuse) SAMService singleton.
    """
    global _sam_instance, _sam_config_cache
    if SAMService is None:
        raise ImportError(f"SAMService not available: {_import_error}")
    if _sam_instance is not None:
        # If config differs, re-init
        if config and _sam_config_cache != config:
            _sam_instance = SAMService(config)
            _sam_config_cache = dict(config)
        return _sam_instance
    # Default lightweight config (adjust paths to existing weights)
    default_cfg = {
        "cpu_weights": "sam2.1_t.pt",
        "cuda_weights": "sam2.1_l.pt",
    }
    if config:
        default_cfg.update(config)
    _sam_instance = SAMService(default_cfg)
    _sam_config_cache = dict(default_cfg)
    return _sam_instance


def _ensure_path_from_input(image: Union[str, np.ndarray, "Image.Image"]) -> str:
    """
    Accepts a path, numpy array (H,W[,3]), or PIL.Image; returns a temporary file path if needed.
    """
    if isinstance(image, str):
        return image
    if Image is not None and isinstance(image, Image.Image):
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        image.save(tmp.name)
        return tmp.name
    if isinstance(image, np.ndarray):
        if Image is None:
            raise ValueError("PIL is required to handle numpy arrays as input.")
        if image.dtype != np.uint8:
            arr = np.clip(image, 0, 255).astype(np.uint8)
        else:
            arr = image
        img = Image.fromarray(arr)
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        img.save(tmp.name)
        return tmp.name
    raise TypeError(f"Unsupported image input type: {type(image)}")


def run_inference(image: Union[str, np.ndarray, "Image.Image"], config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Perform segmentation inference.
    Returns a dict with at least key 'road' (binary mask 0/255) so that
    VDASLAMService._extract_road_mask can consume it.
    Fallbacks:
      - If SAMService.calculate_mask returns a mask array -> wrap as {'road': mask}
      - If it returns a dict already containing 'road' -> pass through
    """
    sam = _init_sam(config)
    img_path = _ensure_path_from_input(image)

    try:
        result = sam.calculate_mask(img_path)
    except Exception as e:
        # On failure return empty dict (caller will treat as no mask)
        print(f"[segmentation] Inference error: {e}")
        return {}

    # Normalize output
    if isinstance(result, dict):
        if "road" in result:
            return result
        # If dict has a single mask value
        if len(result) == 1:
            k, v = next(iter(result.items()))
            return {"road": v}
        # Try common keys
        for k in ("mask", "seg", "binary"):
            if k in result:
                return {"road": result[k]}
        # Leave as-is (caller may still extract)
        return result

    # Array / list cases
    if isinstance(result, (list, tuple)):
        if len(result) > 0:
            return {"road": result[0]}
        return {}

    # Assume ndarray or compatible
    return {"road": result}