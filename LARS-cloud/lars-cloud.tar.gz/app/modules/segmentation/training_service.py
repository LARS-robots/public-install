import os
import sys

def find_project_root(start_dir, marker="requirements.txt"):
    d = start_dir
    while d != os.path.dirname(d):
        if os.path.isfile(os.path.join(d, marker)):
            return d
        d = os.path.dirname(d)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)


import numpy as np
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torch
import torch.nn as nn
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import torchvision.transforms.functional as F
from tqdm import tqdm

# Импортируем конфигурацию
from app.core.config import SEGFORMER_DIR, SEGFORMER_DIR_TRAINED


class RoadSegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, processor):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.filenames = sorted(os.listdir(mask_dir))
        if not self.filenames:
            raise ValueError(f"Маски не найдены. Создайте как минимум одну маску для ззаппуска обучения модели.")
        self.processor = processor

    def __len__(self):
        return len(self.filenames)

    def __getitem__old(self, idx):
        mask_file = self.filenames[idx]
        img_path = os.path.join(self.img_dir, mask_file.replace('_mask.png', '.jpg'))
        mask_path = os.path.join(self.mask_dir, mask_file)
        image = Image.open(img_path).convert('RGB')
        mask = np.array(Image.open(mask_path).convert('L'))
        mask = (mask > 127).astype(np.uint8)
        encoding = self.processor(images=image, return_tensors="pt")
        return encoding.pixel_values.squeeze(), torch.from_numpy(mask).long()

    def __getitem__(self, idx):
        mask_file = self.filenames[idx]
        img_path = os.path.join(self.img_dir, mask_file.replace('_mask.png', '.jpg'))
        mask_path = os.path.join(self.mask_dir, mask_file)

        image = Image.open(img_path).convert('RGB')
        mask = Image.open(mask_path)  # уже 0 и 1, режим 'L'

        # Получаем целевой размер
        if isinstance(self.processor.size, dict):
            size = self.processor.size.get("shortest_edge", 512)
        else:
            size = self.processor.size

        # Определяем smallest edge resize (как делает processor)
        w, h = image.size
        if w < h:
            new_w = size
            new_h = int(h * size / w)
        else:
            new_h = size
            new_w = int(w * size / h)

        # Ресайз изображения (с интерполяцией)
        image = F.resize(image, (new_h, new_w), interpolation=F.InterpolationMode.BILINEAR)

        # Ресайз маски (без интерполяции! nearest)
        mask = F.resize(mask, (new_h, new_w), interpolation=F.InterpolationMode.NEAREST)

        # Конвертируем маску: 255 → 1
        mask = mask.point(lambda x: 1 if x > 127 else 0)
        mask = np.array(mask)  # в numpy
        mask = torch.from_numpy(mask).long()

        # Обработка изображения через processor (нормализация)
        encoding = self.processor(image, return_tensors="pt")  # уже resized
        pixel_values = encoding.pixel_values.squeeze()

        return pixel_values, mask


class TrainingService:
    def __init__(self, img_dir, mask_dir, output_dir, device=None):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.output_dir = output_dir

        # Проверить существование директорий
        if not os.path.exists(img_dir):
            raise FileNotFoundError(f"Директория изображений не найдена: {img_dir}")
        if not os.path.exists(mask_dir):
            raise FileNotFoundError(f"Директория масок не найдена: {mask_dir}")

        os.makedirs(output_dir, exist_ok=True)
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')

        # Проверяем есть ли конфиг файлы Segformer в SEGFORMER_DIR
        config_path = os.path.join(SEGFORMER_DIR, "config.json")
        preprocessor_config_path = os.path.join(SEGFORMER_DIR, "preprocessor_config.json")

        if os.path.exists(config_path) and os.path.exists(preprocessor_config_path):
            # Загружаем модель из локальной директории
            print(f"🔄 Загружаем базовую модель из {SEGFORMER_DIR}")
            self.processor = SegformerImageProcessor.from_pretrained(SEGFORMER_DIR)
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                SEGFORMER_DIR,
                ignore_mismatched_sizes=True
            ).to(self.device)
        else:
            # Загружаем из HuggingFace и сохраняем в SEGFORMER_DIR
            print("📥 Загружаем предобученную модель Segformer из HuggingFace")
            self.processor = SegformerImageProcessor.from_pretrained("nvidia/segformer-b0-finetuned-ade-512-512")
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                "nvidia/segformer-b0-finetuned-ade-512-512",
                id2label={0: "background", 1: "sidewalk"},
                label2id={"background": 0, "sidewalk": 1},
                ignore_mismatched_sizes=True
            ).to(self.device)

            # Сохраняем базовую модель в SEGFORMER_DIR
            self.model.save_pretrained(SEGFORMER_DIR)
            self.processor.save_pretrained(SEGFORMER_DIR)
            print(f"💾 Базовая модель сохранена в {SEGFORMER_DIR}")

        # Заморозить все параметры - будем тюнить только классификатор
        for param in self.model.parameters():
            param.requires_grad = False
        # Разморозить только classifier (голову)
        for param in self.model.decode_head.parameters():
            param.requires_grad = True

    def train(self, batch_size=4, num_epochs=30, lr=2e-4):
        loader = DataLoader(
            RoadSegDataset(self.img_dir, self.mask_dir, self.processor),
            batch_size=batch_size, shuffle=True
        )
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=lr)
        loss_fn = nn.CrossEntropyLoss()

        logs = []
        for epoch in range(1, num_epochs + 1):
            self.model.train()
            running_loss = 0
            for pixel_values, masks in tqdm(loader, desc=f"Epoch {epoch}", leave=False):
                pixel_values = pixel_values.to(self.device)
                masks = masks.to(self.device)
                outputs = self.model(pixel_values=pixel_values, labels=masks)
                loss = outputs.loss
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                running_loss += loss.item()
            avg = running_loss / len(loader)
            logs.append(f"Epoch {epoch} — loss: {avg:.4f}")

        # Сохраняем обученную модель в SEGFORMER_DIR_TRAINED
        self.model.save_pretrained(SEGFORMER_DIR_TRAINED)
        self.processor.save_pretrained(SEGFORMER_DIR_TRAINED)
        print(f"💾 Обученная модель сохранена в {SEGFORMER_DIR_TRAINED}")

        logs.append(f"Модель сохранена в {SEGFORMER_DIR_TRAINED}")
        return logs
