import os
import sys
import time
import random
from app.core.utils import find_project_root


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)


import numpy as np
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torch
import torch.nn as nn
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import torchvision.transforms.functional as F
from torchvision import transforms as T
from tqdm import tqdm

# Импорт конфигов
from app.core.config import (
    SEGFORMER_DIR, SEGFORMER_DIR_TRAINED,
    TRAINING_PROFILES, AUGMENTATION_CFG, HEARTBEAT_SECONDS
)

# ---------------- Dataset с аугментациями ----------------
class RoadSegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, processor, augment=True):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.filenames = sorted(os.listdir(mask_dir))
        if not self.filenames:
            raise ValueError("Маски не найдены. Создайте как минимум одну маску для запуска обучения модели.")
        self.processor = processor
        self.augment = augment

        # Фотометрические аугментации (только для изображения)
        cj = AUGMENTATION_CFG["color_jitter"]
        self.color_aug = T.ColorJitter(
            brightness=cj["brightness"],
            contrast=cj["contrast"],
            saturation=cj["saturation"],
            hue=cj["hue"]
        )
        self.hflip_p = float(AUGMENTATION_CFG["hflip_p"])

    def __len__(self):
        return len(self.filenames)

    def __getitem__(self, idx):
        mask_file = self.filenames[idx]
        img_path = os.path.join(self.img_dir, mask_file.replace('_mask.png', '.jpg'))
        mask_path = os.path.join(self.mask_dir, mask_file)

        image = Image.open(img_path).convert('RGB')
        mask  = Image.open(mask_path)  # бинарная маска 0/255

        # Resize «по короткой стороне», как у processor
        if isinstance(self.processor.size, dict):
            size = self.processor.size.get("shortest_edge", 512)
        else:
            size = self.processor.size

        w, h = image.size
        if w < h:
            new_w = size
            new_h = int(h * size / w)
        else:
            new_h = size
            new_w = int(w * size / h)

        image = F.resize(image, (new_h, new_w), interpolation=F.InterpolationMode.BILINEAR)
        mask  = F.resize(mask,  (new_h, new_w), interpolation=F.InterpolationMode.NEAREST)

        # --- Простые и надёжные аугментации ---
        if self.augment:
            # 1) Горизонтальный флип — синхронно для изображения и маски
            if random.random() < self.hflip_p:
                image = F.hflip(image)
                mask  = F.hflip(mask)
            # 2) Лёгкая фотометрия — только для изображения
            image = self.color_aug(image)

        # Бинаризация маски в {0,1}
        mask = mask.point(lambda x: 1 if x > 127 else 0)
        mask = np.array(mask)
        mask = torch.from_numpy(mask).long()

        # Нормализация/преобразования процессора
        encoding = self.processor(image, return_tensors="pt")
        pixel_values = encoding.pixel_values.squeeze()  # 3,H,W

        return pixel_values, mask


class TrainingService:
    def __init__(self, img_dir, mask_dir, output_dir, device=None, profile=None):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.output_dir = output_dir

        if not os.path.exists(img_dir):
            raise FileNotFoundError(f"Директория изображений не найдена: {img_dir}")
        if not os.path.exists(mask_dir):
            raise FileNotFoundError(f"Директория масок не найдена: {mask_dir}")

        os.makedirs(output_dir, exist_ok=True)
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')

        # Выбираем профиль обучения
        if profile is None:
            profile = "gpu_standard" if self.device == "cuda" else "cpu_demo"
        self.profile = TRAINING_PROFILES.get(profile, TRAINING_PROFILES["cpu_demo"])

        # Загрузка/инициализация модели и процессора (как было)
        config_path = os.path.join(SEGFORMER_DIR, "config.json")
        preprocessor_config_path = os.path.join(SEGFORMER_DIR, "preprocessor_config.json")

        if os.path.exists(config_path) and os.path.exists(preprocessor_config_path):
            print(f"🔄 Загружаем базовую модель из {SEGFORMER_DIR}")
            self.processor = SegformerImageProcessor.from_pretrained(SEGFORMER_DIR)
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                SEGFORMER_DIR, ignore_mismatched_sizes=True
            ).to(self.device)
        else:
            print("📥 Загружаем предобученную модель Segformer из HuggingFace")
            self.processor = SegformerImageProcessor.from_pretrained("nvidia/segformer-b0-finetuned-ade-512-512")
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                "nvidia/segformer-b0-finetuned-ade-512-512",
                id2label={0: "background", 1: "sidewalk"},
                label2id={"background": 0, "sidewalk": 1},
                ignore_mismatched_sizes=True
            ).to(self.device)
            self.model.save_pretrained(SEGFORMER_DIR)
            self.processor.save_pretrained(SEGFORMER_DIR)
            print(f"💾 Базовая модель сохранена в {SEGFORMER_DIR}")

        # Фризим энкодер, обучаем только head (как было)
        for p in self.model.parameters():
            p.requires_grad = False
        for p in self.model.decode_head.parameters():
            p.requires_grad = True

    def _make_loader(self, batch_size):
        ds = RoadSegDataset(self.img_dir, self.mask_dir, self.processor, augment=True)
        return DataLoader(ds, batch_size=batch_size, shuffle=True)

    def train(self, batch_size=None, num_epochs=None, lr=2e-4, progress_cb=None):
        """Синхронное обучение с heartbeat через progress_cb."""
        batch_size = int(batch_size or self.profile["batch_size"])
        num_epochs = int(num_epochs or self.profile["epochs"])

        loader = self._make_loader(batch_size=batch_size)
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=lr)
        loss_fn = nn.CrossEntropyLoss()

        logs = []
        last_beat = 0.0

        for epoch in range(1, num_epochs + 1):
            self.model.train()
            running_loss = 0.0
            for i, (pixel_values, masks) in enumerate(tqdm(loader, desc=f"Epoch {epoch}", leave=False), start=1):
                pixel_values = pixel_values.to(self.device)
                masks = masks.to(self.device)
                outputs = self.model(pixel_values=pixel_values, labels=masks)
                loss = outputs.loss
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                running_loss += loss.item()

                # Heartbeat прогресса
                now = time.time()
                if progress_cb is not None and (now - last_beat) >= HEARTBEAT_SECONDS:
                    # доля завершения эпохи (0..1)
                    frac = (i / max(1, len(loader)))
                    progress_cb(epoch, num_epochs, frac, f"epoch {epoch}/{num_epochs}, step {i}/{len(loader)}")
                    last_beat = now

            avg = running_loss / max(1, len(loader))
            logs.append(f"Epoch {epoch} — loss: {avg:.4f}")
            if progress_cb is not None:
                progress_cb(epoch, num_epochs, 1.0, f"epoch {epoch}/{num_epochs} done, loss {avg:.4f}")

        # Сохраняем обученную модель
        self.model.save_pretrained(SEGFORMER_DIR_TRAINED)
        self.processor.save_pretrained(SEGFORMER_DIR_TRAINED)
        print(f"💾 Обученная модель сохранена в {SEGFORMER_DIR_TRAINED}")
        logs.append(f"Модель сохранена в {SEGFORMER_DIR_TRAINED}")
        return logs