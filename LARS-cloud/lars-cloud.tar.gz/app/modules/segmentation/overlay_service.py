import cv2
import torch
import numpy as np
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import os, subprocess, time
from app.core.config import HEARTBEAT_SECONDS

class OverlayService:
    def __init__(self, model_dir: str, device: str = None, use_compile: bool = True):
        """
        Инициализация сервиса с поддержкой GPU/CPU и оптимизаций.
        """
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.eval()

        # Попытка включить torch.compile, если возможно
        self.use_torch_compile = use_compile and torch.__version__ >= "2.0"
        if self.use_torch_compile and "cuda" in str(self.model.device):
            try:
                print("🔧 Попытка включить torch.compile для ускорения...")
                self.model = torch.compile(self.model, mode="reduce-overhead", fullgraph=True)
                print("✅ torch.compile успешно включён.")
            except Exception as e:
                print(f"⚠️ torch.compile недоступен: {e}")
                self.use_torch_compile = False
        else:
            self.use_torch_compile = False

        # Логирование устройства
        print(f"🖥️  Модель загружена на: {self.model.device}")

    def apply_overlay(self, input_video: str, output_video: str,
                    alpha: float = 0.4, batch_size: int = None,
                    progress_cb=None, mode: str = "auto"): 
        """
        Основной метод: читает видео, накладывает маску, сохраняет с оверлеем.
        mode: "mono" (весь кадр), "stereo" (только правая половина), "quad" (все 4 тайла), "auto" (автоопределение)
        """
        print(f"📹 Открываем видео: {input_video} (режим: {mode})")
        cap = cv2.VideoCapture(input_video)
        if not cap.isOpened():
            raise ValueError(f"Не удалось открыть видео: {input_video}")

        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0  
        print(f"🎥 Видео: {w}x{h} @ {fps} FPS")

        overlay_color = np.array([0, 255, 0], dtype=np.uint8)  # зелёный

        # Используем cv2.VideoWriter для записи
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # или 'XVID' для .avi, если нужно
        writer = cv2.VideoWriter(output_video, fourcc, fps, (w, h))

        if not writer.isOpened():
            raise ValueError(f"Не удалось открыть VideoWriter для {output_video}")

        # Авто-подбор batch_size
        actual_batch_size = batch_size or (4 if torch.cuda.is_available() else 1)
        print(f"📊 Используется batch_size = {actual_batch_size}")

        frame_buffer = []
        frame_count = 0
        written = 0                 # NEW: сколько кадров реально записано
        last_beat = 0.0             # NEW: для heartbeat

        def _beat(text):            # NEW: локальная обёртка heartbeat
            nonlocal last_beat, written
            now = time.time()
            if progress_cb is None:
                return
            if (now - last_beat) >= HEARTBEAT_SECONDS:
                frac = (written / max(1, total_frames)) if total_frames > 0 else 0.0
                progress_cb(frac, text)
                last_beat = now

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    print("✅ Достигнут конец видео.")
                    break

                frame_buffer.append(frame)
                frame_count += 1

                if len(frame_buffer) == actual_batch_size:
                    print(f"📦 Обрабатываем батч из {actual_batch_size} кадров... ({frame_count} прочитано)")
                    processed = self.process_batch(frame_buffer, alpha=alpha, mode=mode)
                    for proc_frame in processed:
                        writer.write(proc_frame)
                    written += len(processed)    
                    frame_buffer.clear()
                    _beat(f"кадр {written}/{total_frames or '?'}")  

            # Остаток
            if frame_buffer:
                print(f"📦 Обрабатываем последние {len(frame_buffer)} кадров...")
                processed = self.process_batch(frame_buffer, alpha=alpha, mode=mode)
                for proc_frame in processed:
                    writer.write(proc_frame)
                written += len(processed)        
                _beat(f"кадр {written}/{total_frames or '?'}")     

            print("🔚 Все кадры записаны.")

        except Exception as e:
            print(f"❌ Ошибка при обработке: {e}")
            raise
        finally:
            print("🧹 Закрываем ресурсы...")
            cap.release()
            writer.release()

        # Пост-обработка аудио (может занимать время) — аккуратно обновим прогресс:
        if progress_cb is not None:                 # NEW
            # если знаем total_frames — считаем что видеофаза почти закончена
            progress_cb(0.99 if total_frames else 0.5, "подготовка аудио")  # NEW

        # Добавляем аудио (если есть)
        if self.has_audio(input_video):
            print("🎵 Добавляем аудио...")
            self._add_audio(input_video, output_video)
        else:
            print("🔇 Аудио в исходном видео не найдено.")

        if progress_cb is not None:                 # NEW
            progress_cb(1.0, "завершено")           # финальный пульс

        print(f"✅ Готово! Результат: {output_video}")
        return output_video

    def process_batch(self, frames: list, alpha: float = 0.4, mode: str | None = None) -> list:
        """
        Батч-обработка кадров с поддержкой разных режимов камер.
        mode: mono/stereo_h/stereo_v/quad2x2/auto/None
        """
        overlay_color = np.array([0, 255, 0], dtype=np.uint8)  # зелёный
        processed_frames = []

        try:
            h, w = frames[0].shape[:2]
            
            # Normalize mode names (backward compatibility)
            m = (mode or "auto").lower()
            if m == "stereo": m = "stereo_h"  # backward compat
            if m == "quad": m = "quad2x2"     # backward compat
            
            if m not in ("mono", "stereo_h", "stereo_v", "quad2x2", "auto"):
                print(f"⚠️ Неизвестный режим '{m}', используем mono.")
                m = "mono"
                
            # Auto-detection
            if m == "auto":
                from app.modules.video_processing.eis.splitter import detect_layout, SplitMode
                layout = detect_layout(w, h)
                if layout == SplitMode.STEREO_H:
                    m = "stereo_h"
                elif layout == SplitMode.STEREO_V:
                    m = "stereo_v"
                elif layout == SplitMode.QUAD_2x2:
                    m = "quad2x2"
                else:
                    m = "mono"
                print(f"🔍 Автоопределение режима: {m} (layout: {layout})")

            # Process based on mode
            if m in ("mono", "stereo_h", "stereo_v"):
                rgb_batch = [cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) for frame in frames]
                inputs = self.processor(images=rgb_batch, return_tensors="pt")
                
                with torch.inference_mode():
                    outputs = self.model(**inputs.to(self.model.device))
                
                masks = self.processor.post_process_semantic_segmentation(
                    outputs, target_sizes=[(h, w)] * len(frames)
                )

                for frame, mask in zip(frames, masks):
                    mask = mask.cpu().numpy()
                    sidewalk = (mask == 1).astype(np.uint8)

                    # Largest component only
                    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(sidewalk, connectivity=8)
                    if num_labels > 1:
                        largest_label = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
                        sidewalk = (labels == largest_label).astype(np.uint8)

                    # Apply stereo masking
                    if m == "stereo_h":
                        # Horizontal stereo: keep right half only
                        mid = w // 2
                        sidewalk[:, :mid] = 0
                        print(f"🎯 stereo_h: маска только на правой половине (x∈[{mid},{w}))")
                    elif m == "stereo_v":
                        # Vertical stereo: keep bottom half only
                        mid = h // 2
                        sidewalk[:mid, :] = 0
                        print(f"🎯 stereo_v: маска только на нижней половине (y∈[{mid},{h}))")

                    # Apply overlay
                    color_overlay = np.zeros_like(frame)
                    color_overlay[sidewalk == 1] = overlay_color
                    blended = cv2.addWeighted(frame, 1.0, color_overlay, alpha, 0)
                    processed_frames.append(blended)

                return processed_frames

            # Quad processing
            if m == "quad2x2":
                print(f"🎯 Quad режим: обработка по 4 тайла на кадр")
                for frame in frames:
                    tiles = split_quad(frame)
                    tile_order = ["tl", "tr", "bl", "br"]
                    
                    # Process tiles
                    rgb_tiles = [cv2.cvtColor(tiles[k], cv2.COLOR_BGR2RGB) for k in tile_order]
                    inputs = self.processor(images=rgb_tiles, return_tensors="pt")
                    
                    with torch.inference_mode():
                        outputs = self.model(**inputs.to(self.model.device))
                    
                    tile_sizes = [(tiles[k].shape[0], tiles[k].shape[1]) for k in tile_order]
                    masks = self.processor.post_process_semantic_segmentation(outputs, target_sizes=tile_sizes)

                    # Process each tile
                    for (k, mask) in zip(tile_order, masks):
                        m_tile = (mask.cpu().numpy() == 1).astype(np.uint8)
                        
                        # Largest component for tile
                        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(m_tile, connectivity=8)
                        if num_labels > 1:
                            largest_label = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
                            m_tile = (labels == largest_label).astype(np.uint8)
                        
                        # Blend tile
                        color_overlay = np.zeros_like(tiles[k])
                        color_overlay[m_tile == 1] = overlay_color
                        tiles[k] = cv2.addWeighted(tiles[k], 1.0, color_overlay, alpha, 0)

                    # Rejoin tiles
                    processed_frames.append(join_quad(tiles))

                return processed_frames

        except Exception as e:
            print(f"⚠️ Ошибка при обработке батча: {e}. Возвращаем оригинальные кадры.")
            return frames  # Fallback

    def _add_audio(self, input_video: str, output_video: str):
        """
        Добавляет аудио из исходного видео.
        """
        temp_output = output_video + ".temp_no_audio.mp4"
        os.rename(output_video, temp_output)

        cmd = [
            'ffmpeg', '-y',
            '-i', temp_output,
            '-i', input_video,
            '-c:v', 'copy',           # не перекодируем видео
            '-c:a', 'aac',            # аудио в AAC
            '-map', '0:v', '-map', '1:a',
            '-shortest',
            output_video
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            print("🎵 Аудио успешно добавлено.")
        except subprocess.CalledProcessError as e:
            print(f"⚠️ Не удалось добавить аудио: {e.stderr.decode()}")
            # Возвращаем без аудио
            os.rename(temp_output, output_video)
        finally:
            if os.path.exists(temp_output):
                os.remove(temp_output)

    def has_audio(self, video_path: str) -> bool:
        """
        Проверяет, содержит ли видео аудио-дорожку.
        """
        cmd = [
            'ffprobe', '-v', 'quiet', '-print_format', 'json',
            '-show_streams', video_path
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                return False
            import json
            info = json.loads(result.stdout)
            return any(stream.get('codec_type') == 'audio' for stream in info.get('streams', []))
        except Exception as e:
            print(f"⚠️ Ошибка при проверке аудио: {e}")
            return False
