import os, sys
from app.core.utils import find_project_root

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import numpy as np
import cv2
import torch
from ultralytics import SAM
from PIL import Image
import requests
from app.core.config import SEGFORMER_DIR, SEGFORMER_DIR_TRAINED, IMAGE_EXTS

class SAMService:
    def __init__(self, config):
        self.config = config
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        # Determine weight key and path
        weight_key = "cuda_weights" if self.device == "cuda" else "cpu_weights"
        weight_path = self.config.get(weight_key)

        # Check if weight file exists, attempt to download if missing
        if not os.path.isfile(weight_path):
            print(f"Warning: Weights file not found at {weight_path}. Attempting to download...")
            os.makedirs(os.path.dirname(weight_path), exist_ok=True)
            weight_urls = {
                "sam2.1_t.pt": "https://github.com/ultralytics/assets/releases/download/v8.3.0/sam2.1_t.pt",
                "sam2.1_l.pt": "https://github.com/ultralytics/assets/releases/download/v8.3.0/sam2.1_l.pt"
            }
            weight_filename = os.path.basename(weight_path)
            if weight_filename in weight_urls:
                try:
                    response = requests.get(weight_urls[weight_filename], stream=True)
                    response.raise_for_status()
                    with open(weight_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                    print(f"Downloaded {weight_filename} to {weight_path}")
                except requests.RequestException as e:
                    raise FileNotFoundError(
                        f"Failed to download {weight_filename} from {weight_urls[weight_filename]}: {e}")
            else:
                raise FileNotFoundError(f"Weights file not found and no download URL available: {weight_path}")

        self.model = SAM(weight_path)

        self.points = []
        self.labels = []
        self.current_idx = 0
        self.current_mode = 1
        self.frames_dir = None
        self.output_dir = None
        self.frame_files = []
        self.current_mask = None

        # For video frame handling
        self.current_video_frames = []
        self.current_video_start_idx = 0

    def initialize_session(self, frames_dir: str, output_dir: str):
        """Initialize a new segmentation session"""
        self.frames_dir = frames_dir
        self.output_dir = output_dir
        os.makedirs(frames_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)

        if os.path.exists(frames_dir):
            self.frame_files = sorted([f for f in os.listdir(frames_dir) if f.lower().endswith((".jpg", ".jpeg", ".png"))])
        else:
            print(f"Warning: {frames_dir} does not exist or is empty, frame_files will be empty.")
            self.frame_files = []
        self.refresh_frames()
        self.reset_points()

    def refresh_frames(self) -> int:
        """(Re)scan frames_dir and update self.frame_files using unified IMAGE_EXTS."""
        if not self.frames_dir or not os.path.exists(self.frames_dir):
            self.frame_files = []
            return 0
        self.frame_files = sorted([
            f for f in os.listdir(self.frames_dir)
            if os.path.splitext(f.lower())[1] in IMAGE_EXTS
        ])
        # Clamp current_idx
        if self.frame_files:
            self.current_idx = min(self.current_idx, len(self.frame_files) - 1)
        else:
            self.current_idx = 0
        return len(self.frame_files)

    def set_current_video_frames(self, current_frames: list):
        """Set frames for video processing mode"""
        self.current_video_frames = current_frames
        self.current_idx = 0
        self.reset_points()

    def get_current_video_frame_count(self):
        """Get total number of video frames"""
        return len(self.current_video_frames)

    def load_current_video_image(self, video_idx: int):
        """Load image from current video frames"""
        if not self.frames_dir:
            raise ValueError("Frames directory not initialized")
        if not self.current_video_frames or video_idx >= len(self.current_video_frames):
            raise IndexError(
                f"Video frame index {video_idx} out of range. Available frames: {len(self.current_video_frames)}")

        frame_filename = self.current_video_frames[video_idx]
        path = os.path.join(self.frames_dir, frame_filename)

        if not os.path.exists(path):
            raise FileNotFoundError(f"Frame file not found: {path}")

        # Update current_idx to match frame_files if possible
        if frame_filename in self.frame_files:
            self.current_idx = self.frame_files.index(frame_filename)

        img = cv2.imread(path)
        if img is None:
            raise ValueError(f"Failed to load image: {path}")
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def load_image(self, idx: int):
        """Load image by index from frame_files"""
        if not self.frames_dir:
            raise ValueError("Frames directory not initialized")
        if not self.frame_files or idx >= len(self.frame_files):
            raise IndexError(f"Frame index {idx} out of range. Available frames: {len(self.frame_files)}")

        path = os.path.join(self.frames_dir, self.frame_files[idx])

        if not os.path.exists(path):
            raise FileNotFoundError(f"Frame file not found: {path}")

        img = cv2.imread(path)
        if img is None:
            raise ValueError(f"Failed to load image: {path}")
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def draw_points(self, image, points, labels):
        """Draw annotation points on image"""
        if image is None:
            raise ValueError("Image is None")
        img = image.copy()
        for (x, y), l in zip(points, labels):
            color = (0, 0, 255) if l == 1 else (255, 0, 0)  # Green for positive, red for negative
            cv2.circle(img, (int(x), int(y)), 4, color, -1)
            cv2.circle(img, (int(x), int(y)), 12, color, 2)
        return img

    def add_point(self, x: int, y: int):
        """Add annotation point"""
        # Check if we're in video mode or regular mode
        if self.current_video_frames:
            # Video mode - check current video frames
            if not self.current_video_frames:
                raise ValueError("No video frames available")
            current_frame_idx = self.current_idx
            if current_frame_idx >= len(self.current_video_frames):
                raise ValueError("Current video frame index out of range")
            img = self.load_current_video_image(current_frame_idx).copy()
        else:
            # Regular mode - check frame_files
            if not self.frame_files or self.current_idx >= len(self.frame_files):
                raise ValueError("No valid frame to add point")
            img = self.load_image(self.current_idx).copy()

        self.points.append([x, y])
        self.labels.append(self.current_mode)
        return self.draw_points(img, self.points, self.labels)

    def _calculate_masks_data(self):
        """Calculate mask data using SAM model"""
        # Determine which image to use
        if self.current_video_frames:
            if self.current_idx >= len(self.current_video_frames):
                raise ValueError("Current video frame index out of range")
            base = self.load_current_video_image(self.current_idx).copy()
        else:
            if not self.frame_files or self.current_idx >= len(self.frame_files):
                raise ValueError("No valid frame to calculate mask")
            base = self.load_image(self.current_idx).copy()

        if not self.points:
            raise ValueError("No points provided for segmentation")

        pc = np.array(self.points)
        pl = np.array(self.labels)

        results = self.model.predict(
            source=base,
            points=pc.tolist() if pc.size > 0 else None,
            labels=pl.tolist() if pl.size > 0 else None,
        )

        if not results or not hasattr(results[0], 'masks') or not results[0].masks:
            raise ValueError("No masks generated by SAM model")

        result = results[0]
        masks = result.masks.data.cpu().numpy()
        scores = (
            result.masks.conf.cpu().numpy()
            if hasattr(result.masks, 'conf') and result.masks.conf is not None
            else np.array([1.0] * len(masks))
        )

        confidence_threshold = 0.4
        min_area = 200

        combined_mask = np.zeros(base.shape[:2], dtype=bool)

        for mask, score in zip(masks, scores):
            if score >= confidence_threshold:
                mask_uint8 = (mask * 255).astype(np.uint8)
                n_labels, labels_im, stats, _ = cv2.connectedComponentsWithStats(
                    mask_uint8, connectivity=8
                )
                large_components_mask = np.zeros_like(mask_uint8, dtype=bool)
                for label in range(1, n_labels):
                    area = stats[label, cv2.CC_STAT_AREA]
                    if area >= min_area:
                        large_components_mask[labels_im == label] = True
                combined_mask |= large_components_mask

        self.current_mask = combined_mask
        return base

    def calculate_mask(self):
        """Calculate and visualize mask"""
        base = self._calculate_masks_data()

        overlay = base.copy()
        alpha = 0.4
        fill = np.array([0, 255, 0], dtype=np.uint8)  # Green overlay
        idxs = self.current_mask.astype(bool)
        overlay[idxs] = (alpha * fill + (1 - alpha) * overlay[idxs]).astype(np.uint8)

        return self.draw_points(overlay, self.points, self.labels)

    def save_mask(self):
        """Save current mask to file"""
        if not self.points:
            return "Нет точек для сохранения"

        try:
            if not hasattr(self, 'current_mask') or self.current_mask is None:
                self._calculate_masks_data()

            if self.current_mask is None or self.current_mask.sum() == 0:
                return "Маска пустая или не вычислена"

            mask = self.current_mask

            # Determine filename based on mode
            if self.current_video_frames:
                if self.current_idx >= len(self.current_video_frames):
                    return "Некорректный индекс видео кадра"
                frame_filename = self.current_video_frames[self.current_idx]
            else:
                if not self.frame_files or self.current_idx >= len(self.frame_files):
                    return "Некорректный индекс кадра"
                frame_filename = self.frame_files[self.current_idx]

            # Generate mask filename
            base_name = os.path.splitext(frame_filename)[0]
            filename = f"{base_name}_mask.png"
            path = os.path.join(self.output_dir, filename)

            os.makedirs(os.path.dirname(path), exist_ok=True)

            # Save as binary mask (0 or 255)
            Image.fromarray((mask * 255).astype(np.uint8)).save(path)
            return f"Сохранено: {filename}"
        except Exception as e:
            return f"Ошибка сохранения: {str(e)}"

    def reset_points(self):
        """Reset annotation points and return current image"""
        self.points = []
        self.labels = []
        self.current_mask = None

        try:
            if self.current_video_frames:
                if 0 <= self.current_idx < len(self.current_video_frames):
                    return self.load_current_video_image(self.current_idx)
                return None
            else:
                if self.frames_dir and self.frame_files and 0 <= self.current_idx < len(self.frame_files):
                    return self.load_image(self.current_idx)
                return None
        except Exception:
            return None

    def set_mode(self, mode: int):
        """Set annotation mode (1 for positive, 0 for negative)"""
        self.current_mode = mode
        return f"Режим: {'добавить' if mode == 1 else 'вычесть'}"

    def delete_all_masks(self):
        """Delete all saved masks"""
        if not self.output_dir or not os.path.exists(self.output_dir):
            return "Директория масок не найдена"

        mask_files = [f for f in os.listdir(self.output_dir) if f.endswith('_mask.png')]
        deleted_count = 0

        for mask_file in mask_files:
            mask_path = os.path.join(self.output_dir, mask_file)
            try:
                os.remove(mask_path)
                deleted_count += 1
            except Exception as e:
                print(f"Ошибка удаления {mask_file}: {e}")

        return f"Удалено масок: {deleted_count}" if deleted_count > 0 else "Маски не найдены"

    def navigate_frame(self, direction: int):
        """Navigate to next/previous frame"""
        if self.current_video_frames:
            total_frames = len(self.current_video_frames)
        else:
            total_frames = len(self.frame_files)

        if total_frames == 0:
            return None, "Нет доступных кадров"

        new_idx = self.current_idx + direction
        new_idx = max(0, min(new_idx, total_frames - 1))

        if new_idx != self.current_idx:
            self.current_idx = new_idx
            self.reset_points()
            return self.reset_points(), f"Кадр {new_idx + 1}/{total_frames}"
        else:
            return None, f"Кадр {self.current_idx + 1}/{total_frames} (граница)"
