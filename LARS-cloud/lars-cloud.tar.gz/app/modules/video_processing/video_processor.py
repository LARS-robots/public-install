import cv2
import os
from typing import Iterable, List, Optional, Set
from app.core.config import FRAMES_DIR
from app.core.config_loader import load_runtime_config
from app.modules.video_processing.eis.splitter import SplitMode, split_stereo, split_quad

class VideoProcessor:
    def __init__(self):
        self.frames_dir = FRAMES_DIR  # Use FRAMES_DIR from config
        self.current_video_frames = []  # Кадры текущего видео
        self.frame_count = 0
        self.selected_layout = None  # Add this to store the chosen layout

    @staticmethod
    def _normalize_camera_type(camera_type: str) -> str:
        """
        Accept Russian labels ('Моно','Стерео','Квадро'), or English-ish aliases ('mono','stereo','quad*').
        Return Russian label used by existing code paths to preserve behavior.
        """
        if not camera_type:
            return "моно"
        ct = camera_type.strip().lower()
        if ct in ("моно", "mono"):
            return "моно"
        if ct in ("стерео", "stereo", "stereo_h", "stereo_v", "stereo_horizontal", "stereo_vertical"):
            return "стерео"
        if ct in ("квадро", "quad", "quad2x2", "quad_2x2"):
            return "квадро"
        return camera_type  # pass-through (already Russian)

    def _indices_every_n_seconds(self, cap, step_s: float) -> Set[int]:
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        if fps <= 0.0:
            # Fallback to 1 fps if unknown
            fps = 1.0
        length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if step_s <= 0:
            return set(range(length))
        step = max(1, int(round(fps * step_s)))
        return set(range(0, length, step))

    def _indices_every_n_frames(self, cap, step_f: int) -> Set[int]:
        length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if step_f <= 0:
            return set(range(length))
        return set(range(0, length, step_f))

    def _indices_from_timestamps(self, cap, ts_list: List[float]) -> Set[int]:
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        idxs = set()
        if fps > 0:
            for t in ts_list:
                idxs.add(min(max(0, int(round(t * fps))), max(0, length - 1)))
            return idxs
        # If FPS is unknown, seek by time (best effort)
        for t in ts_list:
            cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, float(t)) * 1000.0)
            fidx = int(cap.get(cv2.CAP_PROP_POS_FRAMES) or 0)
            idxs.add(fidx)
        return idxs

    def _indices_scene_change(self, cap, threshold: float) -> Set[int]:
        """
        Simple scene-change picker using gray histogram deltas (lightweight, no heavy deps).
        threshold ~0.30 means "30% relative change".
        """
        idxs = set()
        prev_hist = None
        length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        for i in range(length):
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            hist = cv2.calcHist([gray], [0], None, [64], [0, 256])
            cv2.normalize(hist, hist)
            if prev_hist is not None:
                diff = cv2.compareHist(prev_hist, hist, cv2.HISTCMP_BHATTACHARYYA)  # 0..1
                if diff >= float(threshold):
                    idxs.add(i)
            prev_hist = hist
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        return idxs

    def extract_frames_by_camera_type(self, video_path: str, camera_type: str, fps: int = 1, layout: SplitMode = None):
        """Извлечение кадров с учетом типа камеры"""
        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return "Ошибка: Не удалось открыть видео"
            
            video_fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
            
            # Load config and determine frame indices
            try:
                cfg = load_runtime_config()  # centralized config (validated)
                fe = cfg["frame_extraction"]
            except Exception as e:
                print(f"Warning: Config loading failed: {e}, using defaults")
                fe = {"enabled": False}

            # Build target set of frame indices from config; default keeps old behavior (fps argument)
            target_idxs: Optional[Set[int]] = None
            if fe.get("enabled", False):
                mode = fe.get("mode", "every_n_seconds").lower()
                try:
                    if mode == "every_n_seconds":
                        target_idxs = self._indices_every_n_seconds(cap, float(fe.get("every_n_seconds", 1.0)))
                    elif mode == "every_n_frames":
                        target_idxs = self._indices_every_n_frames(cap, int(fe.get("every_n_frames", 0)))
                    elif mode == "timestamps":
                        target_idxs = self._indices_from_timestamps(cap, [float(x) for x in fe.get("timestamps", [])])
                    elif mode == "scene_change" or fe.get("scene_change", {}).get("enabled", False):
                        target_idxs = self._indices_scene_change(cap, float(fe.get("scene_change", {}).get("threshold", 0.3)))
                except Exception as e:
                    print(f"Warning: Frame selection failed: {e}, falling back to legacy")
                    target_idxs = None
                    
            if target_idxs is None:
                # Legacy path: use fps arg
                frame_interval = int(video_fps / fps) if fps > 0 and video_fps > 0 else max(1, int(1 / max(fps, 1)))
                target_idxs = set(range(0, int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0), max(1, frame_interval)))

            frame_count = 0
            saved_count = 0
            self.layout = layout
            # Normalize camera type to match existing branches
            camera_type = self._normalize_camera_type(camera_type)

            # Convert camera type to SplitMode and store it
            if camera_type == "моно":
                self.selected_layout = SplitMode.MONO
            elif camera_type == "стерео":
                self.selected_layout = SplitMode.STEREO_H
            elif camera_type == "квадро":
                self.selected_layout = SplitMode.QUAD_2x2
            else:
                self.selected_layout = SplitMode.MONO

            actual_layout = self.selected_layout

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                    
                if frame_count in target_idxs:
                    if camera_type == "моно":  # Изменено с "Моно" на "моно"
                        # Сохраняем весь кадр как есть
                        filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}.jpg")
                        cv2.imwrite(filename, frame)
                        saved_count += 1
                        
                    elif camera_type == "стерео":  # Изменено с "Стерео" на "стерео"
                        # Автоматически определяем layout или используем переданный
                        h, w = frame.shape[:2]
                        actual_layout = self.selected_layout
                        
                        if actual_layout in (SplitMode.STEREO_H, SplitMode.STEREO_V):
                            # Разделяем стерео кадр с помощью split_stereo
                            stereo_parts = split_stereo(frame, actual_layout)
                            
                            try:
                                if actual_layout == SplitMode.STEREO_H:
                                    # Горизонтальное stereo: берем ЛЕВУЮ половину
                                    key = "left"  # ИСПРАВЛЕНО: было "right"
                                    part_frame = stereo_parts.get(key, frame)
                                    filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}_left.jpg")
                                else:  # STEREO_V
                                    # Вертикальное stereo: берем ВЕРХНЮЮ половину
                                    key = "top"   # ИСПРАВЛЕНО: было "bottom"
                                    part_frame = stereo_parts.get(key, frame)
                                    filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}_top.jpg")
                                
                                cv2.imwrite(filename, part_frame)
                                saved_count += 1
                                
                            except Exception as e:
                                # На всякий случай — сохраним исходный кадр
                                filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}_fallback.jpg")
                                cv2.imwrite(filename, frame)
                                saved_count += 1
                        else:
                            # Fallback: если не stereo layout, сохраняем весь кадр
                            filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}.jpg")
                            cv2.imwrite(filename, frame)
                            saved_count += 1
                            
                    elif camera_type == "квадро":  # Изменено с "Квадро" на "квадро"
                        # Разделяем на 4 части и сохраняем все
                        quad_parts = split_quad(frame)
                        for part_name, part_frame in quad_parts.items():
                            filename = os.path.join(FRAMES_DIR, f"frame_{saved_count:06d}_{part_name}.jpg")
                            cv2.imwrite(filename, part_frame)
                        saved_count += 4  # Увеличиваем счетчик на 4, так как сохранили 4 части
                        
                frame_count += 1
                
            cap.release()
            self.frame_count = saved_count
        
            return f"Успешно обработано {frame_count} кадров, сохранено {saved_count} изображений"
            
        except Exception as e:
            return f"Ошибка при извлечении кадров: {str(e)}"

    def extract_frames(self, video_path: str, fps: int = 1, frames_dir: str = None):
        """Extract frames from video with incremental numbering"""
        if frames_dir is None:
            frames_dir = self.frames_dir

        os.makedirs(frames_dir, exist_ok=True)

        # Найти последний номер кадра в папке
        existing_frames = [f for f in os.listdir(frames_dir) if f.startswith('frame_') and f.endswith('.jpg')]
        if existing_frames:
            frame_numbers = []
            for f in existing_frames:
                try:
                    num = int(f.replace('frame_', '').replace('.jpg', ''))
                    frame_numbers.append(num)
                except ValueError:
                    continue
            start_frame_num = max(frame_numbers) + 1 if frame_numbers else 0
        else:
            start_frame_num = 0

        cap = cv2.VideoCapture(video_path)
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(video_fps / fps)

        frame_count = 0
        saved_count = 0
        self.current_video_frames = []  # Сбросить кадры текущего видео

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % frame_interval == 0:
                frame_filename = f"frame_{start_frame_num + saved_count:04d}.jpg"
                frame_path = os.path.join(frames_dir, frame_filename)
                cv2.imwrite(frame_path, frame)

                # Добавить в список кадров текущего видео
                self.current_video_frames.append(frame_filename)
                saved_count += 1

            frame_count += 1

        cap.release()
        return f"Извлечено {saved_count} кадров (номера {start_frame_num}-{start_frame_num + saved_count - 1})"

    def get_current_video_frames(self):
        """Получить список кадров текущего видео"""
        return self.current_video_frames

    def get_frame_count(self):
        """Get number of extracted frames"""
        if not os.path.exists(self.frames_dir):
            return 0
        return len([f for f in os.listdir(self.frames_dir) if f.endswith('.jpg')])

    def get_selected_layout(self) -> SplitMode:
        """Get the layout mode selected during frame extraction"""
        layout = self.selected_layout or SplitMode.MONO
        print(f"🎯 VideoProcessor.get_selected_layout() returning: {layout}")
        return layout