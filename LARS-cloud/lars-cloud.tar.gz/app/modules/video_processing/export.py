# app/modules/export.py
from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Dict, Tuple

import onnx
from onnx import checker
import onnxruntime as ort

from ultralytics import YOLO

import torch
from transformers import AutoImageProcessor, AutoModelForSemanticSegmentation
from optimum.exporters.onnx import export as hf_export
from optimum.exporters.tasks import TasksManager


def _ensure_dir(p: str | Path) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p


def validate_onnx(model_path: str) -> Tuple[bool, str]:
    """
    Быстрая проверка ONNX без инференса:
    1) onnx.checker.check_model()
    2) Загрузка графа в onnxruntime.InferenceSession (без запуска)
    """
    try:
        m = onnx.load(model_path)
        checker.check_model(m)  # проверка структуры/ops
        # Попробуем открыть с ORT. Провайдеры выбираем по доступности CUDA.
        providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if ort.get_device() == "GPU" else ["CPUExecutionProvider"]
        _ = ort.InferenceSession(model_path, providers=providers)
        return True, "OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def export_yolo_to_onnx(ultralytics_dir: str, weights: str, out_dir: str, opset: int = 17) -> Tuple[str, str]:
    """
    Экспорт YOLO (ultralytics) в ONNX.
    :param ultralytics_dir: каталог с весами YOLO (ULTRALYTICS_DIR из config)
    :param weights: имя файла весов, например 'yolo11n.pt'
    :param out_dir: папка для вывода
    :return: (путь к .onnx, текст результата валидации)
    """
    out_dir = _ensure_dir(out_dir)
    model_path = Path(ultralytics_dir) / weights
    if not model_path.exists():
        # Подстраховка: возьмем первый .pt из каталога
        pts = list(Path(ultralytics_dir).glob("*.pt"))
        if not pts:
            raise FileNotFoundError(f"Не найден файл весов {weights} и нет *.pt в {ultralytics_dir}")
        model_path = pts[0]

    model = YOLO(str(model_path))
    onnx_export = model.export(
        format="onnx",
        opset=opset,
        simplify=True,
        dynamic=True,
        verbose=False
    )    

    # Ultralytics возвращает путь к файлу; перенесём в out_dir/models с осмысленным именем
    src = Path(onnx_export)
    dst = out_dir / f"{src.stem}.onnx"
    if src.resolve() != dst.resolve():
        shutil.move(str(src), str(dst))
    ok, msg = validate_onnx(str(dst))
    return str(dst), ("✅ Валидация прошла" if ok else f"❌ Проблема: {msg}")


def export_segformer_to_onnx(model_dir: str, out_dir: str, opset: int = 17, input_size: tuple[int, int] = (512, 512)) -> Tuple[str, str]:
    """
    Экспорт стандартного SegFormer (transformers) в ONNX через Optimum.
    :param model_dir: id/путь модели (например 'nvidia/segformer-b0-finetuned-ade-512-512' или локальная папка)
    :param out_dir: папка для вывода
    :param input_size: (H, W) для фиктивного входа
    :return: (путь к .onnx, текст результата валидации)
    """
    out_dir = _ensure_dir(out_dir)
    onnx_path = Path(out_dir) / "segformer.onnx"

    # Загрузка модели и процессора
    device = "cuda" if torch.cuda.is_available() else "cpu"
    processor = AutoImageProcessor.from_pretrained(model_dir)  # (зарезервировано на будущее)
    model = AutoModelForSemanticSegmentation.from_pretrained(model_dir).to(device)
    model.eval()

    # Конфиг экспорта под задачу
    exporter_cfg_ctor = TasksManager.get_exporter_config_constructor(
        model=model,
        exporter="onnx",
        task="semantic-segmentation"
    )
    onnx_config = exporter_cfg_ctor(model.config)

    # Dummy input (batch=1)
    import numpy as np
    h, w = input_size
    dummy = np.zeros((1, 3, h, w), dtype=np.float32)
    inputs = {"pixel_values": torch.from_numpy(dummy)}

    # Экспорт
    hf_export(
        model=model,
        config=onnx_config,
        opset=opset,
        output=onnx_path)

    ok, msg = validate_onnx(str(onnx_path))
    return str(onnx_path), ("✅ Валидация прошла" if ok else f"❌ Проблема: {msg}")


def export_both_models(
    ultralytics_dir: str,
    yolo_weights: str,
    segformer_dir: str,
    output_dir: str,
    opset: int = 17
) -> Dict[str, Tuple[str, str]]:
    """
    Экспортирует YOLO и SegFormer в ONNX и валидирует их.
    Возвращает словарь { 'yolo': (path, status), 'segformer': (path, status) }
    """
    models_dir = _ensure_dir(Path(output_dir) / "models")
    results: Dict[str, Tuple[str, str]] = {}

    # YOLO
    yolo_path, yolo_status = export_yolo_to_onnx(
        ultralytics_dir=ultralytics_dir,
        weights=yolo_weights,
        out_dir=str(models_dir),
        opset=opset
    )
    results["yolo"] = (yolo_path, yolo_status)

    # SegFormer (стандартный)
    segformer_path, segformer_status = export_segformer_to_onnx(
        model_dir=segformer_dir,
        out_dir=str(models_dir),
        opset=opset
    )
    results["segformer"] = (segformer_path, segformer_status)

    return results
