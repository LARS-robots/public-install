import torch
import os
from ultralytics import YOLO
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
from optimum.onnxruntime import ORTModelForSemanticSegmentation
from typing import Dict, Tuple

def export_yolo_to_onnx(ultralytics_dir: str, weights: str, output_dir: str, opset: int = 17) -> Tuple[str, str]:
    """Экспорт YOLO модели в ONNX"""
    try:
        weights_path = os.path.join(ultralytics_dir, weights)
        if not os.path.exists(weights_path):
            return "", f"Веса не найдены: {weights_path}"
        
        # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Принудительно CPU для экспорта
        device = 'cpu'  # Всегда экспортируем с CPU
        print(f"🔄 Loading YOLO model on {device} for ONNX export...")
        
        model = YOLO(weights_path)
        
        # Переносим модель на CPU перед экспортом
        if hasattr(model.model, 'to'):
            model.model.to(device)
        
        output_path = os.path.join(output_dir, f"{os.path.splitext(weights)[0]}.onnx")
        
        # Экспорт с явным указанием device
        model.export(
            format='onnx',
            opset=opset,
            device=device,  # Явно указываем CPU
            dynamic=False,
            simplify=True,
            imgsz=640
        )
        
        # YOLO может сохранить в текущей папке, переносим если нужно
        potential_onnx = weights_path.replace('.pt', '.onnx')
        if os.path.exists(potential_onnx) and potential_onnx != output_path:
            import shutil
            shutil.move(potential_onnx, output_path)
            
        if os.path.exists(output_path):
            return output_path, "✅ Успешно экспортирован"
        else:
            return "", "❌ Файл ONNX не создан"
            
    except Exception as e:
        print(f"❌ YOLO export error: {e}")
        return "", f"Ошибка: {str(e)}"

def export_segformer_to_onnx(segformer_dir: str, output_dir: str, opset: int = 17) -> Tuple[str, str]:
    """Экспорт SegFormer модели в ONNX"""
    try:
        if not os.path.exists(segformer_dir) and not segformer_dir.startswith("nvidia/"):
            return "", f"Папка модели не найдена: {segformer_dir}"
        
        # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Принудительно CPU
        device = 'cpu'
        print(f"🔄 Loading SegFormer model on {device} for ONNX export...")
        
        # Загружаем модель на CPU
        model = SegformerForSemanticSegmentation.from_pretrained(
            segformer_dir,
            torch_dtype=torch.float32  # Явно float32 для совместимости
        ).to(device)
        
        processor = SegformerImageProcessor.from_pretrained(segformer_dir)
        
        # Создаем пример входных данных на том же устройстве
        dummy_input = torch.randn(1, 3, 512, 512, dtype=torch.float32, device=device)
        
        output_path = os.path.join(output_dir, "segformer_model.onnx")
        
        print(f"🔄 Exporting SegFormer to ONNX...")
        
        # Экспорт с правильными устройствами
        torch.onnx.export(
            model,
            dummy_input,
            output_path,
            export_params=True,
            opset_version=opset,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['logits'],
            dynamic_axes={
                'input': {0: 'batch_size', 2: 'height', 3: 'width'},
                'logits': {0: 'batch_size', 2: 'height', 3: 'width'}
            }
        )
        
        if os.path.exists(output_path):
            return output_path, "✅ Успешно экспортирован"
        else:
            return "", "❌ Файл ONNX не создан"
            
    except Exception as e:
        print(f"❌ SegFormer export error: {e}")
        import traceback
        traceback.print_exc()
        return "", f"Ошибка: {str(e)}"

# Альтернативный метод через Optimum (если основной не работает)
def export_segformer_via_optimum(segformer_dir: str, output_dir: str) -> Tuple[str, str]:
    """Экспорт через библиотеку Optimum (может быть более стабильным)"""
    try:
        from optimum.onnxruntime import ORTModelForSemanticSegmentation
        
        print(f"🔄 Exporting SegFormer via Optimum...")
        
        # Экспорт через Optimum
        ort_model = ORTModelForSemanticSegmentation.from_pretrained(
            segformer_dir, 
            export=True,
            device='cpu'  # Явно CPU
        )
        
        output_path = os.path.join(output_dir, "segformer_optimum.onnx")
        ort_model.save_pretrained(output_path)
        
        # Optimum создает папку, ищем .onnx файл внутри
        onnx_files = []
        if os.path.exists(output_path):
            for root, dirs, files in os.walk(output_path):
                onnx_files.extend([os.path.join(root, f) for f in files if f.endswith('.onnx')])
        
        if onnx_files:
            return onnx_files[0], "✅ Успешно экспортирован (Optimum)"
        else:
            return "", "❌ ONNX файл не найден"
            
    except Exception as e:
        print(f"❌ Optimum export error: {e}")
        return "", f"Ошибка Optimum: {str(e)}"

def export_both_models(ultralytics_dir: str, yolo_weights: str, segformer_dir: str, 
                      output_dir: str, opset: int = 17) -> Dict[str, Tuple[str, str]]:
    """Экспорт обеих моделей с обработкой ошибок"""
    
    os.makedirs(output_dir, exist_ok=True)
    results = {}
    
    # YOLO экспорт
    print("🚀 Starting YOLO export...")
    yolo_path, yolo_status = export_yolo_to_onnx(ultralytics_dir, yolo_weights, output_dir, opset)
    results['yolo'] = (yolo_path, yolo_status)
    
    # SegFormer экспорт (с fallback на Optimum)
    print("🚀 Starting SegFormer export...")
    seg_path, seg_status = export_segformer_to_onnx(segformer_dir, output_dir, opset)
    
    # Если основной метод не сработал, пробуем Optimum
    if not seg_path and "nvidia/" in segformer_dir:
        print("🔄 Trying Optimum fallback...")
        seg_path, seg_status = export_segformer_via_optimum(segformer_dir, output_dir)
    
    results['segformer'] = (seg_path, seg_status)
    
    return results