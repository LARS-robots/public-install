# app/modules/video_processing/eis/eis.py
# filepath: /home/master/PycharmProjects/LARS/LARS-cloud/app/modules/video_processing/eis/eis.py

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple, Optional
from .virtual_gimbal import VirtualGimbal, VGParams
import cv2
import numpy as np
import math

@dataclass
class EISParams:
    hfov_deg: float = 84.0
    downscale_width: int = 640
    gftt_max_corners: int = 800
    lk_win: int = 21
    ransac_thresh: float = 3.0  # pixels
    ema_alpha_pos: float = 0.20
    ema_alpha_rot: float = 0.20
    safety_crop_percent: int = 15
    show_debug: bool = False  # рисовать фичи/траекторию
    # NEW: опциональные параметры виртуального кардана (feature-flag)
    virtual_gimbal: Optional[Dict] = field(default=None)

@dataclass
class EISMetrics:
    fps: float
    n_features_avg: float
    n_inliers_avg: float
    jitter_before_pct: float
    jitter_after_pct: float
    params: Dict

def _to_gray_small(frame_bgr: np.ndarray, w_small: int) -> Tuple[np.ndarray, float]:
    h, w = frame_bgr.shape[:2]
    scale = w_small / float(w)
    small = cv2.resize(frame_bgr, (w_small, int(round(h * scale))), interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    return gray, scale

def _estimate_affine(prev_gray: np.ndarray, gray: np.ndarray,
                     max_corners: int, lk_win: int, ransac_thresh: float) -> Tuple[float, float, float, int, int]:
    # GFTT
    pts0 = cv2.goodFeaturesToTrack(prev_gray, maxCorners=max_corners, qualityLevel=0.01, minDistance=7, blockSize=7)
    if pts0 is None or len(pts0) < 6:
        return 0.0, 0.0, 0.0, 0, 0
    # PyrLK
    pts1, st, err = cv2.calcOpticalFlowPyrLK(prev_gray, gray, pts0, None, winSize=(lk_win, lk_win), maxLevel=3,
                                             criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    good0 = pts0[st.flatten() == 1]
    good1 = pts1[st.flatten() == 1] if pts1 is not None else None
    if good1 is None or len(good0) < 6 or len(good1) < 6:
        return 0.0, 0.0, 0.0, len(pts0), 0
    # Глобальная аффинная модель с RANSAC
    M, inliers = cv2.estimateAffinePartial2D(good0, good1, method=cv2.RANSAC, ransacReprojThreshold=ransac_thresh)
    if M is None:
        return 0.0, 0.0, 0.0, len(good0), 0
    # Извлекаем dx, dy, dθ (радианы)
    dx = float(M[0, 2])
    dy = float(M[1, 2])
    dtheta = float(math.atan2(M[1, 0], M[0, 0]))
    nin = int(inliers.sum()) if inliers is not None else 0
    return dx, dy, dtheta, len(good0), nin

def _ema(prev: float, cur: float, alpha: float) -> float:
    return alpha * cur + (1.0 - alpha) * prev

def _compose_matrix(dx: float, dy: float, dtheta: float) -> np.ndarray:
    c = math.cos(dtheta); s = math.sin(dtheta)
    return np.array([[c, -s, dx],
                     [s,  c, dy]], dtype=np.float32)

def _trajectory_smooth(motions: List[Tuple[float, float, float]], alpha_pos: float, alpha_rot: float):
    traj = []
    x=y=theta=0.0
    for dx, dy, dth in motions:
        x += dx; y += dy; theta += dth
        traj.append((x, y, theta))
    # EMA
    sx = sy = st = 0.0
    smooth = []
    for (x, y, t) in traj:
        sx = _ema(sx, x, alpha_pos)
        sy = _ema(sy, y, alpha_pos)
        st = _ema(st, t, alpha_rot)
        smooth.append((sx, sy, st))
    # разница — корректирующее движение
    corr = []
    for (x, y, t), (sx, sy, stheta) in zip(traj, smooth):
        corr.append((sx - x, sy - y, stheta - t))
    return traj, smooth, corr

def _rms(values: List[float]) -> float:
    if not values:
        return 0.0
    arr = np.array(values, dtype=np.float64)
    return float(np.sqrt(np.mean(arr * arr)))

def _overlay_text(frame_bgr: np.ndarray, text: str) -> np.ndarray:
    out = frame_bgr.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 28), (0,0,0), thickness=-1)
    cv2.putText(out, text, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1, cv2.LINE_AA)
    return out

class EIS:
    def __init__(self, params: EISParams):
        self.p = params

    def _build_virtual_gimbal(self, width_px: int, fps: float) -> Optional[VirtualGimbal]:
        """Создаёт виртуальный кардан из конфига или возвращает None если отключён"""
        vgcfg = (self.p.virtual_gimbal or {})
        if not vgcfg or not vgcfg.get("enabled", False):
            return None
        
        # Пороговые единицы:
        # X/Y — пиксели фулл-рез; θ — радианы.
        use_percent = bool(vgcfg.get("use_percent_hfov", True))
        hfov_deg = float(vgcfg.get("hfov_deg", self.p.hfov_deg))
        
        # dead-zone пороги
        if use_percent:
            enter_xy = float(vgcfg.get("enter_xy_percent", 0.12)) * 0.01 * width_px
            exit_xy  = float(vgcfg.get("exit_xy_percent",  0.08)) * 0.01 * width_px
            enter_th = math.radians(float(vgcfg.get("enter_theta_percent", 0.12)) * 0.01 * hfov_deg)
            exit_th  = math.radians(float(vgcfg.get("exit_theta_percent",  0.08)) * 0.01 * hfov_deg)
        else:
            enter_xy = float(vgcfg.get("enter_xy_px", 0.0))
            exit_xy  = float(vgcfg.get("exit_xy_px", 0.0))
            enter_th = math.radians(float(vgcfg.get("enter_theta_deg", 0.0)))
            exit_th  = math.radians(float(vgcfg.get("exit_theta_deg", 0.0)))
        
        # динамика/лимиты
        p_xy = VGParams(
            omega=float(vgcfg.get("omega_xy", 6.0)),
            zeta=float(vgcfg.get("zeta", 1.0)),
            vmax=float(vgcfg.get("vmax_xy_px_s", 0.0)),
            amax=float(vgcfg.get("amax_xy_px_s2", 0.0)),
            enter=enter_xy, exit=exit_xy,
            lock_hold_frames=int(vgcfg.get("lock_hold_frames", 3)),
        )
        p_th = VGParams(
            omega=float(vgcfg.get("omega_theta", 4.0)),
            zeta=float(vgcfg.get("zeta", 1.0)),
            vmax=math.radians(float(vgcfg.get("vmax_theta_deg_s", 0.0))),
            amax=math.radians(float(vgcfg.get("amax_theta_deg_s2", 0.0))),
            enter=enter_th, exit=exit_th,
            lock_hold_frames=int(vgcfg.get("lock_hold_frames", 3)),
        )
        return VirtualGimbal(p_xy=p_xy, p_th=p_th)

    def analyze(self, frames_iter, total_frames: int,
                progress_cb: Optional[Callable[[int, str], None]]=None) -> Dict:
        """Быстрый прогон без варпа: оцениваем траекторию и RMS(dθ), рекомендуем crop."""
        motions = []
        prev_small = None
        dt_list = []
        nfeat_list = []
        nin_list = []
        step = 0

        for bgr in frames_iter():
            step += 1
            if progress_cb: progress_cb(int(100 * step / max(total_frames,1)), "оценка движения (анализ)")
            small, scale = _to_gray_small(bgr, self.p.downscale_width)
            if prev_small is None:
                prev_small = small
                continue
            dx, dy, dth, nf, nin = _estimate_affine(prev_small, small,
                                                    self.p.gftt_max_corners, self.p.lk_win, self.p.ransac_thresh)
            # Масштабируем с малой картинки в пиксели оригинала
            dx /= scale; dy /= scale
            motions.append((dx, dy, dth))
            dt_list.append(dth); nfeat_list.append(nf); nin_list.append(nin)
            prev_small = small

        if not motions:
            # Если нет движения, возвращаем базовые метрики
            return dict(
                jitter_before_pct=0.0,
                n_features_avg=float(np.mean(nfeat_list)) if nfeat_list else 0.0,
                n_inliers_avg=float(np.mean(nin_list)) if nin_list else 0.0,
                recommended_crop_percent=self.p.safety_crop_percent
            )

        traj, smooth, corr = _trajectory_smooth(motions, self.p.ema_alpha_pos, self.p.ema_alpha_rot)
        jitter_before = _rms([d for (_,_,d) in motions])
        jitter_pct = (jitter_before / math.radians(self.p.hfov_deg)) * 100.0

        # эвристика под crop: 3σ для позиций -> перевод в % ширины/высоты, округление до шага 1%
        xs = np.array([dx for (dx,_,_) in corr])
        ys = np.array([dy for (_,dy,_) in corr])
        
        # Исправлено: убираем initial параметр и добавляем проверку на пустые массивы
        if len(xs) > 0 and len(ys) > 0:
            # Используем ddof=0 для совместимости со старыми версиями numpy
            x_std = xs.std(ddof=0) if len(xs) > 1 else 0.0
            y_std = ys.std(ddof=0) if len(ys) > 1 else 0.0
            pad_px = int(3 * max(x_std, y_std))
        else:
            pad_px = 0
            
        # Добавляем проверку на ширину кадра
        frame_width = getattr(frames_iter, 'width', 640)  # fallback значение
        rec_crop = min(20, max(self.p.safety_crop_percent, int(round(100.0 * pad_px / max(1, frame_width)))))

        metrics = dict(
            jitter_before_pct=jitter_pct,
            n_features_avg=float(np.mean(nfeat_list)) if nfeat_list else 0.0,
            n_inliers_avg=float(np.mean(nin_list)) if nin_list else 0.0,
            recommended_crop_percent=rec_crop
        )
        return metrics

    def stabilize(self, frames_iter, total_frames: int, fps: float,
                  progress_cb: Optional[Callable[[int, str], None]]=None):
        """Полный прогон: оцениваем коррекции, варпим, safety-crop, возвращаем итератор кадров и метрики."""
        # === этап: оценка движения ===
        motions = []
        prev_small = None
        dt_list = []
        nfeat_list = []
        nin_list = []
        frames_cache: List[np.ndarray] = []

        step = 0
        for bgr in frames_iter():
            frames_cache.append(bgr)
            step += 1
            if progress_cb: progress_cb(min(99, int(15 * step / max(total_frames,1))), "извлечение кадров")
        total_frames = len(frames_cache)

        if total_frames == 0:
            raise ValueError("No frames loaded from video")

        for i in range(total_frames):
            if progress_cb: progress_cb(15 + int(25 * (i+1) / max(total_frames,1)), "оценка движения")
            bgr = frames_cache[i]
            small, scale = _to_gray_small(bgr, self.p.downscale_width)
            if prev_small is None:
                prev_small = small
                continue
            dx, dy, dth, nf, nin = _estimate_affine(prev_small, small,
                                                    self.p.gftt_max_corners, self.p.lk_win, self.p.ransac_thresh)
            dx /= scale; dy /= scale
            motions.append((dx, dy, dth))
            dt_list.append(dth); nfeat_list.append(nf); nin_list.append(nin)
            prev_small = small

        if not motions:
            # Если нет движения, возвращаем оригинальные кадры с заглушкой метрик
            jitter_before_pct = jitter_after_pct = 0.0
            out_frames = [_overlay_text(frames_cache[0], f"джиттер: {jitter_before_pct:.2f}% HFOV | crop: {self.p.safety_crop_percent}%")]
            out_frames.extend(frames_cache[1:])
            if out_frames:
                out_frames[-1] = _overlay_text(out_frames[-1], f"джиттер: {jitter_after_pct:.2f}% HFOV | crop: {self.p.safety_crop_percent}%")
        else:
            # Строим кумулятивную «сырую» траекторию
            traj = []
            x = y = th = 0.0
            for dx, dy, dth in motions:
                x += dx; y += dy; th += dth
                traj.append((x, y, th))

            # По умолчанию — прежний EMA сглаживатель
            use_vg = False
            vg = self._build_virtual_gimbal(width_px=frames_cache[0].shape[1], fps=fps)
            if vg is not None:
                use_vg = True
                # Пропускаем траекторию через виртуальный кардан (он выдаёт diff = s - traj)
                dt = 1.0 / max(1.0, float(fps))
                diffs = []
                for (tx, ty, tth) in traj:
                    dx_c, dy_c, dth_c = vg.update(tx, ty, tth, dt)
                    diffs.append((dx_c, dy_c, dth_c))
                # Сглаженная траектория s = traj + diff
                smooth = [(tx + dx_c, ty + dy_c, tth + dth_c) for (tx, ty, tth), (dx_c, dy_c, dth_c) in zip(traj, diffs)]
                corr = diffs
            else:
                # старый путь (точно как раньше): EMA → corr = smooth - traj
                _, smooth, corr = _trajectory_smooth(motions, self.p.ema_alpha_pos, self.p.ema_alpha_rot)

            jitter_before = _rms([d for (_,_,d) in motions])
            # оценим остаточную угловую дрожь после компенсации (m + corr по углу)
            jitter_after  = _rms([m[2] + c[2] for m, c in zip(motions, corr)])
            jitter_before_pct = (jitter_before / math.radians(self.p.hfov_deg)) * 100.0
            jitter_after_pct  = (jitter_after  / math.radians(self.p.hfov_deg)) * 100.0

            # === этап: рендер ===
            h, w = frames_cache[0].shape[:2]
            crop = int(max(0, min(40, self.p.safety_crop_percent)))
            x0 = int(round(w * (crop/100.0))); y0 = int(round(h * (crop/100.0)))
            Wc = w - 2*x0; Hc = h - 2*y0

            out_frames: List[np.ndarray] = []
            # первый кадр без коррекции
            out_frames.append(_overlay_text(frames_cache[0], f"джиттер: {jitter_before_pct:.2f}% HFOV | crop: {crop}%"))
            for i in range(1, total_frames):
                if progress_cb: progress_cb(40 + int(50 * (i+1) / max(total_frames,1)), "рендер")
                bgr = frames_cache[i]
                if i-1 < len(corr):  # Проверяем что индекс в пределах массива
                    cdx, cdy, cdth = corr[i-1]
                    M = _compose_matrix(cdx, cdy, cdth)
                    warped = cv2.warpAffine(bgr, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
                    crop_frame = warped[y0:y0+Hc, x0:x0+Wc]
                    crop_frame = cv2.resize(crop_frame, (w, h), interpolation=cv2.INTER_LINEAR)
                    out_frames.append(crop_frame)
                else:
                    # Если нет коррекции для этого кадра, добавляем оригинал
                    out_frames.append(bgr)

            # финальный оверлей на последнем кадре (после стабилизации)
            if out_frames:
                out_frames[-1] = _overlay_text(out_frames[-1], f"джиттер: {jitter_after_pct:.2f}% HFOV | crop: {crop}%")

        metrics = EISMetrics(
            fps=fps,
            n_features_avg=float(np.mean(nfeat_list)) if nfeat_list else 0.0,
            n_inliers_avg=float(np.mean(nin_list)) if nin_list else 0.0,
            jitter_before_pct=jitter_before_pct,
            jitter_after_pct=jitter_after_pct,
            params=self.p.__dict__.copy()
        )
        return out_frames, metrics