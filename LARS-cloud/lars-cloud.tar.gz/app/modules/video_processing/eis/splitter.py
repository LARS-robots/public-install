from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, Iterator, Tuple

import numpy as np

class SplitMode(str, Enum):
    AUTO = "auto"
    STEREO_H = "stereo_horizontal"   # 2x1 (side-by-side)
    STEREO_V = "stereo_vertical"     # 1x2 (top-bottom)
    QUAD_2x2 = "quad_2x2"            # 2x2
    MONO = "mono"                 # 1x1 (нет сплита)

@dataclass
class StereoPick:
    # какую половину брать при stereo
    value: str  # "left"|"right"|"top"|"bottom"

def detect_layout(width: int, height: int, tol: float = 0.3) -> SplitMode:
    """Простая эвристика: если одна сторона примерно в 2 раза больше другой"""
    if height <= 0 or width <= 0:
        return SplitMode.MONO
    r = width / float(height)
    inv = height / float(width)
    if r >= (2.0 - tol):
        return SplitMode.STEREO_H
    if inv >= (2.0 - tol):
        return SplitMode.STEREO_V
    if abs(width - height) <= 0.05 * min(width, height):
        return SplitMode.QUAD_2x2
    return SplitMode.MONO

def split_quad(frame: np.ndarray) -> Dict[str, np.ndarray]:
    h, w = frame.shape[:2]
    h2, w2 = h // 2, w // 2
    return {
        "tl": frame[:h2, :w2],
        "tr": frame[:h2, w2:],
        "bl": frame[h2:, :w2],
        "br": frame[h2:, w2:]
    }

def join_quad(tiles: Dict[str, np.ndarray]) -> np.ndarray:
    """
    Сшивает квадранты (tl,tr,bl,br) обратно в общий кадр.
    Предполагает совпадающие размеры у пар.
    """
    tl, tr = tiles["tl"], tiles["tr"]
    bl, br = tiles["bl"], tiles["br"]
    top = np.concatenate([tl, tr], axis=1)
    bottom = np.concatenate([bl, br], axis=1)
    return np.concatenate([top, bottom], axis=0)

def right_half_roi(shape: Tuple[int, int, int] | Tuple[int, int]) -> Tuple[slice, slice]:
    """Возвращает ROI правой половины кадра (вью, без копии)."""
    h, w = shape[:2]
    mid = w // 2
    return (slice(None), slice(mid, w))

def split_stereo(frame: np.ndarray, layout: SplitMode) -> Dict[str, np.ndarray]:
    h, w = frame.shape[:2]
    # STEREO_H (side-by-side): разделяем по ШИРИНЕ -> left | right
    if layout == SplitMode.STEREO_H:
        hw = w // 2
        return {
            "left":  frame[:, :hw],
            "right": frame[:, hw:],
        }
    # STEREO_V (top-bottom): разделяем по ВЫСОТЕ -> top / bottom
    elif layout == SplitMode.STEREO_V:
        hh = h // 2
        return {
            "top":    frame[:hh, :],
            "bottom": frame[hh:, :],
        }
    # Fallback: возвращаем весь кадр
    return {"full": frame}

def split_quad(frame: np.ndarray) -> Dict[str, np.ndarray]:
    h, w = frame.shape[:2]
    h2, w2 = h // 2, w // 2
    return {
        "tl": frame[:h2, :w2],
        "tr": frame[:h2, w2:],
        "bl": frame[h2:, :w2],
        "br": frame[h2:, w2:]
    }

def iter_substream(frames_iter: Callable[[], Iterator[np.ndarray]],
                   choose: Callable[[np.ndarray], np.ndarray]) -> Callable[[], Iterator[np.ndarray]]:
    """Оборачивает исходный итератор так, чтобы он yield'ил выбранный subframe на лету"""
    def _gen():
        for f in frames_iter():
            yield choose(f)
    # Пробрасываем полезные метаданные
    _gen.fps = getattr(frames_iter, "fps", 30.0)
    _gen.length = getattr(frames_iter, "length", 0)
    return _gen

def normalize_stereo_pick(layout: SplitMode, pick: str) -> str:
    """Ensure pick is valid for given stereo layout."""
    pick = (pick or "").lower()
    if layout == SplitMode.STEREO_H:
        # горизонтальное stereo: только left/right
        return "left" if pick not in ("left", "right") else pick
    elif layout == SplitMode.STEREO_V:
        # вертикальное stereo: только top/bottom
        return "top" if pick not in ("top", "bottom") else pick
    # на всякий случай дефолт
    return "left"

def mode_from_config(name: str) -> SplitMode:
    """Map config mode names to SplitMode enum"""
    name = (name or "").lower()
    if name in ("mono",): 
        return SplitMode.MONO
    if name in ("stereo_h", "stereo-horizontal", "stereo_horizontal", "stereo"): 
        return SplitMode.STEREO_H
    if name in ("stereo_v", "stereo-vertical", "stereo_vertical"): 
        return SplitMode.STEREO_V
    if name in ("quad2x2", "quad_2x2", "quad"): 
        return SplitMode.QUAD_2x2
    return SplitMode.AUTO