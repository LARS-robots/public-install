# app/modules/video_processing/eis/eis_service.py
# filepath: /home/master/PycharmProjects/LARS/LARS-cloud/app/modules/video_processing/eis/eis_service.py

import os, json, time
from typing import Callable, Dict, Tuple
import cv2
import numpy as np

from ....modules.video_processing.eis.eis import EIS, EISParams
from ....core.config import EIS_OUTPUT_DIR
from ....core import ffmpeg_utils
from ....modules.video_processing.eis.splitter import (
    SplitMode, StereoPick, detect_layout, split_stereo, split_quad, iter_substream
)

def _ensure_dirs():
    os.makedirs(EIS_OUTPUT_DIR, exist_ok=True)

def _iter_frames_cv2(video_path: str):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    n  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    def iterator():
        nonlocal cap
        while True:
            ok, frame = cap.read()
            if not ok:
                cap.release()  # Освобождаем ресурсы
                break
            yield frame
    iterator.width = w
    iterator.height = h
    iterator.fps = fps
    iterator.length = n
    return iterator, fps, n

def _iter_frames(video_path: str):
    """Предпочитаем ffmpeg_utils, иначе fallback на cv2."""
    if hasattr(ffmpeg_utils, "iter_video_frames"):
        try:
            iterator = ffmpeg_utils.iter_video_frames(video_path)
            fps = getattr(iterator, "fps", 30.0)
            n   = getattr(iterator, "length", 0)
            return iterator, fps, n
        except Exception as e:
            print(f"⚠️ ffmpeg_utils недоступен, используем cv2: {e}")
    return _iter_frames_cv2(video_path)

def _write_video_ffmpeg(out_path: str, frames, fps: float):
    # если есть ffmpeg_utils.video_writer — используем
    if hasattr(ffmpeg_utils, "video_writer"):
        try:
            with ffmpeg_utils.video_writer(out_path, fps=fps) as sink:
                for f in frames:
                    sink.write(f)
            return
        except Exception as e:
            print(f"⚠️ ffmpeg_utils.video_writer failed, fallback to cv2: {e}")
    
    # fallback через cv2 (mp4v)
    if not frames:
        raise ValueError("No frames to write")
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    h, w = frames[0].shape[:2]
    vw = cv2.VideoWriter(out_path, fourcc, fps, (w, h))
    if not vw.isOpened():
        raise RuntimeError(f"Cannot create video writer for {out_path}")
    
    for f in frames:
        vw.write(f)
    vw.release()

def analyze(video_path: str, params: EISParams,
            progress_cb: Callable[[int, str], None],
            mode: SplitMode = SplitMode.AUTO,
            stereo_pick: StereoPick | None = None) -> Dict:
    _ensure_dirs()
    
    # Проверяем входной файл
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")
    
    iterator, fps, n = _iter_frames(video_path)
    
    # Подготовим под-стрим (если надо)
    def choose_identity(f): return f
    chooser = choose_identity
    
    # Определяем геометрию
    w = getattr(iterator, "width", None); h = getattr(iterator, "height", None)
    layout = mode
    if layout == SplitMode.AUTO and w and h:
        layout = detect_layout(w, h)
    
    if layout in (SplitMode.STEREO_H, SplitMode.STEREO_V):
        from ....modules.video_processing.eis.splitter import normalize_stereo_pick
        user_pick = (stereo_pick.value if stereo_pick else "right")  # дефолт: right
        pick = normalize_stereo_pick(layout, user_pick)
        def choose(f):
            return split_stereo(f, layout)[pick]
        sub_iter = iter_substream(iterator, choose)  # ВАЖНО: подменяем iterator
    elif layout == SplitMode.QUAD_2x2:
        iterator = iter_substream(iterator, lambda f: split_quad(f)["tl"])


    # heartbeat ≥ 1 Hz
    last_hb = time.time()
    def hb_cb(pct: int, stage: str):
        nonlocal last_hb
        now = time.time()
        if (now - last_hb) >= 0.9:
            progress_cb(pct, stage)
            last_hb = now
    
    progress_cb(0, "инициализация")
    eis = EIS(params)
    metrics = eis.analyze(iterator, n, progress_cb=hb_cb)
    progress_cb(100, "готово (анализ)")
    return metrics

def stabilize(video_path: str, params: EISParams,
              progress_cb: Callable[[int, str], None],
              mode: SplitMode = SplitMode.AUTO,
              stereo_pick: StereoPick | None = None):
    _ensure_dirs()
    
    # Проверяем входной файл
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")
    
    iterator, fps, n = _iter_frames(video_path)
    last_hb = time.time()
    def hb_cb(pct: int, stage: str):
        nonlocal last_hb
        now = time.time()
        if (now - last_hb) >= 0.9:
            progress_cb(pct, stage)
            last_hb = now

    # Развилка по режимам
    base = os.path.splitext(os.path.basename(video_path))[0]
    w = getattr(iterator, "width", None); h = getattr(iterator, "height", None)
    layout = mode
    if layout == SplitMode.AUTO and w and h:
        layout = detect_layout(w, h)

    if layout in (SplitMode.STEREO_H, SplitMode.STEREO_V):
        pick = (stereo_pick.value if stereo_pick else "right")
        def choose(f):
            return split_stereo(f, layout)[pick]
        sub_iter = iter_substream(iterator, choose)
        
        progress_cb(0, "инициализация")
        eis = EIS(params)
        frames, metrics = eis.stabilize(sub_iter, n, fps, progress_cb=hb_cb)
        
        out_mp4 = os.path.join(EIS_OUTPUT_DIR, f"{base}_stab_{pick}.mp4")
        out_json = os.path.join(EIS_OUTPUT_DIR, f"{base}_metrics_{pick}.json")
        out_thumb = os.path.join(EIS_OUTPUT_DIR, f"{base}_thumb_{pick}.jpg")
        
        progress_cb(92, "сохранение (видео)")
        _write_video_ffmpeg(out_mp4, frames, fps)
        
        progress_cb(96, "сохранение (метрики/превью)")
        if frames:
            mid = frames[len(frames)//2]
            cv2.imwrite(out_thumb, mid)
        
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump({
                "jitter_before_pct": metrics.jitter_before_pct,
                "jitter_after_pct": metrics.jitter_after_pct,
                "n_features_avg": metrics.n_features_avg,
                "n_inliers_avg": metrics.n_inliers_avg,
                "fps": metrics.fps,
                "params": metrics.params
            }, f, ensure_ascii=False, indent=2)
        
        progress_cb(100, "готово (стабилизация)")
        return out_mp4, out_json, out_thumb

    # QUAD: гоняем 4 независимых стабилизации
    results = {}
    quads = ("tl", "tr", "bl", "br")
    
    # Пройдёмся по кадрам один раз и разложим их по четырём спискам
    progress_cb(15, "разделение на квадранты")
    frames_buckets = {k: [] for k in quads}
    for frame in iterator():
        parts = split_quad(frame)
        for k in quads:
            frames_buckets[k].append(parts[k])
    
    total = len(next(iter(frames_buckets.values()))) if frames_buckets["tl"] else 0
    
    for idx, key in enumerate(quads):
        progress_cb(20 + int(15*idx), f"стабилизация {key}")
        
        # делаем локальный итератор для EIS из накопленного списка
        def _gen(seq=frames_buckets[key]):
            for f in seq: yield f
        setattr(_gen, "fps", fps); setattr(_gen, "length", total)
        
        eis = EIS(params)
        frames, metrics = eis.stabilize(_gen, total, fps, progress_cb=hb_cb)
        
        out_mp4 = os.path.join(EIS_OUTPUT_DIR, f"{base}_stab_{key}.mp4")
        out_json = os.path.join(EIS_OUTPUT_DIR, f"{base}_metrics_{key}.json")
        out_thumb = os.path.join(EIS_OUTPUT_DIR, f"{base}_thumb_{key}.jpg")
        
        _write_video_ffmpeg(out_mp4, frames, fps)
        
        if frames:
            mid = frames[len(frames)//2]
            cv2.imwrite(out_thumb, mid)
        
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump({
                "jitter_before_pct": metrics.jitter_before_pct,
                "jitter_after_pct": metrics.jitter_after_pct,
                "n_features_avg": metrics.n_features_avg,
                "n_inliers_avg": metrics.n_inliers_avg,
                "fps": metrics.fps,
                "params": metrics.params
            }, f, ensure_ascii=False, indent=2)
        
        results[key] = (out_mp4, out_json, out_thumb)
    
    progress_cb(100, "готово (quad)")
    return results

# === NEW: helpers for multiplex split/join ===

def _split_stereo(frame: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    h, w = frame.shape[:2]
    w2 = w // 2
    left  = frame[:, :w2].copy()
    right = frame[:, w2:].copy()
    return left, right

def _split_quad(frame: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    h, w = frame.shape[:2]
    h2, w2 = h // 2, w // 2
    tl = frame[:h2, :w2].copy()
    tr = frame[:h2,  w2:].copy()
    bl = frame[ h2:, :w2].copy()
    br = frame[ h2:,  w2:].copy()
    return tl, tr, bl, br

def _join_stereo(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    # подгоняем по размеру на случай небольших расхождений
    h = min(left.shape[0], right.shape[0])
    left  = cv2.resize(left,  (left.shape[1],  h))
    right = cv2.resize(right, (right.shape[1], h))
    return cv2.hconcat([left, right])

def _join_quad(tl: np.ndarray, tr: np.ndarray, bl: np.ndarray, br: np.ndarray) -> np.ndarray:
    # приводим плитки к одинаковому размеру
    h = min(tl.shape[0], tr.shape[0], bl.shape[0], br.shape[0])
    w = min(tl.shape[1], tr.shape[1], bl.shape[1], br.shape[1])
    def fit(x): return cv2.resize(x, (w, h))
    top = cv2.hconcat([fit(tl), fit(tr)])
    bot = cv2.hconcat([fit(bl), fit(br)])
    return cv2.vconcat([top, bot])

class _ListFramesIterator:
    """Мини-итератор, имитирующий iter_video_frames: frames -> yield, с метаданными."""
    def __init__(self, frames: list, fps: float):
        self._frames = frames
        self.fps = fps
        self.length = len(frames)
        if frames:
            self.height, self.width = frames[0].shape[:2]
        else:
            self.height = self.width = 0
    def __call__(self):
        for f in self._frames:
            yield f

def _stabilize_frames_list(frames: list, fps: float, params: EISParams,
                           progress_cb: Callable[[int, str], None],
                           pct_start: int, pct_span: int, tag: str):
    """Вспомогательный прогон EIS над списком кадров с локальным прогрессом."""
    iterator = _ListFramesIterator(frames, fps)
    total = iterator.length
    def local_cb(pct, stage):
        # переведём локальные проценты тайла в глобальные
        gpct = pct_start + int((pct/100.0) * pct_span)
        progress_cb(gpct, f"{tag}: {stage}")
    eis = EIS(params)
    out_frames, metrics = eis.stabilize(iterator, total, fps, progress_cb=local_cb)
    return out_frames, metrics

# === NEW: public API for stereo and quad ===

def stabilize_stereo(video_path: str, params: EISParams,
                     progress_cb: Callable[[int, str], None],
                     layout: SplitMode = None):
    _ensure_dirs()
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")

    iterator, fps, n = _iter_frames(video_path)
    
    # Auto-detect layout if not provided
    if layout is None:
        w = getattr(iterator, "width", None)
        h = getattr(iterator, "height", None)
        if w and h:
            layout = detect_layout(w, h)
        else:
            layout = SplitMode.STEREO_V  # default fallback
    
    progress_cb(0, "split (stereo)")
    left_frames, right_frames = [], []
    step = 0
    for f in iterator():
        step += 1
        if step % max(1, n//50) == 0:
            progress_cb(min(10, int(10*step/max(1,n))), "split (stereo)")
        
        # Use the split_stereo function from splitter module
        parts = split_stereo(f, layout)
        
        if layout == SplitMode.STEREO_H:
            # Для горизонтального стерео: top и bottom
            L, R = parts["top"], parts["bottom"]
        else:  # STEREO_V
            # Для вертикального стерео: left и right
            L, R = parts["left"], parts["right"]
            
        left_frames.append(L)
        right_frames.append(R)

    # стабилизируем левый и правый потоки независимо
    L_out, Lm = _stabilize_frames_list(left_frames, fps, params, progress_cb, pct_start=10, pct_span=40, tag="tile L")
    R_out, Rm = _stabilize_frames_list(right_frames, fps, params, progress_cb, pct_start=50, pct_span=40, tag="tile R")

    # сшиваем обратно с правильной ориентацией
    progress_cb(92, "compose (stereo)")
    if layout == SplitMode.STEREO_H:
        # For vertical stereo, join top-bottom
        out_frames = [_join_stereo_vertical(L_out[i], R_out[i]) for i in range(min(len(L_out), len(R_out)))]
    elif layout == SplitMode.STEREO_V:
        out_frames = [_join_stereo_horizontal(L_out[i], R_out[i]) for i in range(min(len(L_out), len(R_out)))]
    else:
        # For horizontal stereo, join left-right
        out_frames = [_join_stereo(L_out[i], R_out[i]) for i in range(min(len(L_out), len(R_out)))]

    base = os.path.splitext(os.path.basename(video_path))[0]
    out_mp4  = os.path.join(EIS_OUTPUT_DIR, f"{base}_stab_both.mp4")
    out_json = os.path.join(EIS_OUTPUT_DIR, f"{base}_metrics_both.json")
    out_thumb= os.path.join(EIS_OUTPUT_DIR, f"{base}_thumb_both.jpg")

    progress_cb(94, "save (video)")
    _write_video_ffmpeg(out_mp4, out_frames, fps)

    progress_cb(96, "save (metrics/preview)")
    if out_frames:
        mid = out_frames[len(out_frames)//2]
        cv2.imwrite(out_thumb, mid)
    
    # агрегированные метрики
    agg = {
        "fps": fps,
        "layout": layout.value,
        "left_or_top": {
            "jitter_before_pct": Lm.jitter_before_pct,
            "jitter_after_pct":  Lm.jitter_after_pct,
            "n_features_avg":    Lm.n_features_avg,
            "n_inliers_avg":     Lm.n_inliers_avg,
            "params":            Lm.params,
        },
        "right_or_bottom": {
            "jitter_before_pct": Rm.jitter_before_pct,
            "jitter_after_pct":  Rm.jitter_after_pct,
            "n_features_avg":    Rm.n_features_avg,
            "n_inliers_avg":     Rm.n_inliers_avg,
            "params":            Rm.params,
        }
    }
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(agg, f, ensure_ascii=False, indent=2)

    progress_cb(100, "done (stereo)")
    return out_mp4, out_json, out_thumb

def _join_stereo_vertical(top: np.ndarray, bottom: np.ndarray) -> np.ndarray:
    """Join two frames vertically (for stereo_vertical layout)"""
    # подгоняем по размеру на случай небольших расхождений
    w = min(top.shape[1], bottom.shape[1])
    top    = cv2.resize(top,    (w, top.shape[0]))
    bottom = cv2.resize(bottom, (w, bottom.shape[0]))
    return cv2.vconcat([top, bottom])

def _join_stereo_horizontal(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Join two frames horizontally (for stereo_horizontal layout)"""
    # подгоняем по размеру на случай небольших расхождений
    h = min(left.shape[0], right.shape[0])
    left  = cv2.resize(left,  (left.shape[1], h))
    right = cv2.resize(right, (right.shape[1], h))
    return cv2.hconcat([left, right])

def stabilize_quad(video_path: str, params: EISParams,
                   progress_cb: Callable[[int, str], None]):
    _ensure_dirs()
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")

    iterator, fps, n = _iter_frames(video_path)
    progress_cb(0, "split (quad)")
    TL, TR, BL, BR = [], [], [], []
    step = 0
    for f in iterator():
        step += 1
        if step % max(1, n//50) == 0:
            progress_cb( min(10, int(10*step/max(1,n))) , "split (quad)")
        tl, tr, bl, br = _split_quad(f)
        TL.append(tl); TR.append(tr); BL.append(bl); BR.append(br)

    # по очереди стабилизируем 4 плитки
    TL_out, TLm = _stabilize_frames_list(TL, fps, params, progress_cb, 10, 22, "tile TL")
    TR_out, TRm = _stabilize_frames_list(TR, fps, params, progress_cb, 32, 22, "tile TR")
    BL_out, BLm = _stabilize_frames_list(BL, fps, params, progress_cb, 54, 22, "tile BL")
    BR_out, BRm = _stabilize_frames_list(BR, fps, params, progress_cb, 76, 22, "tile BR")

    progress_cb(92, "compose (quad)")
    frames_n = min(len(TL_out), len(TR_out), len(BL_out), len(BR_out))
    out_frames = [ _join_quad(TL_out[i], TR_out[i], BL_out[i], BR_out[i]) for i in range(frames_n) ]

    base = os.path.splitext(os.path.basename(video_path))[0]
    out_mp4  = os.path.join(EIS_OUTPUT_DIR, f"{base}_stab_quad.mp4")
    out_json = os.path.join(EIS_OUTPUT_DIR, f"{base}_metrics_quad.json")
    out_thumb= os.path.join(EIS_OUTPUT_DIR, f"{base}_thumb_quad.jpg")

    progress_cb(94, "save (video)")
    _write_video_ffmpeg(out_mp4, out_frames, fps)

    progress_cb(96, "save (metrics/preview)")
    if out_frames:
        mid = out_frames[len(out_frames)//2]
        cv2.imwrite(out_thumb, mid)
    agg = {
        "fps": fps,
        "TL": {"jitter_before_pct": TLm.jitter_before_pct, "jitter_after_pct": TLm.jitter_after_pct,
               "n_features_avg": TLm.n_features_avg, "n_inliers_avg": TLm.n_inliers_avg, "params": TLm.params},
        "TR": {"jitter_before_pct": TRm.jitter_before_pct, "jitter_after_pct": TRm.jitter_after_pct,
               "n_features_avg": TRm.n_features_avg, "n_inliers_avg": TRm.n_inliers_avg, "params": TRm.params},
        "BL": {"jitter_before_pct": BLm.jitter_before_pct, "jitter_after_pct": BLm.jitter_after_pct,
               "n_features_avg": BLm.n_features_avg, "n_inliers_avg": BLm.n_inliers_avg, "params": BLm.params},
        "BR": {"jitter_before_pct": BRm.jitter_before_pct, "jitter_after_pct": BRm.jitter_after_pct,
               "n_features_avg": BRm.n_features_avg, "n_inliers_avg": BRm.n_inliers_avg, "params": BRm.params},
    }
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(agg, f, ensure_ascii=False, indent=2)

    progress_cb(100, "done (quad)")
    return out_mp4, out_json, out_thumb