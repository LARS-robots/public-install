# app/modules/video_processing/eis/virtual_gimbal.py

from dataclasses import dataclass
import math

def _wrap_pi(a: float) -> float:
    """Нормализуем угол к [-pi, pi]"""
    return (a + math.pi) % (2.0 * math.pi) - math.pi

def _angle_err(a: float, b: float) -> float:
    """Кратчайшая разность углов a - b"""
    return _wrap_pi(a - b)

@dataclass
class AxisState:
    s: float = 0.0      # положение
    v: float = 0.0      # скорость
    lock: bool = True
    lock_counter: int = 0

@dataclass
class VGParams:
    # динамика 2-го порядка (критически затухающая: ζ=1)
    omega: float = 6.0  # рад/с
    zeta:  float = 1.0  # фиксировано =1, но оставим в параметрах
    # лимиты
    vmax: float = 0.0   # 0 => без ограничения
    amax: float = 0.0   # 0 => без ограничения
    # dead-zone (enter > exit), в единицах оси (px или rad)
    enter: float = 0.0
    exit:  float = 0.0
    # гистерезис: сколько кадров «тишины» держим, чтобы вернуться в lock
    lock_hold_frames: int = 3

class VirtualGimbal:
    """
    Drop-in фильтр поверх сырой траектории.
    Вход: traj_x, traj_y (px фулл-рез), traj_th (rad), dt (s).
    Выход: diff_x, diff_y, diff_th = s - traj для компенсации warp.
    """
    def __init__(self, p_xy: VGParams, p_th: VGParams):
        self.x = AxisState()
        self.y = AxisState()
        self.th = AxisState()
        self.px = p_xy
        self.py = VGParams(**p_xy.__dict__)  # независимая копия для Y
        self.pth = p_th

    @staticmethod
    def _deadzone(e: float, st: AxisState, p: VGParams):
        """Dead-zone + гистерезис (enter > exit)"""
        ae = abs(e)
        if st.lock:
            if ae <= p.exit:
                st.lock_counter += 1
                return 0.0, True
            else:
                st.lock = False
                st.lock_counter = 0
        else:
            if ae <= p.enter:
                return 0.0, False

        eff = math.copysign(max(0.0, ae - p.exit), e)
        st.lock_counter = 0
        return eff, False

    @staticmethod
    def _step(st: AxisState, p: VGParams, e_eff: float, dt: float):
        """Критически затухающая 2-порядка: acc_cmd = ω^2 e - 2 ζ ω v"""
        acc_cmd = p.omega * p.omega * e_eff - 2.0 * p.zeta * p.omega * st.v
        # лимит ускорения
        if p.amax and p.amax > 0.0:
            acc_cmd = max(-p.amax, min(p.amax, acc_cmd))
        # интеграция скорости
        st.v += acc_cmd * dt
        # лимит скорости
        if p.vmax and p.vmax > 0.0:
            st.v = max(-p.vmax, min(p.vmax, st.v))
        # интеграция положения
        st.s += st.v * dt

    def update(self, traj_x: float, traj_y: float, traj_th: float, dt: float):
        """Обновление виртуального кардана"""
        # ошибки по положению: e = traj - s
        ex  = traj_x - self.x.s
        ey  = traj_y - self.y.s
        eth = _angle_err(traj_th, self.th.s)

        # dead-zone + hysteresis
        ex_eff, x_locked  = self._deadzone(ex,  self.x,  self.px)
        ey_eff, y_locked  = self._deadzone(ey,  self.y,  self.py)
        eth_eff, th_locked = self._deadzone(eth, self.th, self.pth)

        # шаг динамики
        self._step(self.x,  self.px,  ex_eff,  dt)
        self._step(self.y,  self.py,  ey_eff,  dt)
        self._step(self.th, self.pth, eth_eff, dt)

        # авто-возврат в lock после quiet-периода
        if x_locked  and self.x.lock_counter  >= self.px.lock_hold_frames:  self.x.lock  = True
        if y_locked  and self.y.lock_counter  >= self.py.lock_hold_frames:  self.y.lock  = True
        if th_locked and self.th.lock_counter >= self.pth.lock_hold_frames: self.th.lock = True

        # компенсации (diff = s - traj)
        diff_x  = self.x.s  - traj_x
        diff_y  = self.y.s  - traj_y
        diff_th = _wrap_pi(self.th.s - traj_th)
        return diff_x, diff_y, diff_th
