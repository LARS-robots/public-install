"""
Depth overlay service — берёт подготовленные кадры из FRAMES_DIR,
прогоняет через Depth Anything V2, создаёт цветные depth-кадры и собирает видео,
при этом объединяя оригинальные кадры слева с кадрами глубины справа.
"""

import os
import sys

def find_project_root(start_dir, marker="requirements.txt"):
    d = start_dir
    while d != os.path.dirname(d):
        if os.path.isfile(os.path.join(d, marker)):
            return d
        d = os.path.dirname(d)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)


from pathlib import Path
from typing import Optional
import numpy as np
import torch
import cv2
from PIL import Image
from transformers import AutoImageProcessor, AutoModelForDepthEstimation
from app.core.ffmpeg_utils import assemble_video
from app.core.config import FRAMES_DIR

class DepthOverlayService:
    def __init__(
        self,
        model_name: str = "depth-anything/Depth-Anything-V2-Small-hf",
        device: Optional[str] = None,
        colormap: int = cv2.COLORMAP_MAGMA,
    ):
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        self.model_name = model_name
        self.colormap = colormap

        # загрузка модели и процессора
        self.image_processor = AutoImageProcessor.from_pretrained(self.model_name)
        self.model = AutoModelForDepthEstimation.from_pretrained(self.model_name).to(self.device)
        self.model.eval()

    def _is_image_file(self, p: Path):
        return p.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

    def process_batch(self, frames: list) -> list:
        """Process a batch of frames -> return depth colorized frames"""
        if not frames:
            return []
        processed = []
        for frame in frames:
            image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            w, h = image.width, image.height
            inputs = self.image_processor(images=image, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs)
            post_processed = self.image_processor.post_process_depth_estimation(
                outputs, target_sizes=[(h, w)]
            )
            depth = post_processed[0]["predicted_depth"]
            depth_max = float(depth.max() if depth.max() > 0 else 1.0)
            depth = depth * 255.0 / depth_max
            depth_np = depth.squeeze().detach().cpu().numpy().astype("uint8")
            depth_color = cv2.applyColorMap(depth_np, self.colormap)
            processed.append(depth_color)
        return processed

    def process_frames_dir(
        self,
        input_frames_dir: Optional[str] = None,
        output_video_path: Optional[str] = None,
        output_frames_dir: Optional[str] = None,
        fps: int = 30,
        cleanup_frames: bool = False,
        progress=None  # gr.Progress() для Gradio
    ) -> str:
        """
        Берёт кадры из input_frames_dir, создаёт depth-кадры, объединяет их с оригиналом
        и собирает видео.
        """

        input_frames_dir = input_frames_dir or FRAMES_DIR
        if output_frames_dir is None:
            output_frames_dir = str(Path(input_frames_dir) / "combined_frames")
        output_frames_dir = str(Path(output_frames_dir))
        Path(output_frames_dir).mkdir(parents=True, exist_ok=True)

        # Очистка папки перед началом
        for p in Path(output_frames_dir).glob("*"):
            p.unlink()

        # поиск кадров
        frame_paths = sorted(
            [p for p in Path(input_frames_dir).iterdir() if p.is_file() and self._is_image_file(p)]
        )
        if len(frame_paths) == 0:
            raise FileNotFoundError(f"No frames found in {input_frames_dir}")

        # путь для итогового видео
        if output_video_path is None:
            out_parent = Path("data/output")
            out_parent.mkdir(parents=True, exist_ok=True)
            output_video_path = str(out_parent / f"depth_overlay_combined.mp4")

        # обработка кадров
        total = len(frame_paths)
        for idx, frame_path in enumerate(frame_paths):
            # обновление прогресса
            if progress is not None:
                progress(idx / total, desc="Processing frames")

            # загружаем оригинальный кадр
            image = Image.open(frame_path).convert("RGB")
            w, h = image.width, image.height

            # предсказание глубины
            inputs = self.image_processor(images=image, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs)
            post_processed = self.image_processor.post_process_depth_estimation(outputs, target_sizes=[(h, w)])
            predicted_depth = post_processed[0]["predicted_depth"]
            depth = predicted_depth
            depth_max = float(depth.max() if depth.max() > 0 else 1.0)
            depth = depth * 255.0 / depth_max
            depth_np = depth.squeeze().detach().cpu().numpy().astype("uint8")
            depth_color = cv2.applyColorMap(depth_np, self.colormap)

            # объединяем оригинал и глубину горизонтально
            orig_bgr = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
            combined = cv2.hconcat([orig_bgr, depth_color])

            # сохраняем комбинированный кадр
            out_fname = Path(output_frames_dir) / frame_path.name
            cv2.imwrite(str(out_fname), combined)

        # финальный прогресс 100%
        if progress is not None:
            progress(1.0, desc="Finished")

        # сборка видео
        assemble_video(input_frames_dir=output_frames_dir, output_path=output_video_path, fps=fps)

        # очистка промежуточных кадров
        if cleanup_frames:
            for p in Path(output_frames_dir).iterdir():
                p.unlink()
            Path(output_frames_dir).rmdir()

        return output_video_path
