import os
import cv2
import torch
import numpy as np
from ultralytics import YOLO
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
from tqdm import tqdm
import subprocess
import time

# Cityscapes color palette for Segformer (pretrained on Cityscapes)
CITYSCAPES_PALETTE = np.array([
    [  0,  0,  0], [128, 64,128], [244, 35,232], [ 70, 70, 70],
    [102,102,156], [190,153,153], [153,153,153], [250,170, 30],
    [220,220,  0], [107,142, 35], [152,251,152], [ 70,130,180],
    [220, 20, 60], [255,  0,  0], [  0,  0,142], [  0,  0, 70],
    [  0, 60,100], [  0, 80,100], [  0,  0,230], [119, 11, 32]
], dtype=np.uint8)

# Custom palette for roadsidewalk model (adjust as needed: 0=bg, 1=road, 2=sidewalk)
CUSTOM_PALETTE = np.array([
    [0, 0, 0],        # background: black
    [128, 64, 128],   # road: purple
    [244, 35, 232]    # sidewalk: pink
], dtype=np.uint8)

class SegformerService:
    """Segformer for Cityscapes class segmentation"""
    def __init__(self, model_dir="nvidia/segformer-b0-finetuned-cityscapes-768-768", device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(self.device)
        self.model.eval()

    def process_batch(self, frames: list, alpha: float = 0.45) -> list:
        try:
            if not frames:
                return []
            h, w = frames[0].shape[:2]
            rgb_batch = [cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) for frame in frames]
            inputs = self.processor(images=rgb_batch, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs).logits
            segs = torch.argmax(outputs, dim=1).cpu().numpy().astype(np.uint8)
            resized_segs = [cv2.resize(seg, (w, h), interpolation=cv2.INTER_NEAREST) for seg in segs]
            processed = []
            for frame, seg in zip(frames, resized_segs):
                color = CITYSCAPES_PALETTE[seg % len(CITYSCAPES_PALETTE)]  # Avoid index error
                overlay = cv2.addWeighted(frame, 1 - alpha, color[..., ::-1], alpha, 0)
                processed.append(overlay)
            return processed
        except Exception as e:
            print(f"Error in Segformer batch: {e}")
            return frames

class OverlayService:
    """Custom Segformer for roadsidewalk segmentation (finetuned model)"""
    def __init__(self, model_dir, use_compile=False, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(self.device)
        if use_compile and hasattr(torch, "compile"):
            self.model = torch.compile(self.model)
        self.model.eval()

    def process_batch(self, frames: list, alpha: float = 0.4) -> list:
        try:
            if not frames:
                return []
            h, w = frames[0].shape[:2]
            rgb_batch = [cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) for frame in frames]
            inputs = self.processor(images=rgb_batch, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs).logits
            segs = torch.argmax(outputs, dim=1).cpu().numpy().astype(np.uint8)
            resized_segs = [cv2.resize(seg, (w, h), interpolation=cv2.INTER_NEAREST) for seg in segs]
            processed = []
            for frame, seg in zip(frames, resized_segs):
                color = CUSTOM_PALETTE[seg % len(CUSTOM_PALETTE)]  # Avoid index error
                overlay = cv2.addWeighted(frame, 1 - alpha, color[..., ::-1], alpha, 0)
                processed.append(overlay)
            return processed
        except Exception as e:
            print(f"Error in custom batch: {e}")
            return frames

    def apply_overlay(self, input_video_path: str, output_video_path: str, alpha: float = 0.4):
        """Apply overlay to entire video using batch processing"""
        cap = cv2.VideoCapture(input_video_path)
        if not cap.isOpened():
            raise ValueError("Не удалось открыть видео")
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_buffer = []
        batch_size = 8  # Can be adjusted

        with tqdm(total=total_frames, desc="Applying overlay") as pbar:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frame_buffer.append(frame)
                if len(frame_buffer) == batch_size:
                    processed = self.process_batch(frame_buffer, alpha)
                    for proc_frame in processed:
                        out.write(proc_frame)
                    pbar.update(len(frame_buffer))
                    frame_buffer = []
            if frame_buffer:
                processed = self.process_batch(frame_buffer, alpha)
                for proc_frame in processed:
                    out.write(proc_frame)
                pbar.update(len(frame_buffer))

        cap.release()
        out.release()
        return "Overlay applied successfully"

class QuadVideoService:
    def __init__(self,
                 output_dir="output",
                 yolo_model_path="yolo11n.pt",  # For object detection
                 segformer=None,
                 custom_segmentor=None,
                 device=None,
                 ultralytics_dir=None,
                 batch_size=8):  # Increased default batch size for real-time
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.batch_size = batch_size if torch.cuda.is_available() else 1

        self.yolo_model = YOLO(os.path.join(ultralytics_dir, yolo_model_path))
        self.segformer = segformer or SegformerService(device=self.device)
        self.custom_segmentor = custom_segmentor or OverlayService(model_dir=os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "segformer_roadsidewalk_model"), use_compile=False, device=self.device)

    def yolo_batch(self, frames: list) -> list:
        results = self.yolo_model(frames, device=self.device, verbose=False)
        return [result.plot() for result in results]

    def _process_batch(self, frames: list) -> list:
        lt_batch = frames  # Original
        rt_batch = self.yolo_batch(frames)  # YOLO detection
        lb_batch = self.segformer.process_batch(frames)  # Segformer Cityscapes
        rb_batch = self.custom_segmentor.process_batch(frames)  # Custom cleaning zone

        quad_batch = []
        for lt, rt, lb, rb in zip(lt_batch, rt_batch, lb_batch, rb_batch):
            top = np.hstack([lt, rt])
            bottom = np.hstack([lb, rb])
            quad = np.vstack([top, bottom])
            quad_batch.append(quad)
        return quad_batch

    def process_video_quad(self, input_video_path: str, output_name="quad_video.mp4", fps=None):
        """
        Обрабатывает видео и создает квадрантный вид

        Args:
            input_video_path: Путь к входному видео файлу
            output_name: Имя выходного файла
            fps: FPS для выходного видео (если None, используется FPS входного видео)

        Returns:
            str: Путь к созданному видео
        """
        cap = cv2.VideoCapture(input_video_path)
        if not cap.isOpened():
            raise ValueError(f"Не удалось открыть видео: {input_video_path}")

        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = fps or cap.get(cv2.CAP_PROP_FPS)
        quad_w, quad_h = width * 2, height * 2
        output_path = os.path.join(self.output_dir, output_name)

        # FFmpeg command for efficient writing
        ffmpeg_cmd = [
            'ffmpeg', '-y',
            '-f', 'rawvideo',
            '-vcodec', 'rawvideo',
            '-pix_fmt', 'bgr24',
            '-s', f'{quad_w}x{quad_h}',
            '-r', str(fps),
            '-i', '-',
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-preset', 'ultrafast',
            output_path
        ]
        proc = subprocess.Popen(ffmpeg_cmd, stdin=subprocess.PIPE)

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_buffer = []

        with tqdm(total=total_frames, desc="Processing frames") as pbar:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frame_buffer.append(frame)

                if len(frame_buffer) == self.batch_size:
                    quad_batch = self._process_batch(frame_buffer)
                    for quad_frame in quad_batch:
                        proc.stdin.write(quad_frame.tobytes())
                    pbar.update(len(frame_buffer))
                    frame_buffer = []

        if frame_buffer:
            quad_batch = self._process_batch(frame_buffer)
            for quad_frame in quad_batch:
                proc.stdin.write(quad_frame.tobytes())
            pbar.update(len(frame_buffer))

        cap.release()
        proc.stdin.close()
        proc.wait()
        return output_path