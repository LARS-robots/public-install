"""
Quad video processing service combining YOLO, Segformer, and custom overlays.
"""

import os
import sys
from app.core.utils import find_project_root

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import cv2
import torch
import numpy as np
from ultralytics import YOLO
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
import subprocess
from typing import Dict
from app.modules.video_processing.depth_overlay_service import DepthOverlayService
from app.core.config import DEFAULT_YOLO_WEIGHTS, DEFAULT_SEGFORMER_HF_ID, ULTRALYTICS_DIR, SEGFORMER_DIR, SEGFORMER_DIR_TRAINED
from app.modules.video_processing.eis.splitter import SplitMode, split_stereo, split_quad

# Cityscapes palette...
CITYSCAPES_PALETTE = np.array([
    [  0,  0,  0], [128, 64,128], [244, 35,232], [ 70, 70, 70],
    [102,102,156], [190,153,153], [153,153,153], [250,170, 30],
    [220,220,  0], [107,142, 35], [152,251,152], [ 70,130,180],
    [220, 20, 60], [255,  0,  0], [  0,  0,142], [  0,  0, 70],
    [  0, 60,100], [  0, 80,100], [  0,  0,230], [119, 11, 32]
], dtype=np.uint8)

# Обновленная палитра для кастомной модели (только дорога зеленая)
CUSTOM_ROAD_PALETTE = np.array([
    [  0,   0,   0],  # Class 0: Фон (черный/прозрачный)
    [  0, 255,   0],  # Class 1: Дорога (зеленый)
], dtype=np.uint8)

class SegformerService:
    def __init__(self, model_dir=DEFAULT_SEGFORMER_HF_ID, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(self.device)
        self.model.eval()

    def process_batch(self, frames: list, alpha: float = 0.45) -> list:
        try:
            if not frames:
                return []
            h, w = frames[0].shape[:2]
            rgb_batch = [cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) for frame in frames]
            inputs = self.processor(images=rgb_batch, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs).logits
            segs = torch.argmax(outputs, dim=1).cpu().numpy().astype(np.uint8)
            resized_segs = [cv2.resize(seg, (w, h), interpolation=cv2.INTER_NEAREST) for seg in segs]
            processed = []
            for frame, seg in zip(frames, resized_segs):
                color = CITYSCAPES_PALETTE[seg % len(CITYSCAPES_PALETTE)]
                overlay = cv2.addWeighted(frame, 1 - alpha, color[..., ::-1], alpha, 0)
                processed.append(overlay)
            return processed
        except Exception as e:
            print(f"Error in Segformer batch: {e}")
            return frames

class OverlayService:
    def __init__(self, model_dir, use_compile=False, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(self.device)
        if use_compile and hasattr(torch, "compile"):
            self.model = torch.compile(self.model)
        self.model.eval()

    def process_batch(self, frames: list, alpha: float = 0.4) -> list:
        try:
            if not frames:
                return []
            h, w = frames[0].shape[:2]
            rgb_batch = [cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) for frame in frames]
            inputs = self.processor(images=rgb_batch, return_tensors="pt").to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs).logits
            
            segs = torch.argmax(outputs, dim=1).cpu().numpy().astype(np.uint8)
            resized_segs = [cv2.resize(seg, (w, h), interpolation=cv2.INTER_NEAREST) for seg in segs]
            
            processed = []
            for frame, seg in zip(frames, resized_segs):
                # Создаем маску только для дороги (класс 1)
                road_mask = (seg == 1).astype(np.uint8)
                
                # Создаем зеленый оверлей только там, где дорога
                green_overlay = np.zeros_like(frame)
                green_overlay[road_mask == 1] = [0, 255, 0]  # BGR зеленый
                
                # Применяем оверлей только на дорогу
                if np.any(road_mask):
                    overlay = frame.copy()
                    overlay[road_mask == 1] = cv2.addWeighted(
                        frame[road_mask == 1], 
                        1 - alpha, 
                        green_overlay[road_mask == 1], 
                        alpha, 
                        0
                    )
                    processed.append(overlay)
                else:
                    # Если дороги нет, возвращаем исходный кадр
                    processed.append(frame)
                    
            return processed
        except Exception as e:
            print(f"Error in custom road segmentation: {e}")
            return frames

    def apply_overlay(self, input_video_path: str, output_video_path: str, alpha: float = 0.4):
        cap = cv2.VideoCapture(input_video_path)
        if not cap.isOpened():
            raise ValueError("Не удалось открыть видео")
            
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_buffer = []
        batch_size = 8
        processed_count = 0

        print(f"🛣️  Применяем зеленое выделение только дороги...")

        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            frame_buffer.append(frame)
            if len(frame_buffer) == batch_size:
                processed = self.process_batch(frame_buffer, alpha)
                for proc_frame in processed:
                    out.write(proc_frame)
                processed_count += len(frame_buffer)
                frame_buffer = []
                
                if processed_count % 100 == 0:
                    print(f"Обработано {processed_count}/{total_frames} кадров")
                    
        # Обработка оставшихся кадров
        if frame_buffer:
            processed = self.process_batch(frame_buffer, alpha)
            for proc_frame in processed:
                out.write(proc_frame)
            processed_count += len(frame_buffer)

        cap.release()
        out.release()
        print(f"✅ Зеленое выделение дороги применено: {processed_count} кадров")
        return output_video_path

class QuadVideoService:
    def __init__(self,
                 output_dir="output",
                 yolo_model_path=DEFAULT_YOLO_WEIGHTS,
                 segformer=None,
                 custom_segmentor=None,
                 depth_service=None,
                 device=None,
                 ultralytics_dir=None,
                 batch_size=8,
                 video_processor=None):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.batch_size = batch_size if torch.cuda.is_available() else 1

        # Always have a valid ULTRALYTICS_DIR
        ultra_dir = ultralytics_dir or ULTRALYTICS_DIR
        # Resolve model path robustly
        if os.path.isabs(yolo_model_path) or os.path.exists(yolo_model_path):
            model_path = yolo_model_path
        else:
            model_path = os.path.join(ultra_dir, yolo_model_path)

        self.depth_service = depth_service or DepthOverlayService(device=self.device)
        self.yolo_model = YOLO(model_path)
        self.segformer = segformer or SegformerService(device=self.device)
        self.custom_segmentor = OverlayService(
            model_dir=SEGFORMER_DIR_TRAINED if os.path.exists(SEGFORMER_DIR_TRAINED) else SEGFORMER_DIR,
            use_compile=False,
            device=self.device
        )
        # Source of truth for layout selection (set by main.py / UI)
        self.video_processor = video_processor

    def _get_layout_mode(self):
        """
        Get layout mode from video processor; fallback to MONO.
        No auto-detection is used in the render path.
        """
        if self.video_processor and hasattr(self.video_processor, "get_selected_layout"):
            return self.video_processor.get_selected_layout()
        return SplitMode.MONO

    def _split_frame_by_layout(self, frame: np.ndarray) -> Dict[str, np.ndarray]:
        """Split frame according to the selected layout mode"""
        layout = self._get_layout_mode()
        
        print(f"Splitting frame with layout: {layout}")  # Отладка

        if layout == SplitMode.MONO:
            return {"mono": frame}
        elif layout in [SplitMode.STEREO_H, SplitMode.STEREO_V]:
            # Правильно обрабатываем стерео
            return split_stereo(frame, layout)
        elif layout == SplitMode.QUAD_2x2:
            # Правильно обрабатываем квадро
            return split_quad(frame)
        else:
            # Fallback
            return {"mono": frame}


    def yolo_batch(self, frames: list) -> list:
        results = self.yolo_model(frames, device=self.device, verbose=False)
        return [result.plot() for result in results]

    def _process_batch(self, frames: list) -> list:
        layout = self._get_layout_mode()
        print(f"🎥 Processing batch with layout: {layout}, frames: {len(frames)}")

        if layout == SplitMode.MONO:
            # Моно: обработка исходных кадров
            lt_batch = frames  # Верхний левый - оригинал
            rt_batch = self.yolo_batch(frames)  # Верхний правый - YOLO
            lb_batch = self.segformer.process_batch(frames)  # Нижний левый - Segformer
            rb_batch = self.custom_segmentor.process_batch(frames)  # Нижний правый - Custom

        elif layout in [SplitMode.STEREO_H, SplitMode.STEREO_V]:
            # Стерео: извлекаем ЛЕВУЮ/ВЕРХНЮЮ часть
            processed_frames = []
            for frame in frames:
                splits = split_stereo(frame, layout)
                if layout == SplitMode.STEREO_H:
                    key = "left"   # ИСПРАВЛЕНО: берем левую часть
                else:  # STEREO_V
                    key = "top"    # ИСПРАВЛЕНО: берем верхнюю часть
            
                part_frame = splits.get(key, frame)
                processed_frames.append(part_frame)

            print(f"🔄 Stereo: extracted {len(processed_frames)} {key} frames for processing")

            # Обрабатываем извлеченную часть всеми методами
            lt_batch = processed_frames                              # TL: оригинал левой/верхней части
            rt_batch = self.yolo_batch(processed_frames)            # TR: YOLO
            lb_batch = self.segformer.process_batch(processed_frames)   # BL: базовый SegFormer
            rb_batch = self.custom_segmentor.process_batch(processed_frames)  # BR: кастомный SegFormer

        elif layout == SplitMode.QUAD_2x2:
            # Квадро: извлекаем верхний левый квадрант
            processed_frames = []
            for frame in frames:
                splits = split_quad(frame)
                tl_frame = splits.get("tl", frame)
                processed_frames.append(tl_frame)

            print(f"🔄 Quad: extracted {len(processed_frames)} tl frames for processing")
            
            lt_batch = processed_frames
            rt_batch = self.yolo_batch(processed_frames)
            lb_batch = self.segformer.process_batch(processed_frames)
            rb_batch = self.custom_segmentor.process_batch(processed_frames)

        else:
            # Fallback к моно
            print(f"⚠️ Unknown layout {layout}, fallback to mono")
            lt_batch = frames
            rt_batch = self.yolo_batch(frames)
            lb_batch = self.segformer.process_batch(frames)
            rb_batch = self.custom_segmentor.process_batch(frames)

        # Создаем квадро-кадры (2×2) - ДЛЯ ВСЕХ РЕЖИМОВ
        result_batch = []
        for lt, rt, lb, rb in zip(lt_batch, rt_batch, lb_batch, rb_batch):
            top = np.hstack([lt, rt])
            bottom = np.hstack([lb, rb])
            quad = np.vstack([top, bottom])
            result_batch.append(quad)

        print(f"✅ Created {len(result_batch)} quad frames")
        return result_batch

    def process_video_quad(self, input_video_path: str, output_name="quad_video.mp4", fps=None, progress_cb=None):
        cap = cv2.VideoCapture(input_video_path)
        if not cap.isOpened():
            raise ValueError(f"Не удалось открыть видео: {input_video_path}")

        # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: определяем base размер на основе первого кадра и layout
        ret, first_frame = cap.read()
        if not ret:
            raise ValueError("Видео пустое")
        
        layout = self._get_layout_mode()
        
        # Вычисляем размер базового кадра (того, что будет обрабатываться)
        if layout == SplitMode.MONO:
            base_h, base_w = first_frame.shape[:2]
        elif layout in [SplitMode.STEREO_H, SplitMode.STEREO_V]:
            splits = split_stereo(first_frame, layout)
            if layout == SplitMode.STEREO_H:
                key = "left"  # Берем левую часть
            else:  # STEREO_V
                key = "top"   # Берем верхнюю часть
            base_frame = splits.get(key, first_frame)
            base_h, base_w = base_frame.shape[:2]
        elif layout == SplitMode.QUAD_2x2:
            splits = split_quad(first_frame)
            base_frame = splits.get("tl", first_frame)  # Берем верхний левый квадрант
            base_h, base_w = base_frame.shape[:2]
        else:
            base_h, base_w = first_frame.shape[:2]
        
        # Размеры выходного квадро-видео (2x2 от базового кадра)
        quad_h = base_h * 2
        quad_w = base_w * 2
        
        print(f"📹 Input: {first_frame.shape[1]}x{first_frame.shape[0]}, Layout: {layout}")
        print(f"📐 Base frame: {base_w}x{base_h}, Output quad: {quad_w}x{quad_h}")
        
        # Сбрасываем видео на начало
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        
        fps = fps or cap.get(cv2.CAP_PROP_FPS)
        output_path = os.path.join(self.output_dir, output_name)

        ffmpeg_cmd = [
            'ffmpeg', '-y',
            '-f', 'rawvideo',
            '-vcodec', 'rawvideo',
            '-pix_fmt', 'bgr24',
            '-s', f'{quad_w}x{quad_h}',  # ИСПРАВЛЕНО: используем правильный размер
            '-r', str(fps),
            '-i', '-',
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-preset', 'ultrafast',
            output_path
        ]
        proc = subprocess.Popen(ffmpeg_cmd, stdin=subprocess.PIPE)

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        frame_buffer = []
        processed = 0

        if progress_cb:
            progress_cb(0.0, desc="Обработка…")

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame_buffer.append(frame)

            if len(frame_buffer) == self.batch_size:
                quad_batch = self._process_batch(frame_buffer)
                print(f"📝 Writing {len(quad_batch)} frames from batch")  # Отладка
                
                for i, quad_frame in enumerate(quad_batch):
                    # Проверка размеров первого кадра
                    if processed == 0 and i == 0:
                        actual_h, actual_w = quad_frame.shape[:2]
                        print(f"📐 First output frame: {actual_w}x{actual_h} (expected: {quad_w}x{quad_h})")
                        if actual_w != quad_w or actual_h != quad_h:
                            print(f"⚠️ SIZE MISMATCH! This will cause ffmpeg tiling issues.")
                
                    # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: перенесено ВНУТРЬ цикла for
                    proc.stdin.write(quad_frame.tobytes())  # Теперь пишет ВСЕ кадры батча
                
                processed += len(frame_buffer)
                frame_buffer = []
                if progress_cb and total_frames > 0:
                    progress_cb(min(processed / total_frames, 0.99), desc="Обработка…")

        # Обработка остатка кадров
        if frame_buffer:
            quad_batch = self._process_batch(frame_buffer)
            print(f"📝 Writing {len(quad_batch)} frames from final batch")  # Отладка
            
            for quad_frame in quad_batch:
                proc.stdin.write(quad_frame.tobytes())
            processed += len(frame_buffer)
            if progress_cb and total_frames > 0:
                progress_cb(min(processed / total_frames, 0.99), desc="Обработка…")

        cap.release()
        proc.stdin.close()
        
        # Проверяем статус FFmpeg
        return_code = proc.wait()
        if return_code != 0:
            print(f"⚠️ FFmpeg finished with return code: {return_code}")
        else:
            print(f"✅ FFmpeg completed successfully")
        
        if progress_cb:
            progress_cb(1.0, desc="Готово")

        # Проверяем, что файл действительно создан
        if os.path.exists(output_path):
            file_size = os.path.getsize(output_path)
            print(f"✅ Video file created: {output_path} ({file_size} bytes)")
        else:
            print(f"❌ Video file not found: {output_path}")
            
        return output_path