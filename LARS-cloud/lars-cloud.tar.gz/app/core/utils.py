import torch

def get_gpu_info():
    if torch.cuda.is_available():
        device_count = torch.cuda.device_count()
        current_device = torch.cuda.current_device()
        device_name = torch.cuda.get_device_name(current_device)
        return f"✅ GPU доступен: {device_name} (устройство {current_device}/{device_count - 1})"
    else:
        return "❌ GPU недоступен, используется CPU"