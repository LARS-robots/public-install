import torch, os

def get_gpu_info():
    if torch.cuda.is_available():
        device_count = torch.cuda.device_count()
        current_device = torch.cuda.current_device()
        device_name = torch.cuda.get_device_name(current_device)
        return f"✅ GPU доступен: {device_name} (устройство {current_device}/{device_count - 1})"
    else:
        return "❌ GPU недоступен, используется CPU"
    
def find_project_root(start_dir, marker="requirements.txt"):
    """
    Ищем корень проекта по наличию marker-файла.
    Фолбэк: родитель папки 'app'; последний фолбэк — текущая.
    """
    d = start_dir
    while d != os.path.dirname(d):
        if os.path.isfile(os.path.join(d, marker)):
            return d
        d = os.path.dirname(d)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir