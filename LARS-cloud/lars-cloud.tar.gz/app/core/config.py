import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA_DIR = os.path.join(ROOT_DIR, "data")
FRAMES_DIR = os.path.join(DATA_DIR, "extracted_frames")
MASKS_DIR = os.path.join(DATA_DIR, "sam_masks")
SFM_DIR = os.path.join(DATA_DIR, "sfm_results")
OUTPUT_DIR = os.path.join(DATA_DIR, "output")
SEGFORMER_DIR = os.path.join(DATA_DIR, "segformer_model")
ULTRALYTICS_DIR = os.path.join(DATA_DIR, "ultralytics_model")
SEGFORMER_DIR_TRAINED = os.path.join(DATA_DIR, "segformer_model_trained")
POINTS_CLOUD_SFM_DIR = os.path.join(SFM_DIR, "pointclouds")
MESH_SFM_DIR = os.path.join(SFM_DIR, "meshes")
TRAJECTORY_SFM_DIR = os.path.join(SFM_DIR, "trajectories")

IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
MASK_EXTS  = {'.png'}

# Профили обучения (значения по умолчанию)
TRAINING_PROFILES = {
    "cpu_demo": {   # ноутбук / демонстрационный режим
        "epochs": 30,
        "batch_size": 2,
    },
    "gpu_standard": {  # сервер с нормальным GPU
        "epochs": 30,
        "batch_size": 8,
    },
}

# Параметры простых аугментаций
AUGMENTATION_CFG = {
    "hflip_p": 0.5,              # вероятностный горизонтальный флип
    "color_jitter": {            # лёгкая фотометрия
        "brightness": 0.15,
        "contrast":   0.15,
        "saturation": 0.10,
        "hue":        0.02,
    }
}

# Heartbeat (частота «пульса» прогресса для длительных операций, сек)
HEARTBEAT_SECONDS = 1.0

# Стандартные модели (для экспорта/тестов)
DEFAULT_YOLO_WEIGHTS = "yolo11n.pt"
DEFAULT_SEGFORMER_HF_ID = "nvidia/segformer-b0-finetuned-ade-512-512"
