import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA_DIR = os.path.join(ROOT_DIR, "data")
FRAMES_DIR = os.path.join(DATA_DIR, "extracted_frames")
MASKS_DIR = os.path.join(DATA_DIR, "sam_masks")
SFM_DIR = os.path.join(DATA_DIR, "sfm_results")
OUTPUT_DIR = os.path.join(DATA_DIR, "output")
SEGFORMER_DIR = os.path.join(DATA_DIR, "segformer_model")
ULTRALYTICS_DIR = os.path.join(DATA_DIR, "ultralytics_model")
SEGFORMER_DIR_TRAINED = os.path.join(DATA_DIR, "segformer_model_trained")
POINTS_CLOUD_SFM_DIR = os.path.join(SFM_DIR, "pointclouds")
MESH_SFM_DIR = os.path.join(SFM_DIR, "meshes")
TRAJECTORY_SFM_DIR = os.path.join(SFM_DIR, "trajectories")
