from __future__ import annotations
import os
from typing import Any, Dict, Optional
try:
    import tomllib as toml  # Py 3.11+
except Exception:  # pragma: no cover
    try:
        import tomli as toml    # fallback
    except ImportError:
        toml = None

SchemaError = ValueError

def find_project_root(start_dir, marker="requirements.txt"):
    """Find project root by looking for marker file"""
    dir_ = start_dir
    while dir_ != os.path.dirname(dir_):
        if os.path.isfile(os.path.join(dir_, marker)):
            return dir_
        dir_ = os.path.dirname(dir_)
    return start_dir

_DEFAULTS = {
    "frame_extraction": {
        "enabled": True,
        "mode": "every_n_seconds",      # "every_n_seconds" | "every_n_frames" | "timestamps" | "scene_change"
        "every_n_seconds": 1.0,         # used iff mode=="every_n_seconds"
        "every_n_frames": 0,            # used iff mode=="every_n_frames", 0→disabled
        "timestamps": [],               # list[float] seconds; used iff mode=="timestamps"
        "scene_change": {
            "enabled": False,
            "threshold": 0.30           # 0..1 relative change sensitivity
        }
    }
}

def _read_toml_bytes(path: str) -> Dict[str, Any]:
    if toml is None:
        return {}
    with open(path, "rb") as f:
        return toml.load(f)

def _resolve_config_path(explicit: Optional[str] = None) -> Optional[str]:
    # Priority: explicit → CWD/config.toml → project_root/app/config.toml
    if explicit and os.path.isfile(explicit):
        return explicit
    cwd = os.path.join(os.getcwd(), "config.toml")
    if os.path.isfile(cwd):
        return cwd
    pr = find_project_root(os.getcwd())
    pr_cfg = os.path.join(pr, "app", "config.toml")
    if os.path.isfile(pr_cfg):
        return pr_cfg
    # Also try project root directly
    pr_cfg_root = os.path.join(pr, "config.toml")
    return pr_cfg_root if os.path.isfile(pr_cfg_root) else None

def _expect_type(where: str, key: str, val: Any, typ):
    if not isinstance(val, typ):
        exp = getattr(typ, "__name__", str(typ))
        got = type(val).__name__
        raise SchemaError(f"{where} → {key}: expected {exp}, got {got}")

def _merge_defaults(user: Dict[str, Any], defaults: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(defaults)
    for k, dv in defaults.items():
        uv = user.get(k, None)
        if isinstance(dv, dict):
            out[k] = _merge_defaults(uv or {}, dv)
        else:
            out[k] = dv if uv is None else uv
    for k, uv in user.items():
        if k not in out:
            out[k] = uv
    return out

def _validate_frame_extraction(fe: Dict[str, Any]) -> Dict[str, Any]:
    where = "frame_extraction"
    _expect_type(where, "enabled", fe["enabled"], bool)
    _expect_type(where, "mode", fe["mode"], str)
    mode = fe["mode"].lower()
    if mode not in {"every_n_seconds", "every_n_frames", "timestamps", "scene_change"}:
        raise SchemaError(f"{where} → mode: one of every_n_seconds|every_n_frames|timestamps|scene_change")
    _expect_type(where, "every_n_seconds", fe["every_n_seconds"], (int, float))
    _expect_type(where, "every_n_frames",  fe["every_n_frames"],  int)
    _expect_type(where, "timestamps",      fe["timestamps"],      list)
    for i, t in enumerate(fe["timestamps"]):
        _expect_type(f"{where} → timestamps[{i}]", "value", t, (int, float))
    sc = fe["scene_change"]
    _expect_type(f"{where} → scene_change", "object", sc, dict)
    _expect_type(f"{where} → scene_change", "enabled", sc.get("enabled", False), bool)
    _expect_type(f"{where} → scene_change", "threshold", sc.get("threshold", 0.3), (int, float))
    return fe

def load_runtime_config(explicit_path: Optional[str] = None) -> Dict[str, Any]:
    path = _resolve_config_path(explicit_path)
    base = {}
    if path and toml is not None:
        try:
            base = _read_toml_bytes(path)
        except Exception as e:
            print(f"Warning: Failed to read config at {path}: {e}")
            # Continue with defaults
    merged = _merge_defaults(base, _DEFAULTS)
    # validate subtrees
    merged["frame_extraction"] = _validate_frame_extraction(merged["frame_extraction"])
    # keep path on object for better errors
    merged["_config_path"] = path or "<defaults-only>"
    return merged