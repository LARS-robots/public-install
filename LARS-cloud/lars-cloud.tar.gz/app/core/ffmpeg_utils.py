import subprocess
import os
from pathlib import Path
from PIL import Image
import shutil
import uuid
from typing import Optional

def extract_frames(video_path, frames_dir, fps=1):
    """
    Извлекает кадры из видео с помощью ffmpeg в директорию frames_dir,
    возвращает сообщение об успехе или ошибке.
    """
    os.makedirs(frames_dir, exist_ok=True)
    output_pattern = os.path.join(frames_dir, "frame_%04d.jpg")
    cmd = ['ffmpeg', '-i', video_path, '-vf', f'fps={fps}', output_pattern]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        return f"Извлечено кадров: {len([f for f in os.listdir(frames_dir) if os.path.isfile(os.path.join(frames_dir, f))])}"
    else:
        return f"Ошибка ffmpeg: {result.stderr}"


def assemble_video(input_frames_dir: str, output_path: str, fps: int = 30, cleanup_tmp: bool = True) -> str:
    """
    Собирает видео из изображений в директории input_frames_dir и сохраняет в output_path (mp4 H.264).
    Гарантирует последовательную нумерацию кадров для ffmpeg, конвертируя кадры в JPEG.
    Параметры:
        input_frames_dir: путь к папке с кадрами (любые .jpg/.jpeg/.png/.bmp/.tiff)
        output_path: путь к итоговому видео (например, data/output/depth_videos/out.mp4)
        fps: кадры в секунду
        cleanup_tmp: удалять ли временную последовательность кадров после сборки
    Возвращает:
        путь к сгенерированному видео (output_path) при успехе,
        в случае ошибки выбрасывает RuntimeError с текстом stderr ffmpeg.
    """
    input_dir = Path(input_frames_dir)
    if not input_dir.exists() or not input_dir.is_dir():
        raise FileNotFoundError(f"Папка с кадрами не найдена: {input_frames_dir}")

    # Собираем список файлов изображений, сортируем по имени
    exts = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp")
    all_files = sorted([p for p in input_dir.iterdir() if p.is_file() and p.suffix.lower() in exts])

    if len(all_files) == 0:
        raise FileNotFoundError(f"В папке {input_frames_dir} не найдено изображений.")

    # Создаём временную папку с уникальным именем
    tmp_dir = input_dir / f"_seq_tmp_{uuid.uuid4().hex}"
    tmp_dir.mkdir(parents=True, exist_ok=True)

    # Конвертируем/сохраняем все кадры в tmp_dir как JPEG с именами frame_000000.jpg ...
    try:
        for idx, src_path in enumerate(all_files):
            dst_name = f"frame_{idx:06d}.jpg"
            dst_path = tmp_dir / dst_name

            # Открываем и сохраняем как JPEG (гарантируется единый формат)
            with Image.open(src_path) as im:
                rgb = im.convert("RGB")
                rgb.save(dst_path, format="JPEG", quality=95)

        # Формируем ffmpeg команду
        pattern = str(tmp_dir / "frame_%06d.jpg")
        output_path_parent = Path(output_path).parent
        output_path_parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            "ffmpeg",
            "-y",  # overwrite output
            "-framerate", str(fps),
            "-i", pattern,
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            str(output_path)
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            # включаем stderr ffmpeg в исключение
            raise RuntimeError(f"Ошибка ffmpeg: {result.stderr}")

    finally:
        # Убираем временную папку, если нужно
        if cleanup_tmp and tmp_dir.exists():
            try:
                shutil.rmtree(tmp_dir)
            except Exception:
                pass

    return str(output_path)
