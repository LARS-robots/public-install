"""
Gradio UI для вкладки "Наложение глубины на видео"
Использует видео из первой вкладки напрямую, без загрузки.
"""

import os
from pathlib import Path
import uuid
import gradio as gr
from app.core.config import OUTPUT_DIR, FRAMES_DIR
from app.modules.video_processing.depth_overlay_service import DepthOverlayService
from app.core.ffmpeg_utils import extract_frames

# OpenCV colormap mapping (без выбора пользователем, дефолт magma)
try:
    import cv2
    CV2_COLORMAPS = {"magma": cv2.COLORMAP_MAGMA}
except Exception:
    CV2_COLORMAPS = {"magma": None}


def _ensure_dir(p: str):
    Path(p).mkdir(parents=True, exist_ok=True)


def run_depth_overlay_from_video(video_path: str, fps: int, cleanup_tmp: bool = True, progress=None):
    """
    Берёт видео напрямую, извлекает кадры во временную папку,
    применяет DepthOverlayService и создаёт комбинированное итоговое видео.
    """

    if not video_path or not Path(video_path).exists():
        return "❌ Видео не найдено", None

    # создаём временную папку для кадров
    uid_frames = uuid.uuid4().hex[:8]
    frames_subdir = Path(FRAMES_DIR) / f"depth_frames"
    _ensure_dir(str(frames_subdir))

    # извлекаем кадры
    try:
        extract_frames(video_path, str(frames_subdir), fps=fps)
    except Exception as e:
        return f"❌ Ошибка при извлечении кадров: {e}", None

    # создаём сервис глубины
    try:
        service = DepthOverlayService(colormap=CV2_COLORMAPS["magma"])
    except Exception as e:
        return f"❌ Не удалось инициализировать модель: {e}", None

    # путь для итогового видео
    output_video_path = os.path.join(OUTPUT_DIR, "depth_overlay_combined.mp4")
    _ensure_dir(OUTPUT_DIR)

    # обработка кадров с прогрессом
    try:
        service.process_frames_dir(
            input_frames_dir=str(frames_subdir),
            output_video_path=output_video_path,
            fps=fps,
            output_frames_dir=None,
            cleanup_frames=cleanup_tmp,
            progress=progress
        )
    except Exception as e:
        return f"❌ Ошибка при генерации depth-видео: {e}", None

    return f"✅ Готово! Видео сохранено: {output_video_path}", output_video_path


def create_depth_overlay_ui(video_path_state):
    """
    Минималистичный UI для вкладки "Наложение глубины на видео" с прогресс-баром.
    """
    with gr.Blocks() as depth_ui:
        gr.Markdown("## Наложение глубины на видео")

        with gr.Row():
            with gr.Column(scale=1):
                out_video = gr.Video(label="Результат (оригинал | глубина)")

            with gr.Column(scale=1):
                status_box = gr.Textbox(label="Статус", interactive=False, lines=3)
                fps_input = gr.Number(value=30, label="FPS для извлечения кадров", precision=0)
                run_btn = gr.Button("Запустить наложение глубины")
                progress_bar = gr.Progress()


        # callback
        def _on_run(video_path, fps):
            try:
                fps_int = int(fps)
            except Exception:
                fps_int = 5
            return run_depth_overlay_from_video(video_path, fps_int, progress=progress_bar)

        run_btn.click(
            fn=_on_run,
            inputs=[video_path_state, fps_input],
            outputs=[status_box, out_video]
        )

    return depth_ui


if __name__ == "__main__":
    demo = create_depth_overlay_ui(video_path_state=gr.State())
    demo.launch(server_name="0.0.0.0", server_port=7865)
