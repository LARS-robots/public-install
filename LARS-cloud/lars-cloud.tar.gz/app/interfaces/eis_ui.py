# app/interfaces/eis_ui.py
# filepath: /home/master/PycharmProjects/LARS/LARS-cloud/app/interfaces/eis_ui.py

import gradio as gr
from app.modules.video_processing.eis.eis_service import analyze, stabilize
from app.modules.video_processing.eis.eis import EISParams
from app.modules.video_processing.eis.splitter import SplitMode, StereoPick

def create_eis_ui(video_path: str = None):
    with gr.Group() as eis_tab:
        gr.Markdown("## Стабилизация (EIS)")
        with gr.Tabs():
            # ---------------- Stereo TAB ----------------
            with gr.Tab("Stereo"):
                with gr.Row():
                    with gr.Column(scale=2):
                        in_video_s = gr.Video(label="Stereo видео")
                        with gr.Accordion("Параметры", open=False):
                            hfov_s = gr.Slider(30.0, 140.0, value=84.0, step=0.5, label="HFOV (град)")
                            ema_pos_s = gr.Slider(0.01, 0.9, value=0.20, step=0.01, label="EMA pos α")
                            ema_rot_s = gr.Slider(0.01, 0.9, value=0.20, step=0.01, label="EMA rot α")
                            crop_s = gr.Slider(0, 40, value=8, step=1, label="Safety-crop (%)")
                            show_dbg_s = gr.Checkbox(value=False, label="Показать траекторию/фичи")
                            layout_s = gr.Radio(["stereo_horizontal", "stereo_vertical"], value="stereo_horizontal",
                                                label="Ориентация стерео")
                            pick_s = gr.Radio(["left", "right", "both"], value="right", label="Выбор половины")
                    with gr.Column(scale=1, min_width=250):
                        status_s = gr.Markdown("", label="Статус")
                        out_path_s = gr.Textbox(label="Результат", interactive=False)
                        with gr.Row():
                            analyze_btn_s = gr.Button("Анализ", variant="secondary")
                            stab_btn_s = gr.Button("Стабилизировать", variant="primary")
                out_video_s = gr.Video(label="Выход (stereo)")

            # ---------------- Quad TAB ----------------
            with gr.Tab("Quad"):
                with gr.Row():
                    with gr.Column(scale=2):
                        in_video_q = gr.Video(label="Quad видео (2×2)")
                        with gr.Accordion("Параметры", open=False):
                            hfov_q = gr.Slider(30.0, 140.0, value=84.0, step=0.5, label="HFOV (град)")
                            ema_pos_q = gr.Slider(0.01, 0.9, value=0.20, step=0.01, label="EMA pos α")
                            ema_rot_q = gr.Slider(0.01, 0.9, value=0.20, step=0.01, label="EMA rot α")
                            crop_q = gr.Slider(0, 40, value=8, step=1, label="Safety-crop (%)")
                            show_dbg_q = gr.Checkbox(value=False, label="Показать траекторию/фичи")
                    with gr.Column(scale=1, min_width=250):
                        status_q = gr.Markdown("", label="Статус")
                        out_path_q = gr.Textbox(label="Базовый путь (см. 4 файла)", interactive=False)
                        with gr.Row():
                            analyze_btn_q = gr.Button("Анализ (TL)", variant="secondary")
                            stab_btn_q = gr.Button("Стабилизировать 4 плитки", variant="primary")
                with gr.Row():
                    tl_video = gr.Video(label="TL"); tr_video = gr.Video(label="TR")
                with gr.Row():
                    bl_video = gr.Video(label="BL"); br_video = gr.Video(label="BR")

        def _pack_params(hfov, ep, er, c, dbg):
            return EISParams(hfov_deg=hfov, ema_alpha_pos=ep, ema_alpha_rot=er, safety_crop_percent=int(c), show_debug=dbg)

        # --------- Stereo handlers ---------
        def run_analyze_s(video, hfov, ep, er, c, dbg, layout, pick, progress=gr.Progress(track_tqdm=False)):
            if not video:
                return "❌ Загрузите видео.", "", None
            p = _pack_params(hfov, ep, er, c, dbg)
            def cb(pct, stage): progress(pct/100.0, desc=stage)
            
            # ИСПРАВЛЕНИЕ: всегда нормализуем pick
            pick_norm = normalize_pick_for_layout(layout, pick)
            print(f"🎯 EIS UI: layout={layout}, pick={pick} -> normalized={pick_norm}")
            
            result = analyze(video, p, cb, mode=SplitMode(layout), stereo_pick=StereoPick(pick_norm))
            msg = "**Готово (analyze)**: сохранены метрики и превью"
            return msg, result[1], result[2]

        def run_stab_s(video, hfov, ep, er, c, dbg, layout, pick, progress=gr.Progress(track_tqdm=False)):
            if not video:
                return "❌ Загрузите видео.", "", None
            p = _pack_params(hfov, ep, er, c, dbg)
            def cb(pct, stage): progress(pct/100.0, desc=stage)
            
            # ИСПРАВЛЕНИЕ: всегда нормализуем pick
            pick_norm = normalize_pick_for_layout(layout, pick)
            print(f"🎯 EIS UI: layout={layout}, pick={pick} -> normalized={pick_norm}")
            
            result = stabilize(video, p, cb, mode=SplitMode(layout), stereo_pick=StereoPick(pick_norm))
            msg = "**Готово (stab)**: сохранено видео"
            return msg, result[0], result[2]

        def load_video(path: str):
            import os
            if path and os.path.isfile(path) and path.endswith(".mp4"):
                return path
            return None

        analyze_btn_s.click(
            fn=run_analyze_s,
            inputs=[in_video_s, hfov_s, ema_pos_s, ema_rot_s, crop_s, show_dbg_s, layout_s, pick_s],
            outputs=[status_s, out_path_s]
        )
        stab_evt_s = stab_btn_s.click(
            fn=run_stab_s,
            inputs=[in_video_s, hfov_s, ema_pos_s, ema_rot_s, crop_s, show_dbg_s, layout_s, pick_s],
            outputs=[status_s, out_path_s, out_video_s]
        )
        stab_evt_s.then(fn=load_video, inputs=[out_path_s], outputs=[out_video_s])

        # --------- Quad handlers ---------
        def run_analyze_q(video, hfov, ep, er, c, dbg, progress=gr.Progress(track_tqdm=False)):
            if not video: return "❌ Загрузите видео.", ""
            p = _pack_params(hfov, ep, er, c, dbg)
            def cb(pct, stage): progress(pct/100.0, desc=stage)
            # Анализ на TL как «репрезентативном» квадранте
            m = analyze(video, p, cb, mode=SplitMode.QUAD_2x2, stereo_pick=None)
            txt = (f"**Анализ (TL) завершён**  \n"
                   f"- джиттер (до): **{m['jitter_before_pct']:.2f}%** HFOV  \n"
                   f"- фичи (среднее): **{m['n_features_avg']:.1f}**  \n"
                   f"- инлайеры (среднее): **{m['n_inliers_avg']:.1f}**")
            return txt, ""

        def run_stab_q(video, hfov, ep, er, c, dbg, progress=gr.Progress(track_tqdm=False)):
            if not video:
                return "❌ Загрузите видео.", "", None, None, None, None
            p = _pack_params(hfov, ep, er, c, dbg)
            def cb(pct, stage): progress(pct/100.0, desc=stage)
            result = stabilize(video, p, cb, mode=SplitMode.QUAD_2x2, stereo_pick=None)
            # ожидаем dict
            def pick_path(k): return result[k][0] if k in result else None
            msg = "**Готово (quad)**: сохранены 4 ролика: TL, TR, BL, BR"
            # базовый «путь» оставим пустым, чтобы не подставлять его в stereo-плеер
            return msg, "", pick_path("tl"), pick_path("tr"), pick_path("bl"), pick_path("br")

        analyze_btn_q.click(
            fn=run_analyze_q,
            inputs=[in_video_q, hfov_q, ema_pos_q, ema_rot_q, crop_q, show_dbg_q],
            outputs=[status_q, out_path_q]
        )
        stab_btn_q.click(
            fn=run_stab_q,
            inputs=[in_video_q, hfov_q, ema_pos_q, ema_rot_q, crop_q, show_dbg_q],
            outputs=[status_q, out_path_q, tl_video, tr_video, bl_video, br_video]
        )

    return eis_tab


def normalize_pick_for_layout(layout: str, pick: str) -> str:
    """
    Нормализует выбор пользователя под конкретный layout
    """
    if pick == "both":
        return "both"
        
    if layout == "stereo_vertical":
        # ПРОБЛЕМА ЗДЕСЬ: неправильное сопоставление
        if pick in ("left", "top"):
            return "top"     # левый выбор -> верхняя половина
        elif pick in ("right", "bottom"):
            return "bottom"  # правый выбор -> нижняя половина  ← ВОТ ТУТ!
        else:
            return "top"     # default
    else:  # stereo_horizontal
        if pick in ("left", "top"):
            return "left"    # левый выбор -> левая половина
        elif pick in ("right", "bottom"):
            return "right"   # правый выбор -> правая половина
        else:
            return "left"    # default