import os
import sys
from app.core.utils import find_project_root

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
import torch
from app.modules.video_processing.video_processor import VideoProcessor
from app.modules.segmentation.sam_service import SAMService
from app.modules.segmentation.training_service import TrainingService
from app.core.config import FRAMES_DIR, MASKS_DIR, SEGFORMER_DIR, OUTPUT_DIR, SEGFORMER_DIR_TRAINED, IMAGE_EXTS, MASK_EXTS
from app.modules.segmentation.overlay_service import OverlayService

# Create directories if they don't exist
os.makedirs(FRAMES_DIR, exist_ok=True)
os.makedirs(MASKS_DIR, exist_ok=True)
os.makedirs(SEGFORMER_DIR, exist_ok=True)

def format_status_message(message, is_error=False):
    """Форматирует сообщение статуса для красивого отображения в Gradio."""
    prefix = "❌ Ошибка" if is_error else "✅ Успех"
    return f"""
{prefix}
{message}
"""

def create_segmentation_ui():
    video_processor = VideoProcessor()
    config = {
        "cpu_weights": os.path.join(SEGFORMER_DIR, "sam2.1_t.pt"),
        "cuda_weights": os.path.join(SEGFORMER_DIR, "sam2.1_l.pt"),
        "output_dir": SEGFORMER_DIR
    }
    if torch.cuda.is_available() and torch.cuda.get_device_capability()[0] < 7:
        torch.cuda.is_available = lambda: False
    sam_service = SAMService(config)
    sam_service.initialize_session(FRAMES_DIR, MASKS_DIR)
    sam_service.current_idx = 0

    frames_count = 0

    def handle_click(evt: gr.SelectData):
        if evt is None or evt.index is None:
            return sam_service.load_image(sam_service.current_idx)
        return sam_service.add_point(evt.index[0], evt.index[1])

    def change_current_video_frame(video_idx):
        video_idx = int(video_idx)
        sam_service.current_idx = video_idx
        sam_service.reset_points()
        return sam_service.load_image(video_idx)

    def reset_points_handler(current_idx):
        if current_idx is None:
            current_idx = 0
        sam_service.reset_points()
        return sam_service.load_image(int(current_idx))

    def set_mode_handler(mode):
        return sam_service.set_mode(mode)
    
    def get_frames_count():
        if not os.path.exists(FRAMES_DIR):
            return 0
        return len([f for f in os.listdir(FRAMES_DIR)
                    if os.path.splitext(f.lower())[1] in IMAGE_EXTS])

    def initialize_slider():
        frames_count = get_frames_count()
        if frames_count > 0:
            return gr.Slider(
                minimum=0,
                maximum=frames_count - 1,
                value=0,
                step=1,
                label=f"Кадр (всего кадров: {frames_count})"
            )
        else:
            return gr.Slider(
                minimum=0,
                maximum=0,
                value=0,
                step=1,
                label="Кадр (нет кадров в папке)"
            )

    def refresh_frames_and_slider():
        """Рефреш списка кадров в SAM и синхрон обновления слайдера/изображения."""
        frames = sam_service.refresh_frames()
        # безопасно грузим текущий (или нулевой) кадр
        img_val = None
        if frames > 0:
            try:
                img_val = sam_service.load_image(sam_service.current_idx)
            except Exception:
                sam_service.current_idx = 0
                img_val = sam_service.load_image(0)
        slider_update = gr.Slider.update(
            minimum=0,
            maximum=max(0, frames - 1),
            value=min(sam_service.current_idx, max(0, frames - 1)),
            step=1,
            label=f"Кадр (всего кадров: {frames})" if frames > 0 else "Кадр (нет кадров в папке)"
        )
        return img_val, slider_update, f"🔄 Обновлено: {frames} файлов"


    def run_finetune_wrapper(progress=gr.Progress()):
        # Проверки наличия данных — без изменений
        mask_files = [f for f in os.listdir(MASKS_DIR) if os.path.splitext(f.lower())[1] in MASK_EXTS] if os.path.exists(MASKS_DIR) else []
        if not mask_files:
            return format_status_message(
                'Нет масок для обучения. Пожалуйста, создайте маски во вкладке "Интерактивная сегментация".',
                is_error=True
            )
        image_files = [f for f in os.listdir(FRAMES_DIR) if os.path.splitext(f.lower())[1] in IMAGE_EXTS] if os.path.exists(FRAMES_DIR) else []
        if not image_files:
            return format_status_message(
                'Нет изображений в папке кадров. Пожалуйста, загрузите видео или изображения во вкладке "Интерактивная сегментация".',
                is_error=True
            )

        # Вызываем TrainingService c профилями из config 
        svc = TrainingService(FRAMES_DIR, MASKS_DIR, SEGFORMER_DIR)

        # Обёртка для прогресса/heartbeat
        def _progress_cb(epoch, total_epochs, frac_in_epoch, text):
            # Общий прогресс 0..1: завер. предыдущие эпохи + текущая доля
            overall = (epoch - 1 + frac_in_epoch) / max(1, total_epochs)
            progress(overall, desc=f"Обучение: {text}")

        logs = svc.train(progress_cb=_progress_cb)

        # Возвращаем краткий итог
        return format_status_message("Обучение завершено успешно!", is_error=False)

    def overlay_mask_wrapper(input_video_path, progress=gr.Progress()):
        if not input_video_path:
            gr.Warning("Выберите видео для наложения маски.")
            return None

        overlay_service = OverlayService(SEGFORMER_DIR_TRAINED)
        output_video = os.path.join(OUTPUT_DIR, "overlay_video.mp4")

        def _progress_cb(frac: float, text: str):
            progress(frac, desc=f"Наложение маски: {text}")

        out_path = overlay_service.apply_overlay(input_video_path, output_video, progress_cb=_progress_cb)
        gr.Success(f"Маска наложена: {out_path}")
        return out_path

    with gr.Blocks(title="LARS Cloud - Сегментация") as demo:
        gr.Markdown("# ")
        with gr.Tabs():
            with gr.Tab("Интерактивная сегментация"):
                with gr.Column():
                    with gr.Row():
                        with gr.Column(scale=1):
                            img = gr.Image(interactive=True, label="Кликай для сегментации", height=500)
                        with gr.Column(scale=2):
                            with gr.Row():
                                frames_count = get_frames_count()
                                video_idx = gr.Slider(
                                    minimum=0,
                                    maximum=max(0, frames_count - 1),
                                    value=0,
                                    step=1,
                                    label=f"Кадр (всего кадров: {frames_count})" if frames_count > 0 else "Кадр (нет кадров в папке)"
                                )
                                status = gr.Textbox(label="Статус", max_lines=2)
                            with gr.Row():
                                with gr.Column():
                                    mode_add = gr.Button("Добавить")
                                    mode_sub = gr.Button("Вычесть")
                                    calc_btn = gr.Button("Рассчитать")
                                with gr.Column():
                                    save_btn = gr.Button("Сохранить маску")
                                    reset_btn = gr.Button("Сбросить разметку")
                                    delete_masks_btn = gr.Button("Удалить все маски", variant="secondary")
                            with gr.Row():
                                refresh_btn = gr.Button("🔄 Обновить кадры", variant="secondary")


            with gr.Tab("Обучение модели"):
                with gr.Row():
                    with gr.Column(scale=1):
                        log_box = gr.Textbox(label="Статус", lines=15, interactive=False)
                    with gr.Column(scale=1):
                        train_btn = gr.Button("Запустить обучение", variant="primary")

            with gr.Tab("Наложение маски на видео"):
                with gr.Row():
                    with gr.Column():
                        input_video = gr.Video(label="Загрузить видео для наложения маски")
                        overlay_btn = gr.Button("Наложить маску", variant="primary")
                    with gr.Column():
                        overlay_video_display = gr.Video(label="Обработанное видео", interactive=False)

        # Обработчики событий
        video_idx.change(fn=change_current_video_frame, inputs=video_idx, outputs=img)
        img.select(fn=handle_click, outputs=img)
        mode_add.click(fn=lambda: set_mode_handler(1), outputs=status)
        mode_sub.click(fn=lambda: set_mode_handler(0), outputs=status)
        calc_btn.click(fn=sam_service.calculate_mask, outputs=img)
        save_btn.click(fn=sam_service.save_mask, outputs=status)
        reset_btn.click(fn=reset_points_handler, inputs=video_idx, outputs=img)
        delete_masks_btn.click(fn=sam_service.delete_all_masks, outputs=status)
        refresh_btn.click(fn=refresh_frames_and_slider, outputs=[img, video_idx, status])
        train_btn.click(fn=run_finetune_wrapper, outputs=log_box)
        overlay_btn.click(fn=overlay_mask_wrapper, inputs=input_video, outputs=overlay_video_display)

    return demo

if __name__ == "__main__":
    demo = create_segmentation_ui()
    demo.launch(server_name="0.0.0.0", server_port=7861)