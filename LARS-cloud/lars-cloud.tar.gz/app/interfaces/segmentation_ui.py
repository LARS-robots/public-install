import os
import sys

# Find project root by looking for a specific marker file (e.g., requirements.txt)
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    # Fallback: return the parent directory of 'app' if marker not found
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir  # Last resort fallback

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
import torch
from app.modules.video_processing.video_processor import VideoProcessor
from app.modules.segmentation.sam_service import SAMService
from app.modules.segmentation.training_service import TrainingService
from app.core.config import FRAMES_DIR, MASKS_DIR, SEGFORMER_DIR, OUTPUT_DIR, SEGFORMER_DIR_TRAINED
from app.modules.segmentation.overlay_service import OverlayService

# Create directories if they don't exist
os.makedirs(FRAMES_DIR, exist_ok=True)
os.makedirs(MASKS_DIR, exist_ok=True)
os.makedirs(SEGFORMER_DIR, exist_ok=True)

def format_status_message(message, is_error=False):
    """Форматирует сообщение статуса для красивого отображения в Gradio."""
    prefix = "❌ Ошибка" if is_error else "✅ Успех"
    return f"""
{prefix}
{message}
"""

def create_segmentation_ui():
    video_processor = VideoProcessor()
    config = {
        "cpu_weights": os.path.join(SEGFORMER_DIR, "sam2.1_t.pt"),
        "cuda_weights": os.path.join(SEGFORMER_DIR, "sam2.1_l.pt"),
        "output_dir": SEGFORMER_DIR
    }
    if torch.cuda.is_available() and torch.cuda.get_device_capability()[0] < 7:
        torch.cuda.is_available = lambda: False
    sam_service = SAMService(config)
    sam_service.initialize_session(FRAMES_DIR, MASKS_DIR)
    sam_service.current_idx = 0

    frames_count = len([f for f in os.listdir(FRAMES_DIR)
                        if os.path.splitext(f.lower())[1] in {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}]) if os.path.exists(FRAMES_DIR) else 0

    def handle_click(evt: gr.SelectData):
        if evt is None or evt.index is None:
            return sam_service.load_image(sam_service.current_idx)
        return sam_service.add_point(evt.index[0], evt.index[1])

    def change_current_video_frame(video_idx):
        video_idx = int(video_idx)
        sam_service.current_idx = video_idx
        sam_service.reset_points()
        return sam_service.load_image(video_idx)

    def reset_points_handler(current_idx):
        if current_idx is None:
            current_idx = 0
        sam_service.reset_points()
        return sam_service.load_image(int(current_idx))

    def set_mode_handler(mode):
        return sam_service.set_mode(mode)

    def get_frames_count():
        if not os.path.exists(FRAMES_DIR):
            return 0
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
        frame_files = [f for f in os.listdir(FRAMES_DIR)
                       if os.path.splitext(f.lower())[1] in image_extensions]
        return len(frame_files)

    def initialize_slider():
        frames_count = get_frames_count()
        if frames_count > 0:
            return gr.Slider(
                minimum=0,
                maximum=frames_count - 1,
                value=0,
                step=1,
                label=f"Кадр (всего кадров: {frames_count})"
            )
        else:
            return gr.Slider(
                minimum=0,
                maximum=0,
                value=0,
                step=1,
                label="Кадр (нет кадров в папке)"
            )

    def run_finetune_wrapper():
        # Check if MASKS_DIR has any mask files
        mask_extensions = {'.png'}
        mask_files = [f for f in os.listdir(MASKS_DIR) if os.path.splitext(f.lower())[1] in mask_extensions] if os.path.exists(MASKS_DIR) else []
        if not mask_files:
            return format_status_message(
                """Нет масок для обучения. Пожалуйста, создайте маски во вкладке "Интерактивная сегментация".""",
                is_error=True
            )

        # Check if FRAMES_DIR has corresponding images
        image_extensions = {'.jpg', '.jpeg'}
        image_files = [f for f in os.listdir(FRAMES_DIR) if os.path.splitext(f.lower())[1] in image_extensions] if os.path.exists(FRAMES_DIR) else []
        if not image_files:
            return format_status_message(
                """Нет изображений в папке кадров. Пожалуйста, загрузите видео или изображения во вкладке "Интерактивная сегментация".""",
                is_error=True
            )

        # Determine batch size: min(500, number of mask files)
        num_masks = len(mask_files)
        batch_size = min(500, num_masks)
        epochs = 100

        # Train the model
        svc = TrainingService(FRAMES_DIR, MASKS_DIR, SEGFORMER_DIR)
        logs = svc.train(batch_size=batch_size, num_epochs=epochs)

        # Format logs for display
        if isinstance(logs, list) and len(logs) == 1 and "No mask files found" in logs[0]:
            return format_status_message(logs[0], is_error=True)
        return format_status_message(
            f"""Обучение завершено успешно!""",
            is_error=False
        )

    def overlay_mask_wrapper(input_video_path):
        if not input_video_path:
            return format_status_message("Выберите видео для наложения маски.", is_error=True), None
        num_frames = len(os.listdir(FRAMES_DIR))
        batch_size = min(500, num_frames)
        overlay_service = OverlayService(SEGFORMER_DIR_TRAINED)
        output_video = os.path.join(OUTPUT_DIR, "overlay_video.mp4")
        output_video = overlay_service.apply_overlay(input_video_path, output_video)
        return format_status_message(f"Маска наложена успешно: {output_video}"), output_video

    with gr.Blocks(title="LARS Cloud - Сегментация") as demo:
        gr.Markdown("# Сегментация видео (SAM & SegFormer)")
        with gr.Tabs():
            with gr.Tab("Интерактивная сегментация"):
                with gr.Column():
                    with gr.Row():
                        with gr.Column(scale=1):
                            img = gr.Image(interactive=True, label="Кликай для сегментации", height=500)
                        with gr.Column(scale=2):
                            with gr.Row():
                                frames_count = get_frames_count()
                                video_idx = gr.Slider(
                                    minimum=0,
                                    maximum=max(0, frames_count - 1),
                                    value=0,
                                    step=1,
                                    label=f"Кадр (всего кадров: {frames_count})" if frames_count > 0 else "Кадр (нет кадров в папке)"
                                )
                                status = gr.Textbox(label="Статус", max_lines=2)
                            with gr.Row():
                                with gr.Column():
                                    mode_add = gr.Button("Добавить")
                                    mode_sub = gr.Button("Вычесть")
                                    calc_btn = gr.Button("Рассчитать")
                                with gr.Column():
                                    save_btn = gr.Button("Сохранить маску")
                                    reset_btn = gr.Button("Сбросить разметку")
                                    delete_masks_btn = gr.Button("Удалить все маски", variant="secondary")

            with gr.Tab("Обучение модели"):
                with gr.Row():
                    with gr.Column(scale=1):
                        log_box = gr.Textbox(label="Статус", lines=15, interactive=False)
                    with gr.Column(scale=1):
                        train_btn = gr.Button("Запустить дообучение", variant="primary")

            with gr.Tab("Наложение маски на видео"):
                with gr.Row():
                    with gr.Column():
                        input_video = gr.Video(label="Загрузить видео для наложения маски")
                        overlay_btn = gr.Button("Наложить маску", variant="primary")
                    with gr.Column():
                        overlay_status = gr.Textbox(label="Статус", interactive=False)
                        overlay_video_display = gr.Video(label="Обработанное видео", interactive=False)

        # Обработчики событий
        video_idx.change(fn=change_current_video_frame, inputs=video_idx, outputs=img)
        img.select(fn=handle_click, outputs=img)
        mode_add.click(fn=lambda: set_mode_handler(1), outputs=status)
        mode_sub.click(fn=lambda: set_mode_handler(0), outputs=status)
        calc_btn.click(fn=sam_service.calculate_mask, outputs=img)
        save_btn.click(fn=sam_service.save_mask, outputs=status)
        reset_btn.click(fn=reset_points_handler, inputs=video_idx, outputs=img)
        delete_masks_btn.click(fn=sam_service.delete_all_masks, outputs=status)
        train_btn.click(fn=run_finetune_wrapper, outputs=log_box)
        overlay_btn.click(fn=overlay_mask_wrapper, inputs=input_video, outputs=[overlay_status, overlay_video_display])

    return demo

if __name__ == "__main__":
    demo = create_segmentation_ui()
    demo.launch(server_name="0.0.0.0", server_port=7861)