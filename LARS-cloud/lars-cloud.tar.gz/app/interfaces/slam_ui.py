import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
import open3d as o3d
from app.modules.slam.moge2_slam_pipeline import run_moge2_python_slam
from app.core.config import SFM_DIR

def _prepare_clean_environment():
    os.makedirs(SFM_DIR, exist_ok=True)
    for f in os.listdir(SFM_DIR):
        if f.endswith((".ply", ".glb")):
            try:
                os.remove(os.path.join(SFM_DIR, f))
            except:
                pass

# ----------------------
# Create Gradio UI
# ----------------------
def create_slam_ui():
    with gr.Blocks(title="MoGe-2 SLAM 3D Reconstruction") as demo:
        gr.Markdown("## 3D Reconstruction from Video")

        with gr.Row():
            with gr.Column(scale=1):
                status_box = gr.Textbox(label="Live Status", value="Waiting for input...", interactive=False,
                                        max_lines=15, show_copy_button=True)
                video_input = gr.File(label="Upload Video")
                run_btn = gr.Button("🚀 Run SLAM", variant="primary", size="lg")

            with gr.Column(scale=2):
                model3d_view = gr.Model3D(label="3D Model", visible=False)
                result_file = gr.File(label="Download .ply file", visible=False)

        # ----------------------
        # Run SLAM streaming
        # ----------------------
        def run_slam_streaming(video_file):
            if video_file is None:
                yield "❌ Please provide a video", None, None

            _prepare_clean_environment()
            progress_messages = []

            try:
                # Run the MoGe2 pipeline with live streaming
                for msg in run_moge2_python_slam(video_file.name):
                    progress_messages.append(msg)
                    # Show only last 10 messages for readability
                    yield "\n".join(progress_messages[-10:]), None, None

                # Find the latest .ply file
                ply_files = [os.path.join(SFM_DIR, f) for f in os.listdir(SFM_DIR) if f.endswith(".ply")]
                if not ply_files:
                    yield "\n".join(progress_messages[-10:]) + "\n❌ No result found", None, None
                    return

                final_ply = max(ply_files, key=os.path.getmtime)

                # Convert to GLB for Model3D
                try:
                    pcd = o3d.io.read_point_cloud(final_ply)
                    mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha=0.03)
                    mesh.compute_vertex_normals()
                    final_glb = os.path.splitext(final_ply)[0] + ".glb"
                    o3d.io.write_triangle_mesh(final_glb, mesh, write_triangle_uvs=False)

                    yield "\n".join(progress_messages[-10:]) + "\n✅ Reconstruction complete", \
                        gr.update(value=final_glb, visible=True), \
                        gr.update(value=final_ply, visible=True)

                except Exception as e:
                    yield "\n".join(progress_messages[-10:]) + f"\n⚠️ Failed to convert to 3D: {e}", None, final_ply

            except Exception as e:
                yield f"❌ Pipeline error: {str(e)}", None, None

        run_btn.click(
            fn=run_slam_streaming,
            inputs=[video_input],
            outputs=[status_box, model3d_view, result_file]
        )

    return demo


# ----------------------
# Launch UI
# ----------------------
if __name__ == "__main__":
    demo = create_slam_ui()
    demo.launch(server_name="0.0.0.0", server_port=7862)
