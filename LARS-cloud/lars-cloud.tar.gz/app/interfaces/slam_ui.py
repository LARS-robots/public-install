import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
import numpy as np
import open3d as o3d
from app.modules.slam.moge2_slam_pipeline import run_moge2_python_slam
from app.core.config import SFM_DIR

def _prepare_clean_environment():
    os.makedirs(SFM_DIR, exist_ok=True)
    for f in os.listdir(SFM_DIR):
        if f.endswith((".ply", ".glb")):
            try:
                os.remove(os.path.join(SFM_DIR, f))
            except:
                pass

# ----------------------
# Run SLAM streaming
# ----------------------
def run_slam_streaming(video_file):
    if video_file is None:
        yield "❌ Please provide a video", None, None

    _prepare_clean_environment()
    progress_messages = []

    try:
        # --- Run SLAM with live streaming ---
        for msg in run_moge2_python_slam(video_file.name):
            progress_messages.append(msg)
            # keep UI alive
            yield "\n".join(progress_messages[-10:]), None, None

        # --- Find the result robustly ---
        final_ply = os.path.join(SFM_DIR, "final_pointcloud.ply")
        if not os.path.isfile(final_ply):
            # fallback scan (in case name differs)
            ply_files = [
                os.path.join(SFM_DIR, f) for f in os.listdir(SFM_DIR)
                if f.lower().endswith(".ply")
            ]
            final_ply = max(ply_files, key=os.path.getmtime) if ply_files else None

        if not final_ply or not os.path.isfile(final_ply):
            yield "\n".join(progress_messages[-10:]) + "\n❌ No result found", None, None
            return

        # --- Quick preview mesh pipeline (streamed) ---
        try:
            progress_messages.append("🧩 Building quick preview mesh (downsample + fast meshing)...")
            yield "\n".join(progress_messages[-10:]), None, None

            # Load point cloud
            pcd = o3d.io.read_point_cloud(final_ply)
            n_pts = len(pcd.points)
            progress_messages.append(f"📥 Loaded point cloud: {n_pts:,} points")
            yield "\n".join(progress_messages[-10:]), None, None

            # Downsample for preview mesh
            TARGET_PREVIEW_POINTS = 150_000
            if n_pts > TARGET_PREVIEW_POINTS:
                ratio = float(TARGET_PREVIEW_POINTS) / float(n_pts)
                pcd = pcd.random_down_sample(ratio)
                progress_messages.append(f"🔻 Downsampled for preview: {len(pcd.points):,} points")
                yield "\n".join(progress_messages[-10:]), None, None

            # Estimate normals (required by meshing)
            pcd.estimate_normals(
                search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.03, max_nn=30)
            )
            progress_messages.append("🧭 Estimated normals")
            yield "\n".join(progress_messages[-10:]), None, None

            # Try fast Ball-Pivoting; radii from avg NN distance
            try:
                dists = pcd.compute_nearest_neighbor_distance()
                avg_dist = float(np.mean(dists)) if len(dists) else 0.01
                radii = o3d.utility.DoubleVector([avg_dist * 2.0, avg_dist * 4.0])
                mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(pcd, radii)
                progress_messages.append(f"🪩 Ball-Pivoting mesh: {len(mesh.triangles):,} tris")
                yield "\n".join(progress_messages[-10:]), None, None

                if len(mesh.triangles) == 0:
                    raise RuntimeError("Empty mesh from Ball-Pivoting")

            except Exception as e_bpa:
                # Fallback: Poisson (lower depth for speed)
                progress_messages.append(f"↩️ Ball-Pivoting failed ({e_bpa}); trying Poisson...")
                yield "\n".join(progress_messages[-10:]), None, None
                mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
                    pcd, depth=8
                )
                # prune low-density
                densities = np.asarray(densities)
                keep = densities > np.quantile(densities, 0.05)
                mesh.remove_vertices_by_mask(~keep)
                progress_messages.append(f"🧱 Poisson mesh: {len(mesh.triangles):,} tris")
                yield "\n".join(progress_messages[-10:]), None, None

            # Simplify for snappy viewing
            target_tris = min(200_000, max(10_000, len(mesh.triangles)))
            if len(mesh.triangles) > target_tris:
                mesh = mesh.simplify_quadric_decimation(target_tris)
                progress_messages.append(f"✂️ Simplified to {len(mesh.triangles):,} tris")
                yield "\n".join(progress_messages[-10:]), None, None

            mesh.compute_vertex_normals()

            # Export OBJ (widely supported by gr.Model3D)
            preview_obj = os.path.splitext(final_ply)[0] + "_preview.obj"
            o3d.io.write_triangle_mesh(preview_obj, mesh, write_triangle_uvs=False)
            progress_messages.append(f"✅ Preview ready: {preview_obj}")
            yield "\n".join(progress_messages[-10:]), gr.update(value=preview_obj, visible=True), gr.update(
                value=final_ply, visible=True)

        except Exception as e_mesh:
            # If preview mesh fails, at least provide the PLY for download
            progress_messages.append(f"⚠️ Preview mesh failed: {e_mesh}")
            yield "\n".join(progress_messages[-10:]), None, gr.update(value=final_ply, visible=True)

    except Exception as e:
        yield f"❌ Pipeline error: {str(e)}", None, None

# ----------------------
# Create Gradio UI
# ----------------------
def create_slam_ui():
    with gr.Blocks(title="MoGe-2 SLAM 3D Reconstruction") as demo:
        gr.Markdown("## 3D Reconstruction from Video")

        with gr.Row():
            with gr.Column(scale=1):
                status_box = gr.Textbox(label="Live Status",
                                        value="Waiting for input...",
                                        interactive=False,
                                        max_lines=15,
                                        show_copy_button=True)
                video_input = gr.File(label="Upload Video")
                run_btn = gr.Button("🚀 Run SLAM", variant="primary", size="lg")

            with gr.Column(scale=2):
                model3d_view = gr.Model3D(label="3D Model", visible=True)
                result_file = gr.File(label="Download .ply file", visible=False)



        run_btn.click(
            fn=run_slam_streaming,
            inputs=[video_input],
            outputs=[status_box, model3d_view, result_file]
        )

    return demo


# ----------------------
# Launch UI
# ----------------------
if __name__ == "__main__":
    demo = create_slam_ui()
    demo.launch(server_name="0.0.0.0", server_port=7862)
