import os, sys
from app.core.utils import find_project_root

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
from app.modules.video_processing.quad_video_service import QuadVideoService
from app.modules.segmentation.overlay_service import OverlayService
from app.core.config import FRAMES_DIR, OUTPUT_DIR, SEGFORMER_DIR_TRAINED, ULTRALYTICS_DIR, SEGFORMER_DIR

# Экспортёр
from app.modules.video_processing.export import export_both_models


def create_video_ui():
    """
    Возвращает (ui_group, run_button, status_output, video_output, run_handler)
    """

    # ── Обработка видео: стабильный прогресс через progress_cb ────────────────
    def run_quad_wrapper(
        video_path,
        progress=gr.Progress(track_tqdm=False)  # включаем нативный прогресс
    ):
        try:
            if not video_path or not os.path.exists(video_path):
                return "❌ Не найден путь к исходному видео. Загрузите видео в разделе «Загрузка видео и обработка».", None

            svc = QuadVideoService(
                output_dir=OUTPUT_DIR,
                custom_segmentor=OverlayService(
                    SEGFORMER_DIR_TRAINED if SEGFORMER_DIR_TRAINED and os.path.exists(SEGFORMER_DIR_TRAINED)
                    else SEGFORMER_DIR,
                    use_compile=False
                ),
                ultralytics_dir=ULTRALYTICS_DIR,
                batch_size=8
            )

            out_path = svc.process_video_quad(
                video_path,
                output_name="quad_video.mp4",
                progress_cb=lambda p, desc=None: progress(p, desc="Обработка…")  # единая подпись, без "Кадры: X/Y"
            )

            return "✅ Квадрантное видео готово!", out_path

        except Exception as e:
            return f"❌ Ошибка: {e}", None

    # ── Экспорт моделей: без прогресс-бара, только статусы ────────────────────
    def export_models_wrapper():
        """
        outputs: [export_status (Markdown), export_files (Files)]
        """
        try:
            yield "Инициализация экспорта…", None

            # Определяем YOLO-веса
            yolo_default = "yolo11n.pt"
            yolo_path = os.path.join(ULTRALYTICS_DIR, yolo_default)
            if not os.path.exists(yolo_path):
                pts = [p for p in os.listdir(ULTRALYTICS_DIR) if p.endswith(".pt")]
                if not pts:
                    yield "❌ Не найдены веса YOLO в ULTRALYTICS_DIR. Проверьте конфигурацию.", None
                    return
                yolo_default = pts[0]

            # Базовый SegFormer при отсутствии кастомной папки
            seg_dir = SEGFORMER_DIR if (SEGFORMER_DIR and os.path.exists(SEGFORMER_DIR)) \
                                     else "nvidia/segformer-b0-finetuned-ade-512-512"

            yield "Экспорт YOLO и SegFormer в ONNX…", None

            results = export_both_models(
                ultralytics_dir=ULTRALYTICS_DIR,
                yolo_weights=yolo_default,
                segformer_dir=seg_dir,
                output_dir=OUTPUT_DIR,
                opset=17
            )

            yield "Проверка результатов…", None

            lines, files = [], []
            for name, (path, status) in results.items():
                exists = os.path.exists(path)
                lines.append(f"• {name.upper()}: {status} | файл: {path if exists else '— не создан —'}")
                if exists:
                    files.append(path)

            final = "Экспорт завершён:\n" + "\n".join(lines)
            yield final, files

        except Exception as e:
            yield f"❌ Ошибка экспорта: {e}", None

    # ── UI ────────────────────────────────────────────────────────────────────
    with gr.Group() as ui_group:
        gr.Markdown("## Обработка видео (квадро-режим с наложениями)")

        with gr.Row():
            with gr.Column(scale=3):
                quad_video_display = gr.Video(label="Результат", interactive=False)
            with gr.Column(scale=2):
                quad_status = gr.Markdown("Готов к запуску.")
                run_quad_btn = gr.Button("Создать квадро-видео", variant="primary")

        quad_video_input_path = gr.State()  # сюда положите путь исходного видео

        gr.Markdown("## Экспорт (ONNX)")
        with gr.Row():
            export_status = gr.Markdown("Ожидает запуска экспорта.")
            export_files = gr.Files(label="Экспортированные модели", interactive=False)
        export_btn = gr.Button("Экспорт моделей", variant="secondary")

        # Обработка видео: один шаг, без .then — статус и видео сразу
        run_quad_btn.click(
            run_quad_wrapper,
            inputs=quad_video_input_path,
            outputs=[quad_status, quad_video_display],
        )

        # Экспорт: генератор без прогресс-бара
        export_btn.click(
            export_models_wrapper,
            inputs=None,
            outputs=[export_status, export_files],
        )

    return ui_group, run_quad_btn, quad_status, quad_video_display, run_quad_wrapper
