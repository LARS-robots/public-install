import os
import sys


# Find project root by looking for a specific marker file (e.g., requirements.txt)
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    # Fallback: return the parent directory of 'app' if marker not found
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir  # Last resort fallback


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import gradio as gr
from app.modules.video_processing.quad_video_service import QuadVideoService
from app.modules.segmentation.overlay_service import OverlayService
from app.core.config import FRAMES_DIR, OUTPUT_DIR, SEGFORMER_DIR_TRAINED, ULTRALYTICS_DIR, SEGFORMER_DIR


def create_video_ui():
    """
    Создает UI для обработки видео и возвращает компоненты для связи
    Returns:
        tuple: (ui_group, run_button, status_output, video_output)
    """

    def run_quad_wrapper(video_path):
        """
        Обработчик для создания квадрантного видео
        Args:
            video_path: путь к исходному видео файлу (строка, полученная из gr.State)
        """
        try:
            # Отладочная информация
            print(f"🔍 Получен video_path: '{video_path}' (тип: {type(video_path)})")

            # Проверяем наличие пути к видео (основная проверка)
            if not video_path or not os.path.exists(video_path):
                return f"❌ Не найден путь к исходному видео: '{video_path}'. Сначала загрузите видео в разделе 'Загрузка видео и обработка'.", None

            # Опциональная проверка кадров (для информации)
            frames_exist = os.path.exists(FRAMES_DIR) and os.listdir(FRAMES_DIR)
            if frames_exist:
                frame_count = len([f for f in os.listdir(FRAMES_DIR) if f.endswith('.jpg')])
                print(f"📁 Найдено {frame_count} кадров в {FRAMES_DIR}")
            else:
                print("📁 Кадры не найдены, QuadVideoService будет обрабатывать видео напрямую")

            print(f"🎬 Начинаем обработку видео: {video_path}")
            print(f"📤 Выходная директория: {OUTPUT_DIR}")

            # Используем обученную модель из SEGFORMER_DIR_TRAINED и YOLO из ULTRALYTICS_DIR
            svc = QuadVideoService(
                output_dir=OUTPUT_DIR,
                custom_segmentor=OverlayService(SEGFORMER_DIR_TRAINED if SEGFORMER_DIR_TRAINED and os.path.exists(SEGFORMER_DIR_TRAINED) else SEGFORMER_DIR, use_compile=False),
                ultralytics_dir=ULTRALYTICS_DIR,
                batch_size=8
            )

            # Передаем только путь к исходному видео в process_video_quad
            out_path = svc.process_video_quad(
                video_path,  # Путь к исходному видео (основной параметр)
                output_name="quad_video.mp4"  # Имя выходного файла
            )

            return f"✅ Квадрантное видео готово!\n📁 Путь: {out_path}", out_path

        except Exception as e:
            print(f"❌ Ошибка при создании квадрантного видео: {str(e)}")
            return f"❌ Ошибка: {e}", None

    # Создаем интерфейс
    with gr.Group() as ui_group:
        gr.Markdown("## Обработка видео (Квадрантное видео с сегментацией)")

        with gr.Row():
            with gr.Column():
                quad_video_display = gr.Video(
                    label="Результат обработки видео",
                    interactive=False
                )

            with gr.Column():
                quad_status = gr.Textbox(
                    label="Статус",
                    interactive=False,
                    lines=3,
                )

                run_quad_btn = gr.Button(
                    "Создать квадрантное видео из кадров",
                    variant="primary",
                    size="lg"
                )

    # Возвращаем компоненты для связи в main.py
    return ui_group, run_quad_btn, quad_status, quad_video_display, run_quad_wrapper


# if __name__ == "__main__":
#     # Тестовый запуск (только для отладки)
#     import gradio as gr
#
#     test_video_path = gr.State(value="")
#     demo = create_video_ui(test_video_path)
#     demo.launch(server_name="0.0.0.0", server_port=7863)