import cv2
import torch
import numpy as np
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor


class OverlayService:
    def __init__(self, model_dir: str, device: str = None):
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.eval()

    def apply_overlay(self, input_video: str, output_video: str, alpha: float = 0.4):
        cap = cv2.VideoCapture(input_video)
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(output_video, fourcc, fps, (w, h))

        overlay_color = np.array([0, 255, 0], dtype=np.uint8)

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            enc = self.processor(images=rgb, return_tensors="pt")
            pixels = enc.pixel_values.to(self.model.device)

            with torch.no_grad():
                outp = self.model(pixel_values=pixels)
            seg = outp.logits.argmax(dim=1).squeeze().cpu().numpy()
            mask = cv2.resize(seg.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
            sidewalk = (mask == 1).astype(np.uint8)

            # Оставляем самый большой компонент
            num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(sidewalk, 8)
            if num_labels > 1:
                sizes = stats[1:, cv2.CC_STAT_AREA]
                max_lbl = 1 + int(np.argmax(sizes))
                sidewalk = (labels == max_lbl).astype(np.uint8)

            color_layer = np.zeros_like(frame)
            color_layer[sidewalk == 1] = overlay_color
            blended = cv2.addWeighted(frame, 1 - alpha, color_layer, alpha, 0)
            out.write(blended)

        cap.release()
        out.release()
        return output_video
