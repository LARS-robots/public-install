import cv2
import torch
import numpy as np
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import os, subprocess


class OverlayService:
    def __init__(self, model_dir: str, device: str = None):
        self.processor = SegformerImageProcessor.from_pretrained(model_dir)
        self.model = SegformerForSemanticSegmentation.from_pretrained(model_dir).to(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.eval()

    def apply_overlay_old(self, input_video: str, output_video: str, alpha: float = 0.4):
        cap = cv2.VideoCapture(input_video)
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(output_video, fourcc, fps, (w, h))

        overlay_color = np.array([0, 255, 0], dtype=np.uint8)

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            enc = self.processor(images=rgb, return_tensors="pt")
            pixels = enc.pixel_values.to(self.model.device)

            with torch.inference_mode():
                outp = self.model(pixel_values=pixels)
            seg = outp.logits.argmax(dim=1).squeeze().cpu().numpy()
            mask = cv2.resize(seg.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
            sidewalk = (mask == 1).astype(np.uint8)

            # Оставляем самый большой компонент
            num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(sidewalk, 8)
            if num_labels > 1:
                sizes = stats[1:, cv2.CC_STAT_AREA]
                max_lbl = 1 + int(np.argmax(sizes))
                sidewalk = (labels == max_lbl).astype(np.uint8)

            color_layer = np.zeros_like(frame)
            color_layer[sidewalk == 1] = overlay_color
            blended = cv2.addWeighted(frame, 1 - alpha, color_layer, alpha, 0)
            out.write(blended)

        cap.release()
        out.release()
        return output_video
    

    def apply_overlay(self, input_video: str, output_video: str, alpha: float = 0.4):
        cap = cv2.VideoCapture(input_video)
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        overlay_color = np.array([0, 255, 0], dtype=np.uint8)

        # Команда FFmpeg
        ffmpeg_cmd = [
            'ffmpeg',
            '-y',
            '-f', 'rawvideo',
            '-vcodec', 'rawvideo',
            '-pix_fmt', 'bgr24',
            '-s', f'{w}x{h}',
            '-r', str(fps),
            '-i', '-',
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-preset', 'medium',
            '-crf', '23',
            '-an',
            output_video  # Выходной файл без аудио
        ]

        process = subprocess.Popen(ffmpeg_cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                # Обработка кадра (SegFormer + маска)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                enc = self.processor(images=rgb, return_tensors="pt")
                pixels = enc.pixel_values.to(self.model.device)
                with torch.inference_mode():
                    outp = self.model(pixel_values=pixels)
                seg = outp.logits.argmax(dim=1).squeeze().cpu().numpy()
                mask = cv2.resize(seg.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
                sidewalk = (mask == 1).astype(np.uint8)

                # Выбор самого большого компонента
                num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(sidewalk, 8)
                if num_labels > 1:
                    sizes = stats[1:, cv2.CC_STAT_AREA]
                    max_lbl = 1 + np.argmax(sizes)
                    sidewalk = (labels == max_lbl).astype(np.uint8)

                # Наложение маски
                color_layer = np.zeros_like(frame)
                color_layer[sidewalk == 1] = overlay_color
                blended = cv2.addWeighted(frame, 1 - alpha, color_layer, alpha, 0)

                # Запись кадра
                process.stdin.write(blended.tobytes())
                process.stdin.flush()  # Сброс буфера

        except BrokenPipeError:
            stderr = process.stderr.read().decode('utf-8')
            print("FFmpeg crashed:", stderr)
            raise
        finally:
            cap.release()
            process.stdin.close()
            process.wait()

        # Добавление аудио (если нужно)
        if self.has_audio(input_video):
            temp_video = output_video.replace(".mp4", "_temp.mp4")
            os.rename(output_video, temp_video)
            cmd = [
                'ffmpeg', '-y',
                '-i', temp_video,
                '-i', input_video,
                '-c:v', 'copy',
                '-c:a', 'aac',
                '-map', '0:v',
                '-map', '1:a',
                output_video
            ]
            subprocess.run(cmd, check=True)
            os.remove(temp_video)

        return output_video

    def has_audio(self, video_path):
        """Проверяет, есть ли аудио в видео"""
        cmd = [
            'ffprobe', '-v', 'quiet', '-print_format', 'json',
            '-show_streams', video_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        import json
        info = json.loads(result.stdout)
        for stream in info.get('streams', []):
            if stream['codec_type'] == 'audio':
                return True
        return False
