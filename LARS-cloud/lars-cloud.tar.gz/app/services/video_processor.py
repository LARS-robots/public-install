import cv2
import os
from pathlib import Path

class VideoProcessor:
    def __init__(self):
        # Use absolute path to project root
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))  # LARS-cloud/
        self.frames_dir = os.path.join(project_root, "data", "extracted_frames")
        self.current_video_frames = []  # Кадры текущего видео

    def extract_frames(self, video_path: str, fps: int = 1, frames_dir: str = None):
        """Extract frames from video with incremental numbering"""
        if frames_dir is None:
            frames_dir = self.frames_dir

        os.makedirs(frames_dir, exist_ok=True)

        # Найти последний номер кадра в папке
        existing_frames = [f for f in os.listdir(frames_dir) if f.startswith('frame_') and f.endswith('.jpg')]
        if existing_frames:
            frame_numbers = []
            for f in existing_frames:
                try:
                    num = int(f.replace('frame_', '').replace('.jpg', ''))
                    frame_numbers.append(num)
                except ValueError:
                    continue
            start_frame_num = max(frame_numbers) + 1 if frame_numbers else 0
        else:
            start_frame_num = 0

        cap = cv2.VideoCapture(video_path)
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(video_fps / fps)

        frame_count = 0
        saved_count = 0
        self.current_video_frames = []  # Сбросить кадры текущего видео

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % frame_interval == 0:
                frame_filename = f"frame_{start_frame_num + saved_count:04d}.jpg"
                frame_path = os.path.join(frames_dir, frame_filename)
                cv2.imwrite(frame_path, frame)

                # Добавить в список кадров текущего видео
                self.current_video_frames.append(frame_filename)
                saved_count += 1

            frame_count += 1

        cap.release()
        return f"Извлечено {saved_count} кадров (номера {start_frame_num}-{start_frame_num + saved_count - 1})"

    def get_current_video_frames(self):
        """Получить список кадров текущего видео"""
        return self.current_video_frames

    def get_frame_count(self):
        """Get number of extracted frames"""
        if not os.path.exists(self.frames_dir):
            return 0
        return len([f for f in os.listdir(self.frames_dir) if f.endswith('.jpg')])