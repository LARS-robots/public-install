import os
from pathlib import Path
import numpy as np
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torch
import torch.nn as nn
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
from tqdm import tqdm

class RoadSegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, processor):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.filenames = sorted(os.listdir(mask_dir))
        self.processor = processor

    def __len__(self):
        return len(self.filenames)

    def __getitem__(self, idx):
        mask_file = self.filenames[idx]
        img_path = os.path.join(self.img_dir, mask_file.replace('_mask.png', '.jpg'))
        mask_path = os.path.join(self.mask_dir, mask_file)
        image = Image.open(img_path).convert('RGB')
        mask = np.array(Image.open(mask_path).convert('L'))
        mask = (mask > 127).astype(np.uint8)
        encoding = self.processor(images=image, return_tensors="pt")
        return encoding.pixel_values.squeeze(), torch.from_numpy(mask).long()

class TrainingService:
    def __init__(self, img_dir, mask_dir, output_dir, device=None):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.output_dir = output_dir

        # Проверить существование директорий
        if not os.path.exists(img_dir):
            raise FileNotFoundError(f"Директория изображений не найдена: {img_dir}")
        if not os.path.exists(mask_dir):
            raise FileNotFoundError(f"Директория масок не найдена: {mask_dir}")

        os.makedirs(output_dir, exist_ok=True)
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')

        # Путь к уже дообученной модели
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))  # LARS-cloud/
        finetuned_model_path = os.path.join(output_dir, "segformer_roadsidewalk_model")
        base_model_path = os.path.join(project_root, "models", "segformer_base")

        # Проверить, есть ли уже дообученная модель
        if os.path.exists(finetuned_model_path) and os.path.exists(os.path.join(finetuned_model_path, "config.json")):
            print(f"🔄 Загружаем уже дообученную модель из {finetuned_model_path}")
            self.processor = SegformerImageProcessor.from_pretrained(finetuned_model_path)
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                finetuned_model_path,
                ignore_mismatched_sizes=True
            ).to(self.device)
        elif os.path.exists(base_model_path) and os.path.exists(os.path.join(base_model_path, "config.json")):
            print(f"🔄 Загружаем базовую модель из {base_model_path}")
            self.processor = SegformerImageProcessor.from_pretrained(base_model_path)
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                base_model_path,
                ignore_mismatched_sizes=True
            ).to(self.device)
        else:
            print("📥 Загружаем предобученную модель Segformer (первый раз)")
            self.processor = SegformerImageProcessor.from_pretrained("nvidia/segformer-b0-finetuned-ade-512-512")
            self.model = SegformerForSemanticSegmentation.from_pretrained(
                "nvidia/segformer-b0-finetuned-ade-512-512",
                id2label={0: "background", 1: "sidewalk"},
                label2id={"background": 0, "sidewalk": 1},
                ignore_mismatched_sizes=True
            ).to(self.device)

            # Сохранить базовую модель для последующего использования
            os.makedirs(base_model_path, exist_ok=True)
            self.model.save_pretrained(base_model_path)
            self.processor.save_pretrained(base_model_path)
            print(f"💾 Базовая модель сохранена в {base_model_path}")

    def train(self, batch_size=4, num_epochs=30, lr=2e-4):
        loader = DataLoader(
            RoadSegDataset(self.img_dir, self.mask_dir, self.processor),
            batch_size=batch_size, shuffle=True
        )
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=lr)
        loss_fn = nn.CrossEntropyLoss()

        logs = []
        for epoch in range(1, num_epochs+1):
            self.model.train()
            running_loss = 0
            for pixel_values, masks in tqdm(loader, desc=f"Epoch {epoch}", leave=False):
                pixel_values = pixel_values.to(self.device)
                masks = masks.to(self.device)
                outputs = self.model(pixel_values=pixel_values, labels=masks)
                loss = outputs.loss
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                running_loss += loss.item()
            avg = running_loss / len(loader)
            logs.append(f"Epoch {epoch} — loss: {avg:.4f}")
        # Сохраняем
        self.model.save_pretrained(os.path.join(self.output_dir, "segformer_roadsidewalk_model"))
        self.processor.save_pretrained(os.path.join(self.output_dir, "segformer_roadsidewalk_model"))
        return logs
