import numpy as np
import cv2
import torch
from ultralytics import SAM
from PIL import Image
import os

class SAMService:
    def __init__(self, config):
        self.config = config
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = SAM(
            config.get("cuda_weights" if self.device == "cuda" else "cpu_weights")   
        )

        self.points = []
        self.labels = []
        self.current_idx = 0
        self.current_mode = 1
        self.frames_dir = None
        self.output_dir = None
        self.frame_files = []

        # Добавляем для работы с текущим видео
        self.current_video_frames = []  # Кадры только текущего видео
        self.current_video_start_idx = 0  # Начальный индекс для текущего видео

    def initialize_session(self, frames_dir: str, output_dir: str):
        """Initialize a new segmentation session"""
        self.frames_dir = frames_dir
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.frame_files = sorted([f for f in os.listdir(frames_dir) if f.endswith(".jpg")])
        self.reset_points()

    def set_current_video_frames(self, current_frames: list):
        """Установить кадры текущего видео"""
        self.current_video_frames = current_frames
        self.reset_points()

    def get_current_video_frame_count(self):
        """Получить количество кадров в текущем видео"""
        return len(self.current_video_frames)

    def load_current_video_image(self, video_idx: int):
        """Загрузить изображение по индексу в текущем видео"""
        if video_idx >= len(self.current_video_frames):
            raise IndexError(f"Video frame index {video_idx} out of range. Available frames: {len(self.current_video_frames)}")

        frame_filename = self.current_video_frames[video_idx]
        path = os.path.join(self.frames_dir, frame_filename)

        if not os.path.exists(path):
            raise FileNotFoundError(f"Frame file not found: {path}")

        # Найти глобальный индекс этого кадра
        if frame_filename in self.frame_files:
            global_idx = self.frame_files.index(frame_filename)
            self.current_idx = global_idx

        img = cv2.imread(path)
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def load_image(self, idx: int):
        """Load image by global index in all frames"""
        if idx >= len(self.frame_files):
            raise IndexError(f"Frame index {idx} out of range. Available frames: {len(self.frame_files)}")

        path = os.path.join(self.frames_dir, self.frame_files[idx])

        if not os.path.exists(path):
            raise FileNotFoundError(f"Frame file not found: {path}")

        img = cv2.imread(path)
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def draw_points(self, image, points, labels):
        """Draw points on image"""
        img = image.copy()
        for (x, y), l in zip(points, labels):
            color = (0, 0, 255) if l == 1 else (255, 0, 0)
            cv2.circle(img, (x, y), 4, color, -1)
            cv2.circle(img, (x, y), 10, color, 1)
        return img

    def add_point(self, x: int, y: int):
        """Add point for segmentation"""
        self.points.append([x, y])
        self.labels.append(self.current_mode)
        img = self.load_image(self.current_idx).copy()
        return self.draw_points(img, self.points, self.labels)

    def calculate_mask(self):
        """Calculate segmentation mask using SAM2"""
        base = self.load_image(self.current_idx).copy()

        pc = np.array(self.points)
        pl = np.array(self.labels)

        # Запуск инференса через Ultralytics
        results = self.model.predict(
            source=base,
            points=pc.tolist(),       # Ultralytics принимает список списков
            labels=pl.tolist(),       # То же самое
        )

        # Получаем маску с наибольшим скором
        result = results[0]
        masks = result.masks.data.cpu().numpy()  # [N, H, W]
        if hasattr(result.masks, 'conf'):
            scores = result.masks.conf.cpu().numpy()  # В новых версиях Ultralytics
        else:
            # Альтернативный способ - проверяем наличие scores
            scores = result.boxes.conf.cpu().numpy() if result.boxes is not None else np.array([1.0] * len(masks))
        
        # Если всё равно нет scores, используем первую маску
        if len(scores) == 0:
            best_mask_idx = 0
        else:
            best_mask_idx = np.argmax(scores)
        
        mask = masks[best_mask_idx]

        # Фильтрация маленьких областей
        min_area = 500
        mask_uint8 = (mask * 255).astype(np.uint8)
        n_labels, labels_im, stats, _ = cv2.connectedComponentsWithStats(
            mask_uint8, connectivity=8
        )
        filtered = np.zeros_like(mask_uint8)
        for label in range(1, n_labels):
            area = stats[label, cv2.CC_STAT_AREA]
            if area >= min_area:
                filtered[labels_im == label] = 255
        mask = (filtered > 0)
        self.current_mask = mask

        # Создание оверлея
        overlay = base.copy()
        alpha = 0.4
        fill = np.array([0, 255, 0], dtype=np.uint8)
        idxs = mask.astype(bool)
        overlay[idxs] = (alpha * fill + (1 - alpha) * overlay[idxs]).astype(np.uint8)

        # Отрисовка точек
        return self.draw_points(overlay, self.points, self.labels)
    
    def calculate_and_get_mask_only(self):
        """Calculate segmentation mask and return it without visualization"""
        base = self.load_image(self.current_idx).copy()

        # Преобразуем точки и метки
        pc = np.array(self.points)
        pl = np.array(self.labels)

        # Запуск инференса через Ultralytics
        results = self.model.predict(
            source=base,
            points=pc.tolist(),
            labels=pl.tolist(),
            multimask_output=False
        )

        # Получаем маску с наибольшим скором
        result = results[0]
        masks = result.masks.data.cpu().numpy()
        # Получаем scores/confidence
        if hasattr(result.masks, 'conf'):
            scores = result.masks.conf.cpu().numpy()
        else:
            scores = result.boxes.conf.cpu().numpy() if result.boxes is not None else np.array([1.0] * len(masks))
        
        # Определяем порог для "хороших" масок
        confidence_threshold = 0.5
        min_area = 500
        
        # Создаем объединенную маску, начиная с нулей
        combined_mask = np.zeros(base.shape[:2], dtype=bool)
        
        # Объединяем все хорошие маски
        for i, (mask, score) in enumerate(zip(masks, scores)):
            if score >= confidence_threshold:
                # Фильтрация маленьких областей
                mask_uint8 = (mask * 255).astype(np.uint8)
                n_labels, labels_im, stats, _ = cv2.connectedComponentsWithStats(
                    mask_uint8, connectivity=8
                )
                
                # Создаем временную маску только с большими компонентами
                large_components_mask = np.zeros_like(mask_uint8, dtype=bool)
                for label in range(1, n_labels):
                    area = stats[label, cv2.CC_STAT_AREA]
                    if area >= min_area:
                        large_components_mask[labels_im == label] = True
                
                # Добавляем в объединенную маску
                combined_mask = combined_mask | large_components_mask

        return combined_mask

    def save_mask(self):
        """Save current mask"""
        if not self.points:
            return "Нет точек для сохранения"

        if not hasattr(self, 'current_mask') or self.current_mask is None:
            self.current_mask = self.calculate_and_get_mask_only()
        
        mask = self.current_mask

        filename = self.frame_files[self.current_idx].replace(".jpg", "_mask.png")
        path = os.path.join(self.output_dir, filename)
        Image.fromarray((mask * 255).astype(np.uint8)).save(path)
        return f"Сохранено: {filename}"

    def reset_points(self):
        """Reset segmentation points"""
        self.points = []
        self.labels = []
        # Return current image if available
        if hasattr(self, 'current_idx') and self.frame_files and self.current_idx < len(self.frame_files):
            return self.load_image(self.current_idx)
        return None

    def set_mode(self, mode: int):
        """Set segmentation mode (1=add, 0=subtract)"""
        self.current_mode = mode
        return f"Режим: {'добавить' if mode == 1 else 'вычесть'}"
