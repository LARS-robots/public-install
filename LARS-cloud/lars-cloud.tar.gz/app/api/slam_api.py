import os
import sys
import uuid
import shutil
from typing import Optional

from fastapi import APIRouter, UploadFile, File, HTTPException

# --- project root resolving (kept minimal) ---
def find_project_root(start_dir, marker="requirements.txt"):
    d = start_dir
    while d != os.path.dirname(d):
        if os.path.isfile(os.path.join(d, marker)):
            return d
        d = os.path.dirname(d)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.append(project_root)

import trimesh

from app.modules.slam.vda_slam_service import VDASLAMService
from app.core.config import (
    SFM_DIR,
    POINTS_CLOUD_SFM_DIR,
    MESH_SFM_DIR,
)

router = APIRouter()

# Single reusable service instance (loads model once)
_vda_service: Optional[VDASLAMService] = None
def _get_service() -> VDASLAMService:
    global _vda_service
    if _vda_service is None:
        _vda_service = VDASLAMService()
    return _vda_service

def _count_points(ply_path: str) -> int:
    try:
        obj = trimesh.load(ply_path)
        # Point cloud or mesh
        if hasattr(obj, "vertices"):
            return int(obj.vertices.shape[0])
        if isinstance(obj, list) and len(obj) > 0 and hasattr(obj[0], "vertices"):
            return int(obj[0].vertices.shape[0])
    except Exception:
        pass
    return 0

@router.post("/reconstruct", summary="Run SLAM+Fusion on uploaded video")
async def reconstruct_3d(video: UploadFile = File(...)):
    if not video.filename.lower().endswith((".mp4", ".mov", ".mkv", ".avi")):
        raise HTTPException(status_code=400, detail="Unsupported video format")

    os.makedirs(SFM_DIR, exist_ok=True)
    os.makedirs(POINTS_CLOUD_SFM_DIR, exist_ok=True)
    os.makedirs(MESH_SFM_DIR, exist_ok=True)

    # Save uploaded video
    run_id = os.path.splitext(os.path.basename(video.filename))[0] + "_" + uuid.uuid4().hex[:8]
    videos_dir = os.path.join(SFM_DIR, "uploaded_videos")
    os.makedirs(videos_dir, exist_ok=True)
    saved_video_path = os.path.join(videos_dir, f"{run_id}.mp4")
    try:
        with open(saved_video_path, "wb") as f:
            f.write(await video.read())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cannot save video: {e}")

    service = _get_service()

    try:
        # Process video (default segmentation fallback inside)
        fused_ply_path = service.process_video(saved_video_path, output_dir=SFM_DIR)

        if not os.path.isfile(fused_ply_path):
            raise HTTPException(status_code=500, detail="Fused point cloud not produced")

        point_count = _count_points(fused_ply_path)
        if point_count == 0:
            raise HTTPException(status_code=500, detail="Empty point cloud")

        glb_path = os.path.join(os.path.dirname(fused_ply_path), f"{run_id}.glb")
        try:
            obj = trimesh.load(fused_ply_path)
            obj.export(glb_path)
        except Exception as e:
            # Non-fatal: return PLY instead
            glb_path = ""
            print(f"[WARN] GLB export failed: {e}")

        return {
            "run_id": run_id,
            "fused_ply": fused_ply_path,
            "glb_path": glb_path or None,
            "points": point_count,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
