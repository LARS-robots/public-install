# app/api/eis_api.py
# filepath: /home/master/PycharmProjects/LARS/LARS-cloud/app/api/eis_api.py

from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, Dict
from app.modules.video_processing.eis.eis import EISParams
from app.modules.video_processing.eis.eis_service import analyze, stabilize
from app.modules.video_processing.eis.splitter import SplitMode, StereoPick

router = APIRouter(prefix="/eis", tags=["eis"])


class AnalyzeRequest(BaseModel):
    video_path: str
    hfov_deg: float = 84.0
    ema_alpha_pos: float = 0.20
    ema_alpha_rot: float = 0.20
    safety_crop_percent: int = 8
    show_debug: bool = False
    mode: str = "auto"  # "auto", "stereo_horizontal", "stereo_vertical", "quad_2x2"
    stereo_pick: str = "right"  # "left", "right", "top", "bottom"

class StabilizeRequest(AnalyzeRequest):
    pass

@router.post("/analyze")
def api_analyze(req: AnalyzeRequest):
    p = EISParams(hfov_deg=req.hfov_deg,
                  ema_alpha_pos=req.ema_alpha_pos,
                  ema_alpha_rot=req.ema_alpha_rot,
                  safety_crop_percent=req.safety_crop_percent,
                  show_debug=req.show_debug)
    def cb(pct, stage): pass
    
    split_mode = SplitMode(req.mode)
    stereo_pick = StereoPick(req.stereo_pick) if "stereo" in req.mode else None
    metrics = analyze(req.video_path, p, cb, mode=split_mode, stereo_pick=stereo_pick)
    return {"status": "ok", "metrics": metrics}

@router.post("/stabilize")
def api_stabilize(req: StabilizeRequest):
    p = EISParams(hfov_deg=req.hfov_deg,
                  ema_alpha_pos=req.ema_alpha_pos,
                  ema_alpha_rot=req.ema_alpha_rot,
                  safety_crop_percent=req.safety_crop_percent,
                  show_debug=req.show_debug)
    def cb(pct, stage): pass
    
    split_mode = SplitMode(req.mode)
    stereo_pick = StereoPick(req.stereo_pick) if "stereo" in req.mode else None
    result = stabilize(req.video_path, p, cb, mode=split_mode, stereo_pick=stereo_pick)
    
    if isinstance(result, tuple):
        mp4, js, thumb = result
        return {"status": "ok", "video": mp4, "metrics_json": js, "thumb": thumb}
    else:
        return {"status": "ok", "videos": result}