# app/api/depth_overlay_api.py
"""
API для запуска наложения глубины на уже извлечённые кадры (в FRAMES_DIR или поддиректории).
Похож на стиль app/api/segment (SAM).
"""

import os
import sys
from pathlib import Path
from typing import Optional

# Find project root (как у тебя в других файлах)
def find_project_root(start_dir, marker="requirements.txt"):
    dir_ = start_dir
    while dir_ != os.path.dirname(dir_):
        if os.path.isfile(os.path.join(dir_, marker)):
            return dir_
        dir_ = os.path.dirname(dir_)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from fastapi.concurrency import run_in_threadpool

from app.core.config import FRAMES_DIR
from app.modules.video_processing.depth_overlay_service import DepthOverlayService

# безопасная маппинга колормапов (если cv2 доступен)
try:
    import cv2
    CV2_COLORMAPS = {
        "magma": cv2.COLORMAP_MAGMA,
        "jet": cv2.COLORMAP_JET,
        "viridis": getattr(cv2, "COLORMAP_VIRIDIS", cv2.COLORMAP_JET),
        "inferno": getattr(cv2, "COLORMAP_INFERNO", cv2.COLORMAP_JET),
        "plasma": getattr(cv2, "COLORMAP_PLASMA", cv2.COLORMAP_JET),
        "turbo": getattr(cv2, "COLORMAP_TURBO", cv2.COLORMAP_JET),
    }
except Exception:
    CV2_COLORMAPS = {"magma": None}

router = APIRouter()


class DepthOverlayRequest(BaseModel):
    """
    frames_subdir: опциональная подпапка внутри FRAMES_DIR с кадрами. Если не передана - используется весь FRAMES_DIR.
    fps: fps для итогового видео (и/или для извлечения, если использовался внешней вкладкой)
    model_name: HF модель Depth Anything V2
    colormap: имя колормэпа (ключ из CV2_COLORMAPS)
    cleanup_frames: удалять ли промежуточные цветные кадры после сборки
    output_filename: опциональное имя итогового файла (например 'my_video.mp4'). Если не указано — сгенерируется.
    """
    frames_subdir: Optional[str] = None
    fps: int = 5
    model_name: str = "depth-anything/Depth-Anything-V2-Small-hf"
    colormap: str = "magma"
    cleanup_frames: bool = True
    output_filename: Optional[str] = None


@router.post("/depth-overlay")
async def depth_overlay(request: DepthOverlayRequest):
    try:
        # определяем папку с кадрами
        if request.frames_subdir:
            input_frames_dir = Path(FRAMES_DIR) / request.frames_subdir
        else:
            input_frames_dir = Path(FRAMES_DIR)

        if not input_frames_dir.exists() or not input_frames_dir.is_dir():
            raise HTTPException(status_code=400, detail=f"Frames dir not found: {input_frames_dir}")

        # проверим, что в папке есть изображения
        exts = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp")
        imgs = [p for p in sorted(input_frames_dir.iterdir()) if p.is_file() and p.suffix.lower() in exts]
        if len(imgs) == 0:
            raise HTTPException(status_code=400, detail=f"No image frames found in {input_frames_dir}")

        # выбираем колормэп значение для OpenCV (или None)
        cv_colormap = CV2_COLORMAPS.get(request.colormap, None)

        # создаём сервис
        service = DepthOverlayService(model_name=request.model_name, colormap=cv_colormap)

        # определяем output path
        out_dir = Path("data/output/depth_videos")
        out_dir.mkdir(parents=True, exist_ok=True)
        if request.output_filename:
            output_path = out_dir / request.output_filename
        else:
            # имя по папке с кадрами
            name_part = input_frames_dir.name if input_frames_dir.name else "depth_output"
            output_path = out_dir / f"depth_overlay_{name_part}.mp4"

        # запускаем обработку в тредпуле чтобы не блокировать loop
        result_path = await run_in_threadpool(
            service.process_frames_dir,
            str(input_frames_dir),
            str(output_path),
            None,  # output_frames_dir (пусть сервис сам создаст подпапку)
            request.fps,
            request.cleanup_frames,
        )

        # проверка результата
        if not Path(result_path).exists():
            raise HTTPException(status_code=500, detail="Processing finished but output file not found")

        return {"status": "success", "output_path": str(result_path)}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
