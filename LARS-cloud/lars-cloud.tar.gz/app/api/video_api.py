import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
sys.path.append(project_root)

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.modules.video_processing.quad_video_service import QuadVideoService
from app.modules.segmentation.overlay_service import OverlayService
from app.core.config import OUTPUT_DIR, SEGFORMER_DIR, FRAMES_DIR

router = APIRouter()

class VideoProcessRequest(BaseModel):
    video_path: str
    output_name: str = "quad_video.mp4"

@router.post("/process")
async def process_video(request: VideoProcessRequest):
    try:
        if not os.path.exists(request.video_path):
            raise HTTPException(status_code=400, detail="Указанный видеофайл не найден")
        svc = QuadVideoService(
            output_dir=OUTPUT_DIR,
            custom_segmentor=OverlayService(SEGFORMER_DIR, use_compile=False),
            batch_size=8
        )
        # Assuming process_video_quad needs adjustment; use a placeholder for now
        out_path = svc.process_video_quad(
            frames_dir=FRAMES_DIR,  # Adjust based on your logic
            input_video_path=request.video_path,
            output_name=request.output_name
        )
        return {"video_path": out_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))