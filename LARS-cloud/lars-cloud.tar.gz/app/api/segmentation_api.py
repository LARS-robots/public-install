import os
import sys

# Find project root
def find_project_root(start_dir, marker="requirements.txt"):
    dir = start_dir
    while dir != os.path.dirname(dir):
        if os.path.isfile(os.path.join(dir, marker)):
            return dir
        dir = os.path.dirname(dir)
    app_dir = os.path.dirname(start_dir)
    if os.path.basename(app_dir) == "app":
        return os.path.dirname(app_dir)
    return start_dir

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = find_project_root(current_dir)
sys.path.append(project_root)

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.modules.segmentation.sam_service import SAMService
from app.core.config import FRAMES_DIR, MASKS_DIR

router = APIRouter()

class SegmentRequest(BaseModel):
    image_path: str
    points: list[tuple[int, int]] = []
    mode: int = 1

@router.post("/segment")
async def segment_image(request: SegmentRequest):
    try:
        sam_service = SAMService({"cpu_weights": "sam2.1_t.pt", "cuda_weights": "sam2.1_l.pt"})
        sam_service.initialize_session(FRAMES_DIR, MASKS_DIR)
        for x, y in request.points:
            sam_service.add_point(x, y)
        sam_service.set_mode(request.mode)
        result = sam_service.calculate_mask(request.image_path)
        return {"mask_path": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))