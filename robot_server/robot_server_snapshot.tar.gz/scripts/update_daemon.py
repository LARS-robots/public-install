#!/usr/bin/env python3
"""
Host-side update daemon.

Exposes local HTTP endpoints to trigger code updates via unpack.py and
optionally restart services via run_dev_win.py.

Default bind: 127.0.0.1:8769 (local-only).
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
import sys
import threading
import time
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = int(os.getenv("LARS_UPDATE_PORT", "8769"))
MAX_LOG_LINES = 200
DEFAULT_ALLOWED_NETS = "127.0.0.0/8,::1/128,172.16.0.0/12"

_state_lock = threading.Lock()
_state: Dict[str, Any] = {
    "status": "idle",  # idle | running | restarting | success | error
    "started_at": None,
    "finished_at": None,
    "exit_code": None,
    "last_error": None,
    "log_tail": [],
    "install_dir": None,
    "script_path": None,
}


def _resolve_install_dir(explicit: Optional[str] = None) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()

    env_dir = os.getenv("LARS_INSTALL_DIR") or os.getenv("ROBOT_INSTALL_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()

    here = Path(__file__).resolve()
    scripts_dir = here.parent
    if (scripts_dir / "unpack.py").exists():
        return scripts_dir.parent

    user = os.getenv("USER") or os.getenv("USERNAME") or "robot"
    return Path(f"/home/{user}/LARS").expanduser().resolve()


def _parse_allowed_nets() -> list[ipaddress._BaseNetwork]:
    raw = os.getenv("LARS_UPDATE_ALLOWED_NETS", DEFAULT_ALLOWED_NETS)
    nets: list[ipaddress._BaseNetwork] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            nets.append(ipaddress.ip_network(item, strict=False))
        except Exception:
            continue
    return nets


_ALLOWED_NETS = _parse_allowed_nets()


def _is_allowed_ip(addr: str) -> bool:
    try:
        ip = ipaddress.ip_address(addr)
    except Exception:
        return False
    for net in _ALLOWED_NETS:
        if ip in net:
            return True
    return False


def _read_version(install_dir: Path) -> Optional[str]:
    try:
        version_path = install_dir / "VERSION"
        if version_path.exists():
            return version_path.read_text(encoding="utf-8").strip()
    except Exception:
        return None
    return None


def _append_log(line: str) -> None:
    with _state_lock:
        tail: List[str] = _state.get("log_tail", [])
        tail.append(line)
        if len(tail) > MAX_LOG_LINES:
            tail = tail[-MAX_LOG_LINES:]
        _state["log_tail"] = tail


def _set_state(**kwargs: Any) -> None:
    with _state_lock:
        _state.update(kwargs)


def _get_snapshot(install_dir: Path, script_path: Path) -> Dict[str, Any]:
    with _state_lock:
        data = dict(_state)

    data["install_dir"] = str(install_dir)
    data["script_path"] = str(script_path)
    data["version"] = _read_version(install_dir)
    if data.get("status") == "running" and data.get("started_at"):
        data["running_for_sec"] = max(0.0, time.time() - float(data["started_at"]))
    return data


def _run_cmd(cmd: List[str], cwd: Path) -> int:
    _append_log(f"$ {' '.join(cmd)}")
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if proc.stdout:
        for line in proc.stdout:
            _append_log(line.rstrip())
    return proc.wait()


def _run_update(install_dir: Path, script_path: Path) -> None:
    _set_state(
        status="running",
        started_at=time.time(),
        finished_at=None,
        exit_code=None,
        last_error=None,
        log_tail=[],
        install_dir=str(install_dir),
        script_path=str(script_path),
    )

    exit_code: Optional[int] = None
    try:
        update_cmd = [sys.executable, str(script_path), str(install_dir)]
        exit_code = _run_cmd(update_cmd, cwd=install_dir)
        if exit_code != 0:
            _set_state(status="error", last_error=f"Update failed (exit code {exit_code})")
            return

        _set_state(status="restarting")
        down_cmd = [sys.executable, str(install_dir / "scripts" / "run_dev_win.py"), "down"]
        up_cmd = [sys.executable, str(install_dir / "scripts" / "run_dev_win.py"), "up"]
        _run_cmd(down_cmd, cwd=install_dir)
        _run_cmd(up_cmd, cwd=install_dir)

        _set_state(status="success")
    except Exception as e:
        _set_state(status="error", last_error=str(e))
    finally:
        _set_state(finished_at=time.time(), exit_code=exit_code)


class UpdateHandler(BaseHTTPRequestHandler):
    server_version = "LARSUpdateDaemon/1.0"

    def _json(self, payload: Dict[str, Any], status: int = 200) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _is_allowed(self) -> bool:
        return _is_allowed_ip(self.client_address[0])

    def do_GET(self) -> None:
        if not self._is_allowed():
            self._json({"ok": False, "error": "forbidden"}, status=403)
            return

        if self.path == "/update/status":
            install_dir = self.server.install_dir
            script_path = self.server.script_path
            self._json(_get_snapshot(install_dir, script_path))
            return

        self._json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:
        if not self._is_allowed():
            self._json({"ok": False, "error": "forbidden"}, status=403)
            return

        if self.path == "/update/run":
            with _state_lock:
                if _state.get("status") in ("running", "restarting"):
                    self._json({"ok": False, "error": "update already running"}, status=409)
                    return

            install_dir = self.server.install_dir
            script_path = self.server.script_path
            if not script_path.exists():
                self._json({"ok": False, "error": f"unpack.py not found at {script_path}"}, status=404)
                return

            t = threading.Thread(target=_run_update, args=(install_dir, script_path), daemon=True)
            t.start()
            self._json({"ok": True, "status": "running"})
            return

        self._json({"ok": False, "error": "not found"}, status=404)

    def log_message(self, fmt: str, *args: Any) -> None:
        # Reduce noise; still emit basic access logs if needed
        return


class UpdateServer(ThreadingHTTPServer):
    def __init__(self, server_address: Tuple[str, int], install_dir: Path):
        super().__init__(server_address, UpdateHandler)
        self.install_dir = install_dir
        self.script_path = install_dir / "scripts" / "unpack.py"


def main() -> int:
    parser = argparse.ArgumentParser(description="LARS host update daemon")
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--install-dir", default=None)
    args = parser.parse_args()

    install_dir = _resolve_install_dir(args.install_dir)
    server = UpdateServer((args.host, args.port), install_dir)
    print(f"[update-daemon] listening on {args.host}:{args.port}")
    print(f"[update-daemon] install_dir={install_dir}")
    print(f"[update-daemon] unpack.py={server.script_path}")
    print(f"[update-daemon] allowed_nets={','.join(str(n) for n in _ALLOWED_NETS) or 'none'}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
