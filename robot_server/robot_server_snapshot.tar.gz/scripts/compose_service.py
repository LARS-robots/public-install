#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Compose Service: Handles docker compose operations for LARS robot server

Detects platform, selects appropriate compose override files, and executes
docker compose commands. Used by systemd service for clean, maintainable service management.

Note: Images must be built separately using install.py before running this script.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

# Add parent directory to path for imports
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.motor_compose_mapper import detect_platform, get_compose_and_env


def get_camera_compose_path(root: Path, platform_type: str) -> Path | None:
    """Get camera daemon compose override file path based on platform."""
    camera_dir = root / "services" / "camera_daemon"
    compose_file = f"compose.{platform_type}.yml"
    compose_path = camera_dir / compose_file
    return compose_path if compose_path.exists() else None


def get_logger_compose_path(root: Path) -> Path | None:
    """Get logger daemon compose override file path."""
    logger_dir = root / "services" / "logger"
    compose_path = logger_dir / "compose.yml"
    return compose_path if compose_path.exists() else None


def pull_public_images(root: Path, platform_type: str) -> bool:
    """Pull public Docker images that are required but not built locally."""
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    public_images = ["nats:2.10-alpine"]
    
    print("Pulling public Docker images...", flush=True)
    
    success = True
    for image in public_images:
        print(f"Pulling {image} ({build_platform})...", flush=True)
        cmd = ["docker", "pull", "--platform", build_platform, image]
        result = subprocess.run(cmd, cwd=str(root), check=False, capture_output=True)
        if result.returncode != 0:
            print(f"Warning: Failed to pull {image}: {result.stderr.decode('utf-8', errors='ignore')}", file=sys.stderr)
            success = False
        else:
            print(f"✓ Pulled {image}", flush=True)
    
    return success


def check_image_exists(image_name: str) -> bool:
    """Check if a Docker image exists locally."""
    try:
        result = subprocess.run(
            ["docker", "image", "inspect", image_name],
            capture_output=True,
            check=False
        )
        return result.returncode == 0
    except Exception:
        return False


def build_compose_command(root: Path, action: str) -> list[str]:
    """Build docker compose command with all necessary override files."""
    platform_type = detect_platform()
    
    compose_files = [str(root / "compose.yml")]
    
    # Add camera override if exists
    camera_compose = get_camera_compose_path(root, platform_type)
    if camera_compose:
        compose_files.append(str(camera_compose))
    
    # Get motor compose override using mapper
    try:
        motor_compose, _ = get_compose_and_env(
            robot_type=None,
            platform_type=None,
            root=root
        )
        if motor_compose.exists():
            compose_files.append(str(motor_compose))
    except Exception as e:
        print(f"Warning: Could not get motor compose file: {e}", file=sys.stderr)
    
    # Add logger override if exists (disabled)
    # logger_compose = get_logger_compose_path(root)
    # if logger_compose:
    #     compose_files.append(str(logger_compose))
    
    # Build command
    cmd = ["docker", "compose"]
    for f in compose_files:
        cmd.extend(["-f", f])
    
    if action == "up":
        cmd.extend(["up", "-d", "--pull", "never"])
    elif action == "down":
        cmd.append("down")
    else:
        raise ValueError(f"Invalid action: {action}. Must be 'up' or 'down'")
    
    return cmd


def main() -> int:
    """Main entry point for systemd service."""
    if len(sys.argv) < 2:
        print("Usage: compose_service.py <up|down> [root_dir]", file=sys.stderr)
        return 1
    
    action = sys.argv[1].lower()
    if action not in ("up", "down"):
        print(f"Error: Invalid action '{action}'. Must be 'up' or 'down'", file=sys.stderr)
        return 1
    
    # Get root directory
    if len(sys.argv) > 2:
        root = Path(sys.argv[2])
    else:
        root = Path(__file__).resolve().parent.parent
    
    if not root.exists():
        print(f"Error: Root directory does not exist: {root}", file=sys.stderr)
        return 1
    
    try:
        platform_type = detect_platform()
        
        # Create log directories if they don't exist
        if action == "up":
            log_live_dir = root / "services" / "log" / "lars" / "live"
            log_archive_dir = root / "services" / "log" / "lars" / "archive"
            log_live_dir.mkdir(parents=True, exist_ok=True)
            log_archive_dir.mkdir(parents=True, exist_ok=True)
            
            # Pull public images (like nats)
            pull_public_images(root, platform_type)
            
            # Optional: Verify local images exist (warn only, don't fail)
            local_images = ["motor-daemon:local", "camera-daemon:latest", "lars-api:dev"]
            missing_images = [img for img in local_images if not check_image_exists(img)]
            if missing_images:
                print(f"Warning: Missing local images: {missing_images}", file=sys.stderr)
                print("  Images should be built using install.py before running compose_service.py", file=sys.stderr)
                print("  Continuing anyway - docker compose may fail if images don't exist", file=sys.stderr)
            else:
                print("✓ All required local images exist", flush=True)
        
        # Build and execute compose command
        cmd = build_compose_command(root, action)
        
        # Execute command
        result = subprocess.run(
            cmd,
            cwd=str(root),
            check=False,
            env=os.environ.copy()
        )
        
        return result.returncode
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())