#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Compose Service: Handles docker compose operations for LARS robot server

Detects platform, selects appropriate compose override files, and executes
docker compose commands. Used by systemd service for clean, maintainable service management.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

# Add parent directory to path for imports
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.motor_compose_mapper import detect_platform, get_compose_and_env

def get_camera_compose_path(root: Path, platform_type: str) -> Path | None:
    """
    Get camera daemon compose override file path based on platform.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        Path to camera compose override file, or None if not found
    """
    camera_dir = root / "services" / "camera_daemon"
    compose_file = f"compose.{platform_type}.yml"
    compose_path = camera_dir / compose_file
    
    return compose_path if compose_path.exists() else None


def build_compose_command(root: Path, action: str) -> list[str]:
    """
    Build docker compose command with all necessary override files.
    
    Args:
        root: Root directory of the project
        action: Action to perform ("up" or "down")
    
    Returns:
        List of command arguments for subprocess
    """
    # Detect platform
    platform_type = detect_platform()
    
    # Get compose files
    compose_files = [str(root / "compose.yml")]
    
    # Add camera override if exists
    camera_compose = get_camera_compose_path(root, platform_type)
    if camera_compose:
        compose_files.append(str(camera_compose))
    
    # Get motor compose override using mapper
    try:
        motor_compose, _ = get_compose_and_env(
            robot_type=None,  # Will read from ROBOT_TYPE env var or config
            platform_type=None,  # Will auto-detect
            root=root
        )
        if motor_compose.exists():
            compose_files.append(str(motor_compose))
    except Exception as e:
        # Log error but continue (motor daemon might not be critical)
        print(f"Warning: Could not get motor compose file: {e}", file=sys.stderr)
    
    # Build command
    cmd = ["docker", "compose"]
    for f in compose_files:
        cmd.extend(["-f", f])
    
    if action == "up":
        cmd.extend(["up", "-d"])
    elif action == "down":
        cmd.append("down")
    else:
        raise ValueError(f"Invalid action: {action}. Must be 'up' or 'down'")
    
    return cmd


def main() -> int:
    """Main entry point for systemd service."""
    if len(sys.argv) < 2:
        print("Usage: compose_service.py <up|down> [root_dir]", file=sys.stderr)
        return 1
    
    action = sys.argv[1].lower()
    if action not in ("up", "down"):
        print(f"Error: Invalid action '{action}'. Must be 'up' or 'down'", file=sys.stderr)
        return 1
    
    # Get root directory (default: parent of scripts directory)
    if len(sys.argv) > 2:
        root = Path(sys.argv[2])
    else:
        root = Path(__file__).resolve().parent.parent
    
    if not root.exists():
        print(f"Error: Root directory does not exist: {root}", file=sys.stderr)
        return 1
    
    try:
        # Build and execute compose command
        cmd = build_compose_command(root, action)
        
        # Execute command
        result = subprocess.run(
            cmd,
            cwd=str(root),
            check=False,  # Don't raise on error for 'down' action
            env=os.environ.copy()
        )
        
        return result.returncode
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
