#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Compose Service: Handles docker compose operations for LARS robot server

Detects platform, selects appropriate compose override files, and executes
docker compose commands. Used by systemd service for clean, maintainable service management.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

# Add parent directory to path for imports
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.motor_compose_mapper import detect_platform, get_compose_and_env

def get_logger_compose_path(root: Path) -> Path | None:
    """
    Get logger daemon compose override file path.
    
    Args:
        root: Root directory of the project
    
    Returns:
        Path to logger compose override file, or None if not found
    """
    logger_dir = root / "services" / "logger"
    compose_path = logger_dir / "compose.yml"
    
    return compose_path if compose_path.exists() else None


def build_api_image(root: Path, platform_type: str) -> bool:
    """
    Build lars-api:dev image using Docker buildx.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if build succeeded, False otherwise
    """
    api_dir = root / "services" / "api"
    dockerfile = api_dir / "Dockerfile"
    
    if not dockerfile.exists():
        print(f"Warning: Dockerfile not found: {dockerfile}", file=sys.stderr)
        return False
    
    # Determine platform
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"Building lars-api:dev image ({build_platform})...", flush=True)
    
    cmd = [
        "docker", "buildx", "build",
        "--platform", build_platform,
        "-f", str(dockerfile),
        "-t", "lars-api:dev",
        "--load",
        str(api_dir)
    ]
    
    result = subprocess.run(cmd, cwd=str(root), check=False)
    return result.returncode == 0


def build_camera_daemon_image(root: Path, platform_type: str) -> bool:
    """
    Build camera-daemon image using Docker Bake.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if build succeeded, False otherwise
    """
    daemon_dir = root / "services" / "camera_daemon"
    bake_file = daemon_dir / "camera-deamon-bake.hcl"
    
    if not bake_file.exists():
        print(f"Warning: {bake_file} not found, skipping camera-daemon build", file=sys.stderr)
        return False
    
    # Determine target based on platform
    if platform_type == "rpi":
        target = "camera-daemon-rpi"
        print(f"Building camera-daemon image for Raspberry Pi (ARM64)...", flush=True)
    else:
        target = "camera-daemon-linux"
        print(f"Building camera-daemon image (linux/amd64)...", flush=True)
    
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        target,
        "--load"
    ]
    
    result = subprocess.run(cmd, cwd=str(daemon_dir), check=False)
    return result.returncode == 0


def build_motor_daemon_image(root: Path, platform_type: str) -> bool:
    """
    Build motor-daemon image using Docker Bake.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if build succeeded, False otherwise
    """
    daemon_dir = root / "services" / "motor_daemon"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"Warning: {bake_file} not found, skipping motor-daemon build", file=sys.stderr)
        return False
    
    # Get build platform
    try:
        _, motor_env_path = get_compose_and_env(
            robot_type=None,
            platform_type=platform_type,
            root=root
        )
        build_platform = "linux/amd64"  # Default
        if motor_env_path.exists():
            with open(motor_env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("MOTOR_PLATFORM="):
                        build_platform = line.split("=", 1)[1].strip()
                        break
    except Exception:
        platform_map = {
            "rpi": "linux/arm64",
            "linux": "linux/amd64",
            "windows": "linux/amd64"
        }
        build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"Building motor-daemon image ({build_platform})...", flush=True)
    
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "motor-daemon-local",
        "--load"
    ]
    
    result = subprocess.run(cmd, cwd=str(root), env=env, check=False)
    return result.returncode == 0


def build_logger_daemon_image(root: Path, platform_type: str) -> bool:
    """
    Build logger-daemon image using Docker Bake.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if build succeeded, False otherwise
    """
    daemon_dir = root / "services" / "logger"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"Warning: {bake_file} not found, skipping logger-daemon build", file=sys.stderr)
        return False
    
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"Building logger-daemon image ({build_platform})...", flush=True)
    
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    # On RPi, use default builder for native ARM64 build
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "default"], check=False, capture_output=True)
    
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "logger-daemon-local",
        "--load"
    ]
    
    result = subprocess.run(cmd, cwd=str(root), env=env, check=False)
    
    # Return to multiplatform builder after build (if it exists)
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "multiplatform"], check=False, capture_output=True)
    
    return result.returncode == 0


def pull_public_images(root: Path, platform_type: str) -> bool:
    """
    Pull public Docker images that are required but not built locally.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if all pulls succeeded, False otherwise
    """
    # Determine platform for pulling
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    # List of public images that need to be pulled
    public_images = [
        "nats:2.10-alpine",
    ]
    
    print("Pulling public Docker images...", flush=True)
    
    success = True
    for image in public_images:
        print(f"Pulling {image} ({build_platform})...", flush=True)
        cmd = [
            "docker", "pull",
            "--platform", build_platform,
            image
        ]
        result = subprocess.run(cmd, cwd=str(root), check=False, capture_output=True)
        if result.returncode != 0:
            print(f"Warning: Failed to pull {image}: {result.stderr.decode('utf-8', errors='ignore')}", file=sys.stderr)
            # Don't fail completely - compose might still work if image exists
            success = False
        else:
            print(f"✓ Pulled {image}", flush=True)
    
    return success


def build_all_images(root: Path, platform_type: str) -> bool:
    """
    Build all required Docker images before starting services.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        True if all builds succeeded, False otherwise
    """
    print("Building Docker images...", flush=True)
    
    success = True
    
    # Build API image
    if not build_api_image(root, platform_type):
        print("Error: Failed to build lars-api:dev", file=sys.stderr)
        success = False
    
    # Build camera-daemon image
    if not build_camera_daemon_image(root, platform_type):
        print("Error: Failed to build camera-daemon", file=sys.stderr)
        success = False
    
    # Build motor-daemon image
    if not build_motor_daemon_image(root, platform_type):
        print("Error: Failed to build motor-daemon", file=sys.stderr)
        success = False
    
    # Build logger-daemon image
    # TEMPORARILY DISABLED - testing without logger-daemon
    # if not build_logger_daemon_image(root, platform_type):
    #     print("Error: Failed to build logger-daemon", file=sys.stderr)
    #     success = False
    
    if success:
        print("All images built successfully", flush=True)
    
    return success


def get_camera_compose_path(root: Path, platform_type: str) -> Path | None:
    """
    Get camera daemon compose override file path based on platform.
    
    Args:
        root: Root directory of the project
        platform_type: Platform type (rpi, linux, windows)
    
    Returns:
        Path to camera compose override file, or None if not found
    """
    camera_dir = root / "services" / "camera_daemon"
    compose_file = f"compose.{platform_type}.yml"
    compose_path = camera_dir / compose_file
    
    return compose_path if compose_path.exists() else None


# def get_logger_compose_path(root: Path) -> Path | None:
#     """
#     Get logger daemon compose override file path.
#     
#     Args:
#         root: Root directory of the project
#     
#     Returns:
#         Path to logger compose override file, or None if not found
#     """
#     logger_dir = root / "services" / "logger"
#     compose_path = logger_dir / "compose.yml"
#     
#     return compose_path if compose_path.exists() else None


def check_image_exists(image_name: str) -> bool:
    """
    Check if a Docker image exists locally.
    
    Args:
        image_name: Name of the image to check (e.g., "logger-daemon:local")
    
    Returns:
        True if image exists, False otherwise
    """
    try:
        result = subprocess.run(
            ["docker", "image", "inspect", image_name],
            capture_output=True,
            check=False
        )
        return result.returncode == 0
    except Exception:
        return False


def build_compose_command(root: Path, action: str) -> list[str]:
    """
    Build docker compose command with all necessary override files.
    
    Args:
        root: Root directory of the project
        action: Action to perform ("up" or "down")
    
    Returns:
        List of command arguments for subprocess
    """
    # Detect platform
    platform_type = detect_platform()
    
    # Get compose files
    compose_files = [str(root / "compose.yml")]
    
    # Add camera override if exists
    camera_compose = get_camera_compose_path(root, platform_type)
    if camera_compose:
        compose_files.append(str(camera_compose))
    
    # Get motor compose override using mapper
    try:
        motor_compose, _ = get_compose_and_env(
            robot_type=None,  # Will read from ROBOT_TYPE env var or config
            platform_type=None,  # Will auto-detect
            root=root
        )
        if motor_compose.exists():
            compose_files.append(str(motor_compose))
    except Exception as e:
        # Log error but continue (motor daemon might not be critical)
        print(f"Warning: Could not get motor compose file: {e}", file=sys.stderr)
    
    # Add logger override if exists
    # TEMPORARILY DISABLED - testing without logger-daemon
    # logger_compose = get_logger_compose_path(root)
    # if logger_compose:
    #     compose_files.append(str(logger_compose))
    
    # Build command
    cmd = ["docker", "compose"]
    for f in compose_files:
        cmd.extend(["-f", f])
    
    if action == "up":
        # Use 'never' to prevent pulling any images
        # Public images (like nats) are already pulled explicitly before this step
        # Local images are built before this step
        # This prevents Docker Compose from trying to pull local images from registry
        cmd.extend(["up", "-d", "--pull", "never"])
    elif action == "down":
        cmd.append("down")
    else:
        raise ValueError(f"Invalid action: {action}. Must be 'up' or 'down'")
    
    return cmd


def main() -> int:
    """Main entry point for systemd service."""
    if len(sys.argv) < 2:
        print("Usage: compose_service.py <up|down> [root_dir]", file=sys.stderr)
        return 1
    
    action = sys.argv[1].lower()
    if action not in ("up", "down"):
        print(f"Error: Invalid action '{action}'. Must be 'up' or 'down'", file=sys.stderr)
        return 1
    
    # Get root directory (default: parent of scripts directory)
    if len(sys.argv) > 2:
        root = Path(sys.argv[2])
    else:
        root = Path(__file__).resolve().parent.parent
    
    if not root.exists():
        print(f"Error: Root directory does not exist: {root}", file=sys.stderr)
        return 1
    
    try:
        # Detect platform
        platform_type = detect_platform()
        
        # Create log directories if they don't exist (for logger-daemon)
        if action == "up":
            log_live_dir = root / "services" / "log" / "lars" / "live"
            log_archive_dir = root / "services" / "log" / "lars" / "archive"
            log_live_dir.mkdir(parents=True, exist_ok=True)
            log_archive_dir.mkdir(parents=True, exist_ok=True)
        
        # Pull public images and build local images before starting services
        if action == "up":
            # Pull public images first (like nats)
            pull_public_images(root, platform_type)
            
            # Build local images
            if not build_all_images(root, platform_type):
                print("Error: Failed to build required images", file=sys.stderr)
                return 1
            
            # Verify that local images exist (especially logger-daemon:local)
            # This is critical - if images don't exist, Docker Compose will try to pull them
            # TEMPORARILY DISABLED logger-daemon:local - testing without logger-daemon
            local_images = ["motor-daemon:local", "camera-daemon:latest", "lars-api:dev"]
            missing_images = []
            for image in local_images:
                if check_image_exists(image):
                    print(f"✓ Verified local image exists: {image}", flush=True)
                else:
                    missing_images.append(image)
                    print(f"Error: Local image {image} not found after build. Cannot proceed.", file=sys.stderr)
            
            if missing_images:
                print(f"\nFailed to find {len(missing_images)} required image(s).", file=sys.stderr)
                print("This usually means the build step failed silently.", file=sys.stderr)
                print("Please check the build output above for errors.", file=sys.stderr)
                return 1
        
        # Build and execute compose command
        cmd = build_compose_command(root, action)
        
        # Execute command
        result = subprocess.run(
            cmd,
            cwd=str(root),
            check=False,  # Don't raise on error for 'down' action
            env=os.environ.copy()
        )
        
        return result.returncode
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
