#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Compose Service: Handles docker compose operations for LARS robot server

Detects platform, selects appropriate compose override files, and executes
docker compose commands. Used by systemd service for clean, maintainable service management.

Note: Images must be built separately using install.py before running this script.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

# Add parent directory to path for imports
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.motor_compose_mapper import detect_platform, get_compose_and_env


def get_camera_compose_path(root: Path, platform_type: str) -> Path | None:
    """Get camera daemon compose override file path based on platform."""
    compose_path = root / "services" / "camera_daemon" / f"compose.{platform_type}.yml"
    return compose_path if compose_path.exists() else None


def get_mode_compose_path(root: Path, mode: str | None) -> Path | None:
    """Get dev/prod compose override file path if mode is specified."""
    if not mode:
        return None
    
    mode = mode.lower()
    if mode == "dev":
        compose_path = root / "compose.dev.yml"
    elif mode == "prod":
        compose_path = root / "compose.prod.yml"
    else:
        return None
    
    return compose_path if compose_path.exists() else None


def load_env_file(env_path: Path) -> dict[str, str]:
    """Load environment variables from .env file."""
    env = {}
    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip().strip('"\'')
                    env[key] = value
    except Exception as e:
        print(f"Warning: Could not load env file {env_path}: {e}", file=sys.stderr)
    return env


def pull_public_images(root: Path, platform_type: str) -> None:
    """Pull public Docker images that are required but not built locally."""
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print("Pulling public Docker images...", flush=True)
    
    for image in ["nats:2.10-alpine"]:
        print(f"Pulling {image} ({build_platform})...", flush=True)
        result = subprocess.run(
            ["docker", "pull", "--platform", build_platform, image],
            cwd=str(root),
            check=False,
            capture_output=True
        )
        if result.returncode == 0:
            print(f"✓ Pulled {image}", flush=True)
        else:
            print(f"Warning: Failed to pull {image}: {result.stderr.decode('utf-8', errors='ignore')}", file=sys.stderr)


def build_compose_command(root: Path, action: str, mode: str | None = None) -> tuple[list[str], Path | None]:
    """Build docker compose command with all necessary override files."""
    platform_type = detect_platform()
    compose_files = [str(root / "compose.yml")]
    
    # Add dev/prod override if specified
    mode_compose = get_mode_compose_path(root, mode)
    if mode_compose:
        compose_files.append(str(mode_compose))
    
    # Add camera override if exists
    camera_compose = get_camera_compose_path(root, platform_type)
    if camera_compose:
        compose_files.append(str(camera_compose))
    
    # Get motor compose override using mapper
    motor_env_path = None
    try:
        motor_compose, motor_env_path = get_compose_and_env(
            robot_type=None,
            platform_type=None,
            root=root
        )
        if motor_compose.exists():
            compose_files.append(str(motor_compose))
    except Exception as e:
        print(f"Warning: Could not get motor compose file: {e}", file=sys.stderr)
    
    # Build command
    cmd = ["docker", "compose"]
    for f in compose_files:
        cmd.extend(["-f", f])
    
    if action == "up":
        cmd.extend(["up", "-d", "--pull", "never", "--remove-orphans"])
    elif action == "down":
        cmd.append("down")
    else:
        raise ValueError(f"Invalid action: {action}. Must be 'up' or 'down'")
    
    return cmd, motor_env_path


def main() -> int:
    """Main entry point for systemd service."""
    if len(sys.argv) < 2:
        print("Usage: compose_service.py <up|down> [root_dir] [--dev|--prod]", file=sys.stderr)
        return 1
    
    action = sys.argv[1].lower()
    if action not in ("up", "down"):
        print(f"Error: Invalid action '{action}'. Must be 'up' or 'down'", file=sys.stderr)
        return 1
    
    # Parse arguments
    root = None
    mode = None
    
    for arg in sys.argv[2:]:
        if arg == "--dev":
            mode = "dev"
        elif arg == "--prod":
            mode = "prod"
        elif not arg.startswith("--"):
            root = Path(arg)
    
    # Get root directory (default if not provided)
    if root is None:
        root = Path(__file__).resolve().parent.parent
    
    if not root.exists():
        print(f"Error: Root directory does not exist: {root}", file=sys.stderr)
        return 1
    
    # Check for COMPOSE_MODE environment variable if mode not specified via CLI
    if mode is None:
        mode = os.getenv("COMPOSE_MODE")
    
    try:
        platform_type = detect_platform()
        
        # Create log directories and pull images if starting
        if action == "up":
            log_live_dir = root / "services" / "log" / "lars" / "live"
            log_archive_dir = root / "services" / "log" / "lars" / "archive"
            log_live_dir.mkdir(parents=True, exist_ok=True)
            log_archive_dir.mkdir(parents=True, exist_ok=True)
            pull_public_images(root, platform_type)
        
        # Build compose command
        cmd, motor_env_path = build_compose_command(root, action, mode)
        
        # Load environment variables
        env = os.environ.copy()
        # Include platform-specific profile (linux/windows) + localization
        # motor-daemon requires linux/windows profile to start
        compose_profiles = f"{platform_type},localization"
        env.setdefault("COMPOSE_PROFILES", compose_profiles)
        
        if motor_env_path and motor_env_path.exists():
            env.update(load_env_file(motor_env_path))
        
        # Execute command
        result = subprocess.run(cmd, cwd=str(root), check=False, env=env)
        return result.returncode
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())