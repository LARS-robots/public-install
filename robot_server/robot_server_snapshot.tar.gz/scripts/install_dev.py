# install_dev.py
# Скрипт для построения контейнеров для разработки
# Запускать из корня папки робота (на уровень выше этой папки)

import subprocess

subprocess.run(["docker", "build", "-t", "camera-daemon:latest", "services/camera_daemon/"])
subprocess.run(["docker", "build", "-t", "lars-api:dev", "services/api/"])
subprocess.run(["docker", "build", "-t", 
                "localization-daemon:latest", "services/localization_daemon/"])
subprocess.run(["docker", "build", "-t", "imu-daemon:local", "services/imu_daemon/"])
subprocess.run(["docker", "build", "-t", "logger-daemon:local", "services/logger/"])
subprocess.run(["docker", "build", "-t", "gps-daemon:local", "services/gps_daemon/"])


