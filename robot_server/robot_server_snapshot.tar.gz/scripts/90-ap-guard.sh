#!/bin/sh
# filepath: /etc/NetworkManager/dispatcher.d/90-ap-guard.sh
# NM dispatcher hook: уважать окно guard и не дергать AP/скрипты восстановления

GUARD="/run/wifi_switch.lock"
NOW="$(date +%s)"

if [ -f "$GUARD" ]; then
    # Читаем JSON и извлекаем expires
    EXP="$(cat "$GUARD" 2>/dev/null | grep -o '"expires":[0-9.]*' | cut -d: -f2 | cut -d. -f1)"
    if [ -n "$EXP" ] && [ "$EXP" -gt "$NOW" ]; then
        logger -t nm-dispatcher "[ap-guard] guard active, skip AP actions ($1 $2)"
        exit 0
    fi
fi

# Если guard не активен, продолжаем обычную логику
exit 0