#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LARS installer: local build with docker buildx (no registry), then compose up.

- Builds image lars-api:<TAG> locally with `--load` (Windows/Linux/Raspberry Pi).
- Automatically sets up multiplatform buildx builder for cross-platform builds.
- Camera-daemon builds platform-specific:
  - RPi: Native ARM64 build using Dockerfile.rpi
  - Linux/Windows: AMD64 build using Dockerfile
- API builds for detected platform (native on ARM64, AMD64 on Windows).
- Automatically selects platform-specific compose override files.
- Optionally writes .env (API_TAG=<TAG>) for compose.yml.
- Optionally runs `docker compose up -d`.

Cross-platform support:
  - Windows: Builds for linux/amd64 (via Docker Desktop)
  - Linux AMD64: Native builds
  - Raspberry Pi (ARM64): Native ARM64 builds for both API and camera-daemon

Usage examples:
  python install.py --tag dev --write-env
  python install.py --tag dev --no-up
  python install.py --tag dev --platform linux/amd64
"""

from __future__ import annotations
import argparse
import os
import platform
import subprocess
import sys

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # Installation directory

# Add ROOT to sys.path for imports
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Import motor compose mapper
from scripts.motor_compose_mapper import get_compose_and_env
API_DIR = ROOT / 'services' / 'api'
DOCKERFILE = API_DIR / "Dockerfile"

IMAGE_NAME = "lars-api"
DEFAULT_TAG = "dev"

def run(cmd: list[str], cwd: Path | None = None, check: bool = True, env: dict | None = None) -> subprocess.CompletedProcess:
    print(f"$ {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=check, env=env)

def ensure_docker() -> None:
    try:
        run(["docker", "version"], check=True)
    except Exception as e:
        print("❌ Docker не найден или не запущен. Установи/запусти Docker Desktop (Windows) или Docker Engine (Linux).")
        raise e

def ensure_buildx_available() -> None:
    try:
        run(["docker", "buildx", "version"], check=True)
    except Exception as e:
        print("❌ Docker Buildx недоступен. Требуется Docker ≥ 20.10 (Compose v2).")
        raise e

def ensure_multiplatform_builder() -> None:
    """
    Ensure a multiplatform buildx builder exists for cross-platform builds.
    Creates one if it doesn't exist (needed for QEMU emulation on ARM64).
    """
    try:
        # Check if multiplatform builder exists
        result = subprocess.run(
            ["docker", "buildx", "ls"],
            capture_output=True,
            text=True,
            check=True
        )
        
        if "multiplatform" in result.stdout:
            # Switch to multiplatform builder and bootstrap it
            subprocess.run(
                ["docker", "buildx", "use", "multiplatform"],
                check=False,  # Don't fail if already in use
                capture_output=True
            )
            # Ensure it's bootstrapped (this sets up QEMU in the builder container)
            subprocess.run(
                ["docker", "buildx", "inspect", "--bootstrap"],
                check=True,
                capture_output=True
            )
            print("✓ Using multiplatform builder (QEMU enabled)")
        else:
            # Create multiplatform builder
            print("✳ Creating multiplatform buildx builder (needed for cross-platform builds)")
            subprocess.run(
                ["docker", "buildx", "create", "--name", "multiplatform", 
                 "--driver", "docker-container", 
                 "--platform", "linux/amd64,linux/arm64", "--use"],
                check=True
            )
            # Bootstrap the builder (downloads and sets up QEMU)
            subprocess.run(
                ["docker", "buildx", "inspect", "--bootstrap"],
                check=True,
                capture_output=True
            )
            print("✓ Multiplatform builder created and ready (QEMU enabled)")
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Warning: Could not set up multiplatform builder: {e}")
        print("  Continuing with default builder (may fail on ARM64 for AMD64 images)")

def detect_platform() -> str:
    """
    Detect platform type: "rpi", "windows", or "linux".
    Can be overridden via CAMERA_PLATFORM_TYPE env var.
    """
    # Check environment variable first
    env_platform = os.getenv("CAMERA_PLATFORM_TYPE") or os.getenv("PLATFORM_TYPE") or os.getenv("LARS_PLATFORM_TYPE")
    if env_platform:
        if env_platform.lower() in ("rpi", "raspberry", "raspberrypi"):
            return "rpi"
        elif env_platform.lower() in ("windows", "win"):
            return "windows"
        elif env_platform.lower() == "linux":
            return "linux"

    # If Docker platform is provided, use it as a hint
    env_platform = os.getenv("CAMERA_PLATFORM") or os.getenv("DOCKER_DEFAULT_PLATFORM")
    if env_platform:
        if "arm" in env_platform.lower():
            return "rpi"
        if "amd64" in env_platform.lower() or "x86_64" in env_platform.lower():
            return "linux"
    
    # Detect Raspberry Pi
    try:
        # Check device tree model
        rpi_markers = ("raspberry pi", "bcm2711", "bcm2712", "bcm2835", "bcm2836", "bcm2837", "bcm2838")
        model_paths = [
            Path("/proc/device-tree/model"),
            Path("/sys/firmware/devicetree/base/model"),
            Path("/sys/firmware/devicetree/base/compatible"),
        ]
        for model_path in model_paths:
            if model_path.exists():
                model_text = model_path.read_text().lower()
                if any(m in model_text for m in rpi_markers):
                    return "rpi"
        
        # Check cpuinfo as fallback
        cpuinfo_path = Path("/proc/cpuinfo")
        if cpuinfo_path.exists():
            cpuinfo_text = cpuinfo_path.read_text().lower()
            if "raspberry pi" in cpuinfo_text or "bcm27" in cpuinfo_text:
                return "rpi"
    except Exception:
        pass
    
    # Detect Windows
    sys_name = platform.system().lower()
    if sys_name.startswith("win"):
        return "windows"
    
    # Default to Linux
    return "linux"

def get_compose_override_path(platform_type: str) -> Path:
    """
    Get path to platform-specific compose override file for camera daemon.
    Override via CAMERA_COMPOSE_FILE or COMPOSE_OVERRIDE_FILE env var if needed.
    """
    override_env = os.getenv("CAMERA_COMPOSE_FILE") or os.getenv("CAMERA_COMPOSE_OVERRIDE") or os.getenv("COMPOSE_OVERRIDE_FILE")
    if override_env:
        return Path(override_env)
    
    override_file = f"compose.{platform_type}.yml"
    return ROOT / "services" / "camera_daemon" / override_file

def detect_robot_type(cli_override: str | None = None) -> str:
    """
    Detect robot type from CLI override, config, or environment.
    Used for local development (compose_up). For systemd deployments,
    robot type is detected by unpack.py and written to /etc/lars/robot.env.
    
    Checks motor_daemon/config.toml first, then API config, then env var.
    Returns: "simulator", "raspbot", or "diktum"
    """
    # CLI override (highest priority for local dev)
    if cli_override:
        robot_type = cli_override.lower().strip()
        if robot_type not in ("simulator", "raspbot", "diktum"):
            print(f"⚠️  Warning: Invalid robot type '{robot_type}', using default 'simulator'")
            return "simulator"
        return robot_type
    
    # Check environment variable
    env_robot_type = os.getenv("ROBOT_TYPE")
    if env_robot_type:
        robot_type = env_robot_type.lower()
        if robot_type in ("simulator", "raspbot", "diktum"):
            return robot_type
    
    # Try motor_daemon config first (dedicated config for motor daemon)
    try:
        motor_config_path = ROOT / "services" / "motor_daemon" / "config.toml"
        if motor_config_path.exists():
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib
            
            with open(motor_config_path, "rb") as f:
                config = tomllib.load(f)
                default_section = config.get("default", {})
                robot_type = default_section.get("robot_type", "simulator")
                return robot_type.lower()
    except Exception as e:
        print(f"⚠️  Warning: Could not read robot_type from motor_daemon config: {e}")
    
    # Fallback to API config
    try:
        config_paths = [
            ROOT / "services" / "api" / "src" / "config" / "config.toml",
            ROOT / "config.toml",
        ]
        
        for config_path in config_paths:
            if config_path.exists():
                try:
                    import tomllib
                except ImportError:
                    import tomli as tomllib
                
                with open(config_path, "rb") as f:
                    config = tomllib.load(f)
                    default_section = config.get("default", {})
                    robot_type = default_section.get("robot_type", "simulator")
                    return robot_type.lower()
    except Exception as e:
        print(f"⚠️  Warning: Could not read robot_type from API config: {e}")
    
    # Default to simulator
    return "simulator"


def detect_platform_arg(user_platform: str | None) -> list[str]:
    """
    Returns ["--platform", value] or [] if native is desired.
    - Windows: default linux/amd64 (под Docker Desktop это предсказуемо)
    - Linux/macOS: native by default; override with --platform if needed
    """
    if user_platform:
        return ["--platform", user_platform]
    sys_name = platform.system().lower()
    if sys_name.startswith("win"):
        return ["--platform", "linux/amd64"]
    # Auto-detect Linux architecture
    machine = platform.machine().lower()
    if "arm" in machine or "aarch64" in machine:
        return ["--platform", "linux/arm64"]
    return ["--platform", "linux/amd64"]

def write_env_file(tag: str) -> None:
    env_path = ROOT / ".env"
    updates = {
        "API_TAG": tag,
        "MOTOR_IMAGE": "motor-daemon:local",
        "LOGGER_IMAGE": "logger-daemon:local"
    }
    
    if env_path.exists():
        with env_path.open("r", encoding="utf-8") as f:
            lines = f.read().splitlines()
        out = []
        for key, value in updates.items():
            replaced = False
            for i, line in enumerate(lines):
                if line.startswith(f"{key}="):
                    out.append(f"{key}={value}")
                    replaced = True
                    lines[i] = ""  # Mark as processed
                    break
            if not replaced:
                out.append(f"{key}={value}")
        # Add remaining lines (non-empty, not processed)
        for line in lines:
            if line and not any(line.startswith(f"{k}=") for k in updates.keys()):
                out.append(line)
        content = "\n".join(out) + "\n"
    else:
        content = "\n".join(f"{k}={v}" for k, v in updates.items()) + "\n"
    
    env_path.write_text(content, encoding="utf-8")
    #print(f"✔ .env обновлён: API_TAG={tag}, MOTOR_IMAGE=motor-daemon:local, LOGGER_IMAGE=logger-daemon:local")
    print(f"✔ .env обновлён: API_TAG={tag}, MOTOR_IMAGE=motor-daemon:local")

def build_image(tag: str, platform_arg: list[str]) -> None:
    if not DOCKERFILE.exists():
        raise FileNotFoundError(f"Dockerfile не найден: {DOCKERFILE}")
    cmd = ["docker", "buildx", "build"]
    if platform_arg:
        cmd += platform_arg
    cmd += [
        "-f", str(DOCKERFILE),
        "-t", f"{IMAGE_NAME}:{tag}",
        "--load",
        str(API_DIR),
    ]
    run(cmd, cwd=ROOT)

def build_camera_daemon(platform_type: str = "linux") -> None:
    """
    Build camera-daemon image using Docker Bake.
    - RPi: Uses Dockerfile.rpi with native ARM64 build (target: camera-daemon-rpi)
    - Linux/Windows: Uses Dockerfile with AMD64 build (target: camera-daemon-linux)
    """
    daemon_dir = ROOT / "services" / "camera_daemon"
    bake_file = daemon_dir / "camera-deamon-bake.hcl"
    
    if not bake_file.exists():
        print(f"⚠️  Warning: {bake_file} not found, skipping camera-daemon build")
        return
    
    # Determine which target to build based on platform
    build_platform = os.getenv("CAMERA_PLATFORM") or os.getenv("DOCKER_DEFAULT_PLATFORM")
    if platform_type == "rpi":
        target = "camera-daemon-rpi"
        print(f"✳ Building camera-daemon image for Raspberry Pi (ARM64 native) using bake")
    else:
        target = "camera-daemon-linux"
        build_platform = build_platform or "linux/amd64"
        print(f"✳ Building camera-daemon image ({build_platform}) using bake")
    
    # Use Docker Bake to build the image
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        target,
        "--load"  # Load image into local Docker daemon
    ]
    env = os.environ.copy()
    if build_platform:
        env["DOCKER_DEFAULT_PLATFORM"] = build_platform

    # On RPi use default builder for native ARM64 build (faster and more reliable)
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "default"], check=False, capture_output=True)

    run(cmd, cwd=daemon_dir, env=env)

    # Return to multiplatform builder after build
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "multiplatform"], check=False, capture_output=True)
    

def build_motor_daemon(platform_type: str = "linux") -> None:
    """
    Build motor-daemon image using Docker Bake.
    Builds for current platform only (not multi-arch) to support --load.
    Reads platform from env file (no hardcode).
    """
    daemon_dir = ROOT / "services" / "motor_daemon"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"⚠️  Warning: {bake_file} not found, skipping motor-daemon build")
        return
    
    # Get robot type to determine which env file to read
    cli_override = os.getenv("ROBOT_TYPE")
    robot_type = detect_robot_type(cli_override=cli_override)
    
    # Get env file path from mapper
    try:
        _, motor_env_path = get_compose_and_env(robot_type, platform_type, ROOT)
        
        # Read MOTOR_PLATFORM from env file
        build_platform = "linux/amd64"  # Default fallback
        if motor_env_path.exists():
            with open(motor_env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("MOTOR_PLATFORM="):
                        build_platform = line.split("=", 1)[1].strip()
                        break
    except Exception as e:
        print(f"⚠️  Warning: Could not read platform from env file: {e}")
        # Fallback to platform_type mapping
        platform_map = {
            "rpi": "linux/arm64",
            "linux": "linux/amd64",
            "windows": "linux/amd64"
        }
        build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"✳ Building motor-daemon image using bake ({build_platform})")
    
    # Use environment variable (HCL automatically picks up env vars matching variable names)
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    # Build command using Python list operations
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "motor-daemon-local",
        "--load"  # Load image into local Docker daemon
    ]
    run(cmd, cwd=ROOT, env=env)

def build_logger_daemon(platform_type: str = "linux") -> None:
    """
    Build logger-daemon image using Docker Bake.
    Similar to build_motor_daemon, builds for current platform.
    """
    daemon_dir = ROOT / "services" / "logger"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"⚠️  Warning: {bake_file} not found, skipping logger-daemon build")
        return
    
    # Determine build platform based on platform_type
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"✳ Building logger-daemon image using bake ({build_platform})")
    
    # Use environment variable for platform
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    # Build command
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "logger-daemon-local",
        "--load"  # Load image into local Docker daemon
    ]
    
    # На RPi используем default builder для нативной сборки (быстрее и надежнее)
    if platform_type == "rpi":
        # Switch to default builder for native ARM64 build
        subprocess.run(["docker", "buildx", "use", "default"], check=False, capture_output=True)
    
    run(cmd, cwd=ROOT, env=env)
    
    # Вернуться к multiplatform builder после сборки
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "multiplatform"], check=False, capture_output=True)

def build_imu_daemon(platform_type: str = "linux") -> None:
    """
    Build imu-daemon image using Docker Bake.
    Similar to build_motor_daemon, builds for current platform.
    """
    daemon_dir = ROOT / "services" / "imu_daemon"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"⚠️  Warning: {bake_file} not found, skipping imu-daemon build")
        return
    
    # Determine build platform based on platform_type
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"✳ Building imu-daemon image using bake ({build_platform})")
    
    # Use environment variable for platform
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    # Build command
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "imu-daemon-local",
        "--load"  # Load image into local Docker daemon
    ]
    
    # On RPi use default builder for native ARM64 build (faster and more reliable)
    if platform_type == "rpi":
        # Switch to default builder for native ARM64 build
        subprocess.run(["docker", "buildx", "use", "default"], check=False, capture_output=True)
    
    run(cmd, cwd=ROOT, env=env)
    
    # Return to multiplatform builder after build
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "multiplatform"], check=False, capture_output=True)

def build_gps_daemon(platform_type: str = "linux") -> None:
    """
    Build gps-daemon image using Docker Bake.
    Similar to build_motor_daemon, builds for current platform.
    """
    daemon_dir = ROOT / "services" / "gps_daemon"
    bake_file = daemon_dir / "docker-bake.hcl"
    
    if not bake_file.exists():
        print(f"⚠️  Warning: {bake_file} not found, skipping gps-daemon build")
        return
    
    # Determine build platform based on platform_type
    platform_map = {
        "rpi": "linux/arm64",
        "linux": "linux/amd64",
        "windows": "linux/amd64"
    }
    build_platform = platform_map.get(platform_type, "linux/amd64")
    
    print(f"✳ Building gps-daemon image using bake ({build_platform})")
    
    # Use environment variable for platform
    env = os.environ.copy()
    env["PLATFORM"] = build_platform
    
    # Build command
    cmd = [
        "docker", "buildx", "bake",
        "-f", str(bake_file),
        "gps-daemon-local",
        "--load"  # Load image into local Docker daemon
    ]
    
    # On RPi use default builder for native ARM64 build (faster and more reliable)
    if platform_type == "rpi":
        # Switch to default builder for native ARM64 build
        subprocess.run(["docker", "buildx", "use", "default"], check=False, capture_output=True)
    
    run(cmd, cwd=ROOT, env=env)
    
    # Return to multiplatform builder after build
    if platform_type == "rpi":
        subprocess.run(["docker", "buildx", "use", "multiplatform"], check=False, capture_output=True)

def compose_down(platform_type: str = "linux") -> None:
    """Stop and remove containers using platform-specific override."""
    override_path = get_compose_override_path(platform_type)
    
    if override_path.exists():
        compose_cmd = [
            "docker", "compose",
            "-f", str(ROOT / "compose.yml"),
            "-f", str(override_path),
            "down"
        ]
    else:
        compose_cmd = ["docker", "compose", "-f", str(ROOT / "compose.yml"), "down"]
    
    run(compose_cmd, cwd=ROOT, check=False)

def compose_up(tag: str, platform_type: str = "linux") -> None:
    env = os.environ.copy()
    env["API_TAG"] = tag
    env["MOTOR_IMAGE"] = "motor-daemon:local"
    # env["LOGGER_IMAGE"] = "logger-daemon:local"  # Temporarily disabled
    
    # Ensure multiplatform builder is used for compose builds (needed for cross-platform builds)
    # docker compose respects the active buildx builder
    ensure_multiplatform_builder()
    
    # Get platform-specific compose override files
    camera_override_path = get_compose_override_path(platform_type)
    
    # Get robot type and motor daemon compose/env files using mapper
    # Note: For systemd deployments, robot type is detected by unpack.py and written to /etc/lars/robot.env
    # For local dev, check env var first (set by CLI --robot-type), then config files
    cli_override = os.getenv("ROBOT_TYPE")  # Set by main() if --robot-type provided
    robot_type = detect_robot_type(cli_override=cli_override)  # Uses CLI override, config files, or env var
    
    # Get compose and env file paths from mapper
    try:
        motor_compose_path, motor_env_path = get_compose_and_env(robot_type, platform_type, ROOT)
    except Exception as e:
        print(f"⚠️  Warning: Could not get motor daemon compose/env mapping: {e}")
        print(f"   Falling back to default behavior")
        # Fallback to old logic if mapper fails
        motor_daemon_dir = ROOT / "services" / "motor_daemon"
        if platform_type == "rpi":
            if robot_type == "raspbot":
                motor_compose_path = motor_daemon_dir / "compose.rpi.raspbot.yml"
            elif robot_type == "diktum":
                motor_compose_path = motor_daemon_dir / "compose.rpi.diktum.yml"
            else:
                motor_compose_path = motor_daemon_dir / "compose.rpi.diktum.yml"
        elif platform_type == "linux":
            motor_compose_path = motor_daemon_dir / "compose.linux.yml"
        elif platform_type == "windows":
            motor_compose_path = motor_daemon_dir / "compose.windows.yml"
        else:
            motor_compose_path = motor_daemon_dir / "compose.linux.yml"
        motor_env_path = None  # Fallback doesn't use env file
    
    # Load variables from motor env file if it exists
    if motor_env_path and motor_env_path.exists():
        try:
            with open(motor_env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith("#"):
                        continue
                    # Parse KEY=VALUE
                    if "=" in line:
                        key, value = line.split("=", 1)
                        key = key.strip()
                        value = value.strip()
                        # Remove quotes if present
                        if value.startswith('"') and value.endswith('"'):
                            value = value[1:-1]
                        elif value.startswith("'") and value.endswith("'"):
                            value = value[1:-1]
                        env[key] = value
                        # Also set in os.environ for compose file variable substitution
                        os.environ[key] = value
        except Exception as e:
            print(f"⚠️  Warning: Could not load variables from {motor_env_path}: {e}")
    
    # Build compose command with all override files
    compose_files = [str(ROOT / "compose.yml")]
    
    if camera_override_path.exists():
        compose_files.append(str(camera_override_path))
        print(f"✳ Using camera override: {camera_override_path.name}")
    else:
        print(f"⚠️  Warning: Camera override file not found: {camera_override_path}")
    
    if motor_compose_path.exists():
        compose_files.append(str(motor_compose_path))
        if motor_env_path:
            print(f"✳ Using motor daemon compose: {motor_compose_path.name} with env: {motor_env_path.name} (robot_type={robot_type})")
        else:
            print(f"✳ Using motor daemon compose: {motor_compose_path.name} (robot_type={robot_type})")
    else:
        print(f"⚠️  Warning: Motor daemon compose file not found: {motor_compose_path}")
    
    print(f"✳ Запуск docker compose (API_TAG={tag}, platform={platform_type}, robot_type={robot_type})")
    compose_cmd = ["docker", "compose"]
    for f in compose_files:
        compose_cmd.extend(["-f", f])
    compose_cmd.extend(["up", "-d"])  # Removed --build since images are pre-built
    
    # Явно передаем переменные через --env-file или убеждаемся, что .env обновлен
    # Docker compose автоматически загружает .env из текущей директории
    run(compose_cmd, cwd=ROOT, env=env)

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build lars-api locally with buildx and run compose (no registry).")
    p.add_argument("--tag", default=DEFAULT_TAG, help="Image tag (default: dev)")
    p.add_argument("--platform", default=None, help="linux/amd64, linux/arm64 ... (default: auto-detect)")
    p.add_argument("--robot-type", help="Override robot type (simulator|raspbot|diktum). For systemd deployments, use unpack.py instead.")
    p.add_argument("--no-up", action="store_true", help="Only build image, do not run docker compose up")
    p.add_argument("--compose-only", action="store_true", help="Only run docker compose (skip builds, assumes images already exist)")
    p.add_argument("--down", action="store_true", help="Stop and remove containers (docker compose down)")
    p.add_argument("--write-env", action="store_true", help="Write .env with API_TAG=<tag>")
    return p.parse_args()

def main() -> None:
    args = parse_args()
    ensure_docker()
    
    # Detect platform type (rpi, windows, linux)
    platform_type = detect_platform()
    print(f"✳ Обнаруженная платформа: {platform_type}")
    
    # Override robot type if provided via CLI (for local dev)
    if args.robot_type:
        # Set environment variable so compose_up uses it
        os.environ["ROBOT_TYPE"] = args.robot_type
        print(f"✳ Robot type override: {args.robot_type}")

    if args.down:
        # Stop containers
        compose_down(platform_type)
        print("✔ Containers stopped.")
        return

    if args.compose_only:
        # Only run compose (for systemd service after builds are done)
        if args.write_env:
            write_env_file(args.tag)
        compose_up(args.tag, platform_type)
        print("✔ Готово.")
        return
    
    ensure_buildx_available()
    
    # Set up multiplatform builder (needed for cross-platform builds, especially ARM64 -> AMD64)
    ensure_multiplatform_builder()
    
    platform_arg = detect_platform_arg(args.platform)
    detected_platform = platform_arg[-1] if platform_arg else "native"
    print(f"✳ Платформа сборки: {detected_platform}")

    # Build camera-daemon (uses platform-specific Dockerfile)
    build_camera_daemon(platform_type)

    # Build motor-daemon (uses single-arch build for current platform)
    build_motor_daemon(platform_type)

    # Build logger-daemon (uses Docker Bake)
    #build_logger_daemon(platform_type)  # Temporarily disabled

    # Build imu-daemon (uses Docker Bake)
    build_imu_daemon(platform_type)

    # Build gps-daemon (uses Docker Bake)
    build_gps_daemon(platform_type)

    # Build API (uses detected platform - can be native on ARM64)
    build_image(args.tag, platform_arg)

    if args.write_env:
        write_env_file(args.tag)

    if not args.no_up:
        compose_up(args.tag, platform_type)

    print("✔ Готово.")

if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Команда завершилась ошибкой (exit={e.returncode}). См. вывод выше.")
        sys.exit(e.returncode)
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        sys.exit(1)
