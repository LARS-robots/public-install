#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LARS installer: local build with docker buildx (no registry), then compose up.

- Builds image lars-api:<TAG> locally with `--load` (Windows/Linux/Raspberry Pi).
- Automatically sets up multiplatform buildx builder for cross-platform builds.
- Camera-daemon builds platform-specific:
  - RPi: Native ARM64 build using Dockerfile.rpi
  - Linux/Windows: AMD64 build using Dockerfile
- API builds for detected platform (native on ARM64, AMD64 on Windows).
- Automatically selects platform-specific compose override files.
- Optionally writes .env (API_TAG=<TAG>) for compose.yml.
- Optionally runs `docker compose up -d`.

Cross-platform support:
  - Windows: Builds for linux/amd64 (via Docker Desktop)
  - Linux AMD64: Native builds
  - Raspberry Pi (ARM64): Native ARM64 builds for both API and camera-daemon

Usage examples:
  python install.py --tag dev --write-env
  python install.py --tag dev --no-up
  python install.py --tag dev --platform linux/amd64
"""

from __future__ import annotations
import argparse
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # Installation directory
API_DIR = ROOT / 'services' / 'api'
DOCKERFILE = API_DIR / "Dockerfile"

IMAGE_NAME = "lars-api"
DEFAULT_TAG = "dev"

def run(cmd: list[str], cwd: Path | None = None, check: bool = True, env: dict | None = None) -> subprocess.CompletedProcess:
    print(f"$ {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=check, env=env)

def ensure_docker() -> None:
    try:
        run(["docker", "version"], check=True)
    except Exception as e:
        print("❌ Docker не найден или не запущен. Установи/запусти Docker Desktop (Windows) или Docker Engine (Linux).")
        raise e

def ensure_buildx_available() -> None:
    try:
        run(["docker", "buildx", "version"], check=True)
    except Exception as e:
        print("❌ Docker Buildx недоступен. Требуется Docker ≥ 20.10 (Compose v2).")
        raise e

def ensure_multiplatform_builder() -> None:
    """
    Ensure a multiplatform buildx builder exists for cross-platform builds.
    Creates one if it doesn't exist (needed for QEMU emulation on ARM64).
    """
    try:
        # Check if multiplatform builder exists
        result = subprocess.run(
            ["docker", "buildx", "ls"],
            capture_output=True,
            text=True,
            check=True
        )
        
        if "multiplatform" in result.stdout:
            # Switch to multiplatform builder and bootstrap it
            subprocess.run(
                ["docker", "buildx", "use", "multiplatform"],
                check=False,  # Don't fail if already in use
                capture_output=True
            )
            # Ensure it's bootstrapped (this sets up QEMU in the builder container)
            subprocess.run(
                ["docker", "buildx", "inspect", "--bootstrap"],
                check=True,
                capture_output=True
            )
            print("✓ Using multiplatform builder (QEMU enabled)")
        else:
            # Create multiplatform builder
            print("✳ Creating multiplatform buildx builder (needed for cross-platform builds)")
            subprocess.run(
                ["docker", "buildx", "create", "--name", "multiplatform", 
                 "--driver", "docker-container", 
                 "--platform", "linux/amd64,linux/arm64", "--use"],
                check=True
            )
            # Bootstrap the builder (downloads and sets up QEMU)
            subprocess.run(
                ["docker", "buildx", "inspect", "--bootstrap"],
                check=True,
                capture_output=True
            )
            print("✓ Multiplatform builder created and ready (QEMU enabled)")
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Warning: Could not set up multiplatform builder: {e}")
        print("  Continuing with default builder (may fail on ARM64 for AMD64 images)")

def detect_platform() -> str:
    """
    Detect platform type: "rpi", "windows", or "linux".
    Can be overridden via CAMERA_PLATFORM_TYPE env var.
    """
    # Check environment variable first
    env_platform = os.getenv("CAMERA_PLATFORM_TYPE")
    if env_platform:
        if env_platform.lower() in ("rpi", "raspberry", "raspberrypi"):
            return "rpi"
        elif env_platform.lower() in ("windows", "win"):
            return "windows"
        elif env_platform.lower() == "linux":
            return "linux"
    
    # Detect Raspberry Pi
    try:
        # Check device tree model
        model_path = Path("/proc/device-tree/model")
        if model_path.exists():
            model_text = model_path.read_text().lower()
            if "raspberry pi" in model_text:
                return "rpi"
        
        # Check cpuinfo as fallback
        cpuinfo_path = Path("/proc/cpuinfo")
        if cpuinfo_path.exists():
            cpuinfo_text = cpuinfo_path.read_text().lower()
            if "raspberry pi" in cpuinfo_text:
                return "rpi"
    except Exception:
        pass
    
    # Detect Windows
    sys_name = platform.system().lower()
    if sys_name.startswith("win"):
        return "windows"
    
    # Default to Linux
    return "linux"

def get_compose_override_path(platform_type: str) -> Path:
    """
    Get path to platform-specific compose override file.
    Override via COMPOSE_OVERRIDE_FILE env var if needed.
    """
    override_env = os.getenv("COMPOSE_OVERRIDE_FILE")
    if override_env:
        return Path(override_env)
    
    override_file = f"compose.{platform_type}.yml"
    return ROOT / "services" / "camera_daemon" / override_file

def detect_platform_arg(user_platform: str | None) -> list[str]:
    """
    Returns ["--platform", value] or [] if native is desired.
    - Windows: default linux/amd64 (под Docker Desktop это предсказуемо)
    - Linux/macOS: native by default; override with --platform if needed
    """
    if user_platform:
        return ["--platform", user_platform]
    sys_name = platform.system().lower()
    if sys_name.startswith("win"):
        return ["--platform", "linux/amd64"]
    # Auto-detect Linux architecture
    machine = platform.machine().lower()
    if "arm" in machine or "aarch64" in machine:
        return ["--platform", "linux/arm64"]
    return ["--platform", "linux/amd64"]

def write_env_file(tag: str) -> None:
    env_path = ROOT / ".env"
    if env_path.exists():
        with env_path.open("r", encoding="utf-8") as f:
            lines = f.read().splitlines()
        out = []
        replaced = False
        for line in lines:
            if line.startswith("API_TAG="):
                out.append(f"API_TAG={tag}")
                replaced = True
            else:
                out.append(line)
        if not replaced:
            out.append(f"API_TAG={tag}")
        content = "\n".join(out) + "\n"
    else:
        content = f"API_TAG={tag}\n"
    env_path.write_text(content, encoding="utf-8")
    print(f"✔ .env обновлён: API_TAG={tag}")

def build_image(tag: str, platform_arg: list[str]) -> None:
    if not DOCKERFILE.exists():
        raise FileNotFoundError(f"Dockerfile не найден: {DOCKERFILE}")
    cmd = ["docker", "buildx", "build"]
    if platform_arg:
        cmd += platform_arg
    cmd += [
        "-f", str(DOCKERFILE),
        "-t", f"{IMAGE_NAME}:{tag}",
        "--load",
        str(API_DIR),
    ]
    run(cmd, cwd=ROOT)

def build_camera_daemon(platform_type: str = "linux") -> None:
    """
    Build camera-daemon image.
    - RPi: Uses Dockerfile.rpi with native ARM64 build
    - Linux/Windows: Uses Dockerfile with AMD64 build
    """
    daemon_dir = ROOT / "services" / "camera_daemon"
    
    # Determine Dockerfile and platform based on detected platform
    if platform_type == "rpi":
        dockerfile = daemon_dir / "Dockerfile.rpi"
        build_platform = os.getenv("CAMERA_PLATFORM", "linux/arm64")
        print(f"✳ Building camera-daemon image for Raspberry Pi (ARM64 native)")
    else:
        dockerfile = daemon_dir / "Dockerfile"
        build_platform = os.getenv("CAMERA_PLATFORM", "linux/amd64")
        print(f"✳ Building camera-daemon image ({build_platform})")
    
    if not dockerfile.exists():
        print(f"⚠️  Warning: {dockerfile} not found, skipping camera-daemon build")
        return
    
    # Use multiplatform builder (set by ensure_multiplatform_builder)
    cmd = [
        "docker", "buildx", "build",
        "--platform", build_platform,
        "-f", str(dockerfile),
        "-t", "camera-daemon:latest",
        "--load",
        str(daemon_dir)
    ]
    run(cmd, cwd=ROOT)

def compose_up(tag: str, platform_type: str = "linux") -> None:
    env = os.environ.copy()
    env["API_TAG"] = tag
    
    # Ensure multiplatform builder is used for compose builds (needed for cross-platform builds)
    # docker compose respects the active buildx builder
    ensure_multiplatform_builder()
    
    # Get platform-specific compose override file
    override_path = get_compose_override_path(platform_type)
    
    if not override_path.exists():
        print(f"⚠️  Warning: Override file not found: {override_path}")
        print("  Using base compose.yml only")
        compose_cmd = ["docker", "compose", "-f", str(ROOT / "compose.yml"), "up", "-d", "--build"]
    else:
        print(f"✳ Запуск docker compose (API_TAG={tag}, platform={platform_type}, override={override_path.name})")
        compose_cmd = [
            "docker", "compose",
            "-f", str(ROOT / "compose.yml"),
            "-f", str(override_path),
            "up", "-d", "--build"
        ]
    
    run(compose_cmd, cwd=ROOT, env=env)

def compose_down(platform_type: str = "linux") -> None:
    """Stop and remove containers using platform-specific override."""
    override_path = get_compose_override_path(platform_type)
    
    if override_path.exists():
        compose_cmd = [
            "docker", "compose",
            "-f", str(ROOT / "compose.yml"),
            "-f", str(override_path),
            "down"
        ]
    else:
        compose_cmd = ["docker", "compose", "-f", str(ROOT / "compose.yml"), "down"]
    
    run(compose_cmd, cwd=ROOT, check=False)

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build lars-api locally with buildx and run compose (no registry).")
    p.add_argument("--tag", default=DEFAULT_TAG, help="Image tag (default: dev)")
    p.add_argument("--platform", default=None, help="linux/amd64, linux/arm64 ... (default: auto-detect)")
    p.add_argument("--no-up", action="store_true", help="Only build image, do not run docker compose up")
    p.add_argument("--compose-only", action="store_true", help="Only run docker compose (skip builds, assumes images already exist)")
    p.add_argument("--down", action="store_true", help="Stop and remove containers (docker compose down)")
    p.add_argument("--write-env", action="store_true", help="Write .env with API_TAG=<tag>")
    return p.parse_args()

def main() -> None:
    args = parse_args()
    ensure_docker()
    
    # Detect platform type (rpi, windows, linux)
    platform_type = detect_platform()
    print(f"✳ Обнаруженная платформа: {platform_type}")

    if args.down:
        # Stop containers
        compose_down(platform_type)
        print("✔ Containers stopped.")
        return

    if args.compose_only:
        # Only run compose (for systemd service after builds are done)
        if args.write_env:
            write_env_file(args.tag)
        compose_up(args.tag, platform_type)
        print("✔ Готово.")
        return
    
    ensure_buildx_available()
    
    # Set up multiplatform builder (needed for cross-platform builds, especially ARM64 -> AMD64)
    ensure_multiplatform_builder()
    
    platform_arg = detect_platform_arg(args.platform)
    detected_platform = platform_arg[-1] if platform_arg else "native"
    print(f"✳ Платформа сборки: {detected_platform}")

    # Build camera-daemon (uses platform-specific Dockerfile)
    build_camera_daemon(platform_type)

    # Build API (uses detected platform - can be native on ARM64)
    build_image(args.tag, platform_arg)

    if args.write_env:
        write_env_file(args.tag)

    if not args.no_up:
        compose_up(args.tag, platform_type)

    print("✔ Готово.")

if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Команда завершилась ошибкой (exit={e.returncode}). См. вывод выше.")
        sys.exit(e.returncode)
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        sys.exit(1)
