# Test all scenarios for map point movement
# Checks that UI shows clear error messages

$baseUrl = "http://localhost:8000"
$results = @()

function Test-Scenario {
    param(
        [string]$Name,
        [scriptblock]$Setup,
        [scriptblock]$Test,
        [scriptblock]$Cleanup
    )
    
    Write-Host ""
    Write-Host "=== Test: $Name ===" -ForegroundColor Cyan
    
    try {
        if ($Setup) { & $Setup }
        Start-Sleep -Seconds 2
        
        $testResult = & $Test
        if ($testResult -is [hashtable]) {
            $results += [PSCustomObject]@{
                Scenario = $Name
                Status = if ($testResult.Success) { "PASS" } else { "FAIL" }
                Message = $testResult.Message
            }
            
            $color = if ($testResult.Success) { "Green" } else { "Red" }
            Write-Host "Result: $($testResult.Message)" -ForegroundColor $color
        } else {
            $results += [PSCustomObject]@{
                Scenario = $Name
                Status = "ERROR"
                Message = "Test did not return proper result"
            }
            Write-Host "Error: Test did not return proper result" -ForegroundColor Red
        }
    }
    catch {
        $results += [PSCustomObject]@{
            Scenario = $Name
            Status = "ERROR"
            Message = $_.Exception.Message
        }
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally {
        if ($Cleanup) { & $Cleanup }
        Start-Sleep -Seconds 2
    }
}

Write-Host "Starting UI scenario tests..." -ForegroundColor Yellow

# Test 1: Normal operation
Test-Scenario -Name "Pose: Normal operation" `
    -Setup { 
        docker compose start motor-daemon localization-daemon 2>&1 | Out-Null
    } `
    -Test {
        Start-Sleep -Seconds 3
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/telemetry/pose" -ErrorAction Stop
            if ($response.x -ne $null -and $response.y -ne $null) {
                return @{ Success = $true; Message = "Pose received: x=$($response.x), y=$($response.y)" }
            } else {
                return @{ Success = $false; Message = "Pose without coordinates" }
            }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            return @{ Success = $false; Message = "Error: HTTP $($_.Exception.Response.StatusCode.value__) - $($body.detail)" }
        }
    } `
    -Cleanup { }

# Test 2: localization-daemon stopped
Test-Scenario -Name "Pose: localization-daemon stopped" `
    -Setup { 
        docker compose stop localization-daemon 2>&1 | Out-Null
    } `
    -Test {
        Start-Sleep -Seconds 3
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/telemetry/pose" -ErrorAction Stop
            return @{ Success = $false; Message = "Unexpected success when daemon stopped" }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            $statusCode = $_.Exception.Response.StatusCode.value__
            
            if ($statusCode -eq 503 -and $body.detail -like "*не обновлялась*") {
                return @{ Success = $true; Message = "Correct error: $($body.detail)" }
            } else {
                return @{ Success = $false; Message = "Wrong error: HTTP $statusCode - $($body.detail)" }
            }
        }
    } `
    -Cleanup { 
        docker compose start localization-daemon 2>&1 | Out-Null
    }

# Test 3: motor-daemon stopped
Test-Scenario -Name "Pose: motor-daemon stopped" `
    -Setup { 
        docker compose stop motor-daemon 2>&1 | Out-Null
    } `
    -Test {
        Start-Sleep -Seconds 5
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/telemetry/pose" -ErrorAction Stop
            return @{ Success = $false; Message = "Unexpected success when motor-daemon stopped" }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            $statusCode = $_.Exception.Response.StatusCode.value__
            
            if ($statusCode -eq 503) {
                return @{ Success = $true; Message = "Correct error: $($body.detail)" }
            } else {
                return @{ Success = $false; Message = "Wrong status: HTTP $statusCode" }
            }
        }
    } `
    -Cleanup { 
        docker compose start motor-daemon 2>&1 | Out-Null
    }

# Test 4: Both daemons stopped
Test-Scenario -Name "Pose: both daemons stopped" `
    -Setup { 
        docker compose stop motor-daemon localization-daemon 2>&1 | Out-Null
    } `
    -Test {
        Start-Sleep -Seconds 5
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/telemetry/pose" -ErrorAction Stop
            return @{ Success = $false; Message = "Unexpected success when both daemons stopped" }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            $statusCode = $_.Exception.Response.StatusCode.value__
            
            if ($statusCode -eq 503) {
                return @{ Success = $true; Message = "Correct error: $($body.detail)" }
            } else {
                return @{ Success = $false; Message = "Wrong status: HTTP $statusCode" }
            }
        }
    } `
    -Cleanup { 
        docker compose start motor-daemon localization-daemon 2>&1 | Out-Null
    }

# Test 5: Motion command with working daemon
Test-Scenario -Name "Motion: command with working daemon" `
    -Setup { 
        docker compose start motor-daemon 2>&1 | Out-Null
        Start-Sleep -Seconds 2
    } `
    -Test {
        $body = @{speed=0.1; forward=0.1; turn=0} | ConvertTo-Json
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/motion/command" -Method POST -Body $body -ContentType "application/json" -ErrorAction Stop
            if ($response.status -eq "sent") {
                return @{ Success = $true; Message = "Command sent successfully" }
            } else {
                return @{ Success = $false; Message = "Unexpected response: $($response | ConvertTo-Json)" }
            }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            return @{ Success = $false; Message = "Error: HTTP $($_.Exception.Response.StatusCode.value__) - $($body.detail)" }
        }
    } `
    -Cleanup { }

# Test 6: Motion command with stopped daemon
Test-Scenario -Name "Motion: command with stopped daemon" `
    -Setup { 
        docker compose stop motor-daemon 2>&1 | Out-Null
        Start-Sleep -Seconds 2
    } `
    -Test {
        $body = @{speed=0.1; forward=0.1; turn=0} | ConvertTo-Json
        try {
            $response = Invoke-RestMethod -Uri "$baseUrl/motion/command" -Method POST -Body $body -ContentType "application/json" -ErrorAction Stop
            return @{ Success = $false; Message = "Unexpected success when daemon stopped" }
        } catch {
            $stream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            $statusCode = $_.Exception.Response.StatusCode.value__
            
            if ($statusCode -eq 503 -and $body.detail -like "*NATS*") {
                return @{ Success = $true; Message = "Correct error: $($body.detail)" }
            } else {
                return @{ Success = $false; Message = "Wrong error: HTTP $statusCode - $($body.detail)" }
            }
        }
    } `
    -Cleanup { 
        docker compose start motor-daemon 2>&1 | Out-Null
    }

# Results
Write-Host ""
Write-Host "=== TEST RESULTS ===" -ForegroundColor Yellow
Write-Host ""

$results | Format-Table -AutoSize

$passed = ($results | Where-Object { $_.Status -eq "PASS" }).Count
$failed = ($results | Where-Object { $_.Status -eq "FAIL" -or $_.Status -eq "ERROR" }).Count
$total = $results.Count

Write-Host ""
Write-Host "Total: $passed/$total tests passed" -ForegroundColor $(if ($failed -eq 0) { "Green" } else { "Yellow" })
if ($failed -gt 0) {
    Write-Host "Failed: $failed tests" -ForegroundColor Red
    Write-Host ""
    Write-Host "Failed test details:" -ForegroundColor Red
    $results | Where-Object { $_.Status -eq "FAIL" -or $_.Status -eq "ERROR" } | Format-List
}







