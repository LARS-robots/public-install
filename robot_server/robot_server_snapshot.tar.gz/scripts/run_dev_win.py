# run_dev_win.py
# Скрипт для запуска сервера робота для тестирования
# Использование: python scripts/run_dev_win.py [up|down]
import sys
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.motor_compose_mapper import detect_platform, get_compose_and_env, get_camera_compose_path

def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1].lower() not in ("up", "down"):
        print("Usage: run_dev_win.py <up|down>", file=sys.stderr)
        return 1
    
    action = sys.argv[1].lower()
    root = Path(__file__).resolve().parent.parent
    platform_type = detect_platform()
    
    # Build compose files list
    compose_files = [
        root / "compose.yml",
        root / "compose.dev.yml"
    ]
    
    # Add motor daemon compose (platform-aware)
    try:
        motor_compose, _ = get_compose_and_env(robot_type=None, platform_type=None, root=root)
        if motor_compose.exists():
            compose_files.append(motor_compose)
    except Exception:
        pass
    
    # Add camera daemon compose (platform-aware)
    camera_compose = get_camera_compose_path(platform_type=platform_type, root=root)
    if camera_compose.exists():
        compose_files.append(camera_compose)
    
    # Add platform-specific compose override (for devices, etc.)
    platform_compose = root / f"compose.{platform_type}.yml"
    if platform_compose.exists():
        compose_files.append(platform_compose)
    
    # Build and execute command
    cmd = ["docker", "compose"]
    for f in compose_files:
        cmd.extend(["-f", str(f)])
    cmd.extend(["up", "-d"] if action == "up" else ["down"])
    
    return subprocess.run(cmd, cwd=str(root), check=False).returncode

if __name__ == "__main__":
    sys.exit(main())
