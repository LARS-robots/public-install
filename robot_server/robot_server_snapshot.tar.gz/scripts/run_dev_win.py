# run_dev_win.py
# Скрипт для запуска сервера робота для тестирования под Windows
# Запускать из корня папки робота (на уровень выше этой папки)

import subprocess

# subprocess.run(["docker", "compose", "--profile", "windows", "up", "-d"])
subprocess.run(["docker", "compose", "-f", "compose.yml", "-f", "compose.dev.yml", "up", "-d"])