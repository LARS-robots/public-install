#!/usr/bin/env python3
"""
Motor Compose Mapper: Maps robot type from config.toml to compose and env files.
"""

from __future__ import annotations
import os
import platform
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib


def detect_platform() -> str:
    """Detect platform: rpi, windows, or linux."""
    if env_platform := os.getenv("CAMERA_PLATFORM_TYPE"):
        if env_platform.lower() in ("rpi", "raspberry", "raspberrypi"):
            return "rpi"
        elif env_platform.lower() in ("windows", "win"):
            return "windows"
        elif env_platform.lower() == "linux":
            return "linux"
    
    # Detect Raspberry Pi
    for path in [Path("/proc/device-tree/model"), Path("/proc/cpuinfo")]:
        try:
            if path.exists() and "raspberry pi" in path.read_text().lower():
                return "rpi"
        except Exception:
            pass
    
    return "windows" if platform.system().lower().startswith("win") else "linux"


def get_robot_type_from_config(root: Path) -> str:
    """Read robot_type from robot/config/config.toml."""
    config_path = root / "config" / "config.toml"
    if not config_path.exists():
        return "simulator"
    
    try:
        with open(config_path, "rb") as f:
            config = tomllib.load(f)
        return config.get("default", {}).get("robot_type", "simulator").lower().strip()
    except Exception:
        return "simulator"


def find_env_file(robot_type: str, root: Path) -> Path:
    """Find env file, checking root/env/ first, then services/motor_daemon/env/."""
    for env_path in [
        root / "env" / f"{robot_type}.env",
        root / "services" / "motor_daemon" / "env" / f"{robot_type}.env",
    ]:
        if env_path.exists():
            return env_path
    
    raise FileNotFoundError(
        f"Env file not found for robot_type '{robot_type}'. "
        f"Checked: root/env/ and services/motor_daemon/env/"
    )


def _determine_compose_file(platform_type: str, robot_type: str) -> str:
    """Determine compose file name from platform and robot type."""
    platform_type, robot_type = platform_type.lower(), robot_type.lower()
    
    if platform_type == "rpi":
        mapping = {
            "raspbot": "compose.rpi.raspbot.yml",
            "diktum": "compose.rpi.diktum.yml",
            "electric": "compose.rpi.electric_train.yml",
            "electric_train": "compose.rpi.electric_train.yml",
        }
        return mapping.get(robot_type, "compose.rpi.diktum.yml")
    
    return {
        "linux": "compose.linux.yml",
        "windows": "compose.windows.yml",
    }.get(platform_type, "compose.linux.yml")


def get_compose_and_env(
    robot_type: str | None = None,
    platform_type: str | None = None,
    root: Path | None = None
) -> tuple[Path, Path]:
    """Get compose and env file paths based on robot_type and platform_type."""
    if root is None:
        root = Path(__file__).resolve().parent.parent
    
    platform_type = platform_type or detect_platform()
    robot_type = robot_type or os.getenv("ROBOT_TYPE") or get_robot_type_from_config(root)
    robot_type = robot_type.lower().strip()
    
    compose_file = _determine_compose_file(platform_type, robot_type)
    compose_path = root / "services" / "motor_daemon" / compose_file
    
    if not compose_path.exists():
        raise FileNotFoundError(f"Compose file not found: {compose_path}")
    
    return (compose_path, find_env_file(robot_type, root))


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Map robot type to compose and env files")
    parser.add_argument("--robot-type", choices=["simulator", "raspbot", "diktum", "electric_train"],
                        help="Robot type (default: from config.toml)")
    parser.add_argument("--platform-type", choices=["rpi", "linux", "windows"],
                        help="Platform type (default: auto-detected)")
    parser.add_argument("--root", type=Path, help="Root directory")
    parser.add_argument("--output-format", choices=["compose", "env", "both"], default="both")
    
    args = parser.parse_args()
    
    try:
        compose_path, env_path = get_compose_and_env(args.robot_type, args.platform_type, args.root)
        if args.output_format == "compose":
            print(compose_path)
        elif args.output_format == "env":
            print(env_path)
        else:
            print(f"Compose: {compose_path}\nEnv: {env_path}")
    except Exception as e:
        print(f"Error: {e}", file=__import__("sys").stderr)
        exit(1)