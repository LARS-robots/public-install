#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Motor Compose Mapper: Maps compose files to env files based on config.compose.toml

Reads the mapping configuration and returns the appropriate compose and env file paths
for a given robot_type and platform_type combination. Auto-detects platform and reads
robot_type from config.compose.toml if not provided.
"""

from __future__ import annotations

import os
import platform
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib


def detect_platform() -> str:
    """
    Detect platform type: "rpi", "windows", or "linux".
    Can be overridden via CAMERA_PLATFORM_TYPE env var.
    """
    # Check environment variable first
    env_platform = os.getenv("CAMERA_PLATFORM_TYPE")
    if env_platform:
        if env_platform.lower() in ("rpi", "raspberry", "raspberrypi"):
            return "rpi"
        elif env_platform.lower() in ("windows", "win"):
            return "windows"
        elif env_platform.lower() == "linux":
            return "linux"
    
    # Detect Raspberry Pi
    try:
        # Check device tree model
        model_path = Path("/proc/device-tree/model")
        if model_path.exists():
            model_text = model_path.read_text().lower()
            if "raspberry pi" in model_text:
                return "rpi"
        
        # Check cpuinfo as fallback
        cpuinfo_path = Path("/proc/cpuinfo")
        if cpuinfo_path.exists():
            cpuinfo_text = cpuinfo_path.read_text().lower()
            if "raspberry pi" in cpuinfo_text:
                return "rpi"
    except Exception:
        pass
    
    # Detect Windows
    sys_name = platform.system().lower()
    if sys_name.startswith("win"):
        return "windows"
    
    # Default to Linux
    return "linux"


def get_robot_type_from_config(config_path: Path) -> str:
    """
    Read robot_type from config.compose.toml default section.
    
    Returns:
        Robot type string (simulator, raspbot, or diktum)
    """
    if not config_path.exists():
        return "simulator"  # Safe default
    
    try:
        with open(config_path, "rb") as f:
            config = tomllib.load(f)
        default_section = config.get("default", {})
        robot_type = default_section.get("robot_type", "simulator")
        return robot_type.lower()
    except Exception:
        return "simulator"  # Safe default


def get_compose_and_env(
    robot_type: str | None = None,
    platform_type: str | None = None,
    root: Path | None = None
) -> tuple[Path, Path]:
    """
    Get compose file and corresponding env file paths based on robot_type and platform_type.
    
    Args:
        robot_type: Type of robot (simulator, raspbot, diktum). If None, reads from config.compose.toml
                   or ROBOT_TYPE env var.
        platform_type: Platform type (rpi, linux, windows). If None, auto-detects.
        root: Root directory of the project (default: parent of scripts directory)
    
    Returns:
        Tuple of (compose_path, env_path) relative to root directory
    
    Raises:
        FileNotFoundError: If config.compose.toml is not found
        ValueError: If compose file is not found in mapping
    """
    if root is None:
        # Default to parent of scripts directory
        root = Path(__file__).resolve().parent.parent
    
    motor_daemon_dir = root / "services" / "motor_daemon"
    config_path = motor_daemon_dir / "config.compose.toml"
    
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    # Auto-detect platform if not provided
    if platform_type is None:
        platform_type = detect_platform()
    
    # Get robot_type from config if not provided
    if robot_type is None:
        # Check env var first (highest priority, used by systemd)
        robot_type = os.getenv("ROBOT_TYPE")
        if not robot_type:
            # Fall back to config file
            robot_type = get_robot_type_from_config(config_path)
    
    robot_type = robot_type.lower()
    
    # Read config.compose.toml
    with open(config_path, "rb") as f:
        config = tomllib.load(f)
    
    # Determine compose file name based on platform and robot type
    compose_file = _determine_compose_file(platform_type, robot_type)
    
    # Find mapping entry
    mapping = config.get("mapping", {})
    files = mapping.get("files", [])
    
    # Find the entry with matching compose file
    for entry in files:
        if entry.get("compose") == compose_file:
            env_file = entry.get("env")
            if not env_file:
                raise ValueError(f"Env file not specified for compose file: {compose_file}")
            
            # Return paths relative to root
            compose_path = motor_daemon_dir / compose_file
            env_path = motor_daemon_dir / env_file
            
            return (compose_path, env_path)
    
    # If not found, raise error
    raise ValueError(
        f"Compose file '{compose_file}' not found in mapping. "
        f"Available files: {[e.get('compose') for e in files]}"
    )


def _determine_compose_file(platform_type: str, robot_type: str) -> str:
    """
    Determine compose file name based on platform_type and robot_type.
    
    Logic:
    - rpi + raspbot → compose.rpi.raspbot.yml
    - rpi + diktum → compose.rpi.diktum.yml
    - rpi + simulator → compose.rpi.diktum.yml (default for RPi)
    - linux + * → compose.linux.yml
    - windows + * → compose.windows.yml
    """
    platform_type = platform_type.lower()
    robot_type = robot_type.lower()
    
    if platform_type == "rpi":
        if robot_type == "raspbot":
            return "compose.rpi.raspbot.yml"
        elif robot_type == "diktum":
            return "compose.rpi.diktum.yml"
        else:
            # Default to diktum for RPi
            return "compose.rpi.diktum.yml"
    elif platform_type == "linux":
        return "compose.linux.yml"
    elif platform_type == "windows":
        return "compose.windows.yml"
    else:
        # Default to linux
        return "compose.linux.yml"


if __name__ == "__main__":
    # CLI interface for testing
    import argparse
    
    parser = argparse.ArgumentParser(description="Map compose files to env files")
    parser.add_argument("--robot-type", choices=["simulator", "raspbot", "diktum"],
                        help="Robot type (default: from config.compose.toml or ROBOT_TYPE env var)")
    parser.add_argument("--platform-type", choices=["rpi", "linux", "windows"],
                        help="Platform type (default: auto-detected)")
    parser.add_argument("--root", type=Path, help="Root directory (default: parent of scripts)")
    parser.add_argument("--output-format", choices=["compose", "env", "both"], default="both",
                        help="Output format: 'compose' (only compose path), 'env' (only env path), or 'both' (default)")
    
    args = parser.parse_args()
    
    try:
        compose_path, env_path = get_compose_and_env(
            args.robot_type,
            args.platform_type,
            args.root
        )
        
        if args.output_format == "compose":
            print(str(compose_path))
        elif args.output_format == "env":
            print(str(env_path))
        else:  # both
            print(f"Compose: {compose_path}")
            print(f"Env: {env_path}")
    except Exception as e:
        print(f"Error: {e}", file=__import__("sys").stderr)
        exit(1)

