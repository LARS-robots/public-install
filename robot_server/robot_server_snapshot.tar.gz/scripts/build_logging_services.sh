#!/bin/bash
# Скрипт для сборки контейнеров системы логирования
# Использование: ./scripts/build_logging_services.sh

set -e  # Остановка при ошибке

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Переход в корневую директорию проекта
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

info "Рабочая директория: $ROOT_DIR"

# Проверка Docker
if ! command -v docker &> /dev/null; then
    error "Docker не установлен или не доступен"
    exit 1
fi

info "Docker версия: $(docker --version)"

# Проверка docker buildx
if ! docker buildx version &> /dev/null; then
    warn "docker buildx не доступен, используем обычный docker build"
    USE_BUILDX=false
else
    info "Docker Buildx версия: $(docker buildx version | head -1)"
    USE_BUILDX=true
fi

# Функция сборки API
build_api() {
    info "Сборка API сервиса (lars-api:dev)..."
    cd services/api
    
    if [ "$USE_BUILDX" = true ]; then
        docker buildx build -f Dockerfile -t lars-api:dev --load .
    else
        docker build -f Dockerfile -t lars-api:dev .
    fi
    
    if [ $? -eq 0 ]; then
        info "✅ API сервис успешно собран"
    else
        error "❌ Ошибка при сборке API сервиса"
        exit 1
    fi
    
    cd "$ROOT_DIR"
}

# Функция сборки logger-daemon
build_logger() {
    info "Сборка logger-daemon (logger-daemon:local)..."
    
    if [ "$USE_BUILDX" = true ] && [ -f "services/logger/docker-bake.hcl" ]; then
        docker buildx bake -f services/logger/docker-bake.hcl logger-daemon-local --load
    else
        docker build -f services/logger/Dockerfile -t logger-daemon:local services/logger
    fi
    
    if [ $? -eq 0 ]; then
        info "✅ logger-daemon успешно собран"
    else
        error "❌ Ошибка при сборке logger-daemon"
        exit 1
    fi
}

# Функция сборки localization-daemon
build_localization() {
    info "Сборка localization-daemon (localization-daemon:local)..."
    
    if [ "$USE_BUILDX" = true ] && [ -f "services/localization_daemon/docker-bake.hcl" ]; then
        docker buildx bake -f services/localization_daemon/docker-bake.hcl localization-daemon-local --load
    else
        docker build -f services/localization_daemon/Dockerfile -t localization-daemon:local services/localization_daemon
    fi
    
    if [ $? -eq 0 ]; then
        info "✅ localization-daemon успешно собран"
    else
        error "❌ Ошибка при сборке localization-daemon"
        exit 1
    fi
}

# Главная функция
main() {
    info "Начало сборки контейнеров системы логирования..."
    echo ""
    
    # Сборка всех сервисов
    build_api
    echo ""
    
    build_logger
    echo ""
    
    build_localization
    echo ""
    
    # Проверка собранных образов
    info "Проверка собранных образов:"
    docker images | grep -E "(lars-api|logger-daemon|localization-daemon)" || warn "Образы не найдены"
    echo ""
    
    info "✅ Все контейнеры успешно собраны!"
    info "Теперь вы можете запустить сервисы:"
    info "  docker compose up -d nats api logger-daemon localization-daemon"
}

# Запуск
main
