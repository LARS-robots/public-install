"""
Usage: python build_site_geojson.py "south,west,north,east"
Fetch OSM data from Overpass API and build a GeoJSON file marking obstacles and roads.
Writes to public/maps/city/site.geojson
"""
import json, requests, math
import time
from pathlib import Path
import argparse
import sys

def tile_bbox(s, w, n, e, step_deg=0.05):
    """Split bounding box into tiles to avoid API timeouts"""
    lat = s
    while lat < n:
        lat2 = min(n, lat + step_deg)
        lon = w
        while lon < e:
            lon2 = min(e, lon + step_deg)
            yield (lat, lon, lat2, lon2)
            lon = lon2
        lat = lat2

def fetch_overpass_bbox(s, w, n, e, timeout=180, retry=3):
    """Fetch OSM data with retry logic"""
    # Use actual coordinates, not {{bbox}} placeholder
    query = f"""
    [out:json][timeout:150];
    (
        /* buildings */
        way["building"]({s},{w},{n},{e});
        relation["building"]({s},{w},{n},{e});

        /* water bodies */
        way["natural"="water"]({s},{w},{n},{e});
        relation["natural"="water"]({s},{w},{n},{e});
        way["waterway"="riverbank"]({s},{w},{n},{e});
        relation["waterway"="riverbank"]({s},{w},{n},{e});

        /* parks & recreation */
        way["leisure"="park"]({s},{w},{n},{e});
        relation["leisure"="park"]({s},{w},{n},{e});
        way["landuse"="recreation_ground"]({s},{w},{n},{e});
        relation["landuse"="recreation_ground"]({s},{w},{n},{e});

        /* highways (roads, paths) */
        way["highway"~"motorway|trunk|primary|secondary|tertiary|residential|service|path|footway|cycleway"]({s},{w},{n},{e});

        /* blocked landuse */
        way["landuse"~"cemetery|industrial|construction"]({s},{w},{n},{e});
        relation["landuse"~"cemetery|industrial|construction"]({s},{w},{n},{e});
    );
    out body geom;
    """
    
    for attempt in range(retry):
        try:
            print(f"  Fetching tile ({s:.4f},{w:.4f},{n:.4f},{e:.4f})... ", end="", flush=True)
            r = requests.post(
                "https://overpass-api.de/api/interpreter",
                data=query.encode("utf-8"), 
                timeout=timeout
            )
            r.raise_for_status()
            elements = r.json().get("elements", [])
            print(f"✅ {len(elements)} elements")
            return elements
        except requests.HTTPError as ex:
            print(f"❌ HTTP Error: {ex.response.status_code}")
            if ex.response.status_code == 429:  # Rate limited
                wait = 60 * (attempt + 1)
                print(f"   Rate limited, waiting {wait}s...")
                time.sleep(wait)
            elif ex.response.status_code == 400:
                print(f"   Bad request, check query syntax")
                print(f"   Response: {ex.response.text[:200]}")
                return []
            else:
                if attempt < retry - 1:
                    time.sleep(5)
                else:
                    return []
        except requests.Timeout:
            print(f"❌ Timeout on attempt {attempt+1}/{retry}")
            if attempt < retry - 1:
                time.sleep(10)
            else:
                return []
        except Exception as ex:
            print(f"❌ Error: {ex}")
            return []
    
    return []

def to_polygons(el):
    """Convert OSM element to polygon coordinates"""
    if "geometry" not in el: 
        return []
    coords = [[pt["lon"], pt["lat"]] for pt in el["geometry"]]
    if coords and coords[0] != coords[-1]: 
        coords.append(coords[0])
    return [coords] if coords else []

def main():
    parser = argparse.ArgumentParser(description='Download OSM data and build GeoJSON')
    parser.add_argument('bbox', help='Bounding box: south,west,north,east')
    parser.add_argument('--output', '-o', type=str, required=True,
                       help='Output GeoJSON file path')
    
    args = parser.parse_args()
    
    # Parse bounding box
    try:
        south, west, north, east = map(float, args.bbox.split(','))
    except:
        print("Error: Invalid bbox format. Use: south,west,north,east", file=sys.stderr)
        sys.exit(1)
    
    # Convert output path to Path object
    output_path = Path(args.output).resolve()
    
    # Ensure parent directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"📍 Bounding box: ({south},{west}) → ({north},{east})")
    print(f"📁 Output file: {output_path}")
    
    # Calculate area
    lat_span = north - south
    lon_span = east - west
    area_km2 = (lat_span * 111) * (lon_span * 111 * math.cos(math.radians((south+north)/2)))
    
    print(f"📍 Fetching area: ({south:.4f},{west:.4f}) → ({north:.4f},{east:.4f})")
    print(f"📏 Area: ~{area_km2:.0f} km²")
    
    tiles = list(tile_bbox(south, west, north, east))
    print(f"🔢 Tiles: {len(tiles)}")
    print()

    features = []
    seen_roads = set()
    seen_obstacles = set()
    
    for idx, (ts, tw, tn, te) in enumerate(tiles, 1):
        print(f"[{idx}/{len(tiles)}] ", end="")
        els = fetch_overpass_bbox(ts, tw, tn, te)
        
        for el in els:
            tags = el.get("tags") or {}
            osm_id = el.get("id")
            
            # Process roads
            if "highway" in tags:
                if "geometry" not in el:
                    continue
                coords = [[pt["lon"], pt["lat"]] for pt in el["geometry"]]
                if not coords:
                    continue
                
                # Deduplicate roads by OSM ID
                if osm_id in seen_roads:
                    continue
                seen_roads.add(osm_id)
                
                props = {
                    "is_road": True,
                    "highway": tags.get("highway", "unknown"),
                    "name": tags.get("name", ""),
                    "osm_id": osm_id
                }
                
                features.append({
                    "type": "Feature",
                    "properties": props,
                    "geometry": {"type": "LineString", "coordinates": coords}
                })
            
            # Process obstacles
            else:
                polys = to_polygons(el)
                if not polys:
                    continue
                
                for poly in polys:
                    # Deduplicate by centroid + size
                    key = (round(poly[0][0], 5), round(poly[0][1], 5), len(poly))
                    if key in seen_obstacles:
                        continue
                    seen_obstacles.add(key)
                    
                    props = {
                        "blocked": True,
                        "osm_type": tags.get("building") or tags.get("natural") or 
                                   tags.get("leisure") or tags.get("landuse") or "unknown",
                        "osm_id": osm_id
                    }
                    
                    features.append({
                        "type": "Feature",
                        "properties": props,
                        "geometry": {"type": "Polygon", "coordinates": [poly]}
                    })
        
        # Be nice to Overpass API
        if idx < len(tiles):
            time.sleep(1)
    
    # Save GeoJSON
    gj = {"type": "FeatureCollection", "features": features}
    
    with open(output_path, 'w', encoding="utf-8") as f:
        json.dump(gj, f, ensure_ascii=False, indent=1)
    
    # Stats
    roads = sum(1 for f in features if f['properties'].get('is_road'))
    obstacles = sum(1 for f in features if f['properties'].get('blocked'))
    file_size_mb = output_path.stat().st_size / (1024 * 1024)
    
    print()
    print(f"Wrote {output_path}")
    print(f"   File size: {file_size_mb:.1f} MB")
    print(f"   Roads: {roads:,}")
    print(f"   Obstacles: {obstacles:,}")
    print(f"   Total features: {len(features):,}")

if __name__ == "__main__":
    main()