# Тестирование NATS логирования

Этот документ описывает скрипты для тестирования NATS логирования на Windows хосте и в контейнерах.

## Быстрый старт

### Вариант 1: PowerShell скрипт (рекомендуется для Windows)

```powershell
# Базовое использование
.\scripts\test-nats-logs.ps1

# С фильтрами
.\scripts\test-nats-logs.ps1 -Service api -Level ERROR

# В контейнере
.\scripts\test-nats-logs.ps1 -InContainer
```

### Вариант 2: Python скрипт напрямую

```powershell
# На Windows хосте
python scripts\test_nats_logs_windows.py

# С параметрами
python scripts\test_nats_logs_windows.py --subject "log.api.>" --timeout 15 --max 50

# Фильтрация
python scripts\test_nats_logs_windows.py --service api --level ERROR
```

## Доступные скрипты

### 1. `test_nats_logs_windows.py` (универсальный)

**Описание:** Универсальный скрипт для проверки NATS логов. Автоматически определяет окружение (хост/контейнер) и использует правильные пути и URL.

**Особенности:**
- ✅ Автоматическое определение окружения
- ✅ Работает на Windows хосте и в контейнере
- ✅ Фильтрация по сервису и уровню логирования
- ✅ Цветной вывод (Windows 10+)
- ✅ JSON вывод для автоматизации
- ✅ Статистика по сервисам и уровням

**Параметры:**
```bash
--subject SUBJECT     # NATS subject pattern (default: "log.>")
--timeout TIMEOUT     # Таймаут в секундах (default: 10)
--max MAX_LOGS        # Максимум логов для получения (default: 20)
--service SERVICE     # Фильтр по имени сервиса (например, "api")
--level LEVEL         # Фильтр по уровню (DEBUG, INFO, WARNING, ERROR, CRITICAL)
--json                # Вывод в формате JSON
--nats-url URL        # URL NATS сервера (по умолчанию определяется автоматически)
```

**Примеры:**
```bash
# Базовое использование
python scripts/test_nats_logs_windows.py

# Только логи от API
python scripts/test_nats_logs_windows.py --service api

# Только ошибки
python scripts/test_nats_logs_windows.py --level ERROR

# JSON вывод для обработки
python scripts/test_nats_logs_windows.py --json | jq .

# Кастомный subject и таймаут
python scripts/test_nats_logs_windows.py --subject "log.motor-daemon.>" --timeout 30
```

### 2. `test-nats-logs.ps1` (PowerShell обертка)

**Описание:** Удобная PowerShell обертка для `test_nats_logs_windows.py` с упрощенным синтаксисом.

**Параметры:**
```powershell
-Subject SUBJECT      # NATS subject pattern (default: "log.>")
-Timeout TIMEOUT      # Таймаут в секундах (default: 10)
-MaxLogs MAX_LOGS    # Максимум логов (default: 20)
-InContainer          # Запустить в API контейнере
-Service SERVICE      # Фильтр по сервису
-Level LEVEL          # Фильтр по уровню (DEBUG, INFO, WARNING, ERROR, CRITICAL)
-Json                 # JSON вывод
-NatsUrl URL          # URL NATS сервера
```

**Примеры:**
```powershell
# Базовое использование
.\scripts\test-nats-logs.ps1

# Фильтрация
.\scripts\test-nats-logs.ps1 -Service api -Level ERROR

# В контейнере
.\scripts\test-nats-logs.ps1 -InContainer

# Длинный таймаут
.\scripts\test-nats-logs.ps1 -Timeout 30 -MaxLogs 100
```

### 3. `test_check_nats_logs.py` (legacy, для контейнера)

**Описание:** Простой скрипт для проверки логов внутри контейнера. Обновлен для автоматического определения окружения.

**Использование:**
```bash
# В контейнере
docker compose exec api python /app/test_check_nats_logs.py

# Или скопировать и запустить
docker compose cp robot/test_check_nats_logs.py api:/app/
docker compose exec api python /app/test_check_nats_logs.py
```

### 4. `test_nats_logging.py` (legacy, тест отправки)

**Описание:** Скрипт для тестирования отправки логов через NATS. Отправляет тестовые логи и проверяет их получение.

**Использование:**
```bash
# На хосте
python robot/test_nats_logging.py

# В контейнере
docker compose exec api python /app/test_nats_logging.py
```

## Требования

### Для Windows хоста:
- Python 3.7+
- Библиотека `nats-py`: `pip install nats-py`
- Docker Desktop (для запуска NATS)

### Для контейнера:
- Все зависимости уже установлены в образе

## Автоматическое определение окружения

Скрипты автоматически определяют, где они запущены:

- **В контейнере:** Используют `/nats_logger` и `nats://dev:devpass@nats:4222`
- **На хосте:** Используют `services/nats_logger/src` и `nats://dev:devpass@localhost:4222`

## Примеры использования

### Проверка логов от всех сервисов
```powershell
.\scripts\test-nats-logs.ps1
```

### Проверка только логов API
```powershell
.\scripts\test-nats-logs.ps1 -Service api
```

### Проверка только ошибок
```powershell
.\scripts\test-nats-logs.ps1 -Level ERROR
```

### Мониторинг в реальном времени (длинный таймаут)
```powershell
.\scripts\test-nats-logs.ps1 -Timeout 60 -MaxLogs 1000
```

### Проверка логов motor-daemon
```powershell
.\scripts\test-nats-logs.ps1 -Subject "log.motor-daemon.>"
```

### JSON вывод для обработки
```powershell
.\scripts\test-nats-logs.ps1 -Json | ConvertFrom-Json
```

## Устранение неполадок

### Ошибка подключения к NATS

**Проблема:** `❌ NATS server is not accessible`

**Решения:**
1. Проверьте, что NATS запущен: `docker compose ps nats`
2. Проверьте порт: `docker compose ps nats` должен показывать `0.0.0.0:4222->4222/tcp`
3. На хосте используйте `localhost:4222`, в контейнере - `nats:4222`

### Скрипт не находит nats_logger

**Проблема:** `ImportError: No module named 'nats_logger'`

**Решения:**
1. Установите зависимости: `pip install nats-py`
2. Проверьте путь: скрипт должен находиться в `robot/scripts/`
3. Для контейнера: убедитесь, что volume `./services/nats_logger/src:/nats_logger:ro` смонтирован

### Нет логов

**Проблема:** Скрипт работает, но не получает логи

**Решения:**
1. Проверьте, что сервисы запущены: `docker compose ps`
2. Проверьте, что сервисы отправляют логи: `docker compose logs api | grep NATS`
3. Увеличьте таймаут: `--timeout 30`
4. Проверьте subject pattern: используйте `log.>` для всех логов

## Интеграция с CI/CD

Для автоматического тестирования в CI/CD:

```yaml
# Пример для GitHub Actions
- name: Test NATS logging
  run: |
    python scripts/test_nats_logs_windows.py --timeout 5 --max 10 --json > logs.json
    jq 'length' logs.json  # Проверка количества логов
```

## См. также

- [nats-logging.md](../docs/nats-logging.md) - Документация по NATS логированию
- [nats-logging.md](../docs/nats-logging.md) - Полное руководство по логированию (включает диаграммы)

