import subprocess

def run_cmd(cmd: str):
    print(f"▶ Выполняю: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print("❌ Ошибка:", result.stderr.strip())
    return result.returncode == 0

def setup_wifi():
    # 1. Отключаем dhcpcd и wpa_supplicant
    run_cmd("sudo systemctl disable --now dhcpcd wpa_supplicant")

    # 2. Включаем NetworkManager
    run_cmd("sudo systemctl enable --now NetworkManager")

    # 3. Создаём подключение
    run_cmd("sudo nmcli con add type wifi ifname wlan0 mode ap con-name LARSrobot-AP ssid 'LARSrobot'")

    # 4. Настраиваем подключение
    run_cmd("""sudo nmcli con mod LARSrobot-AP \
        wifi.band bg wifi.channel 6 802-11-wireless.powersave 2 \
        wifi-sec.key-mgmt wpa-psk wifi-sec.psk 'LARSrobot1234' \
        connection.autoconnect yes connection.autoconnect-priority 100 \
        ipv4.method shared ipv4.addresses 10.42.0.33/24 \
        ipv6.method ignore""")

    # 5. Включаем автоподключение и бесконечные ретраи
    run_cmd("""sudo nmcli con mod 'LARSrobot-AP' \
        connection.autoconnect yes \
        connection.autoconnect-priority 100 \
        connection.autoconnect-retries -1""")

    # 6. Перезагружаем конфигурацию соединений
    run_cmd("sudo nmcli connection reload")

    # 7. Активируем соединение
    run_cmd("sudo nmcli con up LARSrobot-AP")

    # 8. Активируем ssh
    run_cmd("sudo systemctl enable --now ssh")
    run_cmd("sudo systemctl restart ssh")
    
if __name__ == "__main__":
    setup_wifi()