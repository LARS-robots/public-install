# Тестирование логов демона локализации через NATS

## Цель
Проверить, что логи из `localization-daemon` отправляются в NATS и отображаются на веб-странице `/admin/logs`.

## Архитектура логирования

```
localization-daemon
  │
  ├─→ setup_unified_logging()
  │   └─→ NATSHandler
  │       └─→ NATS (log.localization-daemon.{level})
  │           │
  │           ├─→ nats_log_bridge (в API сервисе)
  │           │   └─→ logbus → WebSocket → /admin/logs
  │           │
  │           └─→ Logger Daemon (опционально, для сохранения в файлы)
```

## Шаг 1: Проверка запущенных сервисов

### 1.1. Проверить статус всех сервисов

**Windows PowerShell:**
```powershell
# Перейти в директорию проекта
cd C:\Users\datsa\Sync\Metu\slava_proj\LARS\robot

# Проверить статус сервисов
docker compose ps
```

**Git Bash:**
```bash
# Перейти в директорию проекта
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot

# Проверить статус сервисов
docker compose ps
```

**Ожидаемый результат:**
- `nats` - должен быть `Up` и `healthy`
- `api` - должен быть `Up`
- `localization-daemon` - должен быть `Up`

### 1.2. Проверить логи NATS сервера

**Windows PowerShell:**
```powershell
docker compose logs nats --tail 20
```

**Git Bash:**
```bash
docker compose logs nats --tail 20
```

**Ожидаемый результат:** NATS сервер должен быть запущен без ошибок.

---

## Шаг 2: Запуск необходимых сервисов (если не запущены)

### 2.1. Запустить NATS и API

**Windows PowerShell:**
```powershell
# Запустить NATS и API
docker compose up -d nats api

# Подождать пока сервисы запустятся
Start-Sleep -Seconds 5

# Проверить статус
docker compose ps nats api
```

**Git Bash:**
```bash
# Запустить NATS и API
docker compose up -d nats api

# Подождать пока сервисы запустятся
sleep 5

# Проверить статус
docker compose ps nats api
```

### 2.2. Запустить localization-daemon

**Windows PowerShell:**
```powershell
# Запустить localization-daemon с профилем windows
docker compose --profile windows up -d localization-daemon

# Проверить статус
docker compose ps localization-daemon
```

**Git Bash:**
```bash
# Запустить localization-daemon с профилем windows
docker compose --profile windows up -d localization-daemon

# Проверить статус
docker compose ps localization-daemon
```

### 2.3. Проверить логи запуска localization-daemon

**Windows PowerShell:**
```powershell
# Посмотреть последние логи
docker compose logs localization-daemon --tail 50

# Следить за логами в реальном времени
docker compose logs -f localization-daemon
```

**Git Bash:**
```bash
# Посмотреть последние логи
docker compose logs localization-daemon --tail 50

# Следить за логами в реальном времени
docker compose logs -f localization-daemon
```

**Ожидаемый результат:**
- Должны быть логи о подключении к NATS: `[LOC_DAEMON] Connected to NATS`
- Должны быть логи о настройке логирования: `setup_unified_logging` (если nats_logger доступен)
- Не должно быть ошибок подключения к NATS

---

## Шаг 3: Проверка логов в NATS через CLI

### 3.1. Использовать тестовый скрипт (рекомендуется)

**Windows PowerShell:**
```powershell
# Проверить логи всех сервисов
python scripts/test_nats_logs_windows.py --timeout 10 --max 30

# Проверить только логи localization-daemon
python scripts/test_nats_logs_windows.py --service localization-daemon --timeout 10 --max 20

# Проверить только ERROR логи
python scripts/test_nats_logs_windows.py --level ERROR --timeout 10 --max 10
```

**Git Bash:**
```bash
# Проверить логи всех сервисов
python scripts/test_nats_logs_windows.py --timeout 10 --max 30

# Проверить только логи localization-daemon
python scripts/test_nats_logs_windows.py --service localization-daemon --timeout 10 --max 20

# Проверить только ERROR логи
python scripts/test_nats_logs_windows.py --level ERROR --timeout 10 --max 10
```

**Ожидаемый результат:**
- Должны появиться логи от `localization-daemon` с различными уровнями (INFO, WARNING, ERROR)
- Примеры логов:
  - `[LOC_DAEMON] Connected to NATS`
  - `[LOC_DAEMON] Config: publish_rate=50.0Hz, diag_rate=1.0Hz`
  - `[LOC_DAEMON] All components initialized`
  - `[LOC_DAEMON] Started`
  - Периодические статистики: `[LOC_DAEMON] Stats: loop=...`

### 3.2. Использовать NATS CLI (если установлен)

**Windows PowerShell:**
```powershell
# Подписаться на все логи
nats sub "log.>" --server "nats://dev:devpass@localhost:4222"

# Подписаться только на логи localization-daemon
nats sub "log.localization-daemon.>" --server "nats://dev:devpass@localhost:4222"
```

**Git Bash:**
```bash
# Подписаться на все логи
nats sub "log.>" --server "nats://dev:devpass@localhost:4222"

# Подписаться только на логи localization-daemon
nats sub "log.localization-daemon.>" --server "nats://dev:devpass@localhost:4222"
```

**Ожидаемый результат:** Должны появляться JSON сообщения с логами от localization-daemon.

### 3.3. Проверка через Docker exec (в контейнере API)

**Windows PowerShell:**
```powershell
# Запустить тестовый скрипт внутри контейнера API
docker compose exec api python /app/scripts/test_nats_logs_windows.py --service localization-daemon --timeout 10 --max 20
```

**Git Bash:**
```bash
# Запустить тестовый скрипт внутри контейнера API
docker compose exec api python /app/scripts/test_nats_logs_windows.py --service localization-daemon --timeout 10 --max 20
```

**Примечание:** В контейнере используется URL `nats://dev:devpass@nats:4222` (имя сервиса вместо localhost).

---

## Шаг 4: Проверка веб-интерфейса

### 4.1. Открыть веб-страницу логов

**Браузер:**
```
http://localhost:8000/admin/logs
```

**Ожидаемый результат:**
- Страница должна загрузиться
- Должны отображаться логи в реальном времени
- Должны быть видны логи от `localization-daemon`

### 4.2. Фильтрация логов по сервису

**На веб-странице:**
1. В поле поиска (regex) введите: `"service":"localization-daemon"`
2. Нажмите Enter или кнопку "Reload tail"
3. Должны отображаться только логи от localization-daemon

### 4.3. Проверка уровней логирования

**На веб-странице:**
1. Включите/выключите кнопки уровней: `I` (INFO), `W` (WARNING), `E` (ERROR), `D` (DEBUG)
2. Должны отображаться логи соответствующих уровней

### 4.4. Проверка live обновления

**На веб-странице:**
1. Убедитесь что кнопка "Pause" не нажата (логи должны обновляться автоматически)
2. В логах localization-daemon должны появляться новые записи в реальном времени
3. Примеры логов, которые должны появляться:
   - `[LOC_DAEMON] Connected to NATS`
   - `[LOC_DAEMON] Config: publish_rate=50.0Hz, diag_rate=1.0Hz`
   - `[LOC_DAEMON] All components initialized`
   - `[LOC_DAEMON] Started`
   - Периодические статистики каждые 60 секунд

---

## Шаг 5: Диагностика проблем

### 5.1. Если логи не появляются в NATS

**Проверить подключение localization-daemon к NATS:**

**Windows PowerShell:**
```powershell
# Посмотреть логи запуска
docker compose logs localization-daemon | Select-String -Pattern "NATS|nats_logger|setup_unified"

# Проверить переменные окружения
docker compose exec localization-daemon env | Select-String -Pattern "NATS"
```

**Git Bash:**
```bash
# Посмотреть логи запуска
docker compose logs localization-daemon | grep -i "NATS\|nats_logger\|setup_unified"

# Проверить переменные окружения
docker compose exec localization-daemon env | grep NATS
```

**Возможные проблемы:**
- `nats_logger` не доступен (должен быть смонтирован в `/nats_logger`)
- Неправильный `NATS_URL` (должен быть `nats://dev:devpass@nats:4222` в контейнере)
- NATS сервер недоступен

### 5.2. Если логи не появляются на веб-странице

**Проверить nats_log_bridge в API:**

**Windows PowerShell:**
```powershell
# Посмотреть логи API
docker compose logs api --tail 100 | Select-String -Pattern "nats_log_bridge|NATS log bridge"

# Проверить что bridge запущен
docker compose logs api | Select-String -Pattern "NATS log bridge started"
```

**Git Bash:**
```bash
# Посмотреть логи API
docker compose logs api --tail 100 | grep -i "nats_log_bridge\|NATS log bridge"

# Проверить что bridge запущен
docker compose logs api | grep -i "NATS log bridge started"
```

**Ожидаемый результат:**
- Должны быть логи: `✅ NATS log bridge started successfully and is running`
- Должны быть логи: `✅ Subscribed to log.> for log bridge`

**Проверить WebSocket соединение:**
1. Откройте Developer Tools в браузере (F12)
2. Перейдите на вкладку Network
3. Найдите WebSocket соединение к `/admin/logs/ws`
4. Проверьте что соединение установлено (Status 101 Switching Protocols)

### 5.3. Проверка доступности NATS из контейнеров

**Windows PowerShell:**
```powershell
# Проверить подключение из контейнера localization-daemon
docker compose exec localization-daemon python -c "import nats; import asyncio; asyncio.run(nats.connect('nats://dev:devpass@nats:4222').__aenter__())"

# Проверить подключение из контейнера API
docker compose exec api python -c "import nats; import asyncio; asyncio.run(nats.connect('nats://dev:devpass@nats:4222').__aenter__())"
```

**Git Bash:**
```bash
# Проверить подключение из контейнера localization-daemon
docker compose exec localization-daemon python -c "import nats; import asyncio; asyncio.run(nats.connect('nats://dev:devpass@nats:4222').__aenter__())"

# Проверить подключение из контейнера API
docker compose exec api python -c "import nats; import asyncio; asyncio.run(nats.connect('nats://dev:devpass@nats:4222').__aenter__())"
```

---

## Шаг 6: Генерация тестовых логов

### 6.1. Принудительная генерация логов в localization-daemon

**Windows PowerShell:**
```powershell
# Перезапустить localization-daemon для генерации логов запуска
docker compose restart localization-daemon

# Следить за логами
docker compose logs -f localization-daemon
```

**Git Bash:**
```bash
# Перезапустить localization-daemon для генерации логов запуска
docker compose restart localization-daemon

# Следить за логами
docker compose logs -f localization-daemon
```

**Ожидаемый результат:**
- Должны появиться логи о переподключении к NATS
- Должны появиться логи инициализации компонентов
- Эти логи должны появиться в NATS и на веб-странице

### 6.2. Проверка периодических логов

**Логика:**
- localization-daemon каждые 60 секунд логирует статистику
- Эти логи должны появляться автоматически

**Проверка:**
1. Подождите 60 секунд после запуска
2. Проверьте веб-страницу - должны появиться логи со статистикой
3. Пример: `[LOC_DAEMON] Stats: loop=3000, kv_read=3000, state_pub=3000, diag_pub=60`

---

## Итоговая проверка

### Чеклист успешного тестирования:

- [ ] NATS сервер запущен и доступен
- [ ] API сервис запущен и nats_log_bridge работает
- [ ] localization-daemon запущен и подключен к NATS
- [ ] Логи от localization-daemon видны в NATS (через тестовый скрипт)
- [ ] Логи от localization-daemon видны на веб-странице `/admin/logs`
- [ ] Логи обновляются в реальном времени на веб-странице
- [ ] Фильтрация по сервису работает корректно

---

## Дополнительные команды для отладки

### Просмотр всех логов в реальном времени

**Windows PowerShell:**
```powershell
# Все сервисы
docker compose logs -f

# Только NATS, API и localization-daemon
docker compose logs -f nats api localization-daemon
```

**Git Bash:**
```bash
# Все сервисы
docker compose logs -f

# Только NATS, API и localization-daemon
docker compose logs -f nats api localization-daemon
```

### Проверка портов

**Windows PowerShell:**
```powershell
# Проверить что порты открыты
netstat -an | Select-String -Pattern "4222|8000|8222"
```

**Git Bash:**
```bash
# Проверить что порты открыты (если доступен netstat)
netstat -an | grep -E "4222|8000|8222"
```

### Очистка и перезапуск

**Windows PowerShell:**
```powershell
# Остановить все сервисы
docker compose down

# Запустить заново
docker compose --profile windows up -d nats api localization-daemon
```

**Git Bash:**
```bash
# Остановить все сервисы
docker compose down

# Запустить заново
docker compose --profile windows up -d nats api localization-daemon
```

---

## Примечания

1. **NATS URL в разных окружениях:**
   - На хосте Windows: `nats://dev:devpass@localhost:4222`
   - В Docker контейнере: `nats://dev:devpass@nats:4222`

2. **Профили Docker Compose:**
   - `localization-daemon` использует профиль `windows` для запуска на Windows хосте
   - Используйте `--profile windows` при запуске через docker compose

3. **Логирование:**
   - Все логи (INFO, WARNING, ERROR) отправляются в NATS
   - Только ERROR и CRITICAL логи выводятся в stdout контейнера
   - Веб-интерфейс показывает все логи через WebSocket

4. **Задержка появления логов:**
   - NATSHandler отправляет логи батчами (10 событий или 1 секунда)
   - Логи появляются на веб-странице через ~0.1-0.2 секунды после логирования
