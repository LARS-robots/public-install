#!/usr/bin/env python3
"""
Универсальный скрипт для проверки NATS логов на Windows хосте.
Автоматически определяет окружение и использует правильные пути/URL.

Использование:
    # На Windows хосте
    python scripts/test_nats_logs_windows.py
    
    # С параметрами
    python scripts/test_nats_logs_windows.py --subject "log.api.>" --timeout 15 --max 50
    
    # В контейнере (автоматически определит окружение)
    docker compose exec api python /app/test_nats_logs_windows.py
"""
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Optional, Dict, Any, List

# Определение окружения
def detect_environment() -> str:
    """Определяет, запущен ли скрипт в контейнере или на хосте."""
    if os.path.exists("/.dockerenv"):
        return "container"
    return "host"

ENV = detect_environment()

# Настройка путей в зависимости от окружения
if ENV == "container":
    # В контейнере
    sys.path.insert(0, "/nats_logger")
    NATS_URL_DEFAULT = os.getenv("NATS_URL", "nats://dev:devpass@nats:4222")
else:
    # На хосте Windows
    project_root = Path(__file__).parent.parent
    nats_logger_path = project_root / "services" / "nats_logger" / "src"
    if nats_logger_path.exists():
        sys.path.insert(0, str(nats_logger_path))
    NATS_URL_DEFAULT = os.getenv("NATS_URL", "nats://dev:devpass@localhost:4222")

try:
    import nats
    from nats.aio.client import Client as NATSClient
    NATS_AVAILABLE = True
except ImportError as e:
    print(f"❌ NATS library not available: {e}")
    print(f"💡 Install with: pip install nats-py")
    sys.exit(1)


class Colors:
    """ANSI цвета для терминала (работает в Windows 10+ с поддержкой ANSI)."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"


def colorize(text: str, color: str) -> str:
    """Добавляет цвет к тексту, если терминал поддерживает ANSI."""
    if os.getenv("NO_COLOR") or (sys.platform == "win32" and not os.getenv("TERM")):
        return text
    return f"{color}{text}{Colors.RESET}"


async def check_nats_connection(nats_url: str, timeout: int = 5) -> bool:
    """Проверяет доступность NATS сервера."""
    try:
        nc = NATSClient()
        await asyncio.wait_for(nc.connect(nats_url, connect_timeout=timeout), timeout=timeout)
        await nc.close()
        return True
    except Exception:
        return False


async def check_nats_logs(
    subject: str = "log.>",
    timeout: int = 10,
    max_logs: int = 20,
    nats_url: Optional[str] = None,
    filter_service: Optional[str] = None,
    filter_level: Optional[str] = None,
    json_output: bool = False,
) -> List[Dict[str, Any]]:
    """
    Проверка логов в NATS.
    
    Args:
        subject: NATS subject pattern для подписки
        timeout: Таймаут ожидания логов в секундах
        max_logs: Максимальное количество логов для получения
        nats_url: URL NATS сервера (по умолчанию определяется автоматически)
        filter_service: Фильтр по имени сервиса (опционально)
        filter_level: Фильтр по уровню логирования (опционально)
        json_output: Выводить логи в формате JSON
    
    Returns:
        Список полученных событий
    """
    if nats_url is None:
        nats_url = NATS_URL_DEFAULT
    
    print(colorize(f"🔍 Environment: {ENV}", Colors.CYAN))
    print(colorize(f"📡 Connecting to {nats_url}...", Colors.CYAN))
    
    # Проверка доступности NATS
    if not await check_nats_connection(nats_url, timeout=3):
        print(colorize(f"❌ NATS server is not accessible at {nats_url}", Colors.RED))
        print(colorize("💡 Tips:", Colors.YELLOW))
        print("  1. Make sure NATS is running: docker compose ps nats")
        print("  2. Check NATS URL (use 'localhost' on host, 'nats' in container)")
        print("  3. Verify NATS port is exposed: docker compose ps nats")
        return []
    
    nc = NATSClient()
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print(colorize("✅ Connected to NATS", Colors.GREEN))
    except Exception as e:
        print(colorize(f"❌ Failed to connect: {e}", Colors.RED))
        return []
    
    received: List[Dict[str, Any]] = []
    
    async def handler(msg):
        """Обработчик сообщений из NATS."""
        try:
            data = msg.data.decode("utf-8")
            event = json.loads(data)
            
            # Обработка батчей (списки событий)
            events_to_process = []
            if isinstance(event, list):
                events_to_process = event
            else:
                events_to_process = [event]
            
            for e in events_to_process:
                # Применение фильтров
                if filter_service and e.get("service") != filter_service:
                    continue
                if filter_level and e.get("level", "").upper() != filter_level.upper():
                    continue
                
                received.append(e)
                
                if json_output:
                    print(json.dumps(e, ensure_ascii=False))
                else:
                    service = e.get("service", "unknown")
                    level = e.get("level", "?")
                    msg_text = e.get("msg", "")[:80]
                    timestamp = e.get("ts", "")
                    
                    # Цвет для уровня логирования
                    level_color = Colors.RESET
                    if level == "ERROR" or level == "CRITICAL":
                        level_color = Colors.RED
                    elif level == "WARNING":
                        level_color = Colors.YELLOW
                    elif level == "INFO":
                        level_color = Colors.GREEN
                    elif level == "DEBUG":
                        level_color = Colors.BLUE
                    
                    print(
                        f"{colorize('📨', Colors.MAGENTA)} "
                        f"{colorize(service, Colors.CYAN)} "
                        f"[{colorize(level, level_color)}] "
                        f"{msg_text}"
                        f"{' ' + timestamp if timestamp else ''}"
                    )
                
                if len(received) >= max_logs:
                    await nc.close()
        except Exception as e:
            print(colorize(f"⚠️  Error parsing message: {e}", Colors.YELLOW))
    
    sub = await nc.subscribe(subject, cb=handler)
    print(colorize(f"✅ Subscribed to {subject}", Colors.GREEN))
    
    if filter_service:
        print(colorize(f"🔍 Filter: service={filter_service}", Colors.CYAN))
    if filter_level:
        print(colorize(f"🔍 Filter: level={filter_level}", Colors.CYAN))
    
    print(colorize(f"⏳ Waiting for logs (timeout: {timeout}s, max: {max_logs})...", Colors.CYAN))
    print()
    
    try:
        await asyncio.wait_for(asyncio.sleep(timeout), timeout=timeout)
    except asyncio.TimeoutError:
        pass
    
    await sub.unsubscribe()
    await nc.close()
    
    # Вывод итогов
    if not json_output:
        print()
        print(colorize("📊 Summary:", Colors.BOLD))
        print(f"  - Environment: {ENV}")
        print(f"  - Subject: {subject}")
        print(f"  - Logs received: {colorize(str(len(received)), Colors.GREEN if received else Colors.YELLOW)}")
        
        if received:
            # Статистика по сервисам
            services = {}
            levels = {}
            for e in received:
                service = e.get("service", "unknown")
                level = e.get("level", "unknown")
                services[service] = services.get(service, 0) + 1
                levels[level] = levels.get(level, 0) + 1
            
            print(f"\n  📋 By service:")
            for service, count in sorted(services.items()):
                print(f"    • {colorize(service, Colors.CYAN)}: {count}")
            
            print(f"\n  📋 By level:")
            for level, count in sorted(levels.items()):
                level_color = Colors.RED if level in ["ERROR", "CRITICAL"] else Colors.YELLOW if level == "WARNING" else Colors.GREEN
                print(f"    • {colorize(level, level_color)}: {count}")
            
            print(f"\n  📋 Sample logs (first 5):")
            for e in received[:5]:
                if isinstance(e, dict):
                    service = e.get("service", "unknown")
                    level = e.get("level", "?")
                    msg = e.get("msg", "")[:60]
                    print(f"    • {colorize(service, Colors.CYAN)} [{level}]: {msg}")
        else:
            print(colorize("\n⚠️  No logs received. Check:", Colors.YELLOW))
            print("  1. NATS server is running: docker compose ps nats")
            print("  2. Services are sending logs to NATS")
            print("  3. Subject pattern matches: " + subject)
            print("  4. Services are running: docker compose ps")
    
    return received


def main():
    """Главная функция с парсингом аргументов."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Check NATS logs (works on Windows host and in containers)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python scripts/test_nats_logs_windows.py
  
  # Filter by service
  python scripts/test_nats_logs_windows.py --service api
  
  # Filter by level
  python scripts/test_nats_logs_windows.py --level ERROR
  
  # JSON output
  python scripts/test_nats_logs_windows.py --json
  
  # Custom subject and timeout
  python scripts/test_nats_logs_windows.py --subject "log.api.>" --timeout 15
        """
    )
    parser.add_argument(
        "--subject",
        default="log.>",
        help="NATS subject pattern (default: log.>)"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Timeout in seconds (default: 10)"
    )
    parser.add_argument(
        "--max",
        type=int,
        default=20,
        help="Max logs to receive (default: 20)"
    )
    parser.add_argument(
        "--nats-url",
        help="NATS server URL (default: auto-detect based on environment)"
    )
    parser.add_argument(
        "--service",
        help="Filter by service name (e.g., api, motor-daemon)"
    )
    parser.add_argument(
        "--level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Filter by log level"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output logs in JSON format"
    )
    
    args = parser.parse_args()
    
    asyncio.run(check_nats_logs(
        subject=args.subject,
        timeout=args.timeout,
        max_logs=args.max,
        nats_url=args.nats_url,
        filter_service=args.service,
        filter_level=args.level,
        json_output=args.json,
    ))


if __name__ == "__main__":
    main()

