#!/usr/bin/env python3
"""
Camera Daemon — reads aspect ratio from config.toml and builds a stable
GStreamer pipeline that always sets valid width/height.
"""
import asyncio
import json
import logging
import os
import struct
from dataclasses import dataclass
from functools import partial
from fractions import Fraction
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

import gi
try:
    import tomllib
except ImportError:
    import tomli as tomllib


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s")


def _even(x: int) -> int:
    return max(2, x - (x % 2))


def _parse_ratio(value: Optional[str]) -> Optional[Tuple[int, int]]:
    if not value:
        return None
    try:
        w, h = map(int, value.replace("x", ":").split(":"))
        if w > 0 and h > 0:
            return w, h
    except Exception:
        pass
    return None


def _load_aspect_config() -> dict:
    paths = [
        Path("/app/config.toml"),
        Path("config.toml"),
        Path(__file__).parent.parent / "services/api/src/config/config.toml",
    ]
    for p in paths:
        if p.exists():
            with open(p, "rb") as f:
                data = tomllib.load(f)
                return data.get("aspect", {})
    return {}


@dataclass(frozen=True)
class DaemonConfig:
    control_host: str = "0.0.0.0"
    control_port: int = 8765
    frame_base_port: int = 8800
    fmt_i420: int = 1
    frame_header_fmt: str = ">IHHQB"
    max_cameras: int = 2
    aspect_enabled: bool = False
    aspect_ratio: Optional[Tuple[int, int]] = None
    aspect_mode: str = "letterbox"

    @staticmethod
    def from_toml() -> "DaemonConfig":
        aspect = _load_aspect_config()
        ratio = None
        if aspect:
            s = aspect.get("mono") or aspect.get("stereo_left") or aspect.get("quad")
            ratio = _parse_ratio(s)
        return DaemonConfig(
            aspect_enabled=bool(aspect.get("enabled", False)),
            aspect_ratio=ratio,
            aspect_mode=aspect.get("mode", "letterbox"),
        )

    @property
    def frame_header_size(self) -> int:
        return struct.calcsize(self.frame_header_fmt)


def create_gst():
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
    Gst.init(None)
    return Gst


def pick_source(gst, cam_id: int) -> str:
    if gst.ElementFactory.find("libcamerasrc"):
        return f"libcamerasrc camera-index={cam_id}"
    if gst.ElementFactory.find("v4l2src"):
        return f"v4l2src device=/dev/video{cam_id}"
    return f"ksvideosrc device-index={cam_id}"


class CameraPipeline:
    def __init__(self, cfg: DaemonConfig, gst, cam_id: int, width: int, height: int, fps: int):
        self.cfg = cfg
        self.gst = gst
        self.cam_id = cam_id
        self.width = width
        self.height = height
        self.fps = fps
        self.clients: Set[asyncio.StreamWriter] = set()
        self.logger = logging.getLogger(f"cam{cam_id}")
        self.pipeline = None

    def build_desc(self) -> str:
        src = pick_source(self.gst, self.cam_id)
        base_caps = f"video/x-raw,width={self.width},height={self.height},framerate={self.fps}/1"
        elements = [src, base_caps]

        # apply aspect if configured
        if self.cfg.aspect_enabled and self.cfg.aspect_ratio:
            aw, ah = self.cfg.aspect_ratio
            self.logger.info("Aspect active %dx%d (%s)", aw, ah, self.cfg.aspect_mode)
            ratio = Fraction(aw, ah)
            elements.append("videoconvert")
            if self.gst.ElementFactory.find("aspectratiocrop") and self.cfg.aspect_mode.startswith("crop"):
                elements.append(f"aspectratiocrop aspect-ratio={ratio.numerator}/{ratio.denominator}")
                elements.append("videoscale")
            else:
                elements.append("videoscale add-borders=true")
            elements.append(
                f"video/x-raw,format=I420,width={_even(self.width)},height={_even(self.height)},pixel-aspect-ratio=1/1"
            )
        else:
            if "libcamerasrc" not in src:
                elements.append("videoconvert")
            elements.append(
                f"video/x-raw,format=I420,width={_even(self.width)},height={_even(self.height)}"
            )

        elements.append("queue leaky=2 max-size-buffers=2")
        elements.append("appsink name=sink max-buffers=2 drop=true emit-signals=true")
        desc = " ! ".join(elements)
        self.logger.info("Pipeline: %s", desc)
        return desc

    def start(self):
        desc = self.build_desc()
        self.pipeline = self.gst.parse_launch(desc)
        sink = self.pipeline.get_by_name("sink")
        sink.connect("new-sample", self.on_sample)
        ret = self.pipeline.set_state(self.gst.State.PLAYING)
        if ret == self.gst.StateChangeReturn.FAILURE:
            raise RuntimeError(f"Pipeline start failed (cam {self.cam_id})")
        self.logger.info("Pipeline started")

    def stop(self):
        if self.pipeline:
            self.pipeline.set_state(self.gst.State.NULL)
            self.pipeline = None
        for w in list(self.clients):
            w.close()
        self.clients.clear()

    def on_sample(self, sink):
        sample = sink.emit("pull-sample")
        if not sample:
            return self.gst.FlowReturn.ERROR
        caps = sample.get_caps()
        if caps:
            s = caps.get_structure(0)
            ok_w, w = s.get_int("width")
            ok_h, h = s.get_int("height")
            if ok_w and ok_h:
                self.width, self.height = w, h
        buf = sample.get_buffer()
        success, mapinfo = buf.map(self.gst.MapFlags.READ)
        if not success:
            return self.gst.FlowReturn.ERROR
        try:
            payload = bytes(mapinfo.data)
            pts_us = int(buf.pts / 1000) if buf.pts != self.gst.CLOCK_TIME_NONE else 0
            header = struct.pack(self.cfg.frame_header_fmt, len(payload), self.width, self.height, pts_us, self.cfg.fmt_i420)
            frame = header + payload
            for w in list(self.clients):
                try:
                    w.write(frame)
                except Exception:
                    self.clients.discard(w)
        finally:
            buf.unmap(mapinfo)
        return self.gst.FlowReturn.OK


class CameraService:
    def __init__(self, cfg: DaemonConfig, gst):
        self.cfg = cfg
        self.gst = gst
        self.pipelines: Dict[int, CameraPipeline] = {}

    def start(self, cam_id: int, w: int, h: int, fps: int):
        pipe = CameraPipeline(self.cfg, self.gst, cam_id, w, h, fps)
        pipe.start()
        self.pipelines[cam_id] = pipe
        return {"status": "started", "id": cam_id}

    def stop(self, cam_id: int):
        p = self.pipelines.pop(cam_id, None)
        if p:
            p.stop()
            return {"status": "stopped", "id": cam_id}
        return {"status": "not_found", "id": cam_id}


async def handle_control(reader, writer, service: CameraService):
    try:
        line = await reader.readline()
        if not line:
            return
        req = json.loads(line.decode())
        cmd = req.get("cmd")
        if cmd == "start":
            resp = service.start(int(req.get("id", 0)), int(req.get("w", 640)), int(req.get("h", 480)), int(req.get("fps", 30)))
        elif cmd == "stop":
            resp = service.stop(int(req.get("id", 0)))
        else:
            resp = {"error": "unknown_cmd"}
        writer.write((json.dumps(resp) + "\n").encode())
        await writer.drain()
    finally:
        writer.close()
        await writer.wait_closed()


async def main():
    configure_logging()
    cfg = DaemonConfig.from_toml()
    gst = create_gst()
    service = CameraService(cfg, gst)
    server = await asyncio.start_server(partial(handle_control, service=service), cfg.control_host, cfg.control_port)
    logging.info("Control server listening on %s:%d", cfg.control_host, cfg.control_port)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Camera daemon stopped")
