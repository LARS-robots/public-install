#!/usr/bin/env python3
"""
Camera Daemon — GStreamer-based camera capture process.
Runs as a separate container, exposes control + frame sockets.
"""
import asyncio
import json
import logging
import os
import struct
from dataclasses import dataclass
from functools import partial
from typing import Dict, Set

import gi


@dataclass(frozen=True)
class DaemonConfig:
    control_host: str
    control_port: int
    frame_base_port: int
    max_cameras: int
    fmt_i420: int
    frame_header_fmt: str

    @property
    def frame_header_size(self) -> int:
        return struct.calcsize(self.frame_header_fmt)


def load_required_env(name: str) -> str:
    value = os.getenv(name)
    if value is None:
        raise RuntimeError(f"{name} environment variable is required")
    return value


def load_config() -> DaemonConfig:
    return DaemonConfig(
        control_host=load_required_env("CONTROL_HOST"),
        control_port=int(load_required_env("CONTROL_PORT")),
        frame_base_port=int(load_required_env("FRAME_BASE_PORT")),
        max_cameras=int(load_required_env("MAX_CAMERAS")),
        fmt_i420=int(load_required_env("FMT_I420")),
        frame_header_fmt=load_required_env("FRAME_HEADER_FMT"),
    )


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def create_gstreamer_module():
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst as gst_module  # type: ignore[attr-defined]

    gst_module.init(None)
    return gst_module


def pick_gstreamer_source(gst_module, cam_index: int) -> str:
    logger = logging.getLogger(__name__)

    def has_element(name: str) -> bool:
        return gst_module.ElementFactory.find(name) is not None

    if has_element("libcamerasrc"):
        logger.info("Using libcamerasrc for camera %d", cam_index)
        return f"libcamerasrc camera-index={cam_index}"
    if has_element("v4l2src"):
        logger.info("Using v4l2src for camera %d", cam_index)
        return f"v4l2src device=/dev/video{cam_index}"
    logger.info("Using ksvideosrc for camera %d", cam_index)
    return f"ksvideosrc device-index={cam_index}"


class CameraPipeline:
    def __init__(self, config: DaemonConfig, gst_module, cam_id: int, width: int, height: int, fps: int):
        self._config = config
        self._gst = gst_module
        self._cam_id = cam_id
        self._width = width
        self._height = height
        self._fps = fps
        self._pipeline = None
        self._clients: Set[asyncio.StreamWriter] = set()
        self._logger = logging.getLogger(__name__)

    def start(self) -> None:
        src = pick_gstreamer_source(self._gst, self._cam_id)
        pipeline_desc = (
            f"{src} ! video/x-raw,width={self._width},height={self._height},framerate={self._fps}/1 "
            "! videoconvert ! video/x-raw,format=I420 "
            "! appsink name=sink max-buffers=2 drop=true emit-signals=true"
        )
        self._logger.info("Starting pipeline for cam %d: %s", self._cam_id, pipeline_desc)

        self._pipeline = self._gst.parse_launch(pipeline_desc)
        sink = self._pipeline.get_by_name("sink")
        sink.connect("new-sample", self._on_sample)

        state_ret = self._pipeline.set_state(self._gst.State.PLAYING)
        if state_ret == self._gst.StateChangeReturn.FAILURE:
            self._logger.error("Failed to start pipeline for cam %d", self._cam_id)
            raise RuntimeError(f"Failed to start camera {self._cam_id}")

        self._logger.info("Pipeline started for cam %d", self._cam_id)

    def stop(self) -> None:
        if self._pipeline is not None:
            self._logger.info("Stopping pipeline for cam %d", self._cam_id)
            self._pipeline.set_state(self._gst.State.NULL)
            self._pipeline = None
        for writer in tuple(self._clients):
            writer.close()
        self._clients.clear()

    def register_client(self, writer: asyncio.StreamWriter) -> None:
        self._clients.add(writer)
        self._logger.debug("Client registered for cam %d (clients=%d)", self._cam_id, len(self._clients))

    def remove_client(self, writer: asyncio.StreamWriter) -> None:
        self._clients.discard(writer)
        self._logger.debug("Client removed for cam %d (clients=%d)", self._cam_id, len(self._clients))

    def _on_sample(self, sink) -> object:
        sample = sink.emit("pull-sample")
        if not sample:
            return self._gst.FlowReturn.ERROR

        # log incoming sample caps to diagnose missing width/height
        caps = sample.get_caps()
        try:
            caps_str = caps.to_string() if caps is not None else "<no-caps>"
        except Exception:
            caps_str = "<caps-to_string-failed>"
        self._logger.debug("Sample caps for cam %d: %s", self._cam_id, caps_str)

        buffer = sample.get_buffer()
        success, mapinfo = buffer.map(self._gst.MapFlags.READ)
        if not success:
            return self._gst.FlowReturn.ERROR

        try:
            pts_us = int(buffer.pts / 1000) if buffer.pts != self._gst.CLOCK_TIME_NONE else 0
            payload = bytes(mapinfo.data)
            self._send_frame(payload, pts_us)
        finally:
            buffer.unmap(mapinfo)

        return self._gst.FlowReturn.OK

    def _send_frame(self, payload: bytes, pts_us: int) -> None:
        header = struct.pack(
            self._config.frame_header_fmt,
            len(payload),
            self._width,
            self._height,
            pts_us,
            self._config.fmt_i420,
        )
        frame = header + payload

        dead_clients = []
        for writer in tuple(self._clients):
            try:
                writer.write(frame)
            except Exception as exc:  # noqa: BLE001
                self._logger.debug("Client write error for cam %d: %s", self._cam_id, exc)
                dead_clients.append(writer)

        for writer in dead_clients:
            self.remove_client(writer)
            writer.close()


class CameraDaemonService:
    def __init__(self, config: DaemonConfig, gst_module):
        self._config = config
        self._gst = gst_module
        self._pipelines: Dict[int, CameraPipeline] = {}
        self._logger = logging.getLogger(__name__)

    def start_camera(self, cam_id: int, width: int, height: int, fps: int) -> dict:
        if cam_id < 0 or cam_id >= self._config.max_cameras:
            self._logger.warning("Camera %d is out of allowed range (0..%d)", cam_id, self._config.max_cameras - 1)
            return {"status": "out_of_range", "camera_id": cam_id}

        if cam_id in self._pipelines:
            self._logger.warning("Camera %d already running", cam_id)
            return {"status": "already_running", "camera_id": cam_id}

        pipeline = CameraPipeline(self._config, self._gst, cam_id, width, height, fps)
        pipeline.start()
        self._pipelines[cam_id] = pipeline
        return {"status": "started", "camera_id": cam_id}

    def stop_camera(self, cam_id: int) -> dict:
        pipeline = self._pipelines.pop(cam_id, None)
        if pipeline is None:
            self._logger.warning("Camera %d not found", cam_id)
            return {"status": "not_found", "camera_id": cam_id}

        pipeline.stop()
        return {"status": "stopped", "camera_id": cam_id}

    def get_status(self) -> dict:
        return {"running_cameras": sorted(self._pipelines.keys()), "count": len(self._pipelines)}

    def get_pipeline(self, cam_id: int) -> CameraPipeline | None:
        return self._pipelines.get(cam_id)


async def handle_control_connection(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    service: CameraDaemonService,
) -> None:
    logger = logging.getLogger(__name__)
    try:
        line = await reader.readline()
        if not line:
            return

        try:
            request = json.loads(line.decode().strip())
        except json.JSONDecodeError:
            writer.write(b'{"error":"invalid_json"}\n')
            await writer.drain()
            return

        command = request.get("cmd")
        if command == "start":
            response = service.start_camera(
                int(request.get("id", 0)),
                int(request.get("w", 640)),
                int(request.get("h", 480)),
                int(request.get("fps", 30)),
            )
        elif command == "stop":
            response = service.stop_camera(int(request.get("id", 0)))
        elif command == "status":
            response = service.get_status()
        else:
            response = {"error": "unknown_command", "cmd": command}

        writer.write((json.dumps(response) + "\n").encode())
        await writer.drain()
    except Exception as exc:  # noqa: BLE001
        logger.error("Control handler error: %s", exc)
    finally:
        writer.close()
        await writer.wait_closed()


async def handle_frame_connection(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    service: CameraDaemonService,
    cam_id: int,
) -> None:
    logger = logging.getLogger(__name__)
    pipeline = service.get_pipeline(cam_id)
    if pipeline is None:
        logger.warning("Frame request for inactive camera %d", cam_id)
        writer.close()
        await writer.wait_closed()
        return

    pipeline.register_client(writer)
    try:
        while True:
            chunk = await reader.read(1024)
            if not chunk:
                break
    except asyncio.CancelledError:
        raise
    finally:
        pipeline.remove_client(writer)
        writer.close()
        await writer.wait_closed()


async def run_control_server(config: DaemonConfig, service: CameraDaemonService) -> None:
    logger = logging.getLogger(__name__)
    handler = partial(handle_control_connection, service=service)
    server = await asyncio.start_server(handler, config.control_host, config.control_port)
    socket = server.sockets[0].getsockname() if server.sockets else (config.control_host, config.control_port)
    logger.info("Control server listening on %s:%s", socket[0], socket[1])

    async with server:
        await server.serve_forever()


async def run_frame_server(cam_id: int, config: DaemonConfig, service: CameraDaemonService) -> None:
    logger = logging.getLogger(__name__)
    port = config.frame_base_port + cam_id
    handler = partial(handle_frame_connection, service=service, cam_id=cam_id)
    server = await asyncio.start_server(handler, config.control_host, port)
    socket = server.sockets[0].getsockname() if server.sockets else (config.control_host, port)
    logger.info("Frame server for cam %d listening on %s:%s", cam_id, socket[0], socket[1])

    async with server:
        await server.serve_forever()


async def run_daemon() -> None:
    configure_logging()
    config = load_config()
    gst_module = create_gstreamer_module()
    service = CameraDaemonService(config, gst_module)

    tasks = [asyncio.create_task(run_control_server(config, service))]
    tasks.extend(asyncio.create_task(run_frame_server(cam_id, config, service)) for cam_id in range(config.max_cameras))
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    try:
        asyncio.run(run_daemon())
    except KeyboardInterrupt:
        logging.getLogger(__name__).info("Daemon shutting down on user request")
