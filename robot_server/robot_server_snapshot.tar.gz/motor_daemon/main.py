#!/usr/bin/env python3
"""
Motor Daemon - NATS subscriber for motor control commands.

Subscribes to NATS subjects (motors.*) and processes commands
sequentially using appropriate motor drivers (simulator, raspbot, diktum).
Uses NATS core (not JetStream) as per nats-motor-commands.md.
"""
import asyncio
import json
import logging
import os
import sys
import time
import uuid
from typing import Dict, Any, Optional
from pathlib import Path

import nats
from nats.aio.client import Client as NATS

from common.motor_iface import MotorIface
from motors.simulator import SimulatorMotor
from motors.raspbot import RaspbotMotor
from motors.diktum import DiktumMotor
from config_loader import get_config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


class DaemonState:
    """Simple state object that mimics app.state for motor drivers."""
    def __init__(self):
        # Attributes will be set dynamically via setattr
        pass

class MotorDaemon:
    """Motor daemon that processes commands from NATS."""
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.motor_driver: Optional[MotorIface] = None
        self.robot_type: str = "simulator"
        self.config: Dict[str, Any] = {}
        self.processed_correlation_ids = set()  # For idempotency
        self._daemon_state = DaemonState()  # State object (replaces app_state)
        self._subscriptions = []  # Track subscriptions for cleanup
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from config.toml."""
        try:
            app_config = get_config()
            self.config = app_config.raw_data
            log.info(f"✅ Loaded config from: {app_config.config_path}")
            return self.config
        except Exception as e:
            log.warning(f"❌ Failed to load config: {e}, using defaults")
            self.config = {}
            return self.config
    
    def _get_robot_type(self) -> str:
        """Get robot type from environment or config."""
        # Check environment first
        env_type = os.getenv("ROBOT_TYPE")
        if env_type:
            return env_type.lower()
        
        # Check config
        default_section = self.config.get("default", {})
        robot_type = default_section.get("robot_type", "simulator")
        return robot_type.lower()
    
    def _create_motor_driver(self) -> Optional[MotorIface]:
        """Factory method to create appropriate motor driver."""
        robot_type = self._get_robot_type()
        self.robot_type = robot_type
        
        log.info(f"🤖 Creating motor driver for robot type: {robot_type}")
        
        try:
            if robot_type == "simulator":
                driver = SimulatorMotor()
            elif robot_type == "raspbot":
                driver = RaspbotMotor()
            elif robot_type == "diktum":
                driver = DiktumMotor()
            else:
                log.error(f"Unknown robot type: {robot_type}")
                return None
            
            # Connect driver (pass daemon state instead of app_state)
            driver.connect(self._daemon_state)
            log.info(f"✅ Motor driver created: {driver.name}")
            return driver
            
        except Exception as e:
            log.error(f"❌ Failed to create motor driver: {e}", exc_info=True)
            return None
    
    async def _publish_telemetry(self, state: str, last_cmd: Optional[str] = None, error: Optional[str] = None):
        """Publish telemetry to motors.telemetry.status using NATS core."""
        if not self.nc:
            return
        
        try:
            telemetry = {
                "state": state,
                "lastCmd": last_cmd,
                "error": error,
                "ts": time.time(),
                "robot_type": self.robot_type
            }
            # JSONL format: compact JSON, single line
            jsonl_data = json.dumps(telemetry, separators=(',', ':'), ensure_ascii=False)
            await self.nc.publish("motors.telemetry.status", jsonl_data.encode())
        except Exception as e:
            log.debug(f"Failed to publish telemetry: {e}")
    
    async def _process_move_command(self, args: Dict[str, Any], correlation_id: str):
        """Process a move command (raw joystick values)."""
        if not self.motor_driver:
            log.error("Motor driver not initialized")
            await self._publish_telemetry("error", "move", "driver_not_initialized")
            return
        
        try:
            # Extract raw joystick values (speed/forward/turn)
            speed = args.get("speed")
            forward = args.get("forward")
            turn = args.get("turn")
            
            # For Diktum driver, store raw values directly
            if self.robot_type == "diktum":
                if forward is not None:
                    setattr(self._daemon_state, "diktum_forward", forward)
                if turn is not None:
                    setattr(self._daemon_state, "diktum_turn", turn)
                if speed is not None:
                    setattr(self._daemon_state, "diktum_speed", speed)
                
                # Call command_velocity which will use stored raw values
                self.motor_driver.command_velocity(0.0, 0.0)  # Diktum uses stored raw values
            else:
                # For simulator/raspbot, convert to velocity if needed
                # For now, just call command_velocity with zeros (drivers can be updated later)
                self.motor_driver.command_velocity(0.0, 0.0)
            
            log.info(f"✅ Processed move command: correlation_id={correlation_id}, speed={speed}, forward={forward}, turn={turn}")
            await self._publish_telemetry("running", "move")
            
        except Exception as e:
            log.error(f"❌ Error processing move command: {e}", exc_info=True)
            await self._publish_telemetry("error", "move", str(e))
    
    async def _process_stop_command(self, correlation_id: str):
        """Process a stop command."""
        if not self.motor_driver:
            log.warning("Motor driver not initialized for stop command")
            return
        
        try:
            self.motor_driver.stop()
            log.info(f"✅ Processed stop command: correlation_id={correlation_id}")
            await self._publish_telemetry("stopped", "stop")
        except Exception as e:
            log.error(f"❌ Error processing stop command: {e}", exc_info=True)
            await self._publish_telemetry("error", "stop", str(e))
    
    async def _process_relay_command(self, args: Dict[str, Any], correlation_id: str):
        """Process a relay command."""
        if not self.motor_driver:
            log.error("Motor driver not initialized for relay command")
            await self._publish_telemetry("error", "relay", "driver_not_initialized")
            return
        
        try:
            relay_name = args.get("relay_name")
            relay_on = args.get("relay_on", True)
            
            if not relay_name:
                log.error("Missing relay_name in relay command")
                return
            
            # Diktum driver has set_relay method
            if hasattr(self.motor_driver, "set_relay"):
                result = self.motor_driver.set_relay(self._daemon_state, relay_name, relay_on)
                log.info(f"✅ Processed relay command: {relay_name}={relay_on}, result={result}")
            else:
                log.warning(f"Motor driver {self.motor_driver.name} does not support relay commands")
            
            await self._publish_telemetry("running", f"relay.{relay_name}")
            
        except Exception as e:
            log.error(f"❌ Error processing relay command: {e}", exc_info=True)
            await self._publish_telemetry("error", "relay", str(e))
    
    async def _handle_command(self, msg):
        """Handle incoming command message."""
        try:
            # Parse JSONL message (compact JSON)
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            correlation_id = data.get("correlationId", str(uuid.uuid4()))
            timestamp = data.get("timestamp")
            
            log.info(f"📨 Received command: {cmd}, correlation_id={correlation_id}")
            
            # Idempotency check
            if correlation_id in self.processed_correlation_ids:
                log.warning(f"⚠️ Duplicate command detected: {correlation_id}, skipping")
                return
            
            # Process command based on type
            if cmd == "move":
                await self._process_move_command(args, correlation_id)
            elif cmd == "stop":
                await self._process_stop_command(correlation_id)
            elif cmd == "relay":
                await self._process_relay_command(args, correlation_id)
            else:
                log.error(f"Unknown command type: {cmd}")
                await self._publish_telemetry("error", cmd, f"unknown_command_type")
            
            # Mark as processed
            self.processed_correlation_ids.add(correlation_id)
            
            # Clean up old correlation IDs (keep last 1000)
            if len(self.processed_correlation_ids) > 1000:
                # Remove oldest (simple FIFO, in production use time-based)
                self.processed_correlation_ids = set(list(self.processed_correlation_ids)[-1000:])
            
        except json.JSONDecodeError as e:
            log.error(f"❌ Failed to parse command message: {e}")
        except Exception as e:
            log.error(f"❌ Error handling command: {e}", exc_info=True)
    
    async def start(self):
        """Start the motor daemon."""
        # Load configuration
        self._load_config()
        
        # Create motor driver
        self.motor_driver = self._create_motor_driver()
        if not self.motor_driver:
            log.error("Failed to create motor driver, exiting")
            sys.exit(1)
        
        # Connect to NATS (core only, no JetStream)
        nats_url = os.getenv("NATS_URL", "nats://nats:4222")
        log.info(f"🔌 Connecting to NATS at {nats_url}")
        
        try:
            self.nc = await nats.connect(nats_url)
            log.info("✅ Connected to NATS")
        except Exception as e:
            log.error(f"❌ Failed to connect to NATS: {e}")
            sys.exit(1)
        
        # Subscribe to command subjects using NATS core
        subjects = ["motors.move", "motors.stop", "motors.relay"]
        
        for subject in subjects:
            sub = await self.nc.subscribe(subject, cb=self._handle_command)
            self._subscriptions.append(sub)
            log.info(f"✅ Subscribed to {subject}")
        
        # Publish initial telemetry
        await self._publish_telemetry("ready", None)
        
        log.info("🚀 Motor daemon started, waiting for commands...")
        
        # Keep running
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            log.info("🛑 Shutting down motor daemon...")
        except Exception as e:
            log.error(f"❌ Error in main loop: {e}", exc_info=True)
        finally:
            # Cleanup
            # Unsubscribe from all subjects
            for sub in self._subscriptions:
                await sub.unsubscribe()
            
            if self.motor_driver:
                try:
                    self.motor_driver.shutdown()
                except:
                    pass
            if self.nc:
                await self.nc.close()
            log.info("👋 Motor daemon stopped")


async def main():
    """Main entry point."""
    daemon = MotorDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Motor daemon stopped by user")

