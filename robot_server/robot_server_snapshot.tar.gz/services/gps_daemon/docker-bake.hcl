group "default" {
  targets = ["gps-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, переопределяется из Python

target "gps-daemon-base" {
  context    = "./services/gps_daemon"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Используем переменную
}

target "gps-daemon-local" {
  inherits = ["gps-daemon-base"]
  tags     = ["gps-daemon:local"]
  output   = ["type=docker"]  # Load into local Docker for compose
}





