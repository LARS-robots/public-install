#!/usr/bin/env python3
"""
GPS Daemon - publishes GPS measurements to NATS.

Reads GPS data from serial port and publishes to loc.meas.gps topic.
"""
import asyncio
import json
import logging
import os
import sys
import time
import signal
from typing import Optional, Dict, Any

import nats
from nats.aio.client import Client as NATS

# Add nats_logger to path if available as volume
import sys
from pathlib import Path
nats_logger_path = Path("/nats_logger")
if nats_logger_path.exists():
    sys.path.insert(0, str(nats_logger_path.parent))

from gps_reader import GPSReader
from config_loader import get_config

# Setup nats_logger
try:
    from nats_logger import NATSHandler, detect_service_name
    NATS_LOGGER_AVAILABLE = True
except ImportError:
    NATS_LOGGER_AVAILABLE = False
    log = logging.getLogger(__name__)
    log.warning("nats_logger not available, using standard logging")

# Setup basic logging first
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


class GPSDaemon:
    """
    GPS daemon that reads GPS data and publishes to NATS.
    """
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.gps_reader: Optional[GPSReader] = None
        self.config: Dict[str, Any] = {}
        self.publish_rate_hz = 5.0  # 5 Hz (recommended, within 1-10 Hz spec)
        self._shutdown_event = asyncio.Event()
        self._running = False
        
    def _load_config(self):
        """Load configuration from config.toml."""
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"✅ Loaded config from: {cfg.config_path}")
            
            # Get GPS-specific config
            gps_config = self.config.get("gps", {})
            self.publish_rate_hz = float(gps_config.get("publish_rate_hz", 5.0))
            
            return self.config
        except Exception as e:
            log.warning(f"⚠️ Failed to load config: {e}, using defaults")
            self.config = {}
            return self.config
    
    def _setup_nats_logger(self):
        """Setup nats_logger for centralized logging."""
        if not NATS_LOGGER_AVAILABLE:
            log.warning("⚠️ nats_logger not available, using standard logging only")
            return
        
        try:
            # Get NATS URL from config or env
            nats_config = self.config.get("nats", {})
            nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://dev:devpass@127.0.0.1:4222")
            
            # Clean up URL (only remove trailing colons, don't replace 127.0.0.1)
            if nats_url:
                nats_url = nats_url.strip().rstrip(":")
            
            # Use explicit service name or from env
            service_name = os.getenv("SERVICE_NAME") or "gps-daemon"
            
            # Create NATS handler
            handler = NATSHandler(
                nats_url=nats_url,
                service_name=service_name,
                subject_prefix="log",
                level=logging.INFO,
            )
            
            # Add handler to root logger
            logging.getLogger().addHandler(handler)
            log.info(f"✅ NATS logging enabled for service: {service_name}")
            
        except Exception as e:
            log.warning(f"⚠️ Failed to setup nats_logger: {e}")
    
    def _create_gps_reader(self) -> Optional[GPSReader]:
        """Create and configure GPS reader from config."""
        gps_config = self.config.get("gps", {})
        
        port = gps_config.get("serial_port", "/dev/ttyAMA0")
        baudrate = int(gps_config.get("baudrate", 9600))
        timeout = float(gps_config.get("timeout", 0.5))
        
        reader = GPSReader(port=port, baudrate=baudrate, timeout=timeout)
        
        if reader.connect():
            return reader
        else:
            log.error("❌ Failed to connect to GPS device")
            return None
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS server."""
        try:
            nats_config = self.config.get("nats", {})
            nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://dev:devpass@127.0.0.1:4222")
            
            # Clean up URL (only remove trailing colons, don't replace 127.0.0.1)
            if nats_url:
                nats_url = nats_url.strip().rstrip(":")
            
            log.info(f"🔌 Connecting to NATS at {nats_url}")
            self.nc = await nats.connect(
                nats_url,
                reconnect_time_wait=2,
                max_reconnect_attempts=-1,  # Infinite reconnects
                connect_timeout=5,
            )
            log.info("✅ Connected to NATS")
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to NATS: {e}")
            if self.nc:
                try:
                    await self.nc.close()
                except Exception:
                    pass
                self.nc = None
            return False
    
    async def _publish_gps_data(self, gps_data: Dict[str, Any]):
        """Publish GPS data to NATS topic loc.meas.gps."""
        if not self.nc:
            return
        
        try:
            # Format as JSONL (single line JSON)
            msg = json.dumps(gps_data, separators=(",", ":"))
            
            # Publish to loc.meas.gps (core NATS, not JetStream)
            await self.nc.publish("loc.meas.gps", msg.encode())
            
            # Log at debug level (too verbose for INFO)
            log.debug(f"📡 Published GPS: lat={gps_data.get('lat'):.6f}, lon={gps_data.get('lon'):.6f}, fix={gps_data.get('fix')}")
            
        except Exception as e:
            log.error(f"❌ Error publishing GPS data: {e}")
    
    async def _publish_loop(self):
        """Main loop: read GPS and publish to NATS."""
        log.info(f"🔄 Starting GPS publish loop at {self.publish_rate_hz} Hz")
        
        sleep_interval = 1.0 / self.publish_rate_hz
        publish_count = 0
        last_log_time = time.time()
        log_interval = 10.0  # Log statistics every 10 seconds
        
        while not self._shutdown_event.is_set():
            try:
                # Read GPS data
                gps_data = self.gps_reader.read()
                
                if gps_data:
                    # Publish to NATS
                    await self._publish_gps_data(gps_data)
                    publish_count += 1
                    
                    # Periodic logging (every 10 seconds or every 50 messages)
                    current_time = time.time()
                    if current_time - last_log_time >= log_interval or publish_count % 50 == 0:
                        fix_status = gps_data.get('fix', 'unknown')
                        num_sats = gps_data.get('num_sats', 0)
                        lat = gps_data.get('lat', 0.0)
                        lon = gps_data.get('lon', 0.0)
                        
                        if fix_status == 'none':
                            log.info(f"📡 Published GPS data (location undefined): fix={fix_status}, num_sats={num_sats}, total_published={publish_count}")
                        else:
                            log.info(f"📡 Published GPS data: lat={lat:.6f}, lon={lon:.6f}, fix={fix_status}, num_sats={num_sats}, total_published={publish_count}")
                        
                        last_log_time = current_time
                else:
                    # No valid GPS data (should not happen now, but keep for safety)
                    log.debug("No GPS data returned from reader")
                
                # Sleep to maintain publish rate
                await asyncio.sleep(sleep_interval)
                
            except asyncio.CancelledError:
                log.info("🛑 Publish loop cancelled")
                break
            except Exception as e:
                log.error(f"❌ Error in publish loop: {e}", exc_info=True)
                await asyncio.sleep(sleep_interval)
        
        log.info("🔄 GPS publish loop stopped")
    
    async def start(self):
        """Start the GPS daemon."""
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            log.info(f"🛑 Received signal {signum}, initiating graceful shutdown...")
            self._shutdown_event.set()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # Load configuration
        self._load_config()
        
        # Setup nats_logger
        self._setup_nats_logger()
        
        # Connect to NATS
        if not await self._connect_nats():
            log.error("❌ Failed to connect to NATS, exiting")
            sys.exit(1)
        
        # Create GPS reader
        self.gps_reader = self._create_gps_reader()
        if not self.gps_reader:
            log.error("❌ Failed to initialize GPS reader, exiting")
            sys.exit(1)
        
        log.info("🚀 GPS daemon started")
        
        # Start publishing loop
        self._running = True
        try:
            await self._publish_loop()
        except KeyboardInterrupt:
            log.info("🛑 Shutting down GPS daemon (KeyboardInterrupt)...")
            self._shutdown_event.set()
        except Exception as e:
            log.error(f"❌ Error in main loop: {e}", exc_info=True)
            self._shutdown_event.set()
        finally:
            await self._shutdown()
    
    async def _shutdown(self):
        """Graceful shutdown of the daemon."""
        log.info("🛑 Shutting down GPS daemon...")
        self._running = False
        
        # Disconnect GPS reader
        if self.gps_reader:
            self.gps_reader.disconnect()
        
        # Close NATS connection
        if self.nc:
            try:
                await self.nc.close()
                log.info("✅ NATS connection closed")
            except Exception:
                pass
        
        log.info("👋 GPS daemon stopped")


async def main():
    """Main entry point."""
    daemon = GPSDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("GPS daemon stopped by user")
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

