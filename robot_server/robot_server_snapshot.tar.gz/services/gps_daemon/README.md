# GPS Daemon

Сервис для чтения GPS данных и публикации в NATS.

## Содержание

- [Назначение](#назначение)
- [Архитектура](#архитектура)
- [Формат данных](#формат-данных)
- [Конфигурация](#конфигурация)
- [Интеграция с Docker Compose](#интеграция-с-docker-compose)
- [Зависимости](#зависимости)
- [Сборка образа](#сборка-образа)
- [Запуск](#запуск)
- [Логирование](#логирование)
- [Особенности реализации](#особенности-реализации)
- [Документация](#документация)

---

## Назначение

GPS daemon читает данные GPS/ГЛОНАСС с модуля через UART (serial port) и публикует измерения в NATS топик `loc.meas.gps` для использования основным демоном локализации.

**Основные функции:**
- Чтение NMEA сообщений с GPS модуля (GPRMC/GNRMC)
- Парсинг координат, высоты, точности, количества спутников
- Публикация в NATS топик `loc.meas.gps` (core NATS, 1-10 Гц)
- Логирование через `nats_logger` в топик `log.gps-daemon.*`

## Архитектура

```
GPS Module (UART) → GPS Reader → GPS Daemon → NATS (loc.meas.gps)
```

**Компоненты:**
- `gps_reader.py` - чтение и парсинг NMEA сообщений
- `main.py` - основной демон (NATS publisher)
- `config_loader.py` - загрузка конфигурации

## Формат данных

Публикует в топик `loc.meas.gps` согласно спецификации:

```json
{
  "ts": 1732118400.111222,
  "kind": "gps",
  "lat": 32.1234567,
  "lon": 34.9876543,
  "alt": 48.2,
  "hdop": 0.9,
  "num_sats": 13,
  "fix": "3d",
  "cov_lat": 3.5,
  "cov_lon": 3.5
}
```

**Поля:**
- `ts` - время получения данных (UTC, сек, float)
- `kind` - тип измерения (`"gps"`)
- `lat, lon, alt` - географические координаты (WGS84)
- `hdop` - горизонтальная точность (чем меньше, тем лучше)
- `num_sats` - число видимых спутников
- `fix` - тип фикса: `none`, `2d`, `3d`, `rtk_float`, `rtk_fixed`
- `cov_lat, cov_lon` - оценка дисперсий (в метрах)

## Конфигурация

**`config.toml`:**

```toml
[gps]
# Serial port for GPS device
serial_port = "/dev/ttyAMA10"  # Default: /dev/ttyAMA10 (changed from /dev/ttyAMA0 to avoid conflict with motion_daemon)

# Serial communication settings
baudrate = 9600
timeout = 0.5  # seconds

# Publish rate (Hz) - must be within 1-10 Hz according to spec
publish_rate_hz = 5.0  # Recommended: 5 Hz

[nats]
# NATS server URL
# Use 127.0.0.1 when using host network mode (Raspberry Pi)
# Use "nats" service name when using bridge network mode
url = "nats://dev:devpass@127.0.0.1:4222"
```

## Интеграция с Docker Compose

Сервис добавлен в основной `compose.yml`:

```yaml
gps-daemon:
  image: ${GPS_IMAGE:-gps-daemon:local}
  platform: ${GPS_PLATFORM:-linux/arm64}
  network_mode: ${GPS_NETWORK_MODE:-host}
  devices:
    - ${GPS_DEVICE:-/dev/ttyAMA10:/dev/ttyAMA10}  # Changed from /dev/ttyAMA0 to avoid conflict
  volumes:
    - ./services/gps_daemon:/app:rw
    - ./services/nats_logger/src:/nats_logger:ro
  depends_on:
    - nats
```

**Переменные окружения:**
- `GPS_IMAGE` - Docker образ (по умолчанию: `gps-daemon:local`)
- `GPS_PLATFORM` - платформа (по умолчанию: `linux/arm64` для RPi)
- `GPS_NETWORK_MODE` - режим сети (по умолчанию: `host`)
- `GPS_DEVICE` - serial устройство (по умолчанию: `/dev/ttyAMA10:/dev/ttyAMA10`)
- `NATS_URL` - URL NATS сервера (по умолчанию: `nats://dev:devpass@127.0.0.1:4222`)
- `SERVICE_NAME` - имя сервиса для логирования (по умолчанию: `gps-daemon`)

## Зависимости

**Python библиотеки:**
- `nats-py>=2.0.0` - работа с NATS
- `pyserial>=3.5` - работа с serial портом
- `pynmea2>=1.19.0` - парсинг NMEA сообщений
- `tomli>=2.0.0` - загрузка конфигурации

**Внешние сервисы:**
- NATS сервер (уже есть в проекте)
- GPS модуль подключенный к UART (например, u-blox NEO-M8M-0-10)

## Сборка образа

```bash
# Сборка для локального использования
docker buildx bake -f services/gps_daemon/docker-bake.hcl gps-daemon-local

# Или через docker build
docker build -t gps-daemon:local -f services/gps_daemon/Dockerfile services/gps_daemon
```

## Запуск

```bash
# Запуск через docker compose
docker compose up gps-daemon

# Или весь стек
docker compose up
```

## Логирование

Все логи публикуются через `nats_logger` в топик `log.gps-daemon.*`:
- `log.gps-daemon.INFO` - информационные сообщения
- `log.gps-daemon.WARNING` - предупреждения
- `log.gps-daemon.ERROR` - ошибки

**Особенности:**
- Использует `setup_unified_logging()` из `nats_logger`
- stdout только триггерные события ([START], [STOP], [ERROR])
- Все логи (INFO, WARNING, ERROR) отправляются в NATS
- Логи доступны через веб-интерфейс `/admin/logs`

**Просмотр логов:**
- Веб-интерфейс: `http://localhost:8000/admin/logs` (все логи)
- Docker logs: `docker compose logs gps-daemon` (только триггерные события)

## Особенности реализации

### Обработка отсутствующих полей

Если GPS модуль не предоставляет некоторые поля (alt, hdop, num_sats), используются значения по умолчанию:
- `alt`: 0.0
- `hdop`: 5.0 (плохая точность)
- `num_sats`: 0
- `fix`: определяется из статуса NMEA сообщения

### Публикация без фикса

Демон **всегда** публикует данные, даже если GPS не имеет фикса (`fix: "none"`). Это позволяет основному демону локализации знать, что GPS доступен, но данные недостоверны.

**Специальные значения для неопределенного местоположения:**
- `fix: "none"` - местоположение не определено
- `lat, lon: 0.0` - значения по умолчанию
- `hdop: 99.9` - очень плохая точность (указывает на неопределенность)
- `cov_lat, cov_lon: 999.0` - большая ковариация (указывает на неопределенность)
- `num_sats: 0` - нет видимых спутников

Данные публикуются даже при отсутствии валидных NMEA сообщений или при timeout чтения.

### NATS подключение

Демон использует `127.0.0.1` для подключения к NATS при работе в `host` network mode (Raspberry Pi). URL не заменяется автоматически на имя сервиса `nats`, что позволяет корректно работать в host network mode.

### Периодическое логирование

Для мониторинга работы демона периодически выводится статистика:
- Каждые 10 секунд
- Или каждые 50 опубликованных сообщений

Пример лога:
```
📡 Published GPS data (location undefined): fix=none, num_sats=0, total_published=50
```

### Ковариации

Ковариации (`cov_lat`, `cov_lon`) вычисляются из HDOP по формуле: `cov = hdop * 3.5` метров. Это приблизительная оценка; реальная точность зависит от многих факторов.

## Документация

- [Спецификация локализации](../localization_daemon/README.md) - формат сообщений и топики
- [Архитектура NATS](../../docs/NATS.md) - общая архитектура NATS в проекте

