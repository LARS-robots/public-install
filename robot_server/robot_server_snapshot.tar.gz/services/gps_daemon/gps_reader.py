"""
GPS Reader for GPS daemon.

Reads GPS data from NMEA messages via serial port and provides structured data.
Adapted from test_gps_intsr.py with support for all required fields.
"""
import serial
import time
import logging
from typing import Optional, Dict, Any
import pynmea2

log = logging.getLogger(__name__)


class GPSReader:
    """
    GPS reader that parses NMEA messages from serial port.
    
    Supports GPRMC/GNRMC messages and extracts:
    - lat, lon, alt (coordinates)
    - hdop (horizontal dilution of precision)
    - num_sats (number of satellites)
    - fix quality/status
    """
    
    def __init__(self, port: str = "/dev/ttyAMA0", baudrate: int = 9600, timeout: float = 0.5):
        """
        Initialize GPS reader.
        
        Args:
            port: Serial port path (e.g., "/dev/ttyAMA0" or "/dev/serial0")
            baudrate: Serial baudrate (default: 9600)
            timeout: Serial read timeout in seconds
        """
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.serial_handle: Optional[serial.Serial] = None
        self._connected = False
        
    def connect(self) -> bool:
        """
        Open serial connection to GPS device.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.serial_handle = serial.Serial(
                self.port,
                baudrate=self.baudrate,
                timeout=self.timeout
            )
            self._connected = True
            log.info(f"✅ Connected to GPS on {self.port} at {self.baudrate} baud")
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to GPS on {self.port}: {e}")
            self._connected = False
            return False
    
    def disconnect(self):
        """Close serial connection."""
        if self.serial_handle and self.serial_handle.is_open:
            try:
                self.serial_handle.close()
                log.info("✅ Disconnected from GPS")
            except Exception as e:
                log.warning(f"⚠️ Error closing GPS connection: {e}")
        self._connected = False
        self.serial_handle = None
    
    def _parse_fix_status(self, msg) -> str:
        """
        Parse fix status from NMEA message.
        
        Returns:
            Fix status: "none", "2d", "3d", "rtk_float", "rtk_fixed"
        """
        # Check status field (A = active/valid, V = void/invalid)
        status = getattr(msg, 'status', 'V')
        if status == 'V':
            return "none"
        
        # Check FAA mode if available
        faa_mode = getattr(msg, 'faa_mode', None)
        if faa_mode:
            mode_map = {
                'A': '3d',  # Autonomous
                'D': '3d',  # Differential
                'E': '2d',  # Estimated
                'N': 'none',  # Not valid
            }
            return mode_map.get(faa_mode, 'none')
        
        # Default: assume 3d if status is A
        return "3d" if status == 'A' else "none"
    
    def _calculate_covariance(self, hdop: float) -> tuple[float, float]:
        """
        Calculate covariance from HDOP.
        
        HDOP (Horizontal Dilution of Precision) is converted to meters.
        Typical conversion: 1 HDOP ≈ 3-5 meters accuracy.
        
        Args:
            hdop: Horizontal dilution of precision
            
        Returns:
            Tuple of (cov_lat, cov_lon) in meters
        """
        # Simple conversion: HDOP * 3.5 meters (typical for GPS)
        # This is a rough estimate; actual accuracy depends on many factors
        cov = hdop * 3.5
        return (cov, cov)
    
    def _create_undefined_location_data(self) -> Dict[str, Any]:
        """
        Create GPS data structure with undefined location.
        Used when GPS has no fix or no valid NMEA messages.
        
        Returns:
            Dictionary with GPS data indicating undefined location
        """
        return {
            "ts": time.time(),
            "kind": "gps",
            "lat": 0.0,
            "lon": 0.0,
            "alt": 0.0,
            "hdop": 99.9,  # Very poor accuracy (indicates undefined)
            "num_sats": 0,
            "fix": "none",
            "cov_lat": 999.0,  # Large covariance (indicates undefined)
            "cov_lon": 999.0,
        }
    
    def read(self) -> Optional[Dict[str, Any]]:
        """
        Read and parse GPS data from serial port.
        
        Always returns GPS data structure. If location is undefined (no fix),
        returns data with fix: "none" and default values indicating undefined location.
        
        Returns:
            Dictionary with GPS data according to spec, or None only on critical errors
        """
        if not self._connected or not self.serial_handle:
            return None
        
        try:
            # Read NMEA message
            newdata = self.serial_handle.readline()  # bytes
            
            # Accept GNRMC or GPRMC messages
            if newdata[:6] not in (b"$GPRMC", b"$GNRMC"):
                # No valid NMEA message - return data with undefined location
                return self._create_undefined_location_data()
            
            # Parse NMEA message
            try:
                newmsg = pynmea2.parse(newdata.decode("ascii", errors="ignore"))
            except pynmea2.ParseError as e:
                log.debug(f"Failed to parse NMEA message: {e}")
                # Return data with undefined location on parse error
                return self._create_undefined_location_data()
            
            # Extract required fields with defaults
            lat = getattr(newmsg, 'latitude', None)
            lon = getattr(newmsg, 'longitude', None)
            
            # If no valid coordinates, use defaults and mark as "none" fix
            location_undefined = (lat is None or lon is None)
            if location_undefined:
                lat = 0.0  # Default value when location undefined
                lon = 0.0  # Default value when location undefined
                log.debug("📍 GPS location undefined (no valid coordinates)")
            
            # For undefined location, use default values
            if location_undefined:
                alt = 0.0
                hdop = 99.9  # Very poor accuracy (indicates undefined)
                num_sats = 0
                fix = "none"
                cov_lat = 999.0  # Large covariance (indicates undefined)
                cov_lon = 999.0
            else:
                # Extract optional fields with defaults
                # TODO: After GPS gets satellite fix, verify these fields are available:
                # - newmsg.altitude (float) - altitude in meters
                # - newmsg.horizontal_dilution (float) - HDOP
                # - newmsg.num_satellites (int) - number of visible satellites
                # - newmsg.status (str) - 'A' (active) or 'V' (void)
                # - newmsg.faa_mode (str) - 'A' (autonomous), 'D' (differential), 'E' (estimated), 'N' (not valid)
                
                alt = getattr(newmsg, 'altitude', 0.0)
                hdop = getattr(newmsg, 'horizontal_dilution', 5.0)  # Default: poor accuracy
                num_sats = getattr(newmsg, 'num_satellites', 0)
                fix = self._parse_fix_status(newmsg)
                
                # Calculate covariance from HDOP
                cov_lat, cov_lon = self._calculate_covariance(hdop)
            
            # Build message according to spec
            gps_data = {
                "ts": time.time(),
                "kind": "gps",
                "lat": float(lat),
                "lon": float(lon),
                "alt": float(alt),
                "hdop": float(hdop),
                "num_sats": int(num_sats),
                "fix": fix,
                "cov_lat": cov_lat,
                "cov_lon": cov_lon,
            }
            
            return gps_data
            
        except serial.SerialTimeoutException:
            # Timeout - return data with undefined location
            return self._create_undefined_location_data()
        except Exception as e:
            log.warning(f"⚠️ Error reading GPS: {e}")
            return None
    
    def is_connected(self) -> bool:
        """Check if GPS reader is connected."""
        return self._connected and self.serial_handle is not None and self.serial_handle.is_open

