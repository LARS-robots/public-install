#!/usr/bin/env python3
"""
Simple v4l2 recording test using GStreamer (no rpicam).
Records a short clip from /dev/videoX to a file.
"""
from __future__ import annotations

import argparse
import sys

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib  # noqa: E402


def _has_element(name: str) -> bool:
    return Gst.ElementFactory.find(name) is not None


def _build_pipeline(device: str, width: int, height: int, fps: int, out_path: str, codec: str) -> str:
    caps = f"video/x-raw,width={width},height={height},framerate={fps}/1"
    src = f"v4l2src device={device}"
    conv = "videoconvert"

    if codec == "x264":
        missing = [k for k in ("x264enc", "h264parse", "mp4mux") if not _has_element(k)]
        if missing:
            raise RuntimeError(f"Missing GStreamer elements for x264: {', '.join(missing)}")
        enc = "x264enc tune=zerolatency speed-preset=ultrafast bitrate=2000 key-int-max=30"
        mux = "h264parse ! mp4mux"
    elif codec == "mjpeg":
        missing = [k for k in ("jpegenc", "avimux") if not _has_element(k)]
        if missing:
            raise RuntimeError(f"Missing GStreamer elements for mjpeg: {', '.join(missing)}")
        enc = "jpegenc"
        mux = "avimux"
    else:
        raise ValueError(f"Unknown codec: {codec}")

    return f"{src} ! {caps} ! {conv} ! {enc} ! {mux} ! filesink location={out_path}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Record a short clip using v4l2 + GStreamer.")
    parser.add_argument("--device", default="/dev/video0", help="V4L2 device path (default: /dev/video0)")
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--seconds", type=int, default=5)
    parser.add_argument(
        "--codec",
        choices=["x264", "mjpeg", "auto"],
        default="auto",
        help="Encoding codec (default: auto)",
    )
    parser.add_argument("--out", default="", help="Output file path")
    args = parser.parse_args()

    Gst.init(None)

    codec = args.codec
    if codec == "auto":
        codec = "x264" if _has_element("x264enc") and _has_element("mp4mux") else "mjpeg"

    out_path = args.out
    if not out_path:
        out_path = "out.mp4" if codec == "x264" else "out.avi"

    pipeline_desc = _build_pipeline(args.device, args.width, args.height, args.fps, out_path, codec)
    print(f"[v4l2-test] Pipeline: {pipeline_desc}")

    pipeline = Gst.parse_launch(pipeline_desc)
    bus = pipeline.get_bus()
    bus.add_signal_watch()

    loop = GLib.MainLoop()

    def _on_message(_bus, msg):
        t = msg.type
        if t == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            print(f"[v4l2-test] ERROR: {err}")
            if dbg:
                print(f"[v4l2-test] DEBUG: {dbg}")
            loop.quit()
        elif t == Gst.MessageType.EOS:
            print("[v4l2-test] EOS received")
            loop.quit()

    bus.connect("message", _on_message)

    ret = pipeline.set_state(Gst.State.PLAYING)
    if ret == Gst.StateChangeReturn.FAILURE:
        print("[v4l2-test] Failed to start pipeline")
        pipeline.set_state(Gst.State.NULL)
        return 1

    def _stop():
        pipeline.send_event(Gst.Event.new_eos())
        return False

    GLib.timeout_add_seconds(args.seconds, _stop)
    loop.run()

    pipeline.set_state(Gst.State.NULL)
    print(f"[v4l2-test] Saved: {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
