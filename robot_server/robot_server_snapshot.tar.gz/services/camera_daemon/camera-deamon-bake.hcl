group "default" {
  targets = ["camera-daemon-linux", "camera-daemon-rpi"]
}

target "camera-daemon-linux" {
  context = "."
  dockerfile = "Dockerfile"
  platforms = ["linux/amd64"]
  tags = ["camera-daemon:latest"]
  output = ["type=docker"]
}

target "camera-daemon-rpi" {
  context = "."
  dockerfile = "Dockerfile.rpi"
  platforms = ["linux/arm64"]
  tags = ["camera-daemon:latest"]
  output = ["type=docker"]
}