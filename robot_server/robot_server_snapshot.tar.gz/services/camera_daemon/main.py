#!/usr/bin/env python3
"""
Camera Daemon — reads aspect ratio from config.toml and builds a stable
GStreamer pipeline that always sets valid width/height.
"""
import asyncio
import json
import logging
import os
import sys
import struct
import subprocess
import threading
from dataclasses import dataclass
from functools import partial
from fractions import Fraction
from pathlib import Path
from typing import Dict, Optional, Set, Tuple
import shutil
import gi
try:
    import tomllib
except ImportError:
    import tomli as tomllib


def configure_logging() -> None:
    """
    Унифицированная настройка логирования с опциональной поддержкой NATS.
    
    Использует setup_unified_logging() из nats_logger для единообразной конфигурации.
    stdout содержит только триггерные события: ERROR, CRITICAL и события старт/стоп.
    Все события INFO, WARNING доступны через NATS и веб-интерфейс.
    """
    try:
        from nats_logger import setup_unified_logging
        setup_unified_logging(
            service_name="camera-daemon",
            nats_url=os.getenv("NATS_URL"),
            enable_nats=os.getenv("NATS_LOGGING_ENABLE", "1").lower() in ("1", "true", "yes"),
        )
    except ImportError:
        # Fallback на стандартную настройку если nats_logger не доступен
        root = logging.getLogger()
        root.setLevel(logging.INFO)
        for handler in list(root.handlers):
            root.removeHandler(handler)
        sh = logging.StreamHandler(sys.stdout)
        sh.setLevel(logging.ERROR)
        sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        root.addHandler(sh)
        logging.getLogger(__name__).warning("nats_logger not available, using standard logging only")


def _even(x: int) -> int:
    return max(2, x - (x % 2))


def _parse_ratio(value: Optional[str]) -> Optional[Tuple[int, int]]:
    if not value:
        return None
    try:
        w, h = map(int, value.replace("x", ":").split(":"))
        if w > 0 and h > 0:
            return w, h
    except Exception:
        pass
    return None


def _load_aspect_config() -> dict:
    """
    Load aspect ratio configuration from config.toml.
    Searches multiple paths and logs which one is used.
    """
    base = Path(__file__).resolve().parent
    paths = [
        Path("/app/src/config/config.toml"),  # Daemon src mount (primary in Docker)
        Path("/config/config.toml"),  # Shared config mount (primary in Docker)
        Path("/api/src/config/config.toml"),  # API src mount (legacy path)
        base / "config.toml",  # Same directory as daemon
        (base / "../api/src/config/config.toml").resolve(),  # Relative to API
    ]
    for p in paths:
        if p.exists():
            logging.info("Aspect config found at %s", p)
            with open(p, "rb") as f:
                data = tomllib.load(f)
                return data.get("aspect", {})
        else:
            logging.debug("Aspect config not found at %s", p)
    logging.warning("Aspect config missing; using defaults")
    return {}


@dataclass(frozen=True)
class DaemonConfig:
    control_host: str = "0.0.0.0"
    control_port: int = 8765
    frame_base_port: int = 8800
    fmt_i420: int = 1
    frame_header_fmt: str = ">IHHQB"
    max_cameras: int = 2
    aspect_enabled: bool = False
    aspect_ratio: Optional[Tuple[int, int]] = None
    aspect_mode: str = "letterbox"

    @staticmethod
    def from_toml() -> "DaemonConfig":
        aspect = _load_aspect_config()
        ratio = None
        if aspect:
            s = aspect.get("mono") or aspect.get("stereo_left") or aspect.get("quad")
            logging.info(f"📊 Aspect string from config: '{s}'")
            ratio = _parse_ratio(s)
            logging.info(f"📊 Parsed ratio: {ratio}")

        config = DaemonConfig(
            aspect_enabled=bool(aspect.get("enabled", False)),
            aspect_ratio=ratio,
            aspect_mode=aspect.get("mode", "letterbox"),
        )
        logging.info(f"🎛️  Final DaemonConfig: aspect_enabled={config.aspect_enabled}, aspect_ratio={config.aspect_ratio}, aspect_mode={config.aspect_mode}")
        return config

    @property
    def frame_header_size(self) -> int:
        return struct.calcsize(self.frame_header_fmt)


def create_gst():
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
    Gst.init(None)
    return Gst


def pick_source(gst, cam_id: int) -> str:
    """
    Select GStreamer source element based on environment variable or auto-detection.
    Priority: rpicam (RPi-5) > v4l2src (Linux) > ksvideosrc (Windows) > libcamerasrc.
    """
    backend = os.getenv("CAMERA_BACKEND", "auto").lower()
    
    # Check for rpicam on Raspberry Pi (RPi 5)
    if backend == "rpicam" or (backend == "auto" and shutil.which("rpicam-vid")):
        return "rpicam"  # Special marker for rpicam pipeline
    
    # Define source priorities: (name, factory_name, format_string)
    sources = [
        ("v4l2", "v4l2src", f"v4l2src device=/dev/video{cam_id}"),
        ("ksvideosrc", "ksvideosrc", f"ksvideosrc device-index={cam_id}"),
        ("libcamera", "libcamerasrc", f"libcamerasrc camera-index={cam_id}"),
    ]
    
    # Check explicitly requested backend
    if backend != "auto":
        for name, factory, fmt in sources:
            if backend == name and gst.ElementFactory.find(factory):
                return fmt
    
    # Auto-detect in priority order
    for _, factory, fmt in sources:
        if gst.ElementFactory.find(factory):
            return fmt
    
    return "autovideosrc"


class CameraPipeline:
    def __init__(self, cfg: DaemonConfig, gst, cam_id: int, width: int, height: int, fps: int, video_file: Optional[str] = None):
        self.cfg = cfg
        self.gst = gst
        self.cam_id = cam_id
        self.width = width
        self.height = height
        self.fps = fps
        self.video_file = video_file  # Путь к видео-файлу для виртуальной камеры
        self.clients: Set[asyncio.StreamWriter] = set()
        self.logger = logging.getLogger(f"cam{cam_id}")
        self.pipeline = None
        self._rpicam_proc = None  # For rpicam-vid subprocess
        self._rpicam_pipe_r = None  # Read end of pipe for rpicam-vid

    def _build_video_caps(self, width: int, height: int, framerate: bool = True, pixel_aspect: bool = False, format: str = "I420") -> str:
        """Build video/x-raw caps string."""
        parts = [f"format={format}", f"width={width}", f"height={height}"]
        if framerate:
            parts.append(f"framerate={self.fps}/1")
        if pixel_aspect:
            parts.append("pixel-aspect-ratio=1/1")
        return f"video/x-raw,{','.join(parts)}"
    
    def _build_video_caps_no_format(self, width: int, height: int, framerate: bool = True) -> str:
        """Build video/x-raw caps string without format constraint (for v4l2src negotiation)."""
        parts = [f"width={width}", f"height={height}"]
        if framerate:
            parts.append(f"framerate={self.fps}/1")
        return f"video/x-raw,{','.join(parts)}"

    def build_desc(self, use_rpicam_fd: Optional[int] = None) -> str:
        elements = []
        
        # ВИРТУАЛЬНАЯ КАМЕРА: проверяем video_file
        if self.video_file:
            # Видео-файл через filesrc
            elements = [
                f"filesrc location={self.video_file}",
                "decodebin",
                "videoconvert",
                self._build_video_caps(self.width, self.height, framerate=True),
            ]
            
            # Применяем aspect если настроен (как для физических камер)
            if self.cfg.aspect_enabled and self.cfg.aspect_ratio:
                aw, ah = self.cfg.aspect_ratio
                mode = (self.cfg.aspect_mode or "").lower()
                self.logger.info("Aspect active %dx%d (%s) for virtual camera", aw, ah, mode)
                ratio = Fraction(aw, ah)
                if self.gst.ElementFactory.find("aspectratiocrop") and "crop" in mode:
                    elements.append(f"aspectratiocrop aspect-ratio={ratio.numerator}/{ratio.denominator}")
                    elements.append("videoscale")
                else:
                    elements.append("videoscale add-borders=true")
                elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False, pixel_aspect=True))
            else:
                elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False))
            
            elements.extend([
                "queue leaky=2 max-size-buffers=2",
                "appsink name=sink max-buffers=2 drop=true emit-signals=true"
            ])
            desc = " ! ".join(elements)
            self.logger.info("Virtual camera pipeline: %s", desc)
            return desc
        
        # ФИЗИЧЕСКИЕ КАМЕРЫ (существующая логика)
        src = pick_source(self.gst, self.cam_id)
        
        # Handle rpicam-vid: pipe raw YUV420 frames into GStreamer
        if src == "rpicam" and use_rpicam_fd is not None:
            expected_size = self.width * self.height * 3 // 2  # I420 frame size
            elements = [
                f"fdsrc fd={use_rpicam_fd}",
                f"rawvideoparse width={self.width} height={self.height} format=i420 framerate={self.fps}/1",
                self._build_video_caps(self.width, self.height, framerate=True),
            ]
        else:
            # Standard GStreamer source (v4l2src, ksvideosrc, etc.)
            # For v4l2src, don't force format - let it negotiate (camera may support YUYV/MJPG but not I420)
            # Then convert to I420 after
            if "v4l2src" in src:
                # Let v4l2src negotiate format (width/height/framerate only, no format constraint)
                elements = [src, self._build_video_caps_no_format(self.width, self.height, framerate=True)]
                # Convert to I420 after v4l2src (will be added below if not using aspect)
            else:
                # For other sources (ksvideosrc, etc.), use format constraint
                elements = [src, self._build_video_caps(self.width, self.height, framerate=True)]

        # Apply aspect if configured
        if self.cfg.aspect_enabled and self.cfg.aspect_ratio:
            aw, ah = self.cfg.aspect_ratio
            mode = (self.cfg.aspect_mode or "").lower()
            self.logger.info("Aspect active %dx%d (%s)", aw, ah, mode)
            ratio = Fraction(aw, ah)
            # Add videoconvert if not already added (needed for v4l2src and other sources)
            if "videoconvert" not in " ! ".join(elements):
                elements.append("videoconvert")
            if self.gst.ElementFactory.find("aspectratiocrop") and "crop" in mode:
                elements.append(f"aspectratiocrop aspect-ratio={ratio.numerator}/{ratio.denominator}")
                elements.append("videoscale")
            else:
                elements.append("videoscale add-borders=true")
            elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False, pixel_aspect=True))
        else:
            # No aspect ratio - add conversion and final caps
            # For v4l2src, we need videoconvert to convert from camera format to I420
            if "v4l2src" in src:
                elements.append("videoconvert")
                elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False))
            elif "libcamerasrc" not in src and src != "rpicam":
                # For other sources (ksvideosrc, etc.), add videoconvert if needed
                elements.append("videoconvert")
                elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False))
            else:
                # For libcamerasrc and rpicam, caps are already set
                elements.append(self._build_video_caps(_even(self.width), _even(self.height), framerate=False))

        elements.extend([
            "queue leaky=2 max-size-buffers=2",
            "appsink name=sink max-buffers=2 drop=true emit-signals=true"
        ])
        desc = " ! ".join(elements)
        self.logger.info("Pipeline: %s", desc)
        return desc

    def _start_rpicam(self):
        """Start rpicam-vid subprocess and return file descriptor."""
        self.logger.info("Starting rpicam-vid subprocess for camera %d", self.cam_id)
        cmd = [
            "rpicam-vid",
            "--camera", str(self.cam_id),
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "--codec", "yuv420",
            "--nopreview", "--timeout", "0", "--flush",
            "-o", "-"
        ]
        
        # Set LD_LIBRARY_PATH only for rpicam-vid (not globally to avoid breaking Python/GStreamer)
        # /opt/rpi-libs contains host's /lib/aarch64-linux-gnu (includes rpicam libraries AND system libraries)
        # With matching GLIBC versions, we can use container's libraries first, then host's rpicam libs
        env = os.environ.copy()
        rpi_libs = "/opt/rpi-libs"  # Host's rpicam libraries
        container_libs = "/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu"  # Container's libraries (should match GLIBC now)
        # Put container's libraries first (they should match GLIBC now), then host's for rpicam
        if "LD_LIBRARY_PATH" in env:
            env["LD_LIBRARY_PATH"] = f"{container_libs}:{rpi_libs}:{env['LD_LIBRARY_PATH']}"
        else:
            env["LD_LIBRARY_PATH"] = f"{container_libs}:{rpi_libs}"
        
        try:
            self._rpicam_proc = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                bufsize=0,
                env=env  # Use modified environment with LD_LIBRARY_PATH
            )
            self._rpicam_pipe_r = self._rpicam_proc.stdout.fileno()
            
            # Log stderr in background
            def log_stderr():
                if self._rpicam_proc and self._rpicam_proc.stderr:
                    for line in iter(self._rpicam_proc.stderr.readline, b''):
                        if line:
                            self.logger.info("rpicam-vid stderr: %s", line.decode('utf-8', errors='ignore').strip())
            
            threading.Thread(target=log_stderr, daemon=True).start()
            return self._rpicam_pipe_r
        except FileNotFoundError:
            self.logger.error("rpicam-vid not found. Is rpicam-apps installed?")
            raise RuntimeError("rpicam-vid not found. Is rpicam-apps installed?")
        except Exception as e:
            self.logger.error(f"Failed to start rpicam-vid: {e}")
            raise RuntimeError(f"Failed to start rpicam-vid: {e}")

    def start(self):
        src = pick_source(self.gst, self.cam_id)
        rpicam_fd = self._start_rpicam() if src == "rpicam" else None
        
        desc = self.build_desc(use_rpicam_fd=rpicam_fd)
        self.pipeline = self.gst.parse_launch(desc)
        sink = self.pipeline.get_by_name("sink")
        sink.connect("new-sample", self.on_sample)
        
        ret = self.pipeline.set_state(self.gst.State.PLAYING)
        if ret == self.gst.StateChangeReturn.FAILURE:
            if self._rpicam_proc:
                self._rpicam_proc.terminate()
                self._rpicam_proc = None
            self.logger.error(f"Pipeline start failed (cam {self.cam_id})")
            raise RuntimeError(f"Pipeline start failed (cam {self.cam_id})")
        self.logger.info("Pipeline started")

    def _stop_rpicam(self):
        """Stop rpicam-vid subprocess gracefully."""
        if not self._rpicam_proc:
            return
        try:
            self._rpicam_proc.terminate()
            try:
                self._rpicam_proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.logger.warning("rpicam-vid didn't terminate gracefully, killing it")
                self._rpicam_proc.kill()
                self._rpicam_proc.wait()
        except Exception as e:
            self.logger.warning("Error terminating rpicam-vid: %s", e)
        finally:
            self._rpicam_proc = None
            self._rpicam_pipe_r = None

    def stop(self):
        if self.pipeline:
            self.pipeline.set_state(self.gst.State.NULL)
            self.pipeline = None
        
        self._stop_rpicam()
        
        for w in list(self.clients):
            w.close()
        self.clients.clear()

    def on_sample(self, sink):
        sample = sink.emit("pull-sample")
        if not sample:
            return self.gst.FlowReturn.ERROR
        caps = sample.get_caps()
        if caps:
            s = caps.get_structure(0)
            ok_w, w = s.get_int("width")
            ok_h, h = s.get_int("height")
            if ok_w and ok_h:
                self.width, self.height = w, h
        buf = sample.get_buffer()
        success, mapinfo = buf.map(self.gst.MapFlags.READ)
        if not success:
            return self.gst.FlowReturn.ERROR
        try:
            payload = bytes(mapinfo.data)
            
            # Black frame detection (check sample and first bytes)
            if payload:
                sample_size = min(1000, len(payload))
                is_black = all(b == 0 for b in payload[:sample_size]) or not any(payload[:32])
                if is_black:
                    self.logger.warning("Sending black frame from camera %d, size=%d", self.cam_id, len(payload))

            # Frame size validation
            pts_us = int(buf.pts / 1000) if buf.pts != self.gst.CLOCK_TIME_NONE else 0
            expected_size = self.width * self.height * 3 // 2
            if len(payload) != expected_size:
                self.logger.warning("Frame size mismatch: payload=%d, expected=%d (w=%d h=%d)", 
                                  len(payload), expected_size, self.width, self.height)

            header = struct.pack(self.cfg.frame_header_fmt, len(payload), self.width, self.height, pts_us, self.cfg.fmt_i420)
            frame = header + payload
            
            # Send frame to all connected clients, removing disconnected ones
            disconnected = []
            for client in list(self.clients):
                try:
                    client.write(frame)
                except Exception as e:
                    self.logger.debug("Error sending frame to client: %s", e)
                    disconnected.append(client)
            
            # Clean up disconnected clients
            for client in disconnected:
                self.clients.discard(client)
                try:
                    client.close()
                except Exception:
                    pass
        finally:
            buf.unmap(mapinfo)
        return self.gst.FlowReturn.OK


class CameraService:
    def __init__(self, cfg: DaemonConfig, gst):
        self.cfg = cfg
        self.gst = gst
        self.pipelines: Dict[int, CameraPipeline] = {}
        self.frame_servers: Dict[int, asyncio.Server] = {}

    async def _handle_frame_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, pipeline: CameraPipeline):
        """Handle a client connecting to receive frames."""
        pipeline.logger.info("Frame client connected for camera %d", pipeline.cam_id)
        pipeline.clients.add(writer)
        try:
            # Keep connection alive - frames are pushed from on_sample callback
            while True:
                # Wait for client to disconnect or error
                await asyncio.sleep(1)
                if writer.is_closing():
                    break
        except Exception as e:
            pipeline.logger.debug("Frame client disconnected: %s", e)
        finally:
            pipeline.clients.discard(writer)
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            pipeline.logger.info("Frame client disconnected for camera %d", pipeline.cam_id)

    async def _start_frame_server(self, cam_id: int, pipeline: CameraPipeline):
        """Start TCP server for frame streaming on port frame_base_port + cam_id."""
        port = self.cfg.frame_base_port + cam_id
        server = await asyncio.start_server(
            lambda r, w: self._handle_frame_client(r, w, pipeline),
            self.cfg.control_host,
            port
        )
        self.frame_servers[cam_id] = server
        # Get actual socket addresses to verify binding
        addrs = [sock.getsockname() for sock in server.sockets]
        pipeline.logger.info("Frame server listening on %s:%d for camera %d (sockets: %s)",
                           self.cfg.control_host, port, cam_id, addrs)
        return server

    async def _stop_frame_server(self, cam_id: int):
        """Stop frame server for camera."""
        server = self.frame_servers.pop(cam_id, None)
        if server:
            server.close()
            await server.wait_closed()
            logging.info("Frame server stopped for camera %d", cam_id)

    async def start(self, cam_id: int, w: int, h: int, fps: int, video_file: Optional[str] = None):
        pipe = CameraPipeline(self.cfg, self.gst, cam_id, w, h, fps, video_file=video_file)
        pipe.start()
        self.pipelines[cam_id] = pipe
        # Start frame server for this camera and wait for it to be ready
        server = await self._start_frame_server(cam_id, pipe)
        # Start serving (this runs in background)
        asyncio.create_task(self._serve_frame_server(server))
        # Give server a moment to be ready
        await asyncio.sleep(0.1)
        return {"status": "started", "id": cam_id}

    async def _serve_frame_server(self, server: asyncio.Server):
        """Run the frame server (needed to keep it serving)."""
        try:
            async with server:
                await server.serve_forever()
        except Exception as e:
            logging.error("Frame server error: %s", e, exc_info=True)

    async def stop(self, cam_id: int):
        await self._stop_frame_server(cam_id)
        p = self.pipelines.pop(cam_id, None)
        if p:
            p.stop()
            return {"status": "stopped", "id": cam_id}
        return {"status": "not_found", "id": cam_id}


async def handle_control(reader, writer, service: CameraService):
    try:
        line = await reader.readline()
        if not line:
            return
        req = json.loads(line.decode())
        cmd = req.get("cmd")
        if cmd == "start":
            try:
                video_file = req.get("video_file")
                # Convert empty string to None
                if video_file == "":
                    video_file = None
                resp = await service.start(
                    int(req.get("id", 0)), 
                    int(req.get("w", 640)), 
                    int(req.get("h", 480)), 
                    int(req.get("fps", 30)),
                    video_file=video_file
                )
            except Exception as e:
                logging.error("Failed to start camera: %s", e, exc_info=True)
                resp = {"error": "start_failed", "details": str(e)}
        elif cmd == "stop":
            try:
                resp = await service.stop(int(req.get("id", 0)))
            except Exception as e:
                logging.error("Failed to stop camera: %s", e, exc_info=True)
                resp = {"error": "stop_failed", "details": str(e)}
        else:
            resp = {"error": "unknown_cmd"}
        
        writer.write((json.dumps(resp) + "\n").encode())
        await writer.drain()
    except Exception as e:
        logging.error("Error in handle_control: %s", e, exc_info=True)
        try:
            error_resp = {"error": "internal_error", "details": str(e)}
            writer.write((json.dumps(error_resp) + "\n").encode())
            await writer.drain()
        except:
            pass
    finally:
        writer.close()
        await writer.wait_closed()


async def main():
    configure_logging()
    cfg = DaemonConfig.from_toml()
    gst = create_gst()
    service = CameraService(cfg, gst)
    server = await asyncio.start_server(partial(handle_control, service=service), cfg.control_host, cfg.control_port)
    # Старт сервиса - важное событие, выводим в stdout для гарантированной видимости
    print(f"[START] Camera daemon started, control server listening on {cfg.control_host}:{cfg.control_port}", file=sys.stdout)
    logging.info("Control server listening on %s:%d", cfg.control_host, cfg.control_port)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Остановка сервиса - важное событие, выводим в stdout для гарантированной видимости
        print("[STOP] Camera daemon stopped", file=sys.stdout)
        logging.info("Camera daemon stopped")
