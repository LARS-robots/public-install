# Camera Daemon

## Назначение

Сервис для захвата видео с камер через GStreamer. Единственный сервис с прямым доступом к камере.

**Основные функции:**
- Захват видео с камер через GStreamer
- Поддержка множественных камер
- IPC (TCP/UDP сокеты) для взаимодействия с FastAPI
- Кроссплатформенность: Raspberry Pi (ARM64), Linux (AMD64), Windows (AMD64)

## Архитектура

- **GStreamer pipeline** для захвата видео
  - Raspberry Pi: `rpicam-vid` (libcamera)
  - Linux Desktop: `v4l2src` (V4L2)
  - Windows: `ksvideosrc` (DirectShow)

- **IPC (TCP/UDP сокеты)** для взаимодействия с FastAPI
  - Control server: TCP для управления камерой (start/stop)
  - Frame server: UDP для передачи кадров

- **Поддержка множественных камер** (до 4 камер одновременно)

## Конфигурация

**Платформо-специфичные compose файлы:**
- `compose.rpi.yml` - Raspberry Pi (ARM64, rpicam-vid)
  - Host networking для доступа к устройствам
  - Доступ к `/dev/video*`, `/dev/i2c*`, `/dev/dri`, `/dev/iio`
- `compose.linux.yml` - Linux Desktop (AMD64, v4l2src)
  - Доступ к `/dev/video*`
- `compose.windows.yml` - Windows (AMD64, ksvideosrc)
  - Bridge networking (не host mode)

**Переменные окружения:**
- `CAMERA_BACKEND` - rpicam | v4l2 | ksvideosrc
- `CONTROL_HOST` - хост для control server (по умолчанию: 0.0.0.0)
- `CONTROL_PORT` - порт для control server (по умолчанию: 8765)
- `FRAME_BASE_PORT` - базовый порт для frame servers (по умолчанию: 8800)
- `MAX_CAMERAS` - максимальное количество камер (по умолчанию: 4)
- `NATS_URL` - URL для NATS логирования (опционально)
- `NATS_LOGGING_ENABLE` - включить/выключить NATS логирование (по умолчанию: 1)

## Интеграция с NATS

**Публикация:**
- Логи: через `nats_logger` в топик `log.*` (JetStream)
- Включено по умолчанию, если указан `NATS_URL`

**НЕ подписывается на команды:**
- Только IPC взаимодействие с FastAPI через TCP/UDP сокеты
- FastAPI управляет камерой через control server
- Кадры передаются через frame servers

**Подробности:** см. `../docs/NATS.md` и `../docs/camera-daemon-architecture.md`

## Документация

- Архитектура камеры: `../docs/camera-daemon-architecture.md`
- Архитектура NATS: `../docs/NATS.md`
- Логирование: `../docs/nats-logging.md`
- Camera setup: `../docs/camera-setup.md`
- Stream video: `../docs/stream-video.md`


