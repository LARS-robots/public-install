import RPi.GPIO as GPIO
import time

RIGHT_PINS = [16]
LEFT_PINS = [12]

PWM_FREQ = 50  # 50 Hz for servo / ESC

PPM_MIN_DC = 5.0     # 1000 µs
PPM_NEUTRAL_DC = 7.5 # 1500 µs
PPM_MAX_DC = 10.0    # 2000 µs

GPIO.setmode(GPIO.BCM)

pwms = []

for pin in RIGHT_PINS + LEFT_PINS:
    GPIO.setup(pin, GPIO.OUT)
    pwm = GPIO.PWM(pin, PWM_FREQ)
    pwm.start(PPM_NEUTRAL_DC)
    pwms.append(pwm)

print("NEUTRAL")
time.sleep(3)

print("FORWARD")
for pwm in pwms:
    pwm.ChangeDutyCycle(8.0)
time.sleep(3)

print("STOP")
for pwm in pwms:
    pwm.ChangeDutyCycle(PPM_NEUTRAL_DC)
time.sleep(1)

for pwm in pwms:
    pwm.stop()

GPIO.cleanup()
