import serial
import time
import string
import pynmea2

port = "/dev/ttyAMA0"   # or "/dev/serial0"
ser = serial.Serial(port, baudrate=9600, timeout=0.5)
dataout = pynmea2.NMEAStreamReader()

while True:
    newdata = ser.readline()  # bytes
    # accept GNRMC or GPRMC; compare as bytes so it matches
    if newdata[:6] in (b"$GPRMC", b"$GNRMC"):
        try:
            newmsg = pynmea2.parse(newdata.decode("ascii", errors="ignore"))
            lat = newmsg.latitude
            lng = newmsg.longitude
            gps = "Latitude=" + str(lat) + " and Longitude=" + str(lng)
            print(gps)
        except pynmea2.ParseError:
            pass
    time.sleep(0.2)