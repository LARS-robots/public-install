#!/usr/bin/env python3
"""
Демон локализации.

Читает одометрию из loc_state/motor_odom (KV) и публикует в:
- loc.state (core NATS, 50 Гц) - основной поток для контроллеров
- loc.state.diag (JetStream, 1-2 Гц) - диагностический поток
- loc_state/current (KV) - последнее состояние для быстрого доступа
"""
import asyncio
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

from config_loader import get_config
from kv_reader import OdometryKVReader
from publisher import LocalizationPublisher
from kv_store import CurrentStateKVStore

# Add nats_logger to path if available as volume (ДО импорта!)
nats_logger_path = Path("/nats_logger")
if nats_logger_path.exists():
    # Добавляем родительскую директорию, так как nats_logger находится в /nats_logger/nats_logger
    sys.path.insert(0, str(nats_logger_path))
else:
    # Try alternative path
    alt_path = Path("/app") / "nats_logger"
    if alt_path.exists():
        sys.path.insert(0, str(alt_path))

# Optional structured logging to NATS
try:
    from nats_logger import NATSHandler
    NATS_LOGGER_AVAILABLE = True
except Exception as e:  # pragma: no cover - optional dependency
    NATSHandler = None
    NATS_LOGGER_AVAILABLE = False
    import logging
    logging.getLogger(__name__).debug(f"nats_logger not available: {e}")

# Унифицированная настройка логирования
try:
    from nats_logger import setup_unified_logging
    # Нормализация NATS_URL: убираем лишние двоеточия и пробелы
    # Это важно, так как некоторые конфиги или env переменные могут содержать лишние символы
    nats_url_for_logging = os.getenv("NATS_URL")
    if nats_url_for_logging:
        nats_url_for_logging = nats_url_for_logging.strip().rstrip(':').rstrip()
        # В Docker контейнере используем имя сервиса "nats" вместо 127.0.0.1
        if os.path.exists("/app") and "127.0.0.1" in nats_url_for_logging:
            nats_url_for_logging = nats_url_for_logging.replace("127.0.0.1", "nats")
            nats_url_for_logging = nats_url_for_logging.strip().rstrip(':').rstrip()
        setup_unified_logging(
            service_name="localization-daemon",
            nats_url=nats_url_for_logging,
        )
except ImportError:
    # Fallback на стандартную настройку если nats_logger не доступен
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.ERROR)
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root.addHandler(sh)
    logging.getLogger(__name__).warning("nats_logger not available, using standard logging only")

log = logging.getLogger(__name__)


class LocalizationDaemon:
    """
    Основной демон локализации.
    
    Читает одометрию из KV и публикует в различные топики NATS.
    """
    
    def __init__(self):
        """Инициализация демона локализации."""
        self.nc: Optional[NATS] = None
        self.config: Dict[str, Any] = {}
        
        # Компоненты
        self.kv_reader: Optional[OdometryKVReader] = None
        self.publisher: Optional[LocalizationPublisher] = None
        self.kv_store: Optional[CurrentStateKVStore] = None
        
        # Параметры из конфига
        self.publish_rate_hz = 50.0
        self.diag_rate_hz = 1.0
        self.publish_period = 1.0 / 50.0  # 50 Гц
        self.diag_period = 1.0 / 1.0  # 1 Гц
        
        # Задачи
        self._main_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Время последней публикации диагностики
        self._last_diag_publish_ts = 0.0
        
        # Статистика
        self.stats = {
            "loop_count": 0,
            "error_count": 0,
            "start_time": time.time(),
        }
    
    def load_config(self) -> Dict[str, Any]:
        """Загрузить конфигурацию."""
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"Loaded config: {cfg.config_path}")
            
            # Параметры локализации
            loc_cfg = self.config.get("localization", {})
            self.publish_rate_hz = float(loc_cfg.get("publish_rate_hz", 50.0))
            self.diag_rate_hz = float(loc_cfg.get("diag_rate_hz", 1.0))
            
            self.publish_period = 1.0 / self.publish_rate_hz if self.publish_rate_hz > 0 else 0.02
            self.diag_period = 1.0 / self.diag_rate_hz if self.diag_rate_hz > 0 else 1.0
            
            log.info(f"[LOC_DAEMON] Config: publish_rate={self.publish_rate_hz}Hz, diag_rate={self.diag_rate_hz}Hz")
        except Exception as e:
            log.warning(f"Failed to load config: {e}")
            self.config = {}
        return self.config

    # Логирование уже настроено при импорте модуля через setup_unified_logging()
    # Метод _setup_nats_logging() больше не нужен
    
    async def initialize(self) -> None:
        """Инициализировать все компоненты."""
        # Загрузить конфигурацию
        self.load_config()
        
        # Подключиться к NATS
        # Приоритет: env переменная > config.toml > default
        nats_url = os.getenv("NATS_URL") or self.config.get("nats", {}).get("url", "nats://dev:devpass@nats:4222")
        # Очистить URL от лишних символов (двоеточия, пробелы)
        # Убираем лишние двоеточия в конце, но сохраняем структуру URL
        nats_url = nats_url.strip()
        # Убрать лишние двоеточия в конце URL (но не внутри)
        while nats_url.endswith(':'):
            nats_url = nats_url[:-1]
        # В Docker используем имя сервиса, на хосте - 127.0.0.1
        if os.path.exists("/app") and "127.0.0.1" in nats_url:
            nats_url = nats_url.replace("127.0.0.1", "nats")
        log.info(f"[LOC_DAEMON] Connecting to NATS: {nats_url}")
        
        try:
            # Парсить URL для извлечения username/password
            from urllib.parse import urlparse
            parsed = urlparse(nats_url)
            
            # Извлечь username и password из URL
            user = None
            password = None
            if parsed.username:
                user = parsed.username
            if parsed.password:
                password = parsed.password
            
            # Обработать порт (может быть None или содержать лишние символы)
            port = 4222  # По умолчанию
            try:
                if parsed.port is not None:
                    # Убрать лишние символы из порта (двоеточия, пробелы)
                    port_str = str(parsed.port).strip().rstrip(':')
                    port = int(port_str) if port_str else 4222
            except (ValueError, TypeError, AttributeError):
                port = 4222
            
            # Если hostname не определен, используем значение из netloc
            hostname = parsed.hostname
            if not hostname and parsed.netloc:
                # Извлечь hostname из netloc (убрать user:pass@ и :port)
                netloc = parsed.netloc
                if '@' in netloc:
                    netloc = netloc.split('@')[1]
                if ':' in netloc:
                    netloc = netloc.split(':')[0]
                hostname = netloc
            
            # Построить URL без авторизации
            server_url = f"{parsed.scheme}://{hostname}:{port}"
            log.debug(f"[LOC_DAEMON] Connecting with server_url={server_url}, user={user}, password={'***' if password else None}")
            
            # Подключиться с авторизацией, если указана
            if user and password:
                self.nc = await nats.connect(server_url, user=user, password=password)
            else:
                self.nc = await nats.connect(server_url)
            log.info("[LOC_DAEMON] Connected to NATS")
        except Exception as e:
            log.error(f"[LOC_DAEMON] Failed to connect to NATS: {e}", exc_info=True)
            print(f"[ERROR] Failed to connect to NATS: {e}", file=sys.stdout, flush=True)
            raise

        # Логирование уже настроено при импорте модуля через setup_unified_logging()
        
        # Инициализировать компоненты
        self.kv_reader = OdometryKVReader(self.nc)
        await self.kv_reader.initialize()
        
        self.publisher = LocalizationPublisher(self.nc)
        await self.publisher.initialize()
        
        self.kv_store = CurrentStateKVStore(self.nc, self.config)
        await self.kv_store.initialize()
        
        log.info("[LOC_DAEMON] All components initialized")
    
    async def start(self) -> None:
        """Запустить демон локализации."""
        if self._running:
            log.warning("[LOC_DAEMON] Already running")
            return
        
        if not self.kv_reader or not self.publisher or not self.kv_store:
            log.error("[LOC_DAEMON] Not initialized, call initialize() first")
            print("[ERROR] Localization daemon not initialized", file=sys.stdout)
            return
        
        print("[START] Localization daemon starting...", file=sys.stdout, flush=True)
        self._running = True
        self._main_task = asyncio.create_task(self._main_loop())
        log.info("[LOC_DAEMON] Started")
        print("[START] Localization daemon started successfully", file=sys.stdout, flush=True)
    
    async def stop(self) -> None:
        """Остановить демон локализации."""
        print("[STOP] Localization daemon shutting down...", file=sys.stdout, flush=True)
        self._running = False
        if self._main_task:
            try:
                await asyncio.wait_for(self._main_task, timeout=2.0)
            except asyncio.TimeoutError:
                self._main_task.cancel()
                try:
                    await self._main_task
                except asyncio.CancelledError:
                    pass
        
        if self.nc:
            await self.nc.close()
        
        log.info("[LOC_DAEMON] Stopped")
        print("[STOP] Localization daemon stopped", file=sys.stdout, flush=True)
    
    async def _main_loop(self) -> None:
        """
        Основной цикл демона локализации.
        
        Логика:
        1. Читает одометрию из KV (50 Гц)
        2. Публикует в loc.state (50 Гц)
        3. Публикует в loc.state.diag (1-2 Гц)
        4. Обновляет loc_state/current (при каждом обновлении)
        """
        while self._running:
            try:
                self.stats["loop_count"] += 1
                current_ts = time.time()
                
                # Читаем одометрию из KV
                odom_data = await self.kv_reader.read_odometry()
                
                if odom_data:
                    # Публикуем в loc.state (каждую итерацию, 50 Гц)
                    state_data = self.publisher.to_state_payload(odom_data)
                    await self.publisher.publish_state(state_data)
                    
                    # Публикуем в loc.state.diag (реже, 1-2 Гц)
                    time_since_diag = current_ts - self._last_diag_publish_ts
                    if time_since_diag >= self.diag_period:
                        await self.publisher.publish_diag(state_data, self.publish_rate_hz)
                        self._last_diag_publish_ts = current_ts
                    
                    # Обновляем loc_state/current (при каждом обновлении)
                    await self.kv_store.update_current(state_data)
                else:
                    # Нет данных одометрии - возможно motor_daemon ещё не запущен
                    # Логируем только периодически, чтобы не спамить
                    if self.stats["loop_count"] % 100 == 0:
                        log.debug("[LOC_DAEMON] No odometry data available (waiting for motor_daemon)")
                
                # Обновляем с фиксированной частотой
                await asyncio.sleep(self.publish_period)
                
            except Exception as e:
                self.stats["error_count"] += 1
                log.error(f"[LOC_DAEMON] Error in main loop: {e}", exc_info=True)
                await asyncio.sleep(0.1)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы демона.
        
        Returns:
            Словарь со статистикой всех компонентов
        """
        stats = self.stats.copy()
        stats["uptime"] = time.time() - self.stats["start_time"]
        
        if self.kv_reader:
            stats["kv_reader"] = self.kv_reader.get_stats()
        if self.publisher:
            stats["publisher"] = self.publisher.get_stats()
        if self.kv_store:
            stats["kv_store"] = self.kv_store.get_stats()
        
        return stats


async def main():
    """Главная функция демона локализации."""
    daemon = LocalizationDaemon()
    
    # Обработка сигналов для graceful shutdown
    def signal_handler(sig, frame):
        log.info("Received signal, shutting down...")
        asyncio.create_task(daemon.stop())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # Инициализация и запуск
        await daemon.initialize()
        await daemon.start()
        
        # Основной цикл ожидания
        while daemon._running:
            await asyncio.sleep(1)
            
            # Периодически логируем статистику (каждые 60 секунд)
            if int(time.time()) % 60 == 0:
                stats = daemon.get_stats()
                log.info(f"[LOC_DAEMON] Stats: loop={stats['loop_count']}, "
                        f"kv_read={stats.get('kv_reader', {}).get('read_count', 0)}, "
                        f"state_pub={stats.get('publisher', {}).get('state_publish_count', 0)}, "
                        f"diag_pub={stats.get('publisher', {}).get('diag_publish_count', 0)}")
    
    except KeyboardInterrupt:
        log.info("Shutting down...")
        print("[STOP] Localization daemon stopped by user", file=sys.stdout)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        print(f"[ERROR] Fatal error: {e}", file=sys.stdout, flush=True)
    finally:
        await daemon.stop()


if __name__ == "__main__":
    asyncio.run(main())

