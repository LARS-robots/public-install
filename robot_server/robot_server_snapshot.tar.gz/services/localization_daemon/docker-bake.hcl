group "default" {
  targets = ["localization-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, overridden from Python

target "localization-daemon-base" {
  context    = "./services/localization_daemon"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Use variable
}

target "localization-daemon-local" {
  inherits = ["localization-daemon-base"]
  tags     = ["localization-daemon:local"]
  output   = ["type=docker"]  # Load into local Docker for compose
}




