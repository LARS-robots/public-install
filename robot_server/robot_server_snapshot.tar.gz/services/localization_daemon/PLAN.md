# План реализации Localization Daemon

## 1. Назначение

Сервис для публикации позиции робота на основе GPS и IMU данных. Получает данные с Raspberry Pi, выполняет GPS+IMU fusion и публикует позицию в NATS Key-Value store.

**Основные функции:**
- Получение данных GPS (u-blox NEO-M8M-0-10) и IMU (MPU-9250/6500) с Raspberry Pi через HTTP API
- GPS+IMU fusion для компенсации погрешности GPS
- Преобразование GPS координат (lat/lon) в локальную систему координат (метры от точки входа)
- Публикация локализации в NATS Key-Value store (bucket `localization`, key `current`)
- Публикация логов через `nats_logger` в топик `log.localization.*`

## 2. Архитектура

```
┌─────────────────┐         HTTP API          ┌──────────────────┐
│  Raspberry Pi   │ ────────────────────────> │ localization_    │
│                 │                           │    daemon         │
│  GPS/IMU Server │ <──────────────────────── │                  │
│  (Flask)        │      GET /localization    │  GPS+IMU Fusion  │
└─────────────────┘                           │  Coordinate      │
                                              │  Transform       │
                                              └────────┬─────────┘
                                                       │
                                                       │ NATS KV
                                                       │
                                              ┌────────▼─────────┐
                                              │  NATS Key-Value  │
                                              │  bucket:         │
                                              │  "localization"  │
                                              │  key: "current"  │
                                              └──────────────────┘
```

**Компоненты:**
- **HTTP клиент** (`gps_imu_client.py`) - опрос GPS/IMU сервера на Raspberry Pi
- **Pose Estimator** (`pose_estimator.py`) - GPS+IMU fusion, преобразование координат
- **NATS Publisher** - публикация в NATS Key-Value store
- **Config Loader** - загрузка конфигурации из `config.toml`

## 3. Формат данных

### Входные данные (от Raspberry Pi)

```json
{
  "timestamp": 1234567890.123,
  "gps": {
    "lat": 55.164441,
    "lon": 61.436843,
    "alt": 200.5,
    "fix_quality": 2,
    "num_satellites": 8,
    "hdop": 1.2,
    "valid": true
  },
  "imu": {
    "accel": {"x": 0.0, "y": 0.0, "z": 9.81},
    "gyro": {"x": 0.0, "y": 0.0, "z": 0.0},
    "mag": {"x": 0.0, "y": 0.0, "z": 0.0},
    "temp": 25.0
  }
}
```

### Выходные данные (в NATS KV)

```json
{
  "timestamp": 1234567890.123,
  "gps": { /* ... */ },
  "imu": { /* ... */ },
  "pose": {
    "lat": 55.164441,
    "lon": 61.436843,
    "yaw": 0.0,
    "source": "gps_imu_fusion",
    "accuracy_m": 2.5
  },
  "local": {
    "x": 0.0,
    "y": 0.0,
    "yaw": 0.0
  }
}
```

## 4. Структура проекта

```
services/localization_daemon/
├── main.py                    # Основной демон (NATS subscriber/publisher)
├── config.toml               # Конфигурация
├── config.example.toml       # Пример конфигурации
├── gps_imu_client.py         # HTTP клиент для опроса GPS/IMU сервера
├── pose_estimator.py          # GPS+IMU fusion, преобразование координат
├── config_loader.py          # Загрузка конфигурации (общий с motor_daemon)
├── requirements.txt
├── Dockerfile
├── docker-bake.hcl           # Multi-platform build
└── README.md
```

## 5. Конфигурация

**`config.toml`:**
```toml
[localization]
# URL GPS/IMU сервера на Raspberry Pi
gps_imu_url = "http://raspberry-pi:5000"

# Период обновления (миллисекунды)
update_interval_ms = 200  # 5 Hz

# NATS настройки
nats_url = "nats://dev:devpass@nats:4222"

[pose_estimator]
# Веса для GPS+IMU fusion (0-1)
gps_weight = 0.7
imu_weight = 0.3
```

## 6. Интеграция с Docker Compose

**Добавить в `compose.yml`:**
```yaml
  localization-daemon:
    build:
      context: ./services/localization_daemon
      dockerfile: Dockerfile
    environment:
      <<: *env
      GPS_IMU_URL: ${GPS_IMU_URL:-http://raspberry-pi:5000}
    depends_on:
      - nats
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

## 7. API интерфейс (будущий функционал)

**Эндпоинты в FastAPI (`services/api/src/app/routers/navigation/localization_router.py`):**
- `GET /localization/current` - получить текущую позицию из NATS KV
- `POST /localization/entry-point` - установить точку входа (начальная позиция)
- `POST /localization/zone` - установить зону уборки (полигон)
- `GET /localization/zone/check` - проверить, находится ли робот в зоне

## 8. Этапы реализации

### Этап 1: Базовая инфраструктура
- [ ] Создать структуру проекта `services/localization_daemon/`
- [ ] Реализовать `gps_imu_client.py` (HTTP клиент)
- [ ] Реализовать `pose_estimator.py` (GPS+IMU fusion, преобразование координат)
- [ ] Реализовать `main.py` (основной демон)
- [ ] Добавить конфигурацию `config.toml`

### Этап 2: Интеграция с NATS
- [ ] Публикация в NATS Key-Value store (bucket `localization`, key `current`)
- [ ] Логирование через `nats_logger` в топик `log.localization.*`
- [ ] Обработка ошибок и переподключение к NATS

### Этап 3: Docker и Compose
- [ ] Создать `Dockerfile`
- [ ] Создать `docker-bake.hcl` для multi-platform build
- [ ] Добавить сервис в `compose.yml`
- [ ] Обновить `compose_service.py` (если нужно)

### Этап 4: API интерфейс (будущий)
- [ ] Создать `localization_router.py` в FastAPI
- [ ] Реализовать эндпоинты для чтения позиции
- [ ] Реализовать проверку границ зоны уборки

### Этап 5: Документация
- [ ] Обновить `services/localization_daemon/README.md`
- [ ] Обновить главный `README.md`
- [ ] Добавить примеры использования

## 9. Зависимости

**Python библиотеки:**
- `nats-py>=2.6.0` - работа с NATS
- `aiohttp>=3.9.0` - HTTP клиент для опроса GPS/IMU сервера

**Внешние сервисы:**
- GPS/IMU сервер на Raspberry Pi (HTTP API на порту 5000)
- NATS сервер (уже есть в проекте)

## 10. Особенности реализации

### GPS+IMU Fusion
- GPS - основной источник абсолютной позиции (lat/lon)
- IMU - dead reckoning между GPS обновлениями
- Взвешенное усреднение: GPS (70%) + IMU (30%)
- Ориентация (yaw) из гироскопа с коррекцией от магнитометра (если доступен)

### Преобразование координат
- GPS (lat/lon) → локальная система (метры от точки входа)
- Используется приближение для небольших расстояний (< 1 км)
- x = восток, y = север

### Обработка ошибок
- Graceful degradation: если GPS недоступен, используется только IMU
- Retry логика для HTTP запросов к GPS/IMU серверу
- Логирование всех ошибок через `nats_logger`

## 11. Тестирование

**Локальное тестирование:**
- Запуск GPS/IMU сервера на Raspberry Pi
- Проверка публикации в NATS KV store
- Проверка преобразования координат

**Интеграционное тестирование:**
- Проверка работы с реальными GPS/IMU данными
- Проверка устойчивости к сбоям GPS сигнала
- Проверка точности позиционирования

## 12. Вопросы для обсуждения

1. **Частота обновления:** Какая частота обновления позиции оптимальна? (предложено 5 Hz)
2. **GPS+IMU веса:** Какие веса для fusion оптимальны? (предложено GPS 70%, IMU 30%)
3. **Точка входа:** Как устанавливать точку входа? Автоматически при первом GPS фиксе или через API?
4. **Зона уборки:** Когда реализовывать проверку границ зоны? В первом этапе или позже?
5. **Обработка ошибок:** Нужна ли подписка на команды движения (`motors`) для синхронизации?
6. **Калибровка IMU:** Нужна ли автоматическая калибровка IMU при старте?
7. **История позиций:** Нужно ли сохранять историю позиций или только текущую?

