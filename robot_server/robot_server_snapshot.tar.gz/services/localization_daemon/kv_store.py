#!/usr/bin/env python3
"""
Обновление loc_state/current в NATS KV store.

Модуль обновляет последнее состояние локализации в KV store для быстрого доступа
без подписки на поток.
"""
import json
import logging
import asyncio
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class CurrentStateKVStore:
    """
    Класс для обновления loc_state/current в NATS KV store.
    
    Обновляет последнее состояние локализации в том же формате, что и loc.state.
    """
    
    def __init__(self, nc: Optional[NATS] = None, config: Optional[Dict[str, Any]] = None):
        """
        Инициализация KV store для current state.
        
        Args:
            nc: соединение NATS (опционально, можно установить позже)
            config: конфигурация (опционально, для retry параметров)
        """
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "loc_state"
        self.key_name = "current"
        
        # Параметры retry из конфига
        if config:
            loc_cfg = config.get("localization", {})
            self.retry_count = int(loc_cfg.get("kv_retry_count", 3))
            self.retry_delay = float(loc_cfg.get("kv_retry_delay", 0.1))
        else:
            self.retry_count = 3
            self.retry_delay = 0.1
        
        # Статистика
        self.stats = {
            "update_count": 0,
            "error_count": 0,
            "retry_count": 0,
            "last_update_ts": None,
        }
    
    async def initialize(self) -> None:
        """
        Инициализировать доступ к JetStream и KV store.
        
        Логика:
        - создаём контекст JetStream на существующем соединении NATS;
        - пробуем создать или получить KV‑бакет `loc_state`;
        - если бакет уже существует — просто получаем его.
        """
        try:
            if not self.nc:
                log.warning("[KV_STORE] NATS connection not available")
                return
            
            # Создаём контекст JetStream поверх существующего соединения
            self.js = self.nc.jetstream()
            
            # Пробуем создать или получить KV‑бакет
            try:
                # Пытаемся создать новый бакет
                self.kv = await self.js.create_key_value(bucket=self.bucket_name)
                log.info(f"[KV_STORE] KV store bucket '{self.bucket_name}' initialized")
            except Exception as e:
                # Если бакет уже существует, пробуем просто к нему подключиться
                try:
                    self.kv = await self.js.key_value(bucket=self.bucket_name)
                    log.info(f"[KV_STORE] KV store bucket '{self.bucket_name}' retrieved")
                except Exception:
                    log.error(f"[KV_STORE] Failed to create or get KV bucket '{self.bucket_name}': {e}")
                    self.kv = None
        except Exception as e:
            log.error(f"[KV_STORE] Failed to initialize KV store: {e}", exc_info=True)
            self.kv = None
    
    async def update_current(self, state_data: Dict[str, Any]) -> None:
        """
        Обновить loc_state/current с последним состоянием.
        
        Args:
            state_data: данные состояния в формате loc.state (JSON-совместимый словарь)
            
        Формат данных:
        - Точно такой же JSON, как в loc.state
        """
        if not self.kv:
            return
        
        try:
            # Сериализуем в компактный JSON
            state_json = json.dumps(state_data, separators=(',', ':'))
            
            # Публикуем с retry логикой
            success = await self._update_with_retry(state_json.encode())
            
            if success:
                self.stats["update_count"] += 1
                self.stats["last_update_ts"] = state_data.get("ts")
                log.debug(f"[KV_STORE] Updated loc_state/current: x={state_data.get('x', 0):.3f}, y={state_data.get('y', 0):.3f}")
            else:
                self.stats["error_count"] += 1
                
        except Exception as e:
            self.stats["error_count"] += 1
            log.error(f"[KV_STORE] Failed to update current state: {e}", exc_info=True)
    
    async def _update_with_retry(self, data: bytes) -> bool:
        """
        Обновление в KV store с повторными попытками.
        
        Args:
            data: данные для обновления (JSON в байтах)
            
        Returns:
            True если обновление успешно, False иначе
        """
        for attempt in range(self.retry_count):
            try:
                await self.kv.put(self.key_name, data)
                return True
            except Exception as e:
                if attempt < self.retry_count - 1:
                    self.stats["retry_count"] += 1
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    log.debug(f"[KV_STORE] Retry {attempt + 1}/{self.retry_count}: {e}")
                else:
                    log.error(f"[KV_STORE] Failed to update after {self.retry_count} attempts: {e}", exc_info=True)
                    return False
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы KV store.
        
        Returns:
            Словарь со статистикой
        """
        return self.stats.copy()





