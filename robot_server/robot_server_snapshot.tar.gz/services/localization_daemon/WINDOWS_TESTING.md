# Тестирование Localization Daemon на Windows

Этот документ описывает временные изменения, необходимые для тестирования демона локализации на Windows с Docker Desktop.

## Проблема

На Windows Docker Desktop `network_mode: host` работает некорректно — контейнеры не могут использовать сетевой стек хоста так же, как на Linux. Это требует временных изменений в `compose.yml` для тестирования.

## Временные изменения для Windows

### 1. Изменения в `compose.yml`

#### API сервис

**Закомментировать:**
```yaml
# network_mode: host
# group_add:
#   - video
```

**Изменить NATS_URL:**
```yaml
environment:
  NATS_URL: ${NATS_URL:-nats://dev:devpass@nats:4222}  # Используем имя сервиса вместо 127.0.0.1
```

**Причина:** Без `network_mode: host` контейнеры находятся в bridge network, где нужно использовать имя сервиса `nats` вместо `127.0.0.1`.

#### Camera-daemon

**Закомментировать весь сервис** (если не нужен для тестирования локализации):
```yaml
# camera-daemon:
#   image: camera-daemon:latest
#   ...
```

**Закомментировать зависимость API от camera-daemon:**
```yaml
depends_on:
  - nats
  # - camera-daemon
```

**Причина:** Для тестирования локализации камера не обязательна, и это упрощает запуск стека.

### 2. Изменения в `scripts/compose_service.py`

**Закомментировать логику camera и motor override-файлов:**
```python
# Закомментировано для тестирования локализации - не нужны camera и motor
# # Add camera override if exists
# camera_compose = get_camera_compose_path(root, platform_type)
# if camera_compose:
#     compose_files.append(str(camera_compose))
#
# # Get motor compose override using mapper
# ...
```

**Причина:** Для быстрого тестирования локализации не нужны camera и motor override-файлы.

## Как использовать

1. **Применить изменения** для Windows (см. выше)
2. **Собрать образы:**
   ```bash
   docker build -f services/localization_daemon/Dockerfile -t localization-daemon:latest .
   docker build -t lars-api:dev services/api
   ```
3. **Запустить стек:**
   ```bash
   python scripts/compose_service.py up
   ```
4. **Проверить работу:**
   ```bash
   # Логи локализации
   docker compose logs -f localization-daemon
   
   # Debug-эндпоинты API
   curl http://127.0.0.1:8000/debug/localization/current
   curl http://127.0.0.1:8000/debug/localization/diag
   ```

## Важно

⚠️ **Эти изменения временные и только для тестирования на Windows!**

Перед коммитом и пушем в репозиторий:
- Верните `network_mode: host` для API
- Верните `NATS_URL` с `127.0.0.1` для host network
- Раскомментируйте `camera-daemon` и зависимость API
- Раскомментируйте логику camera и motor в `compose_service.py`

На Linux/Raspberry Pi используйте стандартную конфигурацию без этих изменений.

## Альтернатива

Если нужно тестировать на Windows без изменений в коде:
- Используйте WSL2 с Docker Desktop — там `network_mode: host` работает корректно
- Или используйте Linux виртуальную машину для разработки

