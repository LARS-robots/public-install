#!/usr/bin/env python3
"""
Чтение одометрии из NATS KV store.

Модуль читает данные одометрии из loc_state/motor_odom (KV) и предоставляет
их для публикации в loc.state и loc.state.diag.
"""
import json
import logging
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class OdometryKVReader:
    """
    Класс для чтения одометрии из NATS KV store.
    
    Читает данные из loc_state/motor_odom и валидирует формат.
    """
    
    def __init__(self, nc: Optional[NATS] = None):
        """
        Инициализация читателя одометрии.
        
        Args:
            nc: соединение NATS (опционально, можно установить позже)
        """
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "loc_state"
        self.key_name = "motor_odom"
        
        # Статистика
        self.stats = {
            "read_count": 0,
            "error_count": 0,
            "last_read_ts": None,
            "last_data": None,
        }
    
    async def initialize(self) -> None:
        """
        Инициализировать доступ к JetStream и KV store.
        
        Логика:
        - создаём контекст JetStream на существующем соединении NATS;
        - получаем KV‑бакет `loc_state`;
        - если бакет не существует — логируем предупреждение.
        """
        try:
            if not self.nc:
                log.warning("[KV_READER] NATS connection not available")
                return
            
            # Создаём контекст JetStream поверх существующего соединения
            self.js = self.nc.jetstream()
            
            # Пробуем получить KV‑бакет
            try:
                self.kv = await self.js.key_value(bucket=self.bucket_name)
                log.info(f"[KV_READER] KV store bucket '{self.bucket_name}' connected")
            except Exception as e:
                log.warning(f"[KV_READER] KV bucket '{self.bucket_name}' not found: {e}")
                log.warning(f"[KV_READER] Make sure motor_daemon is running and has published odometry")
                self.kv = None
        except Exception as e:
            log.error(f"[KV_READER] Failed to initialize KV reader: {e}", exc_info=True)
            self.kv = None
    
    async def read_odometry(self) -> Optional[Dict[str, Any]]:
        """
        Прочитать одометрию из KV store.
        
        Returns:
            Словарь с данными одометрии или None если данные недоступны.
            
        Формат данных:
        {
            "ts": float,
            "frame": "robot",
            "x": float,
            "y": float,
            "yaw": float,
            "vx": float,
            "vy": float,
            "omega": float,
            "cov_x": float,
            "cov_y": float,
            "cov_yaw": float,
            "status": "ok",
            "source": "motor_commands"
        }
        """
        if not self.kv:
            return None
        
        try:
            # Читаем значение из KV
            entry = await self.kv.get(self.key_name)
            if not entry:
                return None
            
            # Парсим JSON
            data = json.loads(entry.value.decode('utf-8'))
            
            # Валидация обязательных полей
            required_fields = ["ts", "frame", "x", "y", "yaw", "vx", "vy", "omega", "status"]
            missing_fields = [field for field in required_fields if field not in data]
            if missing_fields:
                log.warning(f"[KV_READER] Missing required fields: {missing_fields}")
                return None
            
            # Обновляем статистику
            self.stats["read_count"] += 1
            self.stats["last_read_ts"] = data.get("ts")
            self.stats["last_data"] = data
            
            return data
            
        except json.JSONDecodeError as e:
            self.stats["error_count"] += 1
            log.error(f"[KV_READER] Failed to parse JSON from KV: {e}")
            return None
        except Exception as e:
            self.stats["error_count"] += 1
            log.error(f"[KV_READER] Failed to read odometry from KV: {e}", exc_info=True)
            return None
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы читателя.
        
        Returns:
            Словарь со статистикой
        """
        return self.stats.copy()



