# localization_daemon/config_loader.py
"""
Configuration loader for localization daemon.

This module provides configuration loading from TOML files for the localization daemon.
"""
from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any

# TOML loader (Py3.11+/older)
try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore

logger = logging.getLogger(__name__)

# ============================================================================
# PATH RESOLUTION
# ============================================================================

def _get_config_search_paths() -> list[Path]:
    """
    Returns prioritized list of paths to search for config.toml.
    
    Order of precedence:
    1. /app/config.toml (localization_daemon's own config in container - highest priority)
    2. Current working directory config.toml (for local development)
    3. Relative to this module: localization_daemon/config.toml
    4. Fallback to shared config paths
    """
    paths = [
        # Localization daemon's own config in container (highest priority)
        Path("/app/config.toml"),
        
        # Current working directory (for local development)
        Path.cwd() / "config.toml",
        
        # Relative to this module (localization_daemon/config.toml)
        Path(__file__).resolve().parent / "config.toml",
        
        # Fallback to shared config paths
        Path("/config/config.toml"),  # Docker container mounted volume
        Path("/app/config/config.toml"),  # Docker container API config path
        Path.cwd() / "src/config/config.toml",
    ]
    
    return paths


def find_config_file() -> Optional[Path]:
    """
    Locate the config.toml file using the search path hierarchy.
    
    Returns:
        Path to config.toml if found, None otherwise
    """
    for path in _get_config_search_paths():
        if path.exists() and path.is_file():
            logger.info(f"✅ Found config at: {path}")
            return path
    
    logger.warning(f"❌ No config file found! Searched paths:")
    for path in _get_config_search_paths():
        logger.warning(f"  - {path}")
    return None


# ============================================================================
# CONFIG LOADER
# ============================================================================

class ConfigLoader:
    """
    Thread-safe singleton config loader for localization daemon.
    """
    _instance: Optional["ConfigLoader"] = None
    
    def __init__(self):
        self._config: Optional[Dict[str, Any]] = None
        self._config_path: Optional[Path] = None
    
    @classmethod
    def get_instance(cls) -> "ConfigLoader":
        """Get singleton instance."""
        if cls._instance is None:
            cls._instance = ConfigLoader()
        return cls._instance
    
    def get_config(self, reload: bool = False) -> Dict[str, Any]:
        """
        Get cached config or load if not yet loaded.
        
        Args:
            reload: Force reload from disk
            
        Returns:
            Dictionary of config data
        """
        if self._config is None or reload:
            config_path = find_config_file()
            if not config_path:
                logger.warning("No config file found, using empty config")
                self._config = {}
                self._config_path = None
                return self._config
            
            with open(config_path, "rb") as f:
                self._config = tomllib.load(f)
            self._config_path = config_path
            logger.info(f"✅ Loaded config from: {config_path}")
        
        return self._config
    
    @property
    def config_path(self) -> Optional[Path]:
        """Get the path to the loaded config file."""
        if self._config_path is None:
            self.get_config()  # Load config if not loaded
        return self._config_path
    
    @property
    def raw_data(self) -> Dict[str, Any]:
        """Get raw config data."""
        return self.get_config()


# ============================================================================
# PUBLIC API
# ============================================================================

def get_config_loader() -> ConfigLoader:
    """Get the singleton ConfigLoader instance."""
    return ConfigLoader.get_instance()


def get_config(reload: bool = False) -> ConfigLoader:
    """
    Get the configuration loader.
    
    Args:
        reload: Force reload from disk
        
    Returns:
        ConfigLoader instance with raw_data property
    """
    loader = get_config_loader()
    loader.get_config(reload=reload)
    return loader













