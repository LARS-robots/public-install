#!/usr/bin/env python3
"""
Публикация состояния локализации в NATS.

Модуль публикует данные локализации в:
- loc.state (core NATS, 50 Гц) - основной поток для контроллеров
- loc.state.diag (JetStream, 1-2 Гц) - диагностический поток
"""
import json
import logging
import time
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class LocalizationPublisher:
    """
    Класс для публикации состояния локализации в NATS.
    
    Публикует данные в loc.state и loc.state.diag согласно спецификации.
    """
    
    def __init__(self, nc: Optional[NATS] = None):
        """
        Инициализация публикатора.
        
        Args:
            nc: соединение NATS (опционально, можно установить позже)
        """
        self.nc = nc
        self.js = None
        
        # Счётчики для диагностики
        self.seq_counter = 0
        self.start_time = time.time()
        
        # Статистика
        self.stats = {
            "state_publish_count": 0,
            "diag_publish_count": 0,
            "state_error_count": 0,
            "diag_error_count": 0,
            "last_state_publish_ts": None,
            "last_diag_publish_ts": None,
        }
    
    async def initialize(self) -> None:
        """
        Инициализировать доступ к JetStream для loc.state.diag.
        
        loc.state использует core NATS (не требует JetStream).
        """
        try:
            if not self.nc:
                log.warning("[PUBLISHER] NATS connection not available")
                return
            
            # Создаём контекст JetStream для loc.state.diag
            self.js = self.nc.jetstream()
            
            # Создать JetStream stream для loc.state.diag, если его нет
            await self._create_jetstream_stream()
            
            log.info("[PUBLISHER] Initialized for loc.state and loc.state.diag")
        except Exception as e:
            log.error(f"[PUBLISHER] Failed to initialize: {e}", exc_info=True)
            self.js = None
    
    async def _create_jetstream_stream(self) -> None:
        """Создать JetStream stream для loc.state.diag, если его нет."""
        try:
            await self.js.add_stream(
                name="LOC_STATE_DIAG",
                subjects=["loc.state.diag"],
                storage="file",  # File storage для персистентности
                retention="limits",  # Retention policy
            )
            log.info("✅ Created JetStream stream 'LOC_STATE_DIAG' for subject 'loc.state.diag'")
        except Exception as e:
            error_str = str(e).lower()
            # Stream может уже существовать - это нормально
            if "stream name already in use" in error_str or "stream already exists" in error_str:
                log.info("ℹ️  JetStream stream 'LOC_STATE_DIAG' already exists")
            else:
                log.warning(f"[PUBLISHER] Failed to create JetStream stream: {e}")
                # Не прерываем инициализацию - можно попробовать публиковать без stream
    
    def to_state_payload(self, odom_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Преобразовать данные одометрии motor_odom в полезную нагрузку loc.state.
        """
        payload = {
            "ts": odom_data.get("ts"),
            "frame": odom_data.get("frame", "robot"),
            "x": odom_data.get("x", 0.0),
            "y": odom_data.get("y", 0.0),
            "yaw": odom_data.get("yaw", 0.0),
            "vx": odom_data.get("vx", 0.0),
            "vy": odom_data.get("vy", 0.0),
            "omega": odom_data.get("omega", 0.0),
            "cov_x": odom_data.get("cov_x", 0.01),
            "cov_y": odom_data.get("cov_y", 0.01),
            "cov_yaw": odom_data.get("cov_yaw", 0.0004),
            "status": odom_data.get("status", "ok"),
            "sources": "odom",
        }
        
        # Добавляем географические координаты, если они есть (для логирования и отображения)
        if odom_data.get("lat") is not None:
            payload["lat"] = odom_data.get("lat")
        if odom_data.get("lon") is not None:
            payload["lon"] = odom_data.get("lon")
        if odom_data.get("start_lat") is not None:
            payload["start_lat"] = odom_data.get("start_lat")
        if odom_data.get("start_lon") is not None:
            payload["start_lon"] = odom_data.get("start_lon")
        
        return payload

    async def publish_state(self, state_data: Dict[str, Any]) -> None:
        """
        Опубликовать состояние в loc.state (core NATS).
        
        Args:
            state_data: данные в формате loc.state
            
        Формат loc.state:
        - Тот же формат, что и motor_odom, но поле "source" заменяется на "sources: 'odom'"
        """
        # ДИАГНОСТИКА: проверяем NATS соединение
        if not self.nc:
            log.warning("[PUBLISHER] NATS connection not available, skipping publish")
            return
        
        # Увеличиваем счетчик ДО публикации, чтобы логи работали даже при ошибках
        self.stats["state_publish_count"] += 1
        
        # ДИАГНОСТИКА: логируем каждое 10-е сообщение для проверки работы
        if self.stats["state_publish_count"] % 10 == 0:
            log.info(f"[PUBLISHER] Attempting to publish #{self.stats['state_publish_count']}")
        
        # Подготовка данных для логирования (вне try-except, чтобы всегда работало)
        x = state_data.get('x')
        y = state_data.get('y')
        yaw = state_data.get('yaw')
        
        # Безопасное форматирование для debug лога
        x_str = f"{x:.3f}" if x is not None else "N/A"
        y_str = f"{y:.3f}" if y is not None else "N/A"
        yaw_str = f"{yaw:.3f}" if yaw is not None else "N/A"
        
        # Публикуем (с обработкой ошибок)
        try:
            # Сериализуем в компактный JSON (jsonl формат)
            state_json = json.dumps(state_data, separators=(',', ':'))
            
            # Публикуем в core NATS (не JetStream)
            await self.nc.publish("loc.state", state_json.encode())
            
            # Обновляем статистику успешной публикации
            self.stats["last_state_publish_ts"] = time.time()
            
            log.debug(f"[PUBLISHER] Published to loc.state: x={x_str}, y={y_str}, yaw={yaw_str}")
            
        except Exception as e:
            self.stats["state_error_count"] += 1
            log.error(f"[PUBLISHER] Failed to publish to loc.state: {e}", exc_info=True)
        
        # Логирование координат ВСЕГДА (вне try-except, чтобы всегда работало)
        lat = state_data.get('lat')
        lon = state_data.get('lon')
        world_x = state_data.get('world_x', state_data.get('x'))
        world_y = state_data.get('world_y', state_data.get('y'))
        origin = state_data.get('origin', {})
        origin_lat = state_data.get('start_lat') or origin.get('lat')
        origin_lon = state_data.get('start_lon') or origin.get('lon')
        
        # Безопасное форматирование для всех значений (чтобы избежать ошибки с None)
        lat_str = f"{lat:.6f}" if lat is not None else "N/A"
        lon_str = f"{lon:.6f}" if lon is not None else "N/A"
        world_x_str = f"{world_x:.3f}" if world_x is not None else "N/A"
        world_y_str = f"{world_y:.3f}" if world_y is not None else "N/A"
        origin_lat_str = f"{origin_lat:.6f}" if origin_lat is not None else "N/A"
        origin_lon_str = f"{origin_lon:.6f}" if origin_lon is not None else "N/A"
        
        # Формируем строку координат: предпочитаем lat/lon, если доступны, иначе x/y
        if lat is not None and lon is not None:
            coords_str = f"World(lat={lat_str}, lon={lon_str}"
            if origin_lat is not None and origin_lon is not None:
                coords_str += f", origin=({origin_lat_str}, {origin_lon_str}))"
            else:
                coords_str += ")"
        else:
            # Fallback на x/y если lat/lon недоступны
            coords_str = f"World(x={world_x_str}m, y={world_y_str}m)"
        
        # Логируем на уровне INFO каждое 50-е сообщение (для видимости)
        if self.stats["state_publish_count"] % 50 == 0:
            log.info(f"[COORDS] Published localization #{self.stats['state_publish_count']}: "
                    f"Robot(x={x_str}m, y={y_str}m, yaw={yaw_str}rad) | {coords_str}")
        else:
            # DEBUG для остальных сообщений
            log.debug(f"[COORDS] Published localization: "
                    f"Robot(x={x_str}m, y={y_str}m, yaw={yaw_str}rad) | {coords_str}")
    
    async def publish_diag(self, state_data: Dict[str, Any], update_rate: float) -> None:
        """
        Опубликовать диагностику в loc.state.diag (JetStream).
        
        Args:
            state_data: данные в формате loc.state
            update_rate: частота обновления (Гц)
            
        Формат loc.state.diag:
        - Все поля из loc.state + дополнительные диагностические поля
        """
        if not self.js:
            return
        
        try:
            # Преобразуем формат motor_odom в формат loc.state
            diag_data = dict(state_data)
            diag_data.update(
                {
                    "seq": self.seq_counter,
                    "uptime": time.time() - self.start_time,
                    "update_rate": update_rate,
                }
            )
            
            # Увеличиваем счётчик
            self.seq_counter += 1
            
            # Сериализуем в компактный JSON (jsonl формат)
            diag_json = json.dumps(diag_data, separators=(',', ':'))
            
            # Публикуем в JetStream
            await self.js.publish("loc.state.diag", diag_json.encode())
            
            # Обновляем статистику
            self.stats["diag_publish_count"] += 1
            self.stats["last_diag_publish_ts"] = time.time()
            
            log.debug(f"[PUBLISHER] Published to loc.state.diag: seq={self.seq_counter}, uptime={diag_data['uptime']:.1f}s")
            
        except Exception as e:
            self.stats["diag_error_count"] += 1
            log.error(f"[PUBLISHER] Failed to publish to loc.state.diag: {e}", exc_info=True)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы публикатора.
        
        Returns:
            Словарь со статистикой
        """
        stats = self.stats.copy()
        stats["seq_counter"] = self.seq_counter
        stats["uptime"] = time.time() - self.start_time
        return stats

