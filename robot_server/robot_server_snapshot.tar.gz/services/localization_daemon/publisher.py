#!/usr/bin/env python3
"""
Публикация состояния локализации в NATS.

Модуль публикует данные локализации в:
- loc.state (core NATS, 50 Гц) - основной поток для контроллеров
- loc.state.diag (JetStream, 1-2 Гц) - диагностический поток
"""
import json
import logging
import time
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class LocalizationPublisher:
    """
    Класс для публикации состояния локализации в NATS.
    
    Публикует данные в loc.state и loc.state.diag согласно спецификации.
    """
    
    def __init__(self, nc: Optional[NATS] = None):
        """
        Инициализация публикатора.
        
        Args:
            nc: соединение NATS (опционально, можно установить позже)
        """
        self.nc = nc
        self.js = None
        
        # Счётчики для диагностики
        self.seq_counter = 0
        self.start_time = time.time()
        
        # Статистика
        self.stats = {
            "state_publish_count": 0,
            "diag_publish_count": 0,
            "state_error_count": 0,
            "diag_error_count": 0,
            "last_state_publish_ts": None,
            "last_diag_publish_ts": None,
        }
    
    async def initialize(self) -> None:
        """
        Инициализировать доступ к JetStream для loc.state.diag.
        
        loc.state использует core NATS (не требует JetStream).
        """
        try:
            if not self.nc:
                log.warning("[PUBLISHER] NATS connection not available")
                return
            
            # Создаём контекст JetStream для loc.state.diag
            self.js = self.nc.jetstream()
            
            # Создать JetStream stream для loc.state.diag, если его нет
            await self._create_jetstream_stream()
            
            log.info("[PUBLISHER] Initialized for loc.state and loc.state.diag")
        except Exception as e:
            log.error(f"[PUBLISHER] Failed to initialize: {e}", exc_info=True)
            self.js = None
    
    async def _create_jetstream_stream(self) -> None:
        """Создать JetStream stream для loc.state.diag, если его нет."""
        try:
            await self.js.add_stream(
                name="LOC_STATE_DIAG",
                subjects=["loc.state.diag"],
                storage="file",  # File storage для персистентности
                retention="limits",  # Retention policy
            )
            log.info("✅ Created JetStream stream 'LOC_STATE_DIAG' for subject 'loc.state.diag'")
        except Exception as e:
            error_str = str(e).lower()
            # Stream может уже существовать - это нормально
            if "stream name already in use" in error_str or "stream already exists" in error_str:
                log.info("ℹ️  JetStream stream 'LOC_STATE_DIAG' already exists")
            else:
                log.warning(f"[PUBLISHER] Failed to create JetStream stream: {e}")
                # Не прерываем инициализацию - можно попробовать публиковать без stream
    
    def to_state_payload(self, odom_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Преобразовать данные одометрии motor_odom в полезную нагрузку loc.state.
        """
        return {
            "ts": odom_data.get("ts"),
            "frame": odom_data.get("frame", "robot"),
            "x": odom_data.get("x", 0.0),
            "y": odom_data.get("y", 0.0),
            "yaw": odom_data.get("yaw", 0.0),
            "vx": odom_data.get("vx", 0.0),
            "vy": odom_data.get("vy", 0.0),
            "omega": odom_data.get("omega", 0.0),
            "cov_x": odom_data.get("cov_x", 0.01),
            "cov_y": odom_data.get("cov_y", 0.01),
            "cov_yaw": odom_data.get("cov_yaw", 0.0004),
            "status": odom_data.get("status", "ok"),
            "sources": "odom",
        }

    async def publish_state(self, state_data: Dict[str, Any]) -> None:
        """
        Опубликовать состояние в loc.state (core NATS).
        
        Args:
            state_data: данные в формате loc.state
            
        Формат loc.state:
        - Тот же формат, что и motor_odom, но поле "source" заменяется на "sources: 'odom'"
        """
        if not self.nc:
            return
        
        try:
            # Сериализуем в компактный JSON (jsonl формат)
            state_json = json.dumps(state_data, separators=(',', ':'))
            
            # Публикуем в core NATS (не JetStream)
            await self.nc.publish("loc.state", state_json.encode())
            
            # Обновляем статистику
            self.stats["state_publish_count"] += 1
            self.stats["last_state_publish_ts"] = time.time()
            
            log.debug(f"[PUBLISHER] Published to loc.state: x={state_data['x']:.3f}, y={state_data['y']:.3f}, yaw={state_data['yaw']:.3f}")
            
        except Exception as e:
            self.stats["state_error_count"] += 1
            log.error(f"[PUBLISHER] Failed to publish to loc.state: {e}", exc_info=True)
    
    async def publish_diag(self, state_data: Dict[str, Any], update_rate: float) -> None:
        """
        Опубликовать диагностику в loc.state.diag (JetStream).
        
        Args:
            state_data: данные в формате loc.state
            update_rate: частота обновления (Гц)
            
        Формат loc.state.diag:
        - Все поля из loc.state + дополнительные диагностические поля
        """
        if not self.js:
            return
        
        try:
            # Преобразуем формат motor_odom в формат loc.state
            diag_data = dict(state_data)
            diag_data.update(
                {
                    "seq": self.seq_counter,
                    "uptime": time.time() - self.start_time,
                    "update_rate": update_rate,
                }
            )
            
            # Увеличиваем счётчик
            self.seq_counter += 1
            
            # Сериализуем в компактный JSON (jsonl формат)
            diag_json = json.dumps(diag_data, separators=(',', ':'))
            
            # Публикуем в JetStream
            await self.js.publish("loc.state.diag", diag_json.encode())
            
            # Обновляем статистику
            self.stats["diag_publish_count"] += 1
            self.stats["last_diag_publish_ts"] = time.time()
            
            log.debug(f"[PUBLISHER] Published to loc.state.diag: seq={self.seq_counter}, uptime={diag_data['uptime']:.1f}s")
            
        except Exception as e:
            self.stats["diag_error_count"] += 1
            log.error(f"[PUBLISHER] Failed to publish to loc.state.diag: {e}", exc_info=True)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы публикатора.
        
        Returns:
            Словарь со статистикой
        """
        stats = self.stats.copy()
        stats["seq_counter"] = self.seq_counter
        stats["uptime"] = time.time() - self.start_time
        return stats

