# nats_logger

NATS logging handler для проекта LARS.

Библиотека для унифицированного логирования во всех сервисах проекта. Обеспечивает разделение на два канала:
- **stdout** — только триггерные события ([START], [STOP], [ERROR]) для оператора
- **NATS** — все события (INFO, WARNING, ERROR, CRITICAL) для детального анализа

## Установка

```bash
cd services/nats_logger
pip install -e .
```

Или добавьте в зависимости проекта:
```toml
dependencies = [
    "nats-logger @ file:///path/to/services/nats_logger",
]
```

## Быстрый старт

### Рекомендуемый способ (для всех сервисов)

Используйте `setup_unified_logging()` для единообразной настройки:

```python
import os
from nats_logger import setup_unified_logging
import logging

# Настройка логирования (stdout только ERROR, все события в NATS)
setup_unified_logging(
    service_name="my-service",
    nats_url=os.getenv("NATS_URL"),
    enable_nats=True,
)

# Использование
log = logging.getLogger(__name__)
log.info("Hello from NATS!", extra={"event": {"stage": "test"}})
```

**Результат:**
- stdout: только ERROR/CRITICAL (триггерные события)
- NATS: все события (INFO, WARNING, ERROR, CRITICAL)

### Прямое использование NATSHandler (для кастомных случаев)

```python
import logging
from nats_logger import NATSHandler

# Создание handler
handler = NATSHandler(
    nats_url="nats://127.0.0.1:4222",
    service_name="my-service",
)

# Добавление handler
logging.getLogger().addHandler(handler)
```

## Конфигурация

### Через config.toml

```toml
[nats]
url = "nats://127.0.0.1:4222"

[nats.logging]
enable = true
service_name = "api"
subject_prefix = "log"  # Формат: log.{service}.{level}
batch_size = 10
batch_timeout = 1.0
queue_size = 1000
fallback_on_error = true
enable_secondary_subjects = true
```

### Через переменные окружения

```bash
export NATS_URL=nats://127.0.0.1:4222
export SERVICE_NAME=api
export NATS_BATCH_SIZE=10
export NATS_BATCH_TIMEOUT=1.0
export NATS_QUEUE_SIZE=1000
```

## Особенности

- ✅ **Унифицированная настройка** - `setup_unified_logging()` для всех сервисов
- ✅ **Разделение каналов** - stdout только для триггерных событий, NATS для всех событий
- ✅ **Асинхронная отправка** - не блокирует основной поток
- ✅ **Батчинг** - уменьшает нагрузку на NATS
- ✅ **Очередь с лимитом** - контролирует использование памяти
- ✅ **Отказоустойчивость** - fallback при ошибках NATS
- ✅ **Thread-safe** - безопасная работа из разных потоков
- ✅ **Автоматическое определение** - service_name и hostname определяются автоматически

## NATS Subjects

Формат: `{prefix}.{service}.{level}`

Примеры:
- `log.api.INFO` - INFO логи от API
- `log.api.ERROR` - ERROR логи от API
- `log.camera-daemon.WARNING` - WARNING логи от camera-daemon
- `log.motor-daemon.INFO` - INFO логи от motor-daemon

## Формат событий (Схема)

Все события логирования должны соответствовать следующей схеме:

### Обязательные поля

- `ts`: str - ISO 8601 timestamp (формат: `YYYY-MM-DDTHH:MM:SS`)
- `level`: str - Уровень логирования (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`)
- `logger`: str - Имя logger (например, `app.services.motor.motor_service`)
- `msg`: str - Текстовое сообщение (обязательно, если нет поля `event`)
- `service`: str - Имя сервиса (например, `api`, `camera-daemon`)
- `hostname`: str - Hostname сервера
- `pid`: int - Process ID

### Опциональные поля

- `event`: dict - Структурированные данные события (рекомендуется для важных событий)
- `exception`: dict - Информация об исключении (автоматически добавляется при логировании исключений)
- `extra`: dict - Дополнительные поля

### Пример события

```json
{
  "ts": "2024-01-15T10:30:45",
  "level": "INFO",
  "logger": "app.services.motor.motor_service",
  "msg": "Route planned successfully",
  "service": "api",
  "hostname": "robot-001",
  "pid": 12345,
  "event": {
    "evt": "route.plan",
    "start": {"lat": 55.164, "lon": 61.436},
    "end": {"lat": 55.200, "lon": 61.500},
    "distance_m": 5000,
    "duration_s": 120
  }
}
```

### Валидация схемы

По умолчанию включена валидация схемы событий перед отправкой в NATS.
При ошибке валидации событие логируется в stderr, но не отправляется в NATS.

Валидацию можно отключить через параметр `enable_validation=False` при создании NATSHandler.

## Структурированное логирование (Best Practices)

### Использование helper функций

Для упрощения создания структурированных событий используйте helper функции:

```python
from nats_logger.utils import create_structured_event, create_event_data

# Простое структурированное событие
log.info("Route planned", extra={
    "event": create_structured_event(
        "Route planned",
        event_data=create_event_data(
            "route.plan",
            start={"lat": 55.164, "lon": 61.436},
            end={"lat": 55.200, "lon": 61.500},
            distance_m=5000
        )
    )
})

# Событие с исключением
try:
    process_data()
except Exception as e:
    log.error("Processing failed", extra={
        "event": create_structured_event(
            "Processing failed",
            level="ERROR",
            exception=e,
            event_data=create_event_data("process.error", step="validation")
        )
    })
```

### Рекомендации

1. **Используйте структурированные данные** для важных событий:
   ```python
   # ✅ Хорошо: структурированные данные
   log.info("Motor started", extra={
       "event": create_structured_event(
           "Motor started",
           event_data=create_event_data("motor.start", speed=100, direction="forward")
       )
   })
   
   # ⚠️ Приемлемо: простое сообщение
   log.info("Motor started")
   ```

2. **Используйте поле `event` для поиска и фильтрации**:
   ```python
   # События с одинаковым типом легко фильтровать
   log.info("Route planned", extra={
       "event": create_structured_event(
           "Route planned",
           event_data=create_event_data("route.plan", ...)
       )
   })
   ```

3. **Логируйте исключения с полной информацией**:
   ```python
   try:
       risky_operation()
   except Exception as e:
       log.error("Operation failed", extra={
           "event": create_structured_event(
               "Operation failed",
               level="ERROR",
               exception=e,
               event_data=create_event_data("operation.error", operation_id=123)
           )
       })
   ```

4. **Используйте осмысленные типы событий** в поле `event.evt`:
   - `route.plan`, `route.start`, `route.complete`
   - `motor.start`, `motor.stop`, `motor.error`
   - `camera.frame`, `camera.error`
   - `sensor.reading`, `sensor.calibration`

## Метрики

```python
metrics = handler.get_metrics()
# {
#     "sent_events": 1000,
#     "dropped_events": 5,
#     "error_count": 2,
#     "queue_size": 10,
#     "is_connected": True
# }
```

## Отказоустойчивость

При недоступности NATS:
- Handler не падает
- Ошибки логируются в stderr
- Старые handlers продолжают работать
- Автоматическое переподключение при восстановлении

## Использование в сервисах

Все сервисы используют `setup_unified_logging()` для единообразной настройки:

```python
from nats_logger import setup_unified_logging

setup_unified_logging(
    service_name="my-service",
    nats_url=os.getenv("NATS_URL"),
    enable_nats=True,
)
```

**Результат:**
- StreamHandler(stdout) — только ERROR/CRITICAL (триггерные события)
- NATSHandler — все события отправляются в NATS

Подробнее: `../docs/nats-logging.md`

## Зависимости

- `nats-py>=2.0.0` - NATS клиент
- `tomli>=2.0.0` - для чтения config.toml (Python < 3.11)

## Лицензия

Proprietary


