# nats_logger

NATS logging handler для проекта LARS.

Библиотека для отправки логов в NATS из всех сервисов проекта. Интегрируется с Python logging framework и работает параллельно со старой системой логирования.

## Установка

```bash
cd services/nats_logger
pip install -e .
```

Или добавьте в зависимости проекта:
```toml
dependencies = [
    "nats-logger @ file:///path/to/services/nats_logger",
]
```

## Быстрый старт

### Минимальный пример

```python
import logging
from nats_logger import NATSHandler

# Создание handler
handler = NATSHandler(
    nats_url="nats://127.0.0.1:4222",
    service_name="my-service",
)

# Добавление handler
logging.getLogger().addHandler(handler)

# Использование
log = logging.getLogger(__name__)
log.info("Hello from NATS!", extra={"event": {"stage": "test"}})
```

### С конфигурацией

```python
from nats_logger import NATSHandler, NATSLoggerConfig

# Загрузка конфигурации из config.toml
config = NATSLoggerConfig.from_toml()

# Создание handler
handler = NATSHandler.from_config(config)

# Добавление handler
logging.getLogger().addHandler(handler)
```

## Конфигурация

### Через config.toml

```toml
[nats]
url = "nats://127.0.0.1:4222"

[nats.logging]
enable = true
service_name = "api"
# subject_prefix = "lars.logs"  # Старый формат
subject_prefix = "log"  # Новый формат согласно архитектуре
batch_size = 10
batch_timeout = 1.0
queue_size = 1000
fallback_on_error = true
enable_secondary_subjects = true
```

### Через переменные окружения

```bash
export NATS_URL=nats://127.0.0.1:4222
export SERVICE_NAME=api
export NATS_BATCH_SIZE=10
export NATS_BATCH_TIMEOUT=1.0
export NATS_QUEUE_SIZE=1000
```

## Особенности

- ✅ **Асинхронная отправка** - не блокирует основной поток
- ✅ **Батчинг** - уменьшает нагрузку на NATS
- ✅ **Очередь с лимитом** - контролирует использование памяти
- ✅ **Отказоустойчивость** - fallback при ошибках NATS
- ✅ **Thread-safe** - безопасная работа из разных потоков
- ✅ **Автоматическое определение** - service_name и hostname определяются автоматически

## NATS Subjects

Формат: `{prefix}.{service}.{level}`

Примеры:
# Старый формат (закомментирован):
# - `lars.logs.api.INFO` - INFO логи от API
# - `lars.logs.api.ERROR` - ERROR логи от API
# - `lars.logs.camera-daemon.WARNING` - WARNING логи от camera-daemon
# Новый формат согласно архитектуре:
- `log.api.INFO` - INFO логи от API
- `log.api.ERROR` - ERROR логи от API
- `log.camera-daemon.WARNING` - WARNING логи от camera-daemon

## Формат событий

```json
{
  "ts": "2024-01-15T10:30:45",
  "level": "INFO",
  "logger": "app.services.motor.motor_service",
  "msg": "route.plan",
  "service": "api",
  "hostname": "robot-001",
  "pid": 12345,
  "event": {
    "stage": "route",
    "action": "plan",
    "start": {"lat": 55.164, "lon": 61.436}
  }
}
```

## Метрики

```python
metrics = handler.get_metrics()
# {
#     "sent_events": 1000,
#     "dropped_events": 5,
#     "error_count": 2,
#     "queue_size": 10,
#     "is_connected": True
# }
```

## Отказоустойчивость

При недоступности NATS:
- Handler не падает
- Ошибки логируются в stderr
- Старые handlers продолжают работать
- Автоматическое переподключение при восстановлении

## Интеграция

См. `docs/nats_logging_implementation_plan.md` для подробной документации по интеграции в сервисы.

## Зависимости

- `nats-py>=2.0.0` - NATS клиент
- `tomli>=2.0.0` - для чтения config.toml (Python < 3.11)

## Лицензия

Proprietary


