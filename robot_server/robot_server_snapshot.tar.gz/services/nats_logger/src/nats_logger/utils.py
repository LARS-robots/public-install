"""
Утилиты для nats_logger.

Функции для автоматического определения service_name, hostname,
и преобразования LogRecord в структурированные события.

Также включает валидацию схемы событий для обеспечения консистентности.
"""

import os
import socket
import logging
import time
import json
from typing import Optional, Dict, Any, List


def detect_service_name() -> str:
    """
    Автоматическое определение имени сервиса.
    
    Приоритет:
    1. Переменная окружения SERVICE_NAME
    2. Имя процесса (если доступен psutil)
    3. Fallback: "unknown"
    
    Returns:
        Имя сервиса (например, "api", "camera-daemon")
    """
    # 1. Из переменной окружения (наивысший приоритет)
    service_name = os.getenv("SERVICE_NAME")
    if service_name:
        return service_name
    
    # 2. Попытка определить из имени процесса
    try:
        import psutil
        process = psutil.Process()
        name = process.name()
        cmdline = process.cmdline()
        
        # Анализ командной строки для определения сервиса
        cmdline_str = " ".join(cmdline).lower()
        if "api" in cmdline_str or "fastapi" in cmdline_str or "uvicorn" in cmdline_str:
            return "api"
        elif "camera" in cmdline_str or "daemon" in cmdline_str:
            return "camera-daemon"
        elif name and name != "python" and name != "python3":
            # Использовать имя процесса, если оно информативное
            return name.replace(".py", "").replace("_", "-")
    except ImportError:
        # psutil не установлен - пропускаем
        pass
    except Exception:
        # Любая другая ошибка - пропускаем
        pass
    
    # 3. Fallback
    return "unknown"


def detect_hostname() -> str:
    """
    Автоматическое определение hostname.
    
    Приоритет:
    1. Переменная окружения HOSTNAME
    2. socket.gethostname()
    3. Fallback: "unknown"
    
    Returns:
        Hostname сервера
    """
    # 1. Из переменной окружения
    hostname = os.getenv("HOSTNAME")
    if hostname:
        return hostname
    
    # 2. Из socket
    try:
        return socket.gethostname()
    except Exception:
        pass
    
    # 3. Fallback
    return "unknown"


def record_to_event(
    record: logging.LogRecord,
    service_name: str,
    hostname: str,
    pid: int,
) -> Dict[str, Any]:
    """
    Преобразование LogRecord в структурированное событие.
    
    Совместимо с текущим record_to_event() из logging_setup.py.
    Добавляет поля service, hostname, pid для идентификации источника.
    
    Логика совпадает с logging_setup.py:
    - Если лог вызывали как log.info(..., extra={"event": {...}}), берём этот dict за основу
    - Иначе создаем новый event с сообщением
    - Добавляем стандартные поля: logger, level, ts
    - Добавляем новые поля: service, hostname, pid
    - Всегда добавляем msg из record.getMessage(), если его нет
    
    Args:
        record: LogRecord из Python logging
        service_name: Имя сервиса (например, "api")
        hostname: Hostname сервера
        pid: Process ID
    
    Returns:
        Словарь с структурированным событием
    """
    # Извлечь event из extra, если есть (совместимо с logging_setup.py)
    ev = getattr(record, "event", None)
    if isinstance(ev, dict):
        # Если event уже есть в extra - используем его как основу
        out = ev.copy()
    else:
        # Иначе создаем новый event с сообщением
        out = {}
    
    # Всегда добавляем msg из record.getMessage(), если его нет
    # Это гарантирует, что валидация пройдет успешно
    if "msg" not in out:
        out["msg"] = record.getMessage()
    
    # Добавить стандартные поля (если их еще нет)
    # Используем setdefault чтобы не перезаписывать существующие поля
    out.setdefault("logger", record.name)
    out.setdefault("level", record.levelname)
    out.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)))
    
    # Добавить новые поля для идентификации источника (всегда добавляем, даже если уже есть)
    out["service"] = service_name
    out["hostname"] = hostname
    out["pid"] = pid
    
    return out


def validate_event_schema(event: Dict[str, Any]) -> tuple[bool, Optional[str]]:
    """
    Валидация структуры события согласно схеме.
    
    Проверяет наличие обязательных полей и корректность типов.
    Используется для обеспечения консистентности событий перед отправкой в NATS.
    
    Обязательные поля:
    - ts: str (ISO 8601 timestamp, формат: YYYY-MM-DDTHH:MM:SS)
    - level: str (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    - logger: str (имя logger)
    - msg: str (сообщение, опционально если есть event)
    - service: str (имя сервиса)
    - hostname: str (hostname сервера)
    - pid: int (process ID)
    
    Опциональные поля:
    - event: dict (структурированные данные события)
    - exception: dict (информация об исключении)
    - extra: dict (дополнительные поля)
    
    Args:
        event: Словарь с событием для валидации
    
    Returns:
        Кортеж (is_valid, error_message):
        - is_valid: True если событие валидно, False иначе
        - error_message: Сообщение об ошибке (если is_valid == False) или None
    """
    errors: List[str] = []
    
    # Обязательные поля
    required_fields = {
        "ts": str,
        "level": str,
        "logger": str,
        "service": str,
        "hostname": str,
        "pid": int,
    }
    
    for field, expected_type in required_fields.items():
        if field not in event:
            errors.append(f"Отсутствует обязательное поле: {field}")
        elif not isinstance(event[field], expected_type):
            errors.append(f"Неправильный тип поля {field}: ожидается {expected_type.__name__}, получен {type(event[field]).__name__}")
    
    # Проверка наличия хотя бы одного из: msg, event, или структурированных полей
    # Структурированные события могут содержать поля evt, src и другие вместо msg
    has_msg = "msg" in event
    has_event_field = "event" in event and isinstance(event["event"], dict)
    has_structured_fields = "evt" in event or "src" in event
    
    if not (has_msg or has_event_field or has_structured_fields):
        errors.append("Отсутствует поле 'msg', 'event' или структурированные поля (evt/src) (хотя бы одно должно быть)")
    
    # Проверка формата timestamp (опционально, но желательно)
    if "ts" in event:
        ts = event["ts"]
        if isinstance(ts, str):
            # Проверка формата ISO 8601 (YYYY-MM-DDTHH:MM:SS)
            try:
                time.strptime(ts, "%Y-%m-%dT%H:%M:%S")
            except ValueError:
                # Не критично, но предупреждаем
                pass  # Не добавляем в errors, так как это не критично
    
    # Проверка уровня логирования (опционально)
    if "level" in event:
        level = event["level"]
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if level not in valid_levels:
            errors.append(f"Недопустимый уровень логирования: {level} (допустимые: {', '.join(valid_levels)})")
    
    # Проверка типов опциональных полей
    if "event" in event and not isinstance(event["event"], dict):
        errors.append(f"Поле 'event' должно быть dict, получен {type(event['event']).__name__}")
    
    if "exception" in event and not isinstance(event["exception"], dict):
        errors.append(f"Поле 'exception' должно быть dict, получен {type(event['exception']).__name__}")
    
    if "extra" in event and not isinstance(event["extra"], dict):
        errors.append(f"Поле 'extra' должно быть dict, получен {type(event['extra']).__name__}")
    
    if errors:
        return False, "; ".join(errors)
    
    return True, None


def serialize_event(event: Dict[str, Any]) -> bytes:
    """
    Сериализация события в JSON.
    
    Используется JSON для читаемости и совместимости.
    Можно заменить на MessagePack для компактности в будущем.
    
    Args:
        event: Словарь с событием
    
    Returns:
        Сериализованное событие в виде bytes
    """
    return json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


# ---------- Helper функции для создания структурированных событий ----------

def create_structured_event(
    msg: str,
    level: str = "INFO",
    logger: Optional[str] = None,
    event_data: Optional[Dict[str, Any]] = None,
    exception: Optional[Exception] = None,
    extra: Optional[Dict[str, Any]] = None,
    service_name: Optional[str] = None,
    hostname: Optional[str] = None,
    pid: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Создание структурированного события для логирования.
    
    Упрощает создание структурированных событий с правильной схемой.
    Все обязательные поля заполняются автоматически.
    
    Пример использования:
        # Простое событие
        log.info("User logged in", extra={
            "event": create_structured_event("User logged in", event_data={"user_id": 123})
        })
        
        # Событие с исключением
        try:
            process_data()
        except Exception as e:
            log.error("Processing failed", extra={
                "event": create_structured_event(
                    "Processing failed",
                    level="ERROR",
                    exception=e,
                    event_data={"step": "validation"}
                )
            })
    
    Args:
        msg: Текстовое сообщение события (обязательно)
        level: Уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL), по умолчанию INFO
        logger: Имя logger (автоопределение если None)
        event_data: Структурированные данные события (опционально)
        exception: Исключение для логирования (опционально)
        extra: Дополнительные поля (опционально)
        service_name: Имя сервиса (автоопределение если None)
        hostname: Hostname (автоопределение если None)
        pid: Process ID (автоопределение если None)
    
    Returns:
        Словарь с структурированным событием, готовым для использования в extra={"event": ...}
    """
    import traceback
    
    # Автоопределение параметров
    if service_name is None:
        service_name = detect_service_name()
    if hostname is None:
        hostname = detect_hostname()
    if pid is None:
        pid = os.getpid()
    if logger is None:
        # Попытка определить logger из стека вызовов
        import inspect
        try:
            frame = inspect.currentframe()
            if frame and frame.f_back:
                logger = frame.f_back.f_globals.get("__name__", "unknown")
        except Exception:
            logger = "unknown"
    
    # Создание базового события
    event: Dict[str, Any] = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
        "level": level.upper(),
        "logger": logger,
        "msg": msg,
        "service": service_name,
        "hostname": hostname,
        "pid": pid,
    }
    
    # Добавление структурированных данных
    if event_data:
        event["event"] = event_data
    
    # Добавление информации об исключении
    if exception:
        event["exception"] = {
            "type": type(exception).__name__,
            "message": str(exception),
            "traceback": traceback.format_exc(),
        }
    
    # Добавление дополнительных полей
    if extra:
        event["extra"] = extra
    
    return event


def create_event_data(
    evt: str,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    Создание структурированных данных события (event field).
    
    Упрощает создание структурированных данных для поля "event".
    
    Пример использования:
        log.info("Route planned", extra={
            "event": create_structured_event(
                "Route planned",
                event_data=create_event_data(
                    "route.plan",
                    start={"lat": 55.164, "lon": 61.436},
                    end={"lat": 55.200, "lon": 61.500},
                    distance_m=5000
                )
            )
        })
    
    Args:
        evt: Тип события (например, "route.plan", "motor.start", "camera.frame")
        **kwargs: Дополнительные поля события
    
    Returns:
        Словарь с данными события для поля "event"
    """
    event_data: Dict[str, Any] = {
        "evt": evt,
    }
    event_data.update(kwargs)
    return event_data

