"""
Утилиты для nats_logger.

Функции для автоматического определения service_name, hostname,
и преобразования LogRecord в структурированные события.
"""

import os
import socket
import logging
import time
import json
from typing import Optional, Dict, Any


def detect_service_name() -> str:
    """
    Автоматическое определение имени сервиса.
    
    Приоритет:
    1. Переменная окружения SERVICE_NAME
    2. Имя процесса (если доступен psutil)
    3. Fallback: "unknown"
    
    Returns:
        Имя сервиса (например, "api", "camera-daemon")
    """
    # 1. Из переменной окружения (наивысший приоритет)
    service_name = os.getenv("SERVICE_NAME")
    if service_name:
        return service_name
    
    # 2. Попытка определить из имени процесса
    try:
        import psutil
        process = psutil.Process()
        name = process.name()
        cmdline = process.cmdline()
        
        # Анализ командной строки для определения сервиса
        cmdline_str = " ".join(cmdline).lower()
        if "api" in cmdline_str or "fastapi" in cmdline_str or "uvicorn" in cmdline_str:
            return "api"
        elif "camera" in cmdline_str or "daemon" in cmdline_str:
            return "camera-daemon"
        elif name and name != "python" and name != "python3":
            # Использовать имя процесса, если оно информативное
            return name.replace(".py", "").replace("_", "-")
    except ImportError:
        # psutil не установлен - пропускаем
        pass
    except Exception:
        # Любая другая ошибка - пропускаем
        pass
    
    # 3. Fallback
    return "unknown"


def detect_hostname() -> str:
    """
    Автоматическое определение hostname.
    
    Приоритет:
    1. Переменная окружения HOSTNAME
    2. socket.gethostname()
    3. Fallback: "unknown"
    
    Returns:
        Hostname сервера
    """
    # 1. Из переменной окружения
    hostname = os.getenv("HOSTNAME")
    if hostname:
        return hostname
    
    # 2. Из socket
    try:
        return socket.gethostname()
    except Exception:
        pass
    
    # 3. Fallback
    return "unknown"


def record_to_event(
    record: logging.LogRecord,
    service_name: str,
    hostname: str,
    pid: int,
) -> Dict[str, Any]:
    """
    Преобразование LogRecord в структурированное событие.
    
    Совместимо с текущим record_to_event() из logging_setup.py.
    Добавляет поля service, hostname, pid для идентификации источника.
    
    Логика совпадает с logging_setup.py:
    - Если лог вызывали как log.info(..., extra={"event": {...}}), берём этот dict за основу
    - Иначе создаем новый event с сообщением
    - Добавляем стандартные поля: logger, level, ts
    - Добавляем новые поля: service, hostname, pid
    
    Args:
        record: LogRecord из Python logging
        service_name: Имя сервиса (например, "api")
        hostname: Hostname сервера
        pid: Process ID
    
    Returns:
        Словарь с структурированным событием
    """
    # Извлечь event из extra, если есть (совместимо с logging_setup.py)
    ev = getattr(record, "event", None)
    if isinstance(ev, dict):
        # Если event уже есть в extra - используем его как основу
        out = ev.copy()
    else:
        # Иначе создаем новый event с сообщением
        out = {"msg": record.getMessage()}
    
    # Добавить стандартные поля (если их еще нет)
    # Используем setdefault чтобы не перезаписывать существующие поля
    out.setdefault("logger", record.name)
    out.setdefault("level", record.levelname)
    out.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)))
    
    # Добавить новые поля для идентификации источника (всегда добавляем, даже если уже есть)
    out["service"] = service_name
    out["hostname"] = hostname
    out["pid"] = pid
    
    return out


def serialize_event(event: Dict[str, Any]) -> bytes:
    """
    Сериализация события в JSON.
    
    Используется JSON для читаемости и совместимости.
    Можно заменить на MessagePack для компактности в будущем.
    
    Args:
        event: Словарь с событием
    
    Returns:
        Сериализованное событие в виде bytes
    """
    return json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

