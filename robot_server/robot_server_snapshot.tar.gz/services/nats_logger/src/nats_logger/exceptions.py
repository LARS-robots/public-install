"""
Кастомные исключения для nats_logger.

Эти исключения используются для обработки ошибок в NATS logger.
Все исключения наследуются от NATSLoggerError для удобной обработки.
"""


class NATSLoggerError(Exception):
    """Базовое исключение для nats_logger."""
    pass


class NATSConnectionError(NATSLoggerError):
    """Ошибка подключения к NATS серверу."""
    pass


class NATSPublishError(NATSLoggerError):
    """Ошибка публикации сообщения в NATS."""
    pass


