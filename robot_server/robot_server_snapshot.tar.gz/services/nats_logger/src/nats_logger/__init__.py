"""
NATS logger for LARS project.

Этот модуль предоставляет Python logging Handler для отправки логов в NATS.
Основные компоненты:
- NATSHandler: logging.Handler для интеграции с Python logging
- NATSLoggerConfig: конфигурация для настройки handler'а
- Утилиты для автоматического определения service_name и hostname
"""

from .handler import NATSHandler
from .config import NATSLoggerConfig
from .utils import detect_service_name, detect_hostname
from .exceptions import NATSLoggerError, NATSConnectionError, NATSPublishError

__version__ = "0.1.0"
__all__ = [
    "NATSHandler",
    "NATSLoggerConfig",
    "detect_service_name",
    "detect_hostname",
    "NATSLoggerError",
    "NATSConnectionError",
    "NATSPublishError",
]


