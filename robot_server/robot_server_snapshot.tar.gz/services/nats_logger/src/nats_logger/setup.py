"""
Унифицированная настройка логирования для всех сервисов.

Функция setup_unified_logging() обеспечивает единообразную конфигурацию логирования:
- StreamHandler(stdout) — ERROR+ только (триггерные события: ERROR, CRITICAL)
- NATSHandler — все события (INFO, WARNING, ERROR, CRITICAL) отправляются в NATS

Соответствует требованиям:
- Стандартный вывод содержит только важные триггерные вещи (ERROR, CRITICAL, старт/стоп)
- Все события логируются в NATS для централизованного хранения и просмотра
"""

import logging
import sys
import os
from typing import Optional

from .utils import detect_service_name, detect_hostname
from .handler import NATSHandler


def setup_unified_logging(
    service_name: Optional[str] = None,
    level: int = logging.INFO,
    nats_url: Optional[str] = None,
    enable_nats: bool = True,
    stdout_format: Optional[str] = None,
    stdout_level: int = logging.ERROR,
    **nats_handler_kwargs,
) -> None:
    """
    Унифицированная настройка логирования для всех сервисов.
    
    Настраивает:
    1. StreamHandler(stdout) — ERROR+ только (триггерные события)
    2. NATSHandler — все события отправляются в NATS (если enable_nats=True)
    
    Соответствует требованиям:
    - stdout содержит только важные триггерные вещи (ERROR, CRITICAL, старт/стоп)
    - Старт/стоп события должны выводиться через print() для гарантированного отображения
    - Все события (INFO, WARNING, ERROR, CRITICAL) доступны через NATS
    
    Args:
        service_name: Имя сервиса (например, "api", "camera-daemon").
                     Если None, определяется автоматически через detect_service_name()
        level: Уровень логирования для root logger (по умолчанию INFO)
        nats_url: URL NATS сервера (например, "nats://127.0.0.1:4222").
                 Если None, берется из переменной окружения NATS_URL
        enable_nats: Включить NATS логирование (по умолчанию True)
        stdout_format: Формат для stdout handler (по умолчанию стандартный)
        stdout_level: Уровень логирования для stdout (по умолчанию ERROR).
                     Должен быть ERROR для соответствия требованиям (только триггерные события)
        **nats_handler_kwargs: Дополнительные параметры для NATSHandler
                               (batch_size, batch_timeout, queue_size, и т.д.)
    
    Примеры использования:
        # Минимальный пример (используются значения по умолчанию)
        setup_unified_logging(service_name="my-service")
        
        # С явным указанием NATS URL
        setup_unified_logging(
            service_name="camera-daemon",
            nats_url="nats://127.0.0.1:4222",
            enable_nats=True,
        )
        
        # Без NATS (только stdout)
        setup_unified_logging(
            service_name="test-service",
            enable_nats=False,
        )
        
        # С дополнительными параметрами NATSHandler
        setup_unified_logging(
            service_name="api",
            nats_url=os.getenv("NATS_URL"),
            batch_size=20,
            queue_size=2000,
        )
    """
    # Определение service_name
    if service_name is None:
        service_name = detect_service_name() or "unknown"
    
    # Получение root logger
    root = logging.getLogger()
    
    # Удаление всех существующих handlers для чистой настройки
    for handler in list(root.handlers):
        root.removeHandler(handler)
    
    # Установка уровня логирования для root logger
    root.setLevel(level)
    
    # ========== 1. StreamHandler (stdout) — ERROR+ только ==========
    # Согласно требованиям: stdout содержит только важные триггерные вещи
    # (ERROR, CRITICAL, старт/стоп)
    # Старт/стоп события выводятся через print() в коде сервиса
    
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(stdout_level)  # По умолчанию ERROR (только триггерные события)
    
    # Формат для stdout
    if stdout_format is None:
        stdout_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
    
    stdout_handler.setFormatter(logging.Formatter(stdout_format))
    root.addHandler(stdout_handler)
    
    # ========== 2. NATSHandler — все события в NATS ==========
    # Все события (INFO, WARNING, ERROR, CRITICAL) отправляются в NATS
    # для централизованного хранения и просмотра через веб-интерфейс
    
    if enable_nats:
        # Получение NATS URL
        if nats_url is None:
            nats_url = os.getenv("NATS_URL")
        
        # Нормализация URL: убираем лишние двоеточия и пробелы в конце
        # Это важно, так как некоторые конфиги или env переменные могут содержать лишние символы
        # Например: "nats://dev:devpass@127.0.0.1:4222:" -> "nats://dev:devpass@127.0.0.1:4222"
        if nats_url:
            nats_url = nats_url.strip().rstrip(':').rstrip()
            
            # В Docker контейнере используем имя сервиса "nats" вместо 127.0.0.1
            # Проверяем, запущены ли мы в Docker (если есть /app/src, значит в контейнере)
            if os.path.exists("/app/src") and "127.0.0.1" in nats_url:
                # В Docker Compose используем имя сервиса
                nats_url = nats_url.replace("127.0.0.1", "nats")
                # Повторно нормализуем после замены (на случай если было двоеточие)
                nats_url = nats_url.strip().rstrip(':').rstrip()
        
        if nats_url:
            try:
                # Определение hostname для NATSHandler
                hostname = detect_hostname()
                
                # Создание NATSHandler с параметрами по умолчанию
                # Параметры из nats_handler_kwargs перезаписывают значения по умолчанию
                nats_handler_params = {
                    "nats_url": nats_url,
                    "service_name": service_name,
                    "subject_prefix": "log",  # Формат: log.{service}.{level}
                    "level": logging.NOTSET,  # Принимает все события (фильтрация на уровне root logger)
                    "batch_size": 10,
                    "batch_timeout": 1.0,
                    "queue_size": 1000,
                    "fallback_on_error": True,  # Не падает при ошибках NATS
                    "enable_secondary_subjects": True,
                    "hostname": hostname,
                    "enable_validation": True,  # Валидация схемы событий
                }
                
                # Обновление параметров из nats_handler_kwargs
                nats_handler_params.update(nats_handler_kwargs)
                
                # Создание и добавление NATSHandler
                nats_handler = NATSHandler(**nats_handler_params)
                root.addHandler(nats_handler)
                
                # Логирование успешной инициализации (через INFO, попадет в NATS)
                logger = logging.getLogger(__name__)
                logger.info(
                    f"NATS logging enabled for service '{service_name}' "
                    f"(NATS URL: {nats_url})"
                )
                
            except Exception as e:
                # Ошибка инициализации NATS - логируем в stderr и продолжаем
                # stdout handler продолжит работать нормально
                try:
                    sys.stderr.write(
                        f"[setup_unified_logging] Failed to initialize NATS logging: {e}\n"
                    )
                    sys.stderr.write(
                        f"[setup_unified_logging] Continuing with stdout logging only.\n"
                    )
                except Exception:
                    pass  # Не падаем если даже stderr недоступен
        else:
            # NATS URL не указан - логируем предупреждение
            logger = logging.getLogger(__name__)
            logger.warning(
                "NATS logging requested but NATS_URL not provided. "
                "Continuing with stdout logging only."
            )
    
    # Финальная настройка: uvicorn loggers (для API сервиса)
    # Прокидываем логи uvicorn наверх, чтобы не было дублей
    for uvicorn_logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        uvicorn_logger = logging.getLogger(uvicorn_logger_name)
        uvicorn_logger.handlers[:] = []
        uvicorn_logger.propagate = True



