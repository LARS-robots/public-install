"""
NATS client wrapper для nats_logger.

Обертка над nats-py клиентом для упрощения использования и thread-safe операций.
Поддерживает как синхронное, так и асинхронное использование.
"""

import asyncio
import threading
import time
from typing import Optional
import logging

try:
    import nats
    from nats.aio.client import Client as NATSClient
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    NATSClient = None

from .exceptions import NATSConnectionError, NATSPublishError

logger = logging.getLogger(__name__)


class NATSClientWrapper:
    """
    Thread-safe обертка над NATS клиентом.
    
    Особенности:
    - Автоматическое подключение/переподключение
    - Thread-safe публикация (можно использовать из разных потоков)
    - Обработка ошибок подключения
    - Асинхронная работа через отдельный event loop
    """
    
    def __init__(self, nats_url: str):
        """
        Инициализация NATS клиента.
        
        Args:
            nats_url: URL NATS сервера (например, "nats://127.0.0.1:4222")
        """
        if not NATS_AVAILABLE:
            raise ImportError("nats-py is not installed. Install it with: pip install nats-py")
        
        self.nats_url = nats_url
        self._client: Optional[NATSClient] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._loop_thread: Optional[threading.Thread] = None
        self._connected = False
        self._lock = threading.Lock()
        self._shutdown = False
    
    def _run_event_loop(self):
        """
        Запуск event loop в отдельном потоке.
        
        Это позволяет использовать асинхронный NATS клиент из синхронного кода.
        """
        # Создать новый event loop для этого потока
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        # Сохранить ссылку на loop ДО запуска
        self._loop = loop
        
        try:
            # Запустить event loop
            loop.run_forever()
        except Exception as e:
            logger.error(f"Event loop error: {e}")
        finally:
            try:
                # Завершить все pending tasks
                pending = asyncio.all_tasks(loop)
                for task in pending:
                    task.cancel()
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            finally:
                loop.close()
                self._loop = None
    
    def connect(self) -> None:
        """
        Подключение к NATS серверу.
        
        Создает отдельный поток с event loop для асинхронных операций.
        """
        if self._shutdown:
            return
        
        with self._lock:
            if self._connected:
                return
            
            # Запустить event loop в отдельном потоке
            if self._loop_thread is None or not self._loop_thread.is_alive():
                self._loop_thread = threading.Thread(
                    target=self._run_event_loop,
                    daemon=True,
                    name="NATSClientLoop"
                )
                self._loop_thread.start()
                
                # Подождать, пока event loop запустится
                max_wait = 50  # Максимум 5 секунд (50 * 0.1)
                for _ in range(max_wait):
                    if self._loop is not None:
                        # Дополнительно подождать, пока loop действительно готов
                        time.sleep(0.1)
                        break
                    time.sleep(0.1)
            
            if self._loop is None:
                raise NATSConnectionError("Failed to start event loop")
            
            # Подключиться к NATS в event loop
            future = asyncio.run_coroutine_threadsafe(
                self._connect_async(),
                self._loop
            )
            
            try:
                future.result(timeout=10.0)  # Таймаут 10 секунд
                self._connected = True
            except asyncio.TimeoutError:
                raise NATSConnectionError("NATS connection timeout")
            except Exception as e:
                raise NATSConnectionError(f"Failed to connect to NATS: {e}")
    
    async def _connect_async(self) -> None:
        """Асинхронное подключение к NATS серверу."""
        try:
            # Создать новый клиент
            self._client = NATSClient()
            
            # Подключиться к NATS
            await self._client.connect(
                servers=[self.nats_url],
                reconnect_time_wait=2,  # Переподключение через 2 секунды
                max_reconnect_attempts=-1,  # Бесконечные попытки переподключения
                connect_timeout=5,  # Таймаут подключения 5 секунд
            )
            logger.debug(f"Connected to NATS at {self.nats_url}")
        except Exception as e:
            logger.error(f"NATS connection error: {e}")
            # Очистить клиент при ошибке
            self._client = None
            raise
    
    def publish(self, subject: str, data: bytes) -> None:
        """
        Публикация сообщения в NATS (thread-safe).
        
        Args:
            subject: NATS subject (например, "lars.logs.api.INFO")
            data: Данные для отправки (bytes)
        
        Raises:
            NATSConnectionError: Если не подключен к NATS
            NATSPublishError: Если ошибка публикации
        """
        if not self._connected or self._client is None or self._loop is None:
            # Попытка переподключения
            try:
                self.connect()
            except Exception as e:
                raise NATSConnectionError(f"Not connected to NATS: {e}")
        
        if self._loop is None:
            raise NATSConnectionError("Event loop not available")
        
        # Публикация в event loop (thread-safe)
        try:
            future = asyncio.run_coroutine_threadsafe(
                self._publish_async(subject, data),
                self._loop
            )
            future.result(timeout=1.0)  # Таймаут 1 секунда
        except asyncio.TimeoutError:
            raise NATSPublishError(f"Publish timeout for subject {subject}")
        except Exception as e:
            raise NATSPublishError(f"Failed to publish to {subject}: {e}")
    
    async def _publish_async(self, subject: str, data: bytes) -> None:
        """Асинхронная публикация сообщения."""
        if self._client is None:
            raise NATSConnectionError("NATS client not initialized")
        
        try:
            await self._client.publish(subject, data)
        except Exception as e:
            logger.error(f"NATS publish error for {subject}: {e}")
            raise
    
    def is_connected(self) -> bool:
        """Проверка состояния подключения."""
        return self._connected and self._client is not None and self._loop is not None
    
    def close(self) -> None:
        """Закрытие соединения и остановка event loop."""
        self._shutdown = True
        
        with self._lock:
            if self._loop is not None:
                # Закрыть соединение в event loop
                if self._client is not None:
                    future = asyncio.run_coroutine_threadsafe(
                        self._close_async(),
                        self._loop
                    )
                    try:
                        future.result(timeout=2.0)
                    except Exception:
                        pass
                
                # Остановить event loop
                self._loop.call_soon_threadsafe(self._loop.stop)
            
            # Подождать завершения потока
            if self._loop_thread is not None and self._loop_thread.is_alive():
                self._loop_thread.join(timeout=2.0)
            
            self._connected = False
            self._client = None
            self._loop = None
    
    async def _close_async(self) -> None:
        """Асинхронное закрытие соединения."""
        if self._client is not None:
            try:
                await self._client.close()
            except Exception:
                pass

