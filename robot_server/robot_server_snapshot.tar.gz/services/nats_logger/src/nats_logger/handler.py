"""
NATSHandler - Python logging Handler для отправки логов в NATS.

Основной компонент библиотеки, который интегрируется с Python logging framework.
Особенности:
- Асинхронная отправка через отдельный поток
- Батчинг для производительности
- Очередь с лимитом (drop oldest при переполнении)
- Автоматический retry при ошибках
- Fallback на stdout при недоступности NATS
- Thread-safe
"""

import logging
import sys
import threading
import queue
import time
import json
import os
from typing import Optional, List, Dict, Any

from .client import NATSClientWrapper
from .utils import record_to_event, serialize_event, detect_service_name, detect_hostname, validate_event_schema
from .exceptions import NATSConnectionError, NATSPublishError

logger = logging.getLogger(__name__)


class NATSHandler(logging.Handler):
    """
    Python logging Handler для отправки логов в NATS.
    
    Использование:
        handler = NATSHandler(
            nats_url="nats://127.0.0.1:4222",
            service_name="api",
        )
        logging.getLogger().addHandler(handler)
    """
    
    def __init__(
        self,
        nats_url: str,
        service_name: str,
        subject_prefix: str = "log",  # Формат: log.{service}.{level}
        level: int = logging.NOTSET,
        batch_size: int = 10,
        batch_timeout: float = 1.0,
        queue_size: int = 1000,
        fallback_on_error: bool = True,
        enable_secondary_subjects: bool = True,
        hostname: Optional[str] = None,
        enable_validation: bool = True,  # Валидация схемы событий (по умолчанию включена)
    ):
        """
        Инициализация NATSHandler.
        
        Args:
            nats_url: URL NATS сервера (например, "nats://127.0.0.1:4222")
            service_name: Имя сервиса (например, "api", "camera-daemon")
            subject_prefix: Префикс для subjects (по умолчанию "log", формат: log.{service}.{level})
            level: Минимальный уровень логирования
            batch_size: Размер батча для отправки (по умолчанию 10)
            batch_timeout: Таймаут батча в секундах (по умолчанию 1.0)
            queue_size: Размер очереди (по умолчанию 1000, drop oldest при переполнении)
            fallback_on_error: Если True, не падает при ошибках NATS (по умолчанию True)
            enable_secondary_subjects: Отправлять в дополнительные subjects (по умолчанию True)
            hostname: Имя хоста (автоопределение если None)
            enable_validation: Включить валидацию схемы событий (по умолчанию True)
                              При ошибке валидации событие логируется в stderr, но не отправляется
        """
        super().__init__(level=level)
        
        self.nats_url = nats_url
        self.service_name = service_name
        self.subject_prefix = subject_prefix
        self.batch_size = batch_size
        self.batch_timeout = batch_timeout
        self.queue_size = queue_size
        self.fallback_on_error = fallback_on_error
        self.enable_secondary_subjects = enable_secondary_subjects
        self.enable_validation = enable_validation
        self.hostname = hostname or detect_hostname()
        self.pid = os.getpid()
        
        # Очередь для событий (thread-safe)
        self._queue: queue.Queue = queue.Queue(maxsize=queue_size)
        
        # NATS клиент (инициализируется лениво)
        self._client: Optional[NATSClientWrapper] = None
        self._client_lock = threading.Lock()
        
        # Фоновый поток для отправки батчей
        self._sender_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # Метрики
        self._sent_events = 0
        self._dropped_events = 0
        self._error_count = 0
        self._metrics_lock = threading.Lock()
        
        # Флаг подключения
        self._connected = False
        
        # Запустить фоновый поток
        self._start_sender_thread()
    
    def _start_sender_thread(self):
        """Запуск фонового потока для отправки батчей."""
        if self._sender_thread is not None and self._sender_thread.is_alive():
            return
        
        self._sender_thread = threading.Thread(
            target=self._batch_sender,
            daemon=True,
            name=f"NATSHandler-{self.service_name}"
        )
        self._sender_thread.start()
    
    def emit(self, record: logging.LogRecord) -> None:
        """
        Обработка log record.
        
        Вызывается автоматически Python logging framework для каждого log record.
        Преобразует LogRecord в событие и добавляет в очередь для отправки.
        
        Args:
            record: LogRecord из Python logging
        """
        try:
            # Преобразование LogRecord в событие
            event = record_to_event(record, self.service_name, self.hostname, self.pid)
            
            # Валидация схемы события (если включена)
            if self.enable_validation:
                is_valid, error_msg = validate_event_schema(event)
                if not is_valid:
                    # Событие не прошло валидацию - логируем ошибку, но не падаем
                    if self.fallback_on_error:
                        try:
                            sys.stderr.write(f"[NATSHandler] Event validation failed: {error_msg}\n")
                            sys.stderr.write(f"[NATSHandler] Invalid event: {json.dumps(event, ensure_ascii=False)}\n")
                        except Exception:
                            pass
                        # Не отправляем невалидное событие
                        return
                    else:
                        # Если fallback отключен - поднимаем исключение
                        raise ValueError(f"Event validation failed: {error_msg}")
            
            # Сериализация в JSON
            event_data = serialize_event(event)
            
            # Добавление в очередь (неблокирующее)
            try:
                self._queue.put_nowait(event_data)
            except queue.Full:
                # Очередь переполнена - drop oldest
                try:
                    # Удалить самое старое событие
                    self._queue.get_nowait()
                    # Добавить новое
                    self._queue.put_nowait(event_data)
                    # Увеличить счетчик dropped
                    with self._metrics_lock:
                        self._dropped_events += 1
                except queue.Empty:
                    # Если очередь пуста (маловероятно, но возможно)
                    pass
        
        except Exception as e:
            # Ошибка обработки - fallback на stderr
            if self.fallback_on_error:
                try:
                    sys.stderr.write(f"[NATSHandler] Error processing log record: {e}\n")
                except Exception:
                    pass
            else:
                self.handleError(record)
    
    def _batch_sender(self):
        """
        Фоновый поток для отправки батчей в NATS.
        
        Собирает события из очереди в батчи и отправляет в NATS.
        Отправка происходит либо при достижении batch_size, либо при истечении batch_timeout.
        """
        batch: List[bytes] = []
        last_send = time.time()
        
        while not self._stop_event.is_set():
            try:
                # Используем более короткий таймаут для частой проверки батча
                # Но не слишком короткий, чтобы не нагружать CPU
                check_interval = min(0.05, self.batch_timeout / 4)  # Проверяем минимум 4 раза за batch_timeout
                
                # Попытка получить событие из очереди с коротким таймаутом
                try:
                    event_data = self._queue.get(timeout=check_interval)
                    batch.append(event_data)
                except queue.Empty:
                    # Очередь пуста, но нужно проверить таймаут батча
                    pass
                
                # Проверка условий отправки батча (проверяем каждый раз)
                now = time.time()
                time_since_last_send = now - last_send
                
                # Условия отправки:
                # 1. Батч заполнен (batch_size событий)
                # 2. Прошел таймаут (batch_timeout секунд)
                # 3. Для реального времени: если batch_timeout очень маленький и есть события
                should_send = (
                    len(batch) >= self.batch_size or  # Набрался полный батч
                    (batch and time_since_last_send >= self.batch_timeout)  # Прошел таймаут
                )
                
                if should_send and batch:
                    # Отправка батча в NATS
                    self._send_batch_to_nats(batch)
                    batch = []
                    last_send = now
                
                # Дополнительная проверка для реального времени:
                # Если batch_timeout очень маленький (< 0.2 сек), отправляем события быстрее
                # Это обеспечивает почти мгновенную отправку
                elif batch and self.batch_timeout < 0.2 and time_since_last_send >= (self.batch_timeout * 0.5):
                    # Отправляем накопленные события раньше (через половину таймаута)
                    # Это ускоряет отправку для реального времени
                    self._send_batch_to_nats(batch)
                    batch = []
                    last_send = now
                
            except Exception as e:
                # Ошибка в фоновом потоке - логируем и продолжаем
                if self.fallback_on_error:
                    try:
                        sys.stderr.write(f"[NATSHandler] Batch sender error: {e}\n")
                    except Exception:
                        pass
                    with self._metrics_lock:
                        self._error_count += 1
                    time.sleep(1)  # Пауза перед повтором
                else:
                    # Если fallback отключен - прерываем поток
                    break
    
    def _get_client(self) -> Optional[NATSClientWrapper]:
        """
        Получение NATS клиента (ленивая инициализация).
        
        Клиент создается при первом использовании для экономии ресурсов.
        
        Returns:
            NATSClientWrapper или None при ошибке
        """
        with self._client_lock:
            if self._client is None:
                try:
                    self._client = NATSClientWrapper(self.nats_url)
                    self._client.connect()
                    self._connected = True
                except Exception as e:
                    if self.fallback_on_error:
                        try:
                            sys.stderr.write(f"[NATSHandler] Failed to connect to NATS: {e}\n")
                        except Exception:
                            pass
                        self._connected = False
                    else:
                        raise
                    return None
            
            return self._client
    
    def _send_batch_to_nats(self, batch: List[bytes]):
        """
        Отправка батча событий в NATS.
        
        Группирует события по уровням логирования и отправляет в соответствующие subjects.
        Также может отправлять в дополнительные subjects (по service и all).
        
        Args:
            batch: Список сериализованных событий (bytes)
        """
        if not batch:
            return
        
        # Получить клиент
        client = self._get_client()
        if client is None or not client.is_connected():
            # Клиент недоступен - попытка переподключения
            with self._client_lock:
                self._client = None
                self._connected = False
            
            if self.fallback_on_error:
                return  # Просто пропускаем, не падаем
            else:
                raise NATSConnectionError("NATS client not available")
        
        # Группировка событий по уровню логирования
        events_by_level: Dict[str, List[bytes]] = {}
        events_by_level_json: Dict[str, List[Dict[str, Any]]] = {}
        
        for event_data in batch:
            try:
                # Парсинг события для определения уровня
                event = json.loads(event_data.decode("utf-8"))
                level = event.get("level", "INFO")
                subject = f"{self.subject_prefix}.{self.service_name}.{level}"
                
                if subject not in events_by_level:
                    events_by_level[subject] = []
                    events_by_level_json[subject] = []
                
                events_by_level[subject].append(event_data)
                events_by_level_json[subject].append(event)
            except Exception as e:
                # Ошибка парсинга - пропускаем событие
                if self.fallback_on_error:
                    try:
                        sys.stderr.write(f"[NATSHandler] Error parsing event: {e}\n")
                    except Exception:
                        pass
                continue
        
        # Отправка в NATS
        for subject, events in events_by_level.items():
            try:
                # Отправка каждого события в основной subject
                for event_data in events:
                    client.publish(subject, event_data)
                    with self._metrics_lock:
                        self._sent_events += 1
                
                # Опционально: отправка в дополнительные subjects
                if self.enable_secondary_subjects:
                    # Все логи сервиса
                    service_subject = f"{self.subject_prefix}.{self.service_name}"
                    batch_json = json.dumps(events_by_level_json[subject]).encode("utf-8")
                    try:
                        client.publish(service_subject, batch_json)
                    except Exception:
                        pass  # Игнорируем ошибки вторичных subjects
                    
                    # Все логи всех сервисов
                    all_subject = f"{self.subject_prefix}.all"
                    try:
                        client.publish(all_subject, batch_json)
                    except Exception:
                        pass  # Игнорируем ошибки вторичных subjects
                        
            except NATSConnectionError as e:
                # Ошибка подключения - сброс клиента
                with self._client_lock:
                    self._client = None
                    self._connected = False
                
                if self.fallback_on_error:
                    with self._metrics_lock:
                        self._error_count += 1
                    try:
                        sys.stderr.write(f"[NATSHandler] Connection error: {e}\n")
                    except Exception:
                        pass
                else:
                    raise
                    
            except NATSPublishError as e:
                # Ошибка публикации - логируем, но продолжаем
                if self.fallback_on_error:
                    with self._metrics_lock:
                        self._error_count += 1
                    try:
                        sys.stderr.write(f"[NATSHandler] Publish error: {e}\n")
                    except Exception:
                        pass
                else:
                    raise
            except Exception as e:
                # Другие ошибки
                if self.fallback_on_error:
                    with self._metrics_lock:
                        self._error_count += 1
                    try:
                        sys.stderr.write(f"[NATSHandler] Unexpected error: {e}\n")
                    except Exception:
                        pass
                else:
                    raise
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Получение метрик handler'а.
        
        Returns:
            Словарь с метриками:
            - sent_events: количество отправленных событий
            - dropped_events: количество потерянных событий (при переполнении очереди)
            - error_count: количество ошибок
            - queue_size: текущий размер очереди
            - is_connected: состояние подключения к NATS
        """
        with self._metrics_lock:
            return {
                "sent_events": self._sent_events,
                "dropped_events": self._dropped_events,
                "error_count": self._error_count,
                "queue_size": self._queue.qsize(),
                "is_connected": self._connected and (self._client is not None and self._client.is_connected() if self._client else False),
            }
    
    def close(self) -> None:
        """
        Закрытие handler'а и очистка ресурсов.
        
        Останавливает фоновый поток, отправляет оставшиеся события, закрывает NATS соединение.
        """
        # Остановить фоновый поток
        self._stop_event.set()
        
        if self._sender_thread is not None and self._sender_thread.is_alive():
            # Подождать завершения потока (максимум 5 секунд)
            self._sender_thread.join(timeout=5.0)
        
        # Отправить оставшиеся события из очереди
        remaining_events: List[bytes] = []
        while not self._queue.empty():
            try:
                event_data = self._queue.get_nowait()
                remaining_events.append(event_data)
            except queue.Empty:
                break
        
        if remaining_events:
            # Отправить оставшиеся события
            try:
                self._send_batch_to_nats(remaining_events)
            except Exception:
                pass  # Игнорируем ошибки при закрытии
        
        # Закрыть NATS соединение
        with self._client_lock:
            if self._client is not None:
                try:
                    self._client.close()
                except Exception:
                    pass
                self._client = None
            self._connected = False
        
        # Вызвать close() родительского класса
        super().close()
    
    @classmethod
    def from_config(cls, config: "NATSLoggerConfig") -> "NATSHandler":
        """
        Создание handler'а из конфигурации.
        
        Удобный способ создания handler'а с использованием NATSLoggerConfig.
        
        Args:
            config: NATSLoggerConfig с параметрами конфигурации
        
        Returns:
            NATSHandler с параметрами из конфигурации
        """
        return cls(
            nats_url=config.nats_url,
            service_name=config.service_name,
            subject_prefix=config.subject_prefix,
            level=config.level,
            batch_size=config.batch_size,
            batch_timeout=config.batch_timeout,
            queue_size=config.queue_size,
            fallback_on_error=config.fallback_on_error,
            enable_secondary_subjects=config.enable_secondary_subjects,
            hostname=config.hostname,
        )

