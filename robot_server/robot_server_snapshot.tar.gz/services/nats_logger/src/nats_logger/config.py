"""
Конфигурация для nats_logger.

Класс NATSLoggerConfig для загрузки конфигурации из различных источников:
- Переменные окружения
- config.toml файл
- Прямое указание параметров
"""

import os
import logging
from dataclasses import dataclass
from typing import Optional
from pathlib import Path


@dataclass
class NATSLoggerConfig:
    """
    Конфигурация для NATS logger.
    
    Все параметры имеют значения по умолчанию для упрощения использования.
    """
    
    nats_url: str
    service_name: str
    subject_prefix: str = "log"  # Формат: log.{service}.{level}
    level: int = logging.INFO
    batch_size: int = 10
    batch_timeout: float = 1.0
    queue_size: int = 1000
    fallback_on_error: bool = True
    enable_secondary_subjects: bool = True
    hostname: Optional[str] = None
    
    @classmethod
    def from_env(cls) -> "NATSLoggerConfig":
        """
        Загрузка конфигурации из переменных окружения.
        
        Используется для простой настройки через env variables.
        
        Returns:
            NATSLoggerConfig с параметрами из env
        """
        from .utils import detect_service_name, detect_hostname
        
        return cls(
            nats_url=os.getenv("NATS_URL", "nats://127.0.0.1:4222"),
            service_name=os.getenv("SERVICE_NAME") or detect_service_name(),
            subject_prefix=os.getenv("NATS_SUBJECT_PREFIX", "log"),  # Формат: log.{service}.{level}
            level=int(os.getenv("NATS_LOG_LEVEL", logging.INFO)),
            batch_size=int(os.getenv("NATS_BATCH_SIZE", "10")),
            batch_timeout=float(os.getenv("NATS_BATCH_TIMEOUT", "1.0")),
            queue_size=int(os.getenv("NATS_QUEUE_SIZE", "1000")),
            fallback_on_error=os.getenv("NATS_FALLBACK_ON_ERROR", "true").lower() == "true",
            enable_secondary_subjects=os.getenv("NATS_ENABLE_SECONDARY_SUBJECTS", "true").lower() == "true",
            hostname=os.getenv("HOSTNAME") or detect_hostname(),
        )
    
    @classmethod
    def from_toml(cls, config_path: Optional[str] = None) -> "NATSLoggerConfig":
        """
        Загрузка конфигурации из config.toml.
        
        Ищет config.toml в стандартных местах:
        1. Указанный путь
        2. Текущая директория
        3. ~/LARS/robot_server/config.toml
        
        Args:
            config_path: Путь к config.toml (опционально)
        
        Returns:
            NATSLoggerConfig с параметрами из config.toml
        
        Raises:
            FileNotFoundError: Если config.toml не найден
        """
        from .utils import detect_service_name, detect_hostname
        
        # Поиск config.toml
        if config_path is None:
            candidates = [
                Path("config.toml"),
                Path.home() / "LARS" / "robot_server" / "config.toml",
                Path("/config/config.toml"),  # Для Docker
            ]
            for candidate in candidates:
                if candidate.exists():
                    config_path = str(candidate)
                    break
        
        if config_path is None or not Path(config_path).exists():
            raise FileNotFoundError("config.toml not found in standard locations")
        
        # Чтение config.toml
        try:
            try:
                import tomllib  # Python 3.11+
            except ImportError:
                import tomli as tomllib  # Fallback для Python < 3.11
        
            with open(config_path, "rb") as f:
                config = tomllib.load(f)
        except Exception as e:
            raise FileNotFoundError(f"Failed to read config.toml: {e}")
        
        # Извлечение конфигурации NATS
        nats_config = config.get("nats", {})
        logging_config = nats_config.get("logging", {})
        
        return cls(
            nats_url=nats_config.get("url") or os.getenv("NATS_URL", "nats://127.0.0.1:4222"),
            service_name=logging_config.get("service_name") or os.getenv("SERVICE_NAME") or detect_service_name(),
            subject_prefix=logging_config.get("subject_prefix", "log"),  # Формат: log.{service}.{level}
            level=logging_config.get("level", logging.INFO),
            batch_size=logging_config.get("batch_size", 10),
            batch_timeout=logging_config.get("batch_timeout", 1.0),
            queue_size=logging_config.get("queue_size", 1000),
            fallback_on_error=logging_config.get("fallback_on_error", True),
            enable_secondary_subjects=logging_config.get("enable_secondary_subjects", True),
            hostname=logging_config.get("hostname") or os.getenv("HOSTNAME") or detect_hostname(),
        )
    
    @classmethod
    def from_dict(cls, data: dict) -> "NATSLoggerConfig":
        """
        Загрузка конфигурации из словаря.
        
        Удобно для программной настройки.
        
        Args:
            data: Словарь с параметрами конфигурации
        
        Returns:
            NATSLoggerConfig с параметрами из словаря
        """
        from .utils import detect_service_name, detect_hostname
        
        return cls(
            nats_url=data.get("nats_url", os.getenv("NATS_URL", "nats://127.0.0.1:4222")),
            service_name=data.get("service_name") or detect_service_name(),
            subject_prefix=data.get("subject_prefix", "log"),  # Формат: log.{service}.{level}
            level=data.get("level", logging.INFO),
            batch_size=data.get("batch_size", 10),
            batch_timeout=data.get("batch_timeout", 1.0),
            queue_size=data.get("queue_size", 1000),
            fallback_on_error=data.get("fallback_on_error", True),
            enable_secondary_subjects=data.get("enable_secondary_subjects", True),
            hostname=data.get("hostname") or detect_hostname(),
        )


