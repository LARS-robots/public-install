# IMU Daemon

Сервис для чтения IMU данных и публикации в NATS.

## Содержание

- [Назначение](#назначение)
- [Архитектура](#архитектура)
- [Формат данных](#формат-данных)
- [Калибровка](#калибровка)
- [Конфигурация](#конфигурация)
- [Интеграция с Docker Compose](#интеграция-с-docker-compose)
- [Зависимости](#зависимости)
- [Сборка образа](#сборка-образа)
- [Запуск](#запуск)
- [Логирование](#логирование)
- [Особенности реализации](#особенности-реализации)
- [Документация](#документация)

---

## Назначение

IMU daemon читает данные с MPU9250 через I2C и публикует измерения в NATS топик `loc.meas.imu` для использования основным демоном локализации.

**Основные функции:**
- Чтение акселерометра, гироскопа, магнитометра с MPU9250
- Автоматическая калибровка при старте (компенсация смещения)
- Публикация в NATS топик `loc.meas.imu` (core NATS, 50-200 Гц)
- Логирование через `nats_logger` в топик `log.imu-daemon.*`

**Примечание:** Магнитометр читается, но НЕ публикуется в `loc.meas.imu` (согласно спецификации "Демон IMU (без компаса)"). Магнитометр используется только для внутренней обработки/калибровки.

## Архитектура

```
MPU9250 (I2C) → IMU Reader → IMU Daemon → NATS (loc.meas.imu)
```

**Компоненты:**
- `imu_reader.py` - чтение данных с MPU9250 и калибровка
- `main.py` - основной демон (NATS publisher)
- `config_loader.py` - загрузка конфигурации

## Формат данных

Публикует в топик `loc.meas.imu` согласно спецификации:

```json
{
  "ts": 1732118400.222333,
  "kind": "imu",
  "ax": -0.12,
  "ay": 0.05,
  "az": 9.81,
  "gx": 0.001,
  "gy": -0.002,
  "gz": 0.034,
  "cov_acc": 0.02,
  "cov_gyro": 0.0003
}
```

**Поля:**
- `ts` - время измерения (UTC, сек)
- `kind` - тип измерения (`"imu"`)
- `ax, ay, az` - ускорения по осям IMU (м/с²)
- `gx, gy, gz` - угловые скорости по осям IMU (рад/с)
- `cov_acc` - типичная дисперсия по акселерометрам
- `cov_gyro` - типичная дисперсия по гироскопам

**Примечание:** Магнитометр (mx, my, mz) НЕ включается в публикуемые данные.

## Калибровка

При старте демон автоматически выполняет калибровку:

1. Собирает 100 образцов данных (по умолчанию) за 2 секунды
2. Предполагает, что IMU неподвижен в течение калибровки
3. Вычисляет средние смещения (bias) для акселерометра и гироскопа
4. Применяет смещения ко всем последующим измерениям

**Важно:** Во время калибровки IMU должен быть неподвижен!

## Конфигурация

**`config.toml`:**

```toml
[imu]
# I2C bus number (1 for Raspberry Pi)
i2c_bus = 1

# Publish rate (Hz) - must be within 50-200 Hz according to spec
publish_rate_hz = 50.0  # Recommended: 50 Hz

# Calibration settings
calibration_samples = 100    # Number of samples for calibration
calibration_duration = 2.0   # Duration of calibration in seconds

[nats]
# NATS server URL
# Use 127.0.0.1 when using host network mode (Raspberry Pi)
# Use "nats" service name when using bridge network mode
url = "nats://dev:devpass@127.0.0.1:4222"
```

## Интеграция с Docker Compose

Сервис добавлен в основной `compose.yml`:

```yaml
imu-daemon:
  image: ${IMU_IMAGE:-imu-daemon:local}
  platform: ${IMU_PLATFORM:-linux/arm64}
  network_mode: ${IMU_NETWORK_MODE:-host}
  devices:
    - ${IMU_DEVICE:-/dev/i2c-1:/dev/i2c-1}
  volumes:
    - ./services/imu_daemon:/app:rw
    - ./services/nats_logger/src:/nats_logger:ro
  depends_on:
    - nats
```

**Переменные окружения:**
- `IMU_IMAGE` - Docker образ (по умолчанию: `imu-daemon:local`)
- `IMU_PLATFORM` - платформа (по умолчанию: `linux/arm64` для RPi)
- `IMU_NETWORK_MODE` - режим сети (по умолчанию: `host`)
- `IMU_DEVICE` - I2C устройство (по умолчанию: `/dev/i2c-1:/dev/i2c-1`)
- `NATS_URL` - URL NATS сервера (по умолчанию: `nats://dev:devpass@127.0.0.1:4222`)
- `SERVICE_NAME` - имя сервиса для логирования (по умолчанию: `imu-daemon`)

## Зависимости

**Python библиотеки:**
- `nats-py>=2.0.0` - работа с NATS
- `mpu9250-jmdev>=1.0.0` - работа с MPU9250 через I2C
- `tomli>=2.0.0` - загрузка конфигурации

**Внешние сервисы:**
- NATS сервер (уже есть в проекте)
- MPU9250 подключенный к I2C bus 1

## Сборка образа

```bash
# Сборка для локального использования
docker buildx bake -f services/imu_daemon/docker-bake.hcl imu-daemon-local

# Или через docker build
docker build -t imu-daemon:local -f services/imu_daemon/Dockerfile services/imu_daemon
```

## Запуск

```bash
# Запуск через docker compose
docker compose up imu-daemon

# Или весь стек
docker compose up
```

## Логирование

Все логи публикуются через `nats_logger` в топик `log.imu-daemon.*`:
- `log.imu-daemon.INFO` - информационные сообщения
- `log.imu-daemon.WARNING` - предупреждения
- `log.imu-daemon.ERROR` - ошибки

**Особенности:**
- Использует `setup_unified_logging()` из `nats_logger`
- stdout только триггерные события ([START], [STOP], [ERROR])
- Все логи (INFO, WARNING, ERROR) отправляются в NATS
- Логи доступны через веб-интерфейс `/admin/logs`

**Просмотр логов:**
- Веб-интерфейс: `http://localhost:8000/admin/logs` (все логи)
- Docker logs: `docker compose logs imu-daemon` (только триггерные события)

## Особенности реализации

### Магнитометр

Магнитометр читается из MPU9250, но **НЕ публикуется** в `loc.meas.imu` согласно спецификации "Демон IMU (без компаса)". Магнитометр может использоваться для внутренней обработки или калибровки в будущем.

### Калибровка

Калибровка выполняется автоматически при старте:
- Собирает образцы данных в течение заданного времени
- Вычисляет средние смещения (bias)
- Применяет смещения ко всем измерениям

Если калибровка не удалась, используются сырые значения без компенсации смещения.

### NATS подключение

Демон использует `127.0.0.1` для подключения к NATS при работе в `host` network mode (Raspberry Pi). URL не заменяется автоматически на имя сервиса `nats`, что позволяет корректно работать в host network mode.

### Ковариации

Используются фиксированные рекомендованные значения:
- `cov_acc = 0.02` - дисперсия акселерометра
- `cov_gyro = 0.0003` - дисперсия гироскопа

Эти значения можно настроить в конфигурации в будущем.

## Документация

- [Спецификация локализации](../localization_daemon/README.md) - формат сообщений и топики
- [Архитектура NATS](../../docs/NATS.md) - общая архитектура NATS в проекте
- [Instructables Guide](https://www.instructables.com/How-to-Connect-MPU9250-and-Raspberry-Pi-Part-1/) - оригинальная инструкция по подключению MPU9250

