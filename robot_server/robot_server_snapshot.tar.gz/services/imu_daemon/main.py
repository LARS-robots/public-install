#!/usr/bin/env python3
"""
IMU Daemon - publishes IMU measurements to NATS.

Reads IMU data from MPU9250 via I2C and publishes to loc.meas.imu topic.
"""
import asyncio
import json
import logging
import os
import sys
import time
import signal
from typing import Optional, Dict, Any

import nats
from nats.aio.client import Client as NATS

# Add nats_logger to path if available as volume
import sys
from pathlib import Path
nats_logger_path = Path("/nats_logger")
if nats_logger_path.exists():
    sys.path.insert(0, str(nats_logger_path.parent))

from imu_reader import IMUReader
from config_loader import get_config

# Setup nats_logger
try:
    from nats_logger import NATSHandler, detect_service_name
    NATS_LOGGER_AVAILABLE = True
except ImportError:
    NATS_LOGGER_AVAILABLE = False
    log = logging.getLogger(__name__)
    log.warning("nats_logger not available, using standard logging")

# Setup basic logging first
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


class IMUDaemon:
    """
    IMU daemon that reads IMU data and publishes to NATS.
    """
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.imu_reader: Optional[IMUReader] = None
        self.config: Dict[str, Any] = {}
        self.publish_rate_hz = 50.0  # 50 Hz (recommended, within 50-200 Hz spec)
        self._shutdown_event = asyncio.Event()
        self._running = False
        
    def _load_config(self):
        """Load configuration from config.toml."""
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"✅ Loaded config from: {cfg.config_path}")
            
            # Get IMU-specific config
            imu_config = self.config.get("imu", {})
            self.publish_rate_hz = float(imu_config.get("publish_rate_hz", 50.0))
            
            return self.config
        except Exception as e:
            log.warning(f"⚠️ Failed to load config: {e}, using defaults")
            self.config = {}
            return self.config
    
    def _setup_nats_logger(self):
        """Setup nats_logger for centralized logging."""
        if not NATS_LOGGER_AVAILABLE:
            log.warning("⚠️ nats_logger not available, using standard logging only")
            return
        
        try:
            # Get NATS URL from config or env
            nats_config = self.config.get("nats", {})
            nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://dev:devpass@127.0.0.1:4222")
            
            # Clean up URL (only remove trailing colons, don't replace 127.0.0.1)
            if nats_url:
                nats_url = nats_url.strip().rstrip(":")
            
            # Use explicit service name or from env
            service_name = os.getenv("SERVICE_NAME") or "imu-daemon"
            
            # Create NATS handler
            handler = NATSHandler(
                nats_url=nats_url,
                service_name=service_name,
                subject_prefix="log",
                level=logging.INFO,
            )
            
            # Add handler to root logger
            logging.getLogger().addHandler(handler)
            log.info(f"✅ NATS logging enabled for service: {service_name}")
            
        except Exception as e:
            log.warning(f"⚠️ Failed to setup nats_logger: {e}")
    
    def _create_imu_reader(self) -> Optional[IMUReader]:
        """Create and configure IMU reader from config."""
        imu_config = self.config.get("imu", {})
        
        bus = int(imu_config.get("i2c_bus", 1))
        calibration_samples = int(imu_config.get("calibration_samples", 100))
        calibration_duration = float(imu_config.get("calibration_duration", 2.0))
        
        reader = IMUReader(
            bus=bus,
            calibration_samples=calibration_samples,
            calibration_duration=calibration_duration
        )
        
        if reader.connect():
            # Perform calibration
            if reader.calibrate():
                log.info("✅ IMU calibration successful")
            else:
                log.warning("⚠️ IMU calibration failed, using raw values")
            return reader
        else:
            log.error("❌ Failed to connect to IMU device")
            return None
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS server."""
        try:
            nats_config = self.config.get("nats", {})
            nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://dev:devpass@127.0.0.1:4222")
            
            # Clean up URL (only remove trailing colons, don't replace 127.0.0.1)
            if nats_url:
                nats_url = nats_url.strip().rstrip(":")
            
            log.info(f"🔌 Connecting to NATS at {nats_url}")
            self.nc = await nats.connect(
                nats_url,
                reconnect_time_wait=2,
                max_reconnect_attempts=-1,  # Infinite reconnects
                connect_timeout=5,
            )
            log.info("✅ Connected to NATS")
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to NATS: {e}")
            if self.nc:
                try:
                    await self.nc.close()
                except Exception:
                    pass
                self.nc = None
            return False
    
    async def _publish_imu_data(self, imu_data: Dict[str, Any]):
        """Publish IMU data to NATS topic loc.meas.imu."""
        if not self.nc:
            return
        
        try:
            # Format as JSONL (single line JSON)
            msg = json.dumps(imu_data, separators=(",", ":"))
            
            # Publish to loc.meas.imu (core NATS, not JetStream)
            await self.nc.publish("loc.meas.imu", msg.encode())
            
            log.debug(f"📡 Published IMU: ax={imu_data.get('ax'):.3f}, ay={imu_data.get('ay'):.3f}, az={imu_data.get('az'):.3f}, gz={imu_data.get('gz'):.3f}")
            
        except Exception as e:
            log.error(f"❌ Error publishing IMU data: {e}")
    
    async def _publish_loop(self):
        """Main loop: read IMU and publish to NATS."""
        log.info(f"🔄 Starting IMU publish loop at {self.publish_rate_hz} Hz")
        
        sleep_interval = 1.0 / self.publish_rate_hz
        
        while not self._shutdown_event.is_set():
            try:
                # Read IMU data
                imu_data = self.imu_reader.read()
                
                if imu_data:
                    # Publish to NATS
                    await self._publish_imu_data(imu_data)
                else:
                    log.debug("No valid IMU data")
                
                # Sleep to maintain publish rate
                await asyncio.sleep(sleep_interval)
                
            except asyncio.CancelledError:
                log.info("🛑 Publish loop cancelled")
                break
            except Exception as e:
                log.error(f"❌ Error in publish loop: {e}", exc_info=True)
                await asyncio.sleep(sleep_interval)
        
        log.info("🔄 IMU publish loop stopped")
    
    async def start(self):
        """Start the IMU daemon."""
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            log.info(f"🛑 Received signal {signum}, initiating graceful shutdown...")
            self._shutdown_event.set()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # Load configuration
        self._load_config()
        
        # Setup nats_logger
        self._setup_nats_logger()
        
        # Connect to NATS
        if not await self._connect_nats():
            log.error("❌ Failed to connect to NATS, exiting")
            sys.exit(1)
        
        # Create IMU reader (with calibration)
        self.imu_reader = self._create_imu_reader()
        if not self.imu_reader:
            log.error("❌ Failed to initialize IMU reader, exiting")
            sys.exit(1)
        
        log.info("🚀 IMU daemon started")
        
        # Start publishing loop
        self._running = True
        try:
            await self._publish_loop()
        except KeyboardInterrupt:
            log.info("🛑 Shutting down IMU daemon (KeyboardInterrupt)...")
            self._shutdown_event.set()
        except Exception as e:
            log.error(f"❌ Error in main loop: {e}", exc_info=True)
            self._shutdown_event.set()
        finally:
            await self._shutdown()
    
    async def _shutdown(self):
        """Graceful shutdown of the daemon."""
        log.info("🛑 Shutting down IMU daemon...")
        self._running = False
        
        # IMU reader doesn't need explicit disconnect (I2C is stateless)
        
        # Close NATS connection
        if self.nc:
            try:
                await self.nc.close()
                log.info("✅ NATS connection closed")
            except Exception:
                pass
        
        log.info("👋 IMU daemon stopped")


async def main():
    """Main entry point."""
    daemon = IMUDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("IMU daemon stopped by user")
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

