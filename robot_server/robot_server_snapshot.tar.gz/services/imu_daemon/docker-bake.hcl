group "default" {
  targets = ["imu-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, переопределяется из Python

target "imu-daemon-base" {
  context    = "./services/imu_daemon"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Используем переменную
}

target "imu-daemon-local" {
  inherits = ["imu-daemon-base"]
  tags     = ["imu-daemon:local"]
  output   = ["type=docker"]  # Load into local Docker for compose
}





