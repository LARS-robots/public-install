"""
IMU Reader for IMU daemon.

Reads IMU data from MPU9250 via I2C and provides structured data.
Adapted from test_imu_instr.py with calibration support.
"""
import time
import logging
from typing import Optional, Dict, Any, Tuple
from mpu9250_jmdev.registers import *
from mpu9250_jmdev.mpu_9250 import MPU9250

log = logging.getLogger(__name__)


class IMUReader:
    """
    IMU reader that reads data from MPU9250 via I2C.
    
    Supports:
    - Accelerometer (ax, ay, az) - published
    - Gyroscope (gx, gy, gz) - published
    - Magnetometer (mx, my, mz) - read but NOT published (used for calibration only)
    
    Performs automatic calibration on startup to compensate for sensor bias.
    """
    
    def __init__(
        self,
        bus: int = 1,
        address_mpu_master: int = MPU9050_ADDRESS_68,
        address_ak: int = AK8963_ADDRESS,
        gfs: int = GFS_1000,
        afs: int = AFS_8G,
        mfs: int = AK8963_BIT_16,
        mode: int = AK8963_MODE_C100HZ,
        calibration_samples: int = 100,
        calibration_duration: float = 2.0
    ):
        """
        Initialize IMU reader.
        
        Args:
            bus: I2C bus number (default: 1 for Raspberry Pi)
            address_mpu_master: MPU9250 master address
            address_ak: AK8963 (magnetometer) address
            gfs: Gyroscope full scale range
            afs: Accelerometer full scale range
            mfs: Magnetometer full scale range
            mode: Magnetometer mode
            calibration_samples: Number of samples for calibration
            calibration_duration: Duration of calibration in seconds
        """
        self.bus = bus
        self.address_mpu_master = address_mpu_master
        self.address_ak = address_ak
        self.gfs = gfs
        self.afs = afs
        self.mfs = mfs
        self.mode = mode
        self.calibration_samples = calibration_samples
        self.calibration_duration = calibration_duration
        
        self.mpu: Optional[MPU9250] = None
        self._connected = False
        
        # Calibration offsets (will be calculated during calibration)
        self.accel_offset = [0.0, 0.0, 0.0]  # [ax, ay, az]
        self.gyro_offset = [0.0, 0.0, 0.0]   # [gx, gy, gz]
        self._calibrated = False
    
    def connect(self) -> bool:
        """
        Initialize and configure MPU9250.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.mpu = MPU9250(
                address_ak=self.address_ak,
                address_mpu_master=self.address_mpu_master,
                address_mpu_slave=None,
                bus=self.bus,
                gfs=self.gfs,
                afs=self.afs,
                mfs=self.mfs,
                mode=self.mode
            )
            
            # Configure the MPU9250
            self.mpu.configure()
            
            self._connected = True
            log.info(f"✅ Connected to MPU9250 on I2C bus {self.bus}")
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to MPU9250: {e}")
            self._connected = False
            return False
    
    def calibrate(self) -> bool:
        """
        Perform automatic calibration to compensate for sensor bias.
        
        Calibration assumes IMU is stationary during this period.
        Collects samples and calculates average offsets.
        
        Returns:
            True if calibration successful, False otherwise
        """
        if not self._connected or not self.mpu:
            log.error("❌ Cannot calibrate: IMU not connected")
            return False
        
        log.info(f"🔧 Starting IMU calibration ({self.calibration_duration}s, {self.calibration_samples} samples)...")
        log.info("   Please keep IMU stationary during calibration")
        
        accel_sum = [0.0, 0.0, 0.0]
        gyro_sum = [0.0, 0.0, 0.0]
        sample_count = 0
        
        start_time = time.time()
        sample_interval = self.calibration_duration / self.calibration_samples
        
        try:
            while sample_count < self.calibration_samples:
                # Read raw values
                accel_data = self.mpu.readAccelerometerMaster()
                gyro_data = self.mpu.readGyroscopeMaster()
                
                # Accumulate for averaging
                accel_sum[0] += accel_data[0]
                accel_sum[1] += accel_data[1]
                accel_sum[2] += accel_data[2]
                
                gyro_sum[0] += gyro_data[0]
                gyro_sum[1] += gyro_data[1]
                gyro_sum[2] += gyro_data[2]
                
                sample_count += 1
                time.sleep(sample_interval)
            
            # Calculate offsets (average of samples)
            self.accel_offset = [
                accel_sum[0] / sample_count,
                accel_sum[1] / sample_count,
                accel_sum[2] / sample_count
            ]
            
            # For accelerometer, subtract gravity from Z axis (assuming Z-up)
            # Typical: az should be ~9.81 m/s² when stationary
            self.accel_offset[2] -= 9.81
            
            self.gyro_offset = [
                gyro_sum[0] / sample_count,
                gyro_sum[1] / sample_count,
                gyro_sum[2] / sample_count
            ]
            
            self._calibrated = True
            log.info(f"✅ Calibration complete:")
            log.info(f"   Accel offset: {self.accel_offset}")
            log.info(f"   Gyro offset: {self.gyro_offset}")
            return True
            
        except Exception as e:
            log.error(f"❌ Calibration failed: {e}")
            self._calibrated = False
            return False
    
    def read(self) -> Optional[Dict[str, Any]]:
        """
        Read and return IMU data.
        
        Returns:
            Dictionary with IMU data according to spec, or None if error
        """
        if not self._connected or not self.mpu:
            return None
        
        try:
            # Read accelerometer, gyroscope, and magnetometer
            accel_data = self.mpu.readAccelerometerMaster()
            gyro_data = self.mpu.readGyroscopeMaster()
            mag_data = self.mpu.readMagnetometerMaster()  # Read but not published
            
            # Apply calibration offsets
            if self._calibrated:
                ax = accel_data[0] - self.accel_offset[0]
                ay = accel_data[1] - self.accel_offset[1]
                az = accel_data[2] - self.accel_offset[2]
                
                gx = gyro_data[0] - self.gyro_offset[0]
                gy = gyro_data[1] - self.gyro_offset[1]
                gz = gyro_data[2] - self.gyro_offset[2]
            else:
                # Use raw values if not calibrated
                ax, ay, az = accel_data[0], accel_data[1], accel_data[2]
                gx, gy, gz = gyro_data[0], gyro_data[1], gyro_data[2]
            
            # Build message according to spec (NO magnetometer in published data)
            imu_data = {
                "ts": time.time(),
                "kind": "imu",
                "ax": float(ax),
                "ay": float(ay),
                "az": float(az),
                "gx": float(gx),
                "gy": float(gy),
                "gz": float(gz),
                "cov_acc": 0.02,      # Recommended default covariance
                "cov_gyro": 0.0003,   # Recommended default covariance
            }
            
            # Note: magnetometer data (mag_data) is read but NOT included in published message
            # This is according to spec: "Демон IMU (без компаса)"
            
            return imu_data
            
        except Exception as e:
            log.warning(f"⚠️ Error reading IMU: {e}")
            return None
    
    def is_connected(self) -> bool:
        """Check if IMU reader is connected."""
        return self._connected and self.mpu is not None
    
    def is_calibrated(self) -> bool:
        """Check if IMU is calibrated."""
        return self._calibrated





