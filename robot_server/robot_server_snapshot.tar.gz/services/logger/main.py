#!/usr/bin/env python3
"""
Logger Daemon - подписчик NATS Core для централизованного хранения логов.

Слушает log.* через Core NATS, накапливает события в памяти и
раз в интервал (например, 1 сек) записывает их в SQLite одной операцией.
JSONL режим поддерживается как legacy-вариант.
"""
import asyncio
import json
import logging
import os
import sys
import signal
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATSClient
from nats.js.errors import NotFoundError

from jsonl_segment_handler import JSONLSegmentHandler
from sqlite_handler import SQLiteHandler
from config_loader import get_config

# Настройка логирования для самого демона
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


class LoggerDaemon:
    """Демон, который читает логи из NATS Core и пишет их в backend-и."""
    
    def __init__(self):
        self.nc: Optional[NATSClient] = None
        self.handler: Optional[JSONLSegmentHandler] = None  # JSONL handler (legacy)
        self.sqlite_handler: Optional[SQLiteHandler] = None  # SQLite handler (new)
        self.config: Dict[str, Any] = {}
        self._subscription = None  # Core NATS subscription
        
        # Метрики
        self._metrics = {
            "messages_processed": 0,
            "events_saved": 0,
            "errors": 0,
            "reconnect_count": 0,
            "start_time": None,
        }
        self._metrics_lock = None  # Will be initialized in start()
        
        # Флаги для graceful shutdown
        self._shutdown_event = asyncio.Event()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
        
        # NATS connection parameters
        self._nats_url: Optional[str] = None
        self._reconnect_delay = 5.0  # seconds
        
        # Буферизация логов для периодической пакетной записи
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_lock: Optional[asyncio.Lock] = None
        self._flush_interval_sec = 1.0
        
        # Периодическая публикация состояния сервиса (KV svc_state с TTL=10s)
        self._state_interval_sec = 5.0
        self._last_state_emit = 0.0
        self._backend: str = "sqlite"
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from config.toml."""
        try:
            app_config = get_config()
            self.config = app_config.raw_data
            log.info(f"✅ Loaded config from: {app_config.config_path}")
            return self.config
        except Exception as e:
            log.warning(f"❌ Failed to load config: {e}, using defaults")
            self.config = {}
            return self.config
    
    def _get_config_value(self, key: str, env_var: str, default: Any, section: str = "logging") -> Any:
        """
        Get configuration value with priority: env var > config.toml > default.
        
        Args:
            key: Key in config.toml section
            env_var: Environment variable name
            default: Default value
            section: Section in config.toml (default: "logger")
        """
        # Priority 1: Environment variable
        env_value = os.getenv(env_var)
        if env_value is not None:
            return env_value
        
        # Priority 2: config.toml
        section_config = self.config.get(section, {})
        if key in section_config:
            return section_config[key]
        
        # Priority 3: Fallback to "logger" section for backward compatibility
        if section == "logging":
            logger_section = self.config.get("logger", {})
            if key in logger_section:
                return logger_section[key]
        
        # Priority 4: Default
        return default
    
    def _should_use_backend(self, backend_name: str) -> bool:
        """
        Determine if a specific backend should be used.
        
        Args:
            backend_name: "sqlite" or "jsonl"
            
        Returns:
            True if backend should be used
        """
        backend = self._get_config_value("backend", "LOG_BACKEND", "sqlite")
        return backend == backend_name or backend == "both"
    
    def _create_sqlite_handler(self) -> Optional[SQLiteHandler]:
        """Create SQLiteHandler from configuration."""
        if not self._should_use_backend("sqlite"):
            return None
        
        logging_config = self.config.get("logging", {})
        sqlite_config = logging_config.get("sqlite", {})
        retention_config = logging_config.get("retention", {})
        
        db_path = sqlite_config.get("path", "/var/log/lars/sqlite/logs.db")
        wal = sqlite_config.get("wal", True)
        synchronous = sqlite_config.get("synchronous", "NORMAL")
        busy_timeout_ms = int(sqlite_config.get("busy_timeout_ms", 5000))
        max_db_size_mb = int(sqlite_config.get("max_db_size_mb", 4096))
        max_age_days = int(retention_config.get("max_days", logging_config.get("max_age_days", 14)))
        cleanup_interval_sec = int(retention_config.get("cleanup_interval_sec", 600))
        
        log.info(f"SQLite database: {db_path}")
        log.info(f"SQLite settings: WAL={wal}, sync={synchronous}, max_size={max_db_size_mb}MB")
        log.info(f"Retention: max_age={max_age_days} days, cleanup_interval={cleanup_interval_sec}s")
        
        handler = SQLiteHandler(
            db_path=db_path,
            wal=wal,
            synchronous=synchronous,
            busy_timeout_ms=busy_timeout_ms,
            max_db_size_mb=max_db_size_mb,
            max_age_days=max_age_days,
            cleanup_interval_sec=cleanup_interval_sec,
        )
        
        return handler
    
    def _create_handler(self) -> Optional[JSONLSegmentHandler]:
        """Create JSONLSegmentHandler from configuration (only if backend="jsonl" or "both")."""
        if not self._should_use_backend("jsonl"):
            return None
        
        # Logger configuration
        live_dir = self._get_config_value("live_dir", "LOG_LIVE_DIR", "/var/log/lars/live")
        archive_dir = self._get_config_value("archive_dir", "LOG_ARCHIVE_DIR", "/var/log/lars/archive")
        segment_size_mb = int(self._get_config_value("segment_size_mb", "LOG_SEGMENT_SIZE_MB", 64))
        segment_max_sec = int(self._get_config_value("segment_max_sec", "LOG_SEGMENT_MAX_SEC", 1800))
        zstd_level = int(self._get_config_value("zstd_level", "LOG_ZSTD_LEVEL", 9))
        max_total_bytes = self._get_config_value("max_total_bytes", "LOG_MAX_TOTAL_BYTES", "8GiB")
        max_age_days = int(self._get_config_value("max_age_days", "LOG_MAX_AGE_DAYS", 14))
        
        log.info(f"📁 JSONL directories: live={live_dir}, archive={archive_dir}")
        log.info(f"⚙️  Segment settings: size={segment_size_mb}MB, time={segment_max_sec}s")
        log.info(f"🗜️  Compression: zstd level={zstd_level}")
        log.info(f"🧹 Retention: max_age={max_age_days} days, max_size={max_total_bytes}")
        
        handler = JSONLSegmentHandler(
            live_dir=live_dir,
            archive_dir=archive_dir,
            segment_size_mb=segment_size_mb,
            segment_max_sec=segment_max_sec,
            zstd_level=zstd_level,
            max_total_bytes=max_total_bytes,
            max_age_days=max_age_days,
        )
        
        return handler
    
    def _parse_log_message(self, msg_data: bytes) -> Optional[Dict[str, Any] | List[Dict[str, Any]]]:
        """
        Parse log message from NATS.
        
        Args:
            msg_data: Raw message data from NATS
            
        Returns:
            Parsed event dict or list of events, or None on error
        """
        try:
            data = json.loads(msg_data.decode("utf-8"))
            return data
        except json.JSONDecodeError as e:
            log.error(f"❌ Failed to parse JSON message: {e}")
            return None
        except Exception as e:
            log.error(f"❌ Error parsing message: {e}")
            return None
    
    def _normalize_log_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize log event dict (ensure required fields exist).
        
        Args:
            event: Event dict from NATS
            
        Returns:
            Normalized event dict
        """
        # Ensure required fields exist with defaults
        normalized = {
            "ts": event.get("ts", ""),
            "level": event.get("level", "INFO"),
            "service": event.get("service", ""),
            "logger": event.get("logger", ""),
            "msg": event.get("msg", ""),
            "hostname": event.get("hostname", ""),
            "pid": event.get("pid", 0),
            "subject": event.get("subject", ""),
        }
        
        # Copy all other fields
        for key, value in event.items():
            if key not in normalized:
                normalized[key] = value
        
        return normalized
    
    async def _on_message(self, msg):
        """Обработать входящее сообщение из NATS Core и положить в буфер."""
        try:
            # Parse message (delegate to helper)
            data = self._parse_log_message(msg.data)
            if data is None:
                return
            
            events_to_process = []
            
            if isinstance(data, list):
                # Batch of events
                for event in data:
                    if isinstance(event, dict):
                        normalized = self._normalize_log_event(event)
                        if not normalized.get("subject"):
                            normalized["subject"] = msg.subject
                        events_to_process.append(normalized)
            elif isinstance(data, dict):
                # Single event
                normalized = self._normalize_log_event(data)
                if not normalized.get("subject"):
                    normalized["subject"] = msg.subject
                events_to_process.append(normalized)
            
            if events_to_process:
                # Важно: в callback не пишем в БД, только складываем в буфер
                # чтобы запись шла пакетно раз в интервал.
                async with self._buffer_lock:
                    self._buffer.extend(events_to_process)
            
            # Метрики по сообщениям (не по событиям)
            async with self._metrics_lock:
                self._metrics["messages_processed"] += 1
            
        except Exception as e:
            log.error(f"❌ Error processing message: {e}", exc_info=True)
            async with self._metrics_lock:
                self._metrics["errors"] += 1
    
    async def _flush_buffer(self, reason: str = "periodic"):
        """Слить накопленные события в backend-и одной операцией."""
        if not self._buffer_lock:
            return
        
        async with self._buffer_lock:
            if not self._buffer:
                return
            batch = self._buffer
            self._buffer = []
        
        # Если нет ни одного backend-а, просто считаем как ошибку
        if not self.handler and not self.sqlite_handler:
            async with self._metrics_lock:
                self._metrics["errors"] += len(batch)
            return
        
        # JSONL (legacy) — пишем поштучно, чтобы сохранить поведение ротации
        if self.handler:
            for event in batch:
                try:
                    self.handler.emit_log(event)
                except Exception as e:
                    log.error(f"❌ JSONL handler error: {e}")
                    async with self._metrics_lock:
                        self._metrics["errors"] += 1
        
        # SQLite — одна транзакция на весь батч
        if self.sqlite_handler:
            try:
                self.sqlite_handler.write_batch(batch)
            except Exception as e:
                log.error(f"❌ SQLite batch write error: {e}")
                async with self._metrics_lock:
                    self._metrics["errors"] += 1
        
        async with self._metrics_lock:
            self._metrics["events_saved"] += len(batch)
        
        log.debug(f"   ✓ Flushed {len(batch)} events ({reason})")
    
    async def _flush_loop(self):
        """Периодический flush буфера в SQLite/JSONL."""
        log.info("🔄 Starting flush loop...")
        while not self._shutdown_event.is_set():
            try:
                await asyncio.sleep(self._flush_interval_sec)
                # Раз в интервал забираем накопленные записи и пишем одной транзакцией
                await self._flush_buffer(reason="periodic")
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"❌ Error in flush loop: {e}", exc_info=True)
                async with self._metrics_lock:
                    self._metrics["errors"] += 1
                await asyncio.sleep(1.0)
        log.info("🔄 Flush loop stopped")
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS Core and subscribe to log.>."""
        try:
            log.info(f"🔌 Connecting to NATS at {self._nats_url}")
            self.nc = await nats.connect(
                self._nats_url,
                reconnect_time_wait=2,
                max_reconnect_attempts=-1,  # Infinite reconnects
                connect_timeout=5,
            )
            log.info("✅ Connected to NATS")
            try:
                await self._svc_state_set("logger-daemon", "starting", None)
            except Exception:
                log.debug("[SVC_STATE] Failed to publish starting status", exc_info=True)
            
            # Подписка на все логи в Core NATS
            self._subscription = await self.nc.subscribe("log.>", cb=self._on_message)
            log.info("✅ Subscribed to 'log.>' in NATS Core")
            
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to NATS: {e}")
            if self.nc:
                try:
                    await self.nc.close()
                except Exception:
                    pass
                self.nc = None
            return False
    
    async def _reconnect(self):
        """Reconnect to NATS with exponential backoff."""
        async with self._metrics_lock:
            self._metrics["reconnect_count"] += 1
            reconnect_count = self._metrics["reconnect_count"]
        
        log.info(f"🔄 Attempting to reconnect to NATS (attempt {reconnect_count})...")
        
        # Close existing connection
        if self.nc:
            try:
                await self.nc.close()
            except Exception:
                pass
            self.nc = None
            self._subscription = None
        
        # Wait before reconnecting
        await asyncio.sleep(self._reconnect_delay)
        
        # Try to reconnect
        if await self._connect_nats():
            log.info("✅ Successfully reconnected to NATS")
            return True
        else:
            log.warning(f"⚠️  Reconnection failed, will retry in {self._reconnect_delay}s")
            return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics."""
        import time
        async def _get():
            async with self._metrics_lock:
                metrics = self._metrics.copy()
                if metrics["start_time"]:
                    metrics["uptime_seconds"] = time.time() - metrics["start_time"]
                return metrics
        # For sync access, we'll use a simple approach
        return self._metrics.copy()
    
    async def start(self):
        """Start the logger daemon."""
        import time
        import threading
        
        # Initialize metrics lock
        self._metrics_lock = asyncio.Lock()
        self._buffer_lock = asyncio.Lock()
        
        self._running = True
        self._metrics["start_time"] = time.time()
        
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            log.info(f"🛑 Received signal {signum}, initiating graceful shutdown...")
            self._shutdown_event.set()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # Load configuration
        self._load_config()
        
        # Determine backend
        backend = self._get_config_value("backend", "LOG_BACKEND", "sqlite")
        self._backend = str(backend)
        log.info(f"📦 Logging backend: {backend}")
        
        # Create handlers based on backend config
        self.handler = self._create_handler()  # JSONL handler (if backend="jsonl" or "both")
        if self.handler:
            log.info("✅ JSONL segment handler created")
        
        self.sqlite_handler = self._create_sqlite_handler()  # SQLite handler (if backend="sqlite" or "both")
        if self.sqlite_handler:
            log.info("✅ SQLite handler created")
        
        if not self.handler and not self.sqlite_handler:
            log.error("❌ No logging backend enabled! Check config.")
            sys.exit(1)
        
        # Интервал пакетной записи (по умолчанию 1 сек)
        try:
            flush_interval = float(self._get_config_value("flush_interval_sec", "LOG_FLUSH_INTERVAL_SEC", 1.0))
        except Exception:
            flush_interval = 1.0
        self._flush_interval_sec = max(0.1, flush_interval)
        log.info(f"⏱️  Batch flush interval: {self._flush_interval_sec:.2f}s")
        
        # Get NATS URL
        nats_config = self.config.get("nats", {})
        nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://nats:4222")
        
        # Clean up URL: remove trailing colons, spaces, and fix common issues
        if nats_url:
            nats_url = nats_url.strip().rstrip(":")
            # Inside Docker container, replace 127.0.0.1 with service name 'nats'
            if "127.0.0.1" in nats_url or "localhost" in nats_url:
                nats_url = nats_url.replace("127.0.0.1", "nats").replace("localhost", "nats")
        
        self._nats_url = nats_url
        log.info(f"🔗 NATS URL configured: {self._nats_url}")
        
        # Debug: Check if we can resolve NATS hostname
        import socket
        try:
            # Parse NATS URL correctly: nats://user:pass@host:port or nats://host:port
            # Extract the part after @ (if present) or after ://
            url_part = self._nats_url.split("://")[1]  # e.g., "dev:devpass@nats:4222" or "nats:4222"
            if "@" in url_part:
                # Has authentication: extract host:port part after @
                host_port = url_part.split("@")[1]  # e.g., "nats:4222"
            else:
                # No authentication: use the whole part
                host_port = url_part  # e.g., "nats:4222"
            # Extract hostname (before the port)
            nats_host = host_port.split(":")[0]  # e.g., "nats"
            
            log.info(f"🔍 Attempting DNS resolution for NATS hostname: {nats_host}")
            resolved = socket.gethostbyname(nats_host)
            log.info(f"✅ DNS resolution successful: {nats_host} -> {resolved}")
        except socket.gaierror as e:
            log.error(f"❌ DNS resolution failed for {nats_host}: {e}")
            log.error("   This usually means the service is not on the same Docker network as NATS")
        except Exception as e:
            log.warning(f"⚠️  Could not test DNS resolution: {e}")
        
        # Connect to NATS
        if not await self._connect_nats():
            log.error("❌ Failed to connect to NATS, exiting")
            sys.exit(1)
        
        # Start periodic flush task
        self._flush_task = asyncio.create_task(self._flush_loop())
        log.info(f"✅ Started flush task (task: {self._flush_task.get_name()})")
        
        log.info("🚀 Logger daemon started, waiting for logs...")
        try:
            await self._svc_state_set("logger-daemon", "ready", None)
        except Exception:
            log.debug("[SVC_STATE] Failed to publish ready status", exc_info=True)
        
        # Keep running until shutdown signal
        try:
            while not self._shutdown_event.is_set():
                await asyncio.sleep(1)
                
                # Periodic metrics log (every 5 minutes)
                if int(time.time()) % 300 == 0:
                    metrics = self.get_metrics()
                    log.info(
                        f"📊 Metrics: processed={metrics['messages_processed']}, "
                        f"events={metrics['events_saved']}, errors={metrics['errors']}, "
                        f"reconnects={metrics['reconnect_count']}"
                    )
                
                # Периодическое обновление svc_state, иначе запись истечет по TTL
                now = time.time()
                if now - self._last_state_emit >= self._state_interval_sec:
                    details = {"backend": self._backend}
                    if self._buffer_lock:
                        try:
                            async with self._buffer_lock:
                                details["buffered"] = len(self._buffer)
                        except Exception:
                            pass
                    try:
                        await self._svc_state_set("logger-daemon", "ready", details)
                    except Exception:
                        log.debug("[SVC_STATE] Failed to publish heartbeat", exc_info=True)
                    self._last_state_emit = now
        except KeyboardInterrupt:
            log.info("🛑 Shutting down logger daemon (KeyboardInterrupt)...")
            self._shutdown_event.set()
        except Exception as e:
            log.error(f"❌ Error in main loop: {e}", exc_info=True)
            self._shutdown_event.set()
        finally:
            await self._shutdown()
    
    async def _shutdown(self):
        """Graceful shutdown of the daemon."""
        log.info("🛑 Shutting down logger daemon...")
        self._running = False
        
        # Cancel flush task
        if self._flush_task and not self._flush_task.done():
            log.info("🛑 Cancelling flush task...")
            self._flush_task.cancel()
            try:
                await asyncio.wait_for(self._flush_task, timeout=5.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        
        # Финальный сброс буфера перед закрытием
        try:
            await self._flush_buffer(reason="shutdown")
        except Exception:
            pass
        
        # Cleanup handlers
        if self.handler:
            try:
                self.handler.close()
                log.info("✅ JSONL handler closed")
            except Exception:
                pass
        
        if self.sqlite_handler:
            try:
                self.sqlite_handler.close()
                log.info("✅ SQLite handler closed")
            except Exception:
                pass
        
        if self._subscription:
            try:
                await self._subscription.unsubscribe()
                log.info("✅ Unsubscribed from logs")
            except Exception:
                pass
        
        if self.nc:
            try:
                await self.nc.close()
                log.info("✅ NATS connection closed")
            except Exception:
                pass
        
        # Final metrics
        metrics = self.get_metrics()
        log.info(
            f"📊 Final metrics: processed={metrics['messages_processed']}, "
            f"events={metrics['events_saved']}, errors={metrics['errors']}, "
            f"reconnects={metrics['reconnect_count']}"
        )
        
        log.info("👋 Logger daemon stopped")

    async def _svc_state_set(self, service: str, status: str, details: Optional[Dict[str, Any]] = None):
        """Publish service status into NATS KV svc_state using existing connection."""
        if not self.nc:
            return
        try:
            js = self.nc.jetstream()
            try:
                kv = await js.key_value("svc_state")
            except NotFoundError:
                kv = await js.create_key_value("svc_state")
            payload = {
                "service": service,
                "status": status,
                "ts": __import__("time").time(),
                "details": details or {},
            }
            await kv.put(service, json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        except Exception:
            # best-effort only
            pass


async def main():
    """Main entry point."""
    daemon = LoggerDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Logger daemon stopped by user")
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

