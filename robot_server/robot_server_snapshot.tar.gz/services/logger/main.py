#!/usr/bin/env python3
"""
Logger Daemon - NATS JetStream subscriber for centralized log storage.

Subscribes to log.* subjects through JetStream with durable consumer,
creates JetStream Stream for log.* on first start,
saves logs to JSONL files with rotation and archiving.
"""
import asyncio
import json
import logging
import os
import sys
import signal
from typing import Dict, Any, Optional
from pathlib import Path

import nats
from nats.aio.client import Client as NATSClient
from nats.js.errors import NotFoundError

from jsonl_segment_handler import JSONLSegmentHandler
from config_loader import get_config

# Настройка логирования для самого демона
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


class LoggerDaemon:
    """Logger daemon that saves logs from NATS JetStream to files."""
    
    def __init__(self):
        self.nc: Optional[NATSClient] = None
        self.js = None  # JetStream context
        self.handler: Optional[JSONLSegmentHandler] = None
        self.config: Dict[str, Any] = {}
        self._subscription = None  # JetStream push subscription
        self._consumer = None  # JetStream pull consumer
        
        # Метрики
        self._metrics = {
            "messages_processed": 0,
            "events_saved": 0,
            "errors": 0,
            "reconnect_count": 0,
            "start_time": None,
        }
        self._metrics_lock = None  # Will be initialized in start()
        
        # Флаги для graceful shutdown
        self._shutdown_event = asyncio.Event()
        self._pull_task: Optional[asyncio.Task] = None
        self._running = False
        
        # NATS connection parameters
        self._nats_url: Optional[str] = None
        self._reconnect_delay = 5.0  # seconds
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from config.toml."""
        try:
            app_config = get_config()
            self.config = app_config.raw_data
            log.info(f"✅ Loaded config from: {app_config.config_path}")
            return self.config
        except Exception as e:
            log.warning(f"❌ Failed to load config: {e}, using defaults")
            self.config = {}
            return self.config
    
    def _get_config_value(self, key: str, env_var: str, default: Any, section: str = "logger") -> Any:
        """
        Get configuration value with priority: env var > config.toml > default.
        
        Args:
            key: Key in config.toml section
            env_var: Environment variable name
            default: Default value
            section: Section in config.toml (default: "logger")
        """
        # Priority 1: Environment variable
        env_value = os.getenv(env_var)
        if env_value is not None:
            return env_value
        
        # Priority 2: config.toml
        section_config = self.config.get(section, {})
        if key in section_config:
            return section_config[key]
        
        # Priority 3: Default
        return default
    
    def _create_handler(self) -> JSONLSegmentHandler:
        """Create JSONLSegmentHandler from configuration."""
        # NATS URL (from [nats] section or env)
        nats_config = self.config.get("nats", {})
        nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://nats:4222")
        # Clean up URL: remove trailing colons and spaces
        if nats_url:
            nats_url = nats_url.strip().rstrip(":")
            # Inside Docker container, replace 127.0.0.1 with service name 'nats'
            if "127.0.0.1" in nats_url or "localhost" in nats_url:
                nats_url = nats_url.replace("127.0.0.1", "nats").replace("localhost", "nats")
        
        # Logger configuration
        live_dir = self._get_config_value("live_dir", "LOG_LIVE_DIR", "/var/log/lars/live")
        archive_dir = self._get_config_value("archive_dir", "LOG_ARCHIVE_DIR", "/var/log/lars/archive")
        segment_size_mb = int(self._get_config_value("segment_size_mb", "LOG_SEGMENT_SIZE_MB", 64))
        segment_max_sec = int(self._get_config_value("segment_max_sec", "LOG_SEGMENT_MAX_SEC", 1800))
        zstd_level = int(self._get_config_value("zstd_level", "LOG_ZSTD_LEVEL", 9))
        max_total_bytes = self._get_config_value("max_total_bytes", "LOG_MAX_TOTAL_BYTES", "8GiB")
        max_age_days = int(self._get_config_value("max_age_days", "LOG_MAX_AGE_DAYS", 14))
        
        log.info(f"📁 Logger directories: live={live_dir}, archive={archive_dir}")
        log.info(f"⚙️  Segment settings: size={segment_size_mb}MB, time={segment_max_sec}s")
        log.info(f"🗜️  Compression: zstd level={zstd_level}")
        log.info(f"🧹 Retention: max_age={max_age_days} days, max_size={max_total_bytes}")
        
        handler = JSONLSegmentHandler(
            live_dir=live_dir,
            archive_dir=archive_dir,
            segment_size_mb=segment_size_mb,
            segment_max_sec=segment_max_sec,
            zstd_level=zstd_level,
            max_total_bytes=max_total_bytes,
            max_age_days=max_age_days,
        )
        
        return handler
    
    async def _create_jetstream_stream(self):
        """Create JetStream Stream for log.> subjects if it doesn't exist."""
        try:
            # Создаем stream для log.> (wildcard для всех логов: log.api.INFO, log.camera-daemon.WARNING, etc.)
            # Используем только log.>, так как log.* перекрывается с log.>
            await self.js.add_stream(
                name="LOGS",
                subjects=["log.>"],  # log.> включает все subjects, начинающиеся с log.
                storage="file",  # File storage для персистентности
                retention="limits",  # Retention policy
            )
            log.info("✅ Created JetStream stream 'LOGS' for subjects 'log.>'")
        except Exception as e:
            error_str = str(e).lower()
            # Stream может уже существовать - это нормально
            if "stream name already in use" in error_str or "stream already exists" in error_str:
                log.info("ℹ️  JetStream stream 'LOGS' already exists")
            else:
                # Обработка ошибки перекрытия subjects (если stream уже существует с другим pattern)
                if "overlaps" in error_str or "subject" in error_str:
                    log.warning(f"⚠️  JetStream stream 'LOGS' exists with different subjects: {e}")
                    log.info("ℹ️  Attempting to update stream configuration...")
                    # Пытаемся обновить stream
                    try:
                        await self.js.update_stream(
                            name="LOGS",
                            subjects=["log.>"],
                        )
                        log.info("✅ Updated JetStream stream 'LOGS' to use 'log.>' subjects")
                    except Exception as update_error:
                        log.warning(f"⚠️  Could not update stream: {update_error}")
                        log.info("ℹ️  Will use existing stream configuration")
                else:
                    log.error(f"❌ Failed to create stream: {e}")
                    raise
    
    async def _pull_messages(self):
        """Pull messages from JetStream consumer with reconnection support."""
        log.info("🔄 Starting pull messages loop...")
        pull_count = 0
        consecutive_errors = 0
        max_consecutive_errors = 10
        
        while not self._shutdown_event.is_set():
            try:
                # Check if consumer is still valid
                if self._consumer is None or self.nc is None or not self.nc.is_connected:
                    log.warning("⚠️  NATS connection lost, attempting to reconnect...")
                    await self._reconnect()
                    continue
                
                try:
                    # Fetch messages from JetStream consumer (batch=10, timeout=5 seconds)
                    msgs = await self._consumer.fetch(batch=10, timeout=5.0)
                    consecutive_errors = 0  # Reset error counter on success
                    
                    if msgs:
                        async with self._metrics_lock:
                            self._metrics["messages_processed"] += len(msgs)
                        
                        log.info(f"📨 Received {len(msgs)} message(s) from JetStream")
                        for msg in msgs:
                            # Показать краткую информацию о сообщении
                            try:
                                data = json.loads(msg.data.decode("utf-8"))
                                if isinstance(data, dict):
                                    service = data.get("service", "unknown")
                                    level = data.get("level", "UNKNOWN")
                                    msg_text = data.get("msg", "")[:50]  # Первые 50 символов
                                    log.info(f"   📝 [{level}] {service}: {msg_text}")
                                else:
                                    log.info(f"   📝 Processing message from subject: {msg.subject}")
                            except Exception:
                                log.info(f"   📝 Processing message from subject: {msg.subject}")
                            await self._handle_message(msg)
                    else:
                        # No messages received (timeout) - this is normal, continue polling
                        pull_count += 1
                        if pull_count % 12 == 0:  # Log every minute (12 * 5 sec = 60 sec)
                            async with self._metrics_lock:
                                metrics = self._metrics.copy()
                            log.info(
                                f"🔄 Pull loop active, waiting for messages... "
                                f"(pulls: {pull_count}, processed: {metrics['messages_processed']}, "
                                f"events: {metrics['events_saved']}, errors: {metrics['errors']})"
                            )
                except Exception as e:
                    error_str = str(e).lower()
                    # Timeout is OK, just continue
                    if "timeout" not in error_str and "no messages" not in error_str and "expired" not in error_str:
                        consecutive_errors += 1
                        async with self._metrics_lock:
                            self._metrics["errors"] += 1
                        
                        if consecutive_errors >= max_consecutive_errors:
                            log.error(f"❌ Too many consecutive errors ({consecutive_errors}), attempting reconnect...")
                            await self._reconnect()
                            consecutive_errors = 0
                        else:
                            log.warning(f"⚠️  Error pulling messages: {e} (consecutive: {consecutive_errors})")
                    
                    # Small delay before next attempt
                    await asyncio.sleep(0.1)
                    
            except asyncio.CancelledError:
                log.info("🛑 Pull messages task cancelled")
                break
            except Exception as e:
                log.error(f"❌ Error in pull loop: {e}", exc_info=True)
                async with self._metrics_lock:
                    self._metrics["errors"] += 1
                await asyncio.sleep(1.0)  # Wait before retrying
        
        log.info("🔄 Pull messages loop stopped")
    
    async def _handle_message(self, msg):
        """Handle incoming log message from NATS JetStream."""
        try:
            # Парсинг JSON сообщения
            data = json.loads(msg.data.decode("utf-8"))
            
            # Обработка батча событий (массив) или одиночного события
            events_count = 0
            if isinstance(data, list):
                # Батч событий (из агрегированных subjects: log.api, log.all)
                log.debug(f"   Processing batch of {len(data)} events")
                for event in data:
                    if isinstance(event, dict):
                        self.handler.emit_log(event)
                        events_count += 1
                        log.debug(f"   ✓ Saved event: {event.get('msg', 'N/A')[:50]}")
            else:
                # Одиночное событие
                if isinstance(data, dict):
                    self.handler.emit_log(data)
                    events_count = 1
                    log.debug(f"   ✓ Saved event: {data.get('msg', 'N/A')[:50]}")
            
            # Обновить метрики
            if events_count > 0:
                async with self._metrics_lock:
                    self._metrics["events_saved"] += events_count
            
            # Подтверждение обработки (ack для JetStream)
            await msg.ack()
            log.debug(f"   ✓ Acknowledged message from {msg.subject}")
            
        except json.JSONDecodeError as e:
            log.error(f"❌ Failed to parse JSON message: {e}")
            log.error(f"   Subject: {msg.subject}")
            log.error(f"   Data preview: {msg.data[:200]}...")
            async with self._metrics_lock:
                self._metrics["errors"] += 1
            # Acknowledge bad messages to prevent infinite reprocessing
            try:
                await msg.ack()
            except Exception:
                pass
        except Exception as e:
            log.error(f"❌ Error processing message: {e}", exc_info=True)
            async with self._metrics_lock:
                self._metrics["errors"] += 1
            # Acknowledge to prevent infinite reprocessing of bad messages
            try:
                await msg.ack()
            except Exception:
                pass
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS and initialize JetStream."""
        try:
            log.info(f"🔌 Connecting to NATS at {self._nats_url}")
            self.nc = await nats.connect(
                self._nats_url,
                reconnect_time_wait=2,
                max_reconnect_attempts=-1,  # Infinite reconnects
                connect_timeout=5,
            )
            log.info("✅ Connected to NATS")
            try:
                await self._svc_state_set("logger-daemon", "starting", None)
            except Exception:
                log.debug("[SVC_STATE] Failed to publish starting status", exc_info=True)
            
            # Initialize JetStream
            self.js = self.nc.jetstream()
            log.info("✅ JetStream initialized")
            
            # Create JetStream Stream for log.*
            await self._create_jetstream_stream()
            
            # Subscribe to all logs through JetStream with durable consumer
            self._consumer = await self.js.pull_subscribe(
                "log.>",  # Subject filter (all logs)
                durable="logger-daemon",  # Durable consumer name (will be created if doesn't exist)
                stream="LOGS",  # Explicit stream name
            )
            log.info("✅ Created pull subscription for 'log.>' with durable consumer 'logger-daemon'")
            
            return True
        except Exception as e:
            log.error(f"❌ Failed to connect to NATS: {e}")
            if self.nc:
                try:
                    await self.nc.close()
                except Exception:
                    pass
                self.nc = None
            return False
    
    async def _reconnect(self):
        """Reconnect to NATS with exponential backoff."""
        async with self._metrics_lock:
            self._metrics["reconnect_count"] += 1
            reconnect_count = self._metrics["reconnect_count"]
        
        log.info(f"🔄 Attempting to reconnect to NATS (attempt {reconnect_count})...")
        
        # Close existing connection
        if self.nc:
            try:
                await self.nc.close()
            except Exception:
                pass
            self.nc = None
            self.js = None
            self._consumer = None
        
        # Wait before reconnecting
        await asyncio.sleep(self._reconnect_delay)
        
        # Try to reconnect
        if await self._connect_nats():
            log.info("✅ Successfully reconnected to NATS")
            return True
        else:
            log.warning(f"⚠️  Reconnection failed, will retry in {self._reconnect_delay}s")
            return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics."""
        import time
        async def _get():
            async with self._metrics_lock:
                metrics = self._metrics.copy()
                if metrics["start_time"]:
                    metrics["uptime_seconds"] = time.time() - metrics["start_time"]
                return metrics
        # For sync access, we'll use a simple approach
        return self._metrics.copy()
    
    async def start(self):
        """Start the logger daemon."""
        import time
        import threading
        
        # Initialize metrics lock
        self._metrics_lock = asyncio.Lock()
        
        self._running = True
        self._metrics["start_time"] = time.time()
        
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            log.info(f"🛑 Received signal {signum}, initiating graceful shutdown...")
            self._shutdown_event.set()
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # Load configuration
        self._load_config()
        
        # Create JSONL segment handler
        self.handler = self._create_handler()
        log.info("✅ JSONL segment handler created")
        
        # Get NATS URL
        nats_config = self.config.get("nats", {})
        nats_url = os.getenv("NATS_URL") or nats_config.get("url", "nats://nats:4222")
        
        # Clean up URL: remove trailing colons, spaces, and fix common issues
        if nats_url:
            nats_url = nats_url.strip().rstrip(":")
            # Inside Docker container, replace 127.0.0.1 with service name 'nats'
            if "127.0.0.1" in nats_url or "localhost" in nats_url:
                nats_url = nats_url.replace("127.0.0.1", "nats").replace("localhost", "nats")
        
        self._nats_url = nats_url
        
        # Connect to NATS
        if not await self._connect_nats():
            log.error("❌ Failed to connect to NATS, exiting")
            sys.exit(1)
        
        # Start pulling messages in background
        self._pull_task = asyncio.create_task(self._pull_messages())
        log.info(f"✅ Started pull messages task (task: {self._pull_task.get_name()})")
        
        log.info("🚀 Logger daemon started, waiting for logs...")
        try:
            await self._svc_state_set("logger-daemon", "ready", None)
        except Exception:
            log.debug("[SVC_STATE] Failed to publish ready status", exc_info=True)
        
        # Keep running until shutdown signal
        try:
            while not self._shutdown_event.is_set():
                await asyncio.sleep(1)
                
                # Periodic metrics log (every 5 minutes)
                if int(time.time()) % 300 == 0:
                    metrics = self.get_metrics()
                    log.info(
                        f"📊 Metrics: processed={metrics['messages_processed']}, "
                        f"events={metrics['events_saved']}, errors={metrics['errors']}, "
                        f"reconnects={metrics['reconnect_count']}"
                    )
        except KeyboardInterrupt:
            log.info("🛑 Shutting down logger daemon (KeyboardInterrupt)...")
            self._shutdown_event.set()
        except Exception as e:
            log.error(f"❌ Error in main loop: {e}", exc_info=True)
            self._shutdown_event.set()
        finally:
            await self._shutdown()
    
    async def _shutdown(self):
        """Graceful shutdown of the daemon."""
        log.info("🛑 Shutting down logger daemon...")
        self._running = False
        
        # Cancel pull task
        if self._pull_task and not self._pull_task.done():
            log.info("🛑 Cancelling pull messages task...")
            self._pull_task.cancel()
            try:
                await asyncio.wait_for(self._pull_task, timeout=5.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        
        # Cleanup
        if self.handler:
            try:
                self.handler.close()
                log.info("✅ JSONL handler closed")
            except Exception:
                pass
        
        if self._subscription:
            try:
                await self._subscription.unsubscribe()
                log.info("✅ Unsubscribed from logs")
            except Exception:
                pass
        
        if self.nc:
            try:
                await self.nc.close()
                log.info("✅ NATS connection closed")
            except Exception:
                pass
        
        # Final metrics
        metrics = self.get_metrics()
        log.info(
            f"📊 Final metrics: processed={metrics['messages_processed']}, "
            f"events={metrics['events_saved']}, errors={metrics['errors']}, "
            f"reconnects={metrics['reconnect_count']}"
        )
        
        log.info("👋 Logger daemon stopped")

    async def _svc_state_set(self, service: str, status: str, details: Optional[Dict[str, Any]] = None):
        """Publish service status into NATS KV svc_state using existing connection."""
        if not self.nc:
            return
        try:
            js = self.nc.jetstream()
            try:
                kv = await js.key_value("svc_state")
            except NotFoundError:
                kv = await js.create_key_value("svc_state")
            payload = {
                "service": service,
                "status": status,
                "ts": __import__("time").time(),
                "details": details or {},
            }
            await kv.put(service, json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        except Exception:
            # best-effort only
            pass


async def main():
    """Main entry point."""
    daemon = LoggerDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Logger daemon stopped by user")
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

