# logger/config_loader.py
"""
Configuration loader for logger daemon.

Loads configuration from environment variables (priority) and config.toml (fallback).
"""
from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any

# TOML loader (Py3.11+/older)
try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore

logger = logging.getLogger(__name__)


def _get_config_search_paths() -> list[Path]:
    """
    Returns prioritized list of paths to search for config.toml.
    
    Order of precedence:
    1. /config/config.toml (centralized config - highest priority)
    2. Current working directory config/config.toml (for local development)
    3. Current working directory config.toml (for local development)
    4. Fallback paths (for backward compatibility)
    """
    paths = [
        # Centralized config (highest priority)
        Path("/config/config.toml"),  # Docker container mounted volume
        
        # Current working directory (for local development)
        Path.cwd() / "config" / "config.toml",
        Path.cwd() / "config.toml",
        
        # Fallback paths (for backward compatibility)
        Path("/app/config.toml"),  # Logger daemon's own config in container
        Path(__file__).resolve().parent / "config.toml",  # Relative to this module
        Path("/app/config/config.toml"),  # Docker container API config path
        Path.cwd() / "src/config/config.toml",
    ]
    
    return paths


def find_config_file() -> Optional[Path]:
    """Locate the config.toml file using the search path hierarchy."""
    for path in _get_config_search_paths():
        if path.exists() and path.is_file():
            return path
    return None


class ConfigLoader:
    """Thread-safe singleton config loader for logger daemon."""
    _instance: Optional["ConfigLoader"] = None
    
    def __init__(self):
        self._config: Optional[Dict[str, Any]] = None
        self._config_path: Optional[Path] = None
    
    @classmethod
    def get_instance(cls) -> "ConfigLoader":
        """Get singleton instance."""
        if cls._instance is None:
            cls._instance = ConfigLoader()
        return cls._instance
    
    def get_config(self, reload: bool = False) -> Dict[str, Any]:
        """Get cached config or load if not yet loaded."""
        if self._config is None or reload:
            config_path = find_config_file()
            if config_path:
                try:
                    with open(config_path, "rb") as f:
                        self._config = tomllib.load(f)
                    self._config_path = config_path
                    logger.info(f"✅ Loaded config from: {config_path}")
                except Exception as e:
                    logger.warning(f"Failed to load config from {config_path}: {e}")
                    self._config = {}
            else:
                self._config = {}
                self._config_path = None
        
        return self._config
    
    @property
    def config_path(self) -> Optional[Path]:
        """Get the path to the loaded config file."""
        if self._config_path is None:
            self.get_config()
        return self._config_path
    
    @property
    def raw_data(self) -> Dict[str, Any]:
        """Get raw config data."""
        return self.get_config()


def get_config() -> ConfigLoader:
    """Get the configuration loader."""
    loader = ConfigLoader.get_instance()
    loader.get_config()
    return loader



