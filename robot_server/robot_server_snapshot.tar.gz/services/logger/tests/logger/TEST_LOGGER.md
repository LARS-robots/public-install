# Инструкция по проверке Logger Daemon

## Быстрая проверка (минимум команд)

```bash
# 1. Проверить статус контейнеров
docker ps --filter "name=logger" --filter "name=nats" --format "table {{.Names}}\t{{.Status}}"

# 2. Отправить тестовые логи
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot
python services/logger/tests/logger/test_logger_daemon.py

# 3. Подождать 10 секунд
sleep 10

# 4. Проверить статистику
docker exec robot-logger-daemon-1 python3 log_reader.py stats

# 5. Проверить файл логов
docker exec robot-logger-daemon-1 sh -c "wc -l /var/log/lars/live/robot-current.json"
```

---

## Полная проверка (пошагово)

### Шаг 1: Проверка состояния сервисов

```bash
# Проверить, что NATS и logger-daemon запущены
docker ps --filter "name=logger" --filter "name=nats" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
```

**Ожидаемый результат:**
- `robot-nats-1` — статус `Up`
- `robot-logger-daemon-1` — статус `Up`

**Если сервисы не запущены:**
```bash
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot
docker compose -f services/logger/compose.standalone.yml up -d
```

---

### Шаг 2: Проверка логов демона

```bash
# Проверить последние логи демона
docker compose -f services/logger/compose.standalone.yml logs logger-daemon --tail 20
```

**Ожидаемые сообщения:**
- `✅ Connected to NATS`
- `✅ JetStream initialized`
- `✅ Created pull subscription for 'log.>'`
- `🚀 Logger daemon started, waiting for logs...`

---

### Шаг 3: Проверка JetStream Stream

```bash
# Создать скрипт для проверки stream
cat > check_stream.py << 'EOF'
import asyncio
import nats

async def main():
    nc = await nats.connect("nats://127.0.0.1:4222")
    js = nc.jetstream()
    
    try:
        info = await js.stream_info("LOGS")
        print(f"[OK] Stream 'LOGS' exists")
        print(f"   Subjects: {info.config.subjects}")
        print(f"   Messages in stream: {info.state.messages}")
        
        if info.config.subjects != ['log.>']:
            print("[WARN] Stream uses wrong format! Updating...")
            await js.update_stream(name="LOGS", subjects=["log.>"])
            print("[OK] Stream updated to 'log.>'")
        else:
            print("[OK] Stream format is correct!")
    except Exception as e:
        print(f"[ERROR] Stream error: {e}")
        print("   Creating stream...")
        await js.add_stream(name="LOGS", subjects=["log.>"])
        print("[OK] Stream created")
    
    await nc.close()

asyncio.run(main())
EOF

# Запустить проверку
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot
python check_stream.py
```

**Ожидаемый результат:**
- `[OK] Stream 'LOGS' exists`
- `Subjects: ['log.>']`
- `[OK] Stream format is correct!`

---

### Шаг 4: Отправка тестовых логов

```bash
# Перейти в директорию robot
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot

# Отправить тестовые логи
python services/logger/tests/logger/test_logger_daemon.py
```

**Ожидаемый результат:**
- `✅ Подключен к NATS`
- `✅ JetStream инициализирован`
- `✅ [1/3] Отправлено через Core NATS: log.test.INFO`
- `✅ [2/3] Отправлено через Core NATS: log.test.WARNING`
- `✅ [3/3] Отправлено через Core NATS: log.test.ERROR`
- `✅ Отправлено событие API через Core NATS: log.api.INFO`
- `✅ Отправлено успешно: 4/4 сообщений`

---

### Шаг 5: Проверка сохранения логов

```bash
# Подождать 5-10 секунд после отправки
sleep 10

# Проверить количество строк в файле
docker exec robot-logger-daemon-1 sh -c "wc -l /var/log/lars/live/robot-current.json"

# Посмотреть последние 3 строки
docker exec robot-logger-daemon-1 sh -c "tail -3 /var/log/lars/live/robot-current.json"

# Посмотреть весь файл (если нужно)
docker exec robot-logger-daemon-1 cat /var/log/lars/live/robot-current.json
```

**Ожидаемый результат:**
- Файл содержит JSON строки (одна строка на событие)
- Количество строк соответствует отправленным сообщениям

---

### Шаг 6: Использование утилиты log_reader.py

#### 6.1. Чтение всех логов
```bash
docker exec robot-logger-daemon-1 python3 log_reader.py read
```

#### 6.2. Фильтрация по сервису
```bash
# Логи от сервиса "test"
docker exec robot-logger-daemon-1 python3 log_reader.py read --service test

# Логи от сервиса "api"
docker exec robot-logger-daemon-1 python3 log_reader.py read --service api
```

#### 6.3. Фильтрация по уровню
```bash
# Только ERROR логи
docker exec robot-logger-daemon-1 python3 log_reader.py read --level ERROR

# Только WARNING логи
docker exec robot-logger-daemon-1 python3 log_reader.py read --level WARNING

# Только INFO логи
docker exec robot-logger-daemon-1 python3 log_reader.py read --level INFO
```

#### 6.4. Комбинированная фильтрация
```bash
# ERROR логи от сервиса "test"
docker exec robot-logger-daemon-1 python3 log_reader.py read --service test --level ERROR
```

#### 6.5. Статистика
```bash
docker exec robot-logger-daemon-1 python3 log_reader.py stats
```

**Ожидаемый вывод:**
```
📊 Log Statistics
============================================================
Total events: X

By service:
  test: Y
  api: Z

By level:
  INFO: A
  WARNING: B
  ERROR: C
```

#### 6.6. Tail в реальном времени
```bash
# В одном терминале запустите tail
docker exec robot-logger-daemon-1 python3 log_reader.py tail

# В другом терминале отправьте логи
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot
python services/logger/tests/logger/test_logger_daemon.py
```

---

### Шаг 7: Проверка метрик демона

```bash
# Проверить метрики в логах
docker logs robot-logger-daemon-1 2>&1 | grep "Metrics" | tail -5

# Проверить текущие метрики
docker logs robot-logger-daemon-1 --tail 50 | grep -E "Metrics|processed|events"
```

**Ожидаемый формат:**
```
📊 Metrics: processed=X, events=Y, errors=Z, reconnects=0
```

---

## Полный скрипт проверки (все в одном)

Создайте файл `test_logger_full.sh`:

```bash
cat > test_logger_full.sh << 'EOF'
#!/bin/bash

echo "=== Logger Daemon Full Test ==="

# 1. Проверка контейнеров
echo "1. Checking containers..."
docker ps --filter "name=logger" --filter "name=nats" --format "table {{.Names}}\t{{.Status}}"

# 2. Проверка stream
echo -e "\n2. Checking JetStream stream..."
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot
python check_stream.py 2>/dev/null || echo "[WARN] check_stream.py not found, skipping..."

# 3. Отправка тестовых логов
echo -e "\n3. Sending test logs..."
python services/logger/tests/logger/test_logger_daemon.py

# 4. Ожидание
echo -e "\n4. Waiting 10 seconds..."
sleep 10

# 5. Проверка файла
echo -e "\n5. Checking log file..."
docker exec robot-logger-daemon-1 sh -c "wc -l /var/log/lars/live/robot-current.json && echo '---' && tail -2 /var/log/lars/live/robot-current.json"

# 6. Статистика
echo -e "\n6. Statistics:"
docker exec robot-logger-daemon-1 python3 log_reader.py stats

# 7. Метрики демона
echo -e "\n7. Daemon metrics:"
docker logs robot-logger-daemon-1 --tail 5 2>&1 | grep "Metrics"

echo -e "\n=== Test Complete ==="
EOF

chmod +x test_logger_full.sh
./test_logger_full.sh
```

---

## Дополнительные полезные команды

### Просмотр логов в реальном времени
```bash
# Логи демона
docker compose -f services/logger/compose.standalone.yml logs -f logger-daemon

# Или напрямую
docker logs -f robot-logger-daemon-1
```

### Остановка и перезапуск
```bash
# Остановить
docker compose -f services/logger/compose.standalone.yml stop logger-daemon

# Запустить
docker compose -f services/logger/compose.standalone.yml start logger-daemon

# Перезапустить
docker restart robot-logger-daemon-1
```

### Очистка логов (если нужно начать заново)
```bash
# Остановить контейнеры
docker compose -f services/logger/compose.standalone.yml down -v

# Очистить логи на хосте
rm -f services/log/lars/live/*
rm -f services/log/lars/archive/*

# Запустить заново
docker compose -f services/logger/compose.standalone.yml up -d
```

### Проверка подключения к NATS
```bash
# Проверить, что NATS доступен
nc -zv 127.0.0.1 4222

# Или через curl (если доступен monitoring порт)
curl -s http://localhost:8222/jsz?streams=1 | head -20
```

---

## Ожидаемые результаты успешной проверки

✅ Контейнеры запущены и работают  
✅ Stream 'LOGS' существует с форматом `log.>`  
✅ Тестовые логи успешно отправлены  
✅ Файл логов содержит новые записи  
✅ Утилита `log_reader.py` показывает статистику  
✅ Метрики демона обновляются (processed > 0, events > 0)  

Если все пункты выполнены — логгер работает корректно! 🎉

---

## Решение проблем

### Проблема: Ошибка подключения к NATS
```bash
# Проверить, что NATS запущен
docker ps --filter "name=nats"

# Проверить порт
netstat -an | grep 4222

# Попробовать подключиться без авторизации
NATS_URL="nats://127.0.0.1:4222" python services/logger/tests/logger/test_logger_daemon.py
```

### Проблема: Логи не сохраняются
```bash
# Проверить логи демона
docker logs robot-logger-daemon-1 --tail 50

# Проверить права на запись
docker exec robot-logger-daemon-1 ls -la /var/log/lars/live/

# Проверить метрики (должны быть processed > 0)
docker logs robot-logger-daemon-1 | grep "Metrics" | tail -1
```

### Проблема: Файл пустой
```bash
# Проверить, что stream использует правильный формат
python check_stream.py

# Убедиться, что сообщения публикуются через JetStream API
# (test_logger_daemon.py использует JetStream API автоматически)
```

