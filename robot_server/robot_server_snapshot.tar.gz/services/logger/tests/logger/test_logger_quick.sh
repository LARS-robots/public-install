#!/bin/bash
# Быстрая проверка Logger Daemon
# Использование: ./test_logger_quick.sh

set -euo pipefail

SCRIPT_DIR="$( cd -- "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
REPO_ROOT="$( cd "${SCRIPT_DIR}/../../../.." >/dev/null 2>&1 && pwd )"
TEST_SCRIPT="${SCRIPT_DIR}/test_logger_daemon.py"

echo "=== Logger Daemon Quick Test ==="

# 1. Проверка контейнеров
echo "1. Checking containers..."
docker ps --filter "name=logger" --filter "name=nats" --format "table {{.Names}}\t{{.Status}}"

# 2. Отправка тестовых логов
echo -e "\n2. Sending test logs..."
cd "${REPO_ROOT}"
python "${TEST_SCRIPT}"

# 3. Ожидание
echo -e "\n3. Waiting 10 seconds..."
sleep 10

# 4. Проверка статистики
echo -e "\n4. Statistics:"
docker exec robot-logger-daemon-1 python3 log_reader.py stats

# 5. Проверка файла
echo -e "\n5. Log file:"
docker exec robot-logger-daemon-1 sh -c "wc -l /var/log/lars/live/robot-current.json && echo '---' && tail -2 /var/log/lars/live/robot-current.json"

# 6. Метрики
echo -e "\n6. Daemon metrics:"
docker logs robot-logger-daemon-1 --tail 1 2>&1 | grep "Metrics"

echo -e "\n=== Test Complete ==="

