#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for logger-daemon - publishes test logs to JetStream.

Usage:
    python services/logger/tests/logger/test_logger_daemon.py

Sends test log messages to NATS JetStream stream 'LOGS' which will be
picked up by logger-daemon and saved to JSONL files.
"""
import asyncio
import json
import sys
import os
from datetime import datetime

# Fix Windows console encoding
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")

try:
    import nats
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    print("❌ nats-py не установлен. Установите: pip install nats-py")
    sys.exit(1)


async def main():
    """Main test function."""
    # NATS URL - используем 127.0.0.1 для подключения с хоста
    nats_url = os.getenv("NATS_URL", "nats://127.0.0.1:4222")
    
    # Clean up URL: remove trailing colons and spaces
    if nats_url:
        nats_url = nats_url.strip().rstrip(":")
    
    print("=" * 60)
    print("Logger Daemon Test - Отправка тестовых логов")
    print("=" * 60)
    print(f"🔌 Подключение к NATS: {nats_url}")
    
    # Подключиться к NATS
    try:
        nc = await nats.connect(nats_url, connect_timeout=5)
        print("✅ Подключен к NATS")
    except Exception as e:
        print(f"❌ Ошибка подключения к NATS: {e}")
        print("\nПопытка подключения без авторизации...")
        try:
            # Попробуем простой URL без авторизации
            simple_url = "nats://127.0.0.1:4222"
            nc = await nats.connect(simple_url, connect_timeout=5)
            print(f"✅ Подключен к NATS (без авторизации): {simple_url}")
        except Exception as e2:
            print(f"❌ Ошибка подключения без авторизации: {e2}")
            print("\nУбедитесь, что NATS сервер запущен:")
            print("  docker ps --filter 'name=nats'")
            sys.exit(1)
    
    # Инициализировать JetStream
    try:
        js = nc.jetstream()
        print("✅ JetStream инициализирован")
    except Exception as e:
        print(f"❌ Ошибка инициализации JetStream: {e}")
        await nc.close()
        sys.exit(1)
    
    print("\n📤 Отправка тестовых сообщений в JetStream...")
    print("=" * 60)
    
    # Тестовые сообщения
    test_messages = [
        {
            "ts": datetime.now().isoformat(),
            "level": "INFO",
            "logger": "test.logger",
            "msg": "🧪 Тестовое сообщение INFO для logger-daemon",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "test": True,
                "type": "info",
                "message": "Logger daemon test - INFO level"
            }
        },
        {
            "ts": datetime.now().isoformat(),
            "level": "WARNING",
            "logger": "test.logger",
            "msg": "⚠️ Тестовое предупреждение для logger-daemon",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "test": True,
                "type": "warning",
                "message": "Logger daemon test - WARNING level"
            }
        },
        {
            "ts": datetime.now().isoformat(),
            "level": "ERROR",
            "logger": "test.logger",
            "msg": "❌ Тестовая ошибка для logger-daemon",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "test": True,
                "type": "error",
                "message": "Logger daemon test - ERROR level",
                "error": "Test error message"
            }
        },
    ]
    
    # Отправить каждое сообщение через JetStream
    success_count = 0
    for i, test_log in enumerate(test_messages, 1):
        level = test_log["level"]
        subject = f"log.test.{level}"
        data = json.dumps(test_log, ensure_ascii=False).encode("utf-8")
        
        try:
            # Пробуем сначала опубликовать через Core NATS (должно попасть в stream автоматически)
            await nc.publish(subject, data)
            print(f"✅ [{i}/{len(test_messages)}] Отправлено через Core NATS: {subject}")
            print(f"   Message: {test_log['msg']}")
            success_count += 1
            
            # Дополнительно пробуем через JetStream API для гарантии
            try:
                ack = await js.publish(subject, data)
                print(f"   (Также отправлено через JetStream API: seq={ack.seq})")
            except Exception as js_e:
                # Если JetStream API не работает - это нормально, Core NATS должно работать
                pass
        except Exception as e:
            print(f"❌ [{i}/{len(test_messages)}] Ошибка отправки: {e}")
        
        # Небольшая пауза между сообщениями
        await asyncio.sleep(0.3)
    
    # Также отправить сообщение в формате API
    api_log = {
        "ts": datetime.now().isoformat(),
        "level": "INFO",
        "logger": "app.services.test",
        "msg": "route.plan",
        "service": "api",
        "hostname": "robot-001",
        "pid": 54321,
        "event": {
            "stage": "route",
            "action": "plan",
            "start": {"lat": 55.164, "lon": 61.436},
            "goal": {"lat": 55.165, "lon": 61.440},
            "path_points": 8,
            "planner_used": "road",
            "planning_time_ms": 45
        }
    }
    
    subject = "log.api.INFO"
    data = json.dumps(api_log, ensure_ascii=False).encode("utf-8")
    
    try:
        # Используем Core NATS publish - сообщения автоматически попадут в JetStream stream
        await nc.publish(subject, data)
        print(f"\n✅ Отправлено событие API через Core NATS: {subject}")
        print(f"   Сообщение автоматически попадет в JetStream stream LOGS")
        print(f"   Message: {api_log['msg']}")
        success_count += 1
    except Exception as e:
        print(f"\n❌ Ошибка отправки API события: {e}")
    
    # Закрыть соединение
    await nc.close()
    
    print("\n" + "=" * 60)
    print(f"✅ Отправлено успешно: {success_count}/{len(test_messages) + 1} сообщений")
    print("\n📋 Проверьте логи logger-daemon:")
    print("   docker compose -f compose.yml -f services/motor_daemon/compose.linux.yml -f services/logger/compose.yml logs logger-daemon --tail 30")
    print("\n📁 Проверьте файлы логов:")
    print("   Get-Content services\\log\\lars\\live\\robot-current.json -Tail 10")
    print("=" * 60)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Выход")
        sys.exit(0)

