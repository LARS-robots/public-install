#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple NATS log subscriber for testing.

Usage:
    python services/logger/tests/nats/test_nats_subscriber.py

Subscribes to all logs from API service and prints them to console.
"""
import asyncio
import json
import sys
import os
from datetime import datetime

# Fix Windows console encoding
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")

try:
    from nats.aio.client import Client as NATS
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    print("❌ nats-py не установлен. Установите: pip install nats-py")
    sys.exit(1)


async def main():
    """Основная функция подписчика."""
    nats_url = "nats://127.0.0.1:4222"
    
    print("=" * 60, flush=True)
    print("NATS Log Subscriber - Testing Logging", flush=True)
    print("=" * 60, flush=True)
    print(f"Connecting to NATS: {nats_url}", flush=True)
    sys.stdout.flush()
    
    # Подключиться к NATS
    nc = NATS()
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("[OK] Connected to NATS server", flush=True)
        sys.stdout.flush()
    except Exception as e:
        print(f"[ERROR] Failed to connect to NATS: {e}", flush=True)
        print("\nMake sure NATS server is running:", flush=True)
        print("  docker compose up nats -d", flush=True)
        sys.stdout.flush()
        sys.exit(1)
    
    print("\nSubscribing to subjects:", flush=True)
    # Старый формат (закомментирован):
    # print("  - lars.logs.api.> (all API logs)", flush=True)
    # print("  - lars.logs.api (all API logs, aggregated)", flush=True)
    # print("  - lars.logs.all (all logs from all services)", flush=True)
    # Новый формат согласно архитектуре:
    print("  - log.api.> (all API logs)", flush=True)
    print("  - log.api (all API logs, aggregated)", flush=True)
    print("  - log.all (all logs from all services)", flush=True)
    sys.stdout.flush()
    
    message_count = 0
    last_timestamp = None
    
    async def message_handler(msg):
        """Обработчик сообщений из NATS."""
        nonlocal message_count, last_timestamp
        
        message_count += 1
        subject = msg.subject
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        try:
            # Парсинг JSON
            data = json.loads(msg.data.decode("utf-8"))
            
            # Если это батч событий (массив)
            if isinstance(data, list):
                for event in data:
                    print_event(event, subject, timestamp)
            else:
                # Одиночное событие
                print_event(data, subject, timestamp)
            
            last_timestamp = timestamp
            
            # Принудительный flush после каждого события
            sys.stdout.flush()
            
        except json.JSONDecodeError as e:
            print(f"[{timestamp}] [ERROR] Ошибка парсинга JSON: {e}", flush=True)
            print(f"  Subject: {subject}", flush=True)
            print(f"  Data: {msg.data[:200]}...", flush=True)
            sys.stdout.flush()
        except Exception as e:
            print(f"[{timestamp}] [ERROR] Ошибка обработки: {e}", flush=True)
            print(f"  Subject: {subject}", flush=True)
            sys.stdout.flush()
    
    def print_event(event, subject, timestamp):
        """Вывод события в консоль."""
        level = event.get("level", "UNKNOWN")
        msg = event.get("msg", "")
        service = event.get("service", "unknown")
        logger = event.get("logger", "unknown")
        ts = event.get("ts", "")
        
        # Цветовая подсветка по уровню (упрощенная для Windows)
        level_markers = {
            "DEBUG": "[DEBUG]",
            "INFO": "[INFO]",
            "WARNING": "[WARN]",
            "ERROR": "[ERROR]",
            "CRITICAL": "[CRIT]",
        }
        marker = level_markers.get(level, f"[{level}]")
        
        # Вывод основной информации (немедленно, с flush)
        print(f"\n[{timestamp}] {marker} {service} | {logger}", flush=True)
        print(f"  Subject: {subject}", flush=True)
        if msg:
            print(f"  Message: {msg}", flush=True)
        if ts:
            print(f"  Timestamp: {ts}", flush=True)
        
        # Вывод event данных, если есть
        if "event" in event and isinstance(event["event"], dict):
            event_data = event["event"]
            print(f"  Event:", flush=True)
            for key, value in event_data.items():
                if isinstance(value, (dict, list)):
                    print(f"    {key}: {json.dumps(value, ensure_ascii=False)}", flush=True)
                else:
                    print(f"    {key}: {value}", flush=True)
        
        # Вывод других полей
        other_fields = {k: v for k, v in event.items() 
                       if k not in ("level", "msg", "service", "logger", "ts", "event", "hostname", "pid")}
        if other_fields:
            print(f"  Other: {other_fields}", flush=True)
        
        # Принудительный flush для немедленного вывода
        sys.stdout.flush()
    
    # Подписаться на все логи API (wildcard для всех уровней)
    # Старый формат (закомментирован):
    # sub = await nc.subscribe("lars.logs.api.>", cb=message_handler)
    # print(f"[OK] Subscribed to: lars.logs.api.>", flush=True)
    # await nc.subscribe("lars.logs.api", cb=message_handler)
    # await nc.subscribe("lars.logs.all", cb=message_handler)
    # print(f"[OK] Subscribed to: lars.logs.api, lars.logs.all", flush=True)
    # Новый формат согласно архитектуре:
    sub = await nc.subscribe("log.api.>", cb=message_handler)
    print(f"[OK] Subscribed to: log.api.>", flush=True)
    
    # Также подписаться на агрегированные subjects для полноты
    await nc.subscribe("log.api", cb=message_handler)
    await nc.subscribe("log.all", cb=message_handler)
    print(f"[OK] Subscribed to: log.api, log.all", flush=True)
    sys.stdout.flush()
    
    # Периодический вывод статистики (опционально, каждые 60 секунд)
    async def stats_printer():
        """Периодический вывод статистики."""
        while True:
            await asyncio.sleep(60)  # Каждые 60 секунд
            if message_count > 0:
                print(f"\n[STATS] Received {message_count} messages", flush=True)
                if last_timestamp:
                    print(f"  Last message: {last_timestamp}", flush=True)
                sys.stdout.flush()
    
    # Запустить задачу статистики
    stats_task = asyncio.create_task(stats_printer())
    
    # Ждать сообщения (бесконечно, пока не будет Ctrl+C)
    try:
        print("\n[OK] Waiting for messages... (Press Ctrl+C to exit)", flush=True)
        print("=" * 60, flush=True)
        sys.stdout.flush()
        
        # Бесконечный цикл ожидания (более надежный чем sleep)
        while True:
            await asyncio.sleep(1)  # Проверка каждую секунду (для возможности прервать)
    except KeyboardInterrupt:
        print("\n\n[STOP] Stopping subscriber...", flush=True)
        sys.stdout.flush()
    finally:
        stats_task.cancel()
        try:
            await stats_task
        except asyncio.CancelledError:
            pass
        
        await nc.close()
        print(f"[OK] Total messages received: {message_count}", flush=True)
        print("Goodbye!", flush=True)
        sys.stdout.flush()


if __name__ == "__main__":
    # Настройка unbuffered output для реального времени
    import sys
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(line_buffering=True)
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(line_buffering=True)
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n[EXIT] Exiting...", flush=True)
        sys.exit(0)
