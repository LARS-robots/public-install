#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple NATS log publisher for testing.

Usage:
    python services/logger/tests/nats/test_nats_publisher.py

Sends test messages to NATS for subscriber testing.
"""
import asyncio
import json
import sys
import os
from datetime import datetime

# Fix Windows console encoding
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")

try:
    from nats.aio.client import Client as NATS
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    print("❌ nats-py не установлен. Установите: pip install nats-py")
    sys.exit(1)


async def main():
    """Основная функция публикатора."""
    nats_url = "nats://127.0.0.1:4222"
    
    print("=" * 60)
    print("NATS Log Publisher - Тестирование публикации")
    print("=" * 60)
    print(f"Подключение к NATS: {nats_url}")
    
    # Подключиться к NATS
    nc = NATS()
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("✅ Подключен к NATS серверу")
    except Exception as e:
        print(f"❌ Ошибка подключения к NATS: {e}")
        print("\nУбедитесь, что NATS сервер запущен:")
        print("  docker compose up nats -d")
        sys.exit(1)
    
    print("\nОтправка тестовых сообщений...")
    print("=" * 60)
    
    # Тестовые события
    test_events = [
        {
            "ts": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "level": "INFO",
            "logger": "test.publisher",
            "msg": "Тестовое сообщение INFO",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "stage": "test",
                "action": "publish",
                "test_id": 1
            }
        },
        {
            "ts": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "level": "WARNING",
            "logger": "test.publisher",
            "msg": "Тестовое предупреждение",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "stage": "test",
                "action": "warning",
                "test_id": 2
            }
        },
        {
            "ts": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "level": "ERROR",
            "logger": "test.publisher",
            "msg": "Тестовая ошибка",
            "service": "test",
            "hostname": "test-host",
            "pid": 12345,
            "event": {
                "stage": "test",
                "action": "error",
                "test_id": 3,
                "error": "Test error message"
            }
        },
    ]
    
    # Отправить события
    for i, event in enumerate(test_events, 1):
        level = event["level"]
        # Старый формат (закомментирован):
        # subject = f"lars.logs.test.{level}"
        # Новый формат согласно архитектуре:
        subject = f"log.test.{level}"
        data = json.dumps(event, ensure_ascii=False).encode("utf-8")
        
        try:
            await nc.publish(subject, data)
            print(f"✅ [{i}/{len(test_events)}] Отправлено: {subject}")
            print(f"   Message: {event['msg']}")
        except Exception as e:
            print(f"❌ Ошибка отправки: {e}")
        
        # Небольшая пауза между сообщениями
        await asyncio.sleep(0.5)
    
    # Также отправить событие в формат API
    api_event = {
        "ts": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "level": "INFO",
        "logger": "app.services.motor.motor_service",
        "msg": "route.plan",
        "service": "api",
        "hostname": "robot-001",
        "pid": 12345,
        "event": {
            "stage": "route",
            "action": "plan",
            "start": {"lat": 55.164, "lon": 61.436},
            "goal": {"lat": 55.165, "lon": 61.440},
            "path_points": 8,
            "planner_used": "road",
            "planning_time_ms": 45
        }
    }
    
    # Старый формат (закомментирован):
    # subject = "lars.logs.api.INFO"
    # Новый формат согласно архитектуре:
    subject = "log.api.INFO"
    data = json.dumps(api_event, ensure_ascii=False).encode("utf-8")
    
    try:
        await nc.publish(subject, data)
        print(f"\n✅ Отправлено событие API: {subject}")
        print(f"   Message: {api_event['msg']}")
    except Exception as e:
        print(f"❌ Ошибка отправки: {e}")
    
    # Закрыть соединение
    await nc.close()
    print("\n✅ Все сообщения отправлены")
    print("👋 Проверьте подписчик для получения сообщений")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Выход")
        sys.exit(0)

