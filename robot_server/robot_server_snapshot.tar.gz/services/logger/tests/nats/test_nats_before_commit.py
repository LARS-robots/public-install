#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Быстрая проверка NATS логирования перед коммитом.

Проверяет:
1. NATS сервер запущен и доступен
2. API сервис отправляет логи в NATS
3. Логи имеют правильный формат
"""
import asyncio
import json
import sys
import os
from datetime import datetime

# Fix Windows console encoding
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")

try:
    from nats.aio.client import Client as NATS
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    print("❌ nats-py не установлен. Установите: pip install nats-py")
    sys.exit(1)


async def test_nats_connection():
    """Тест 1: Проверка подключения к NATS."""
    print("=" * 60)
    print("Тест 1: Проверка подключения к NATS")
    print("=" * 60)
    
    nats_url = os.getenv("NATS_URL", "nats://127.0.0.1:4222")
    # Убрать лишние символы в конце (двоеточия, пробелы)
    nats_url = nats_url.rstrip(": \t\n\r")
    print(f"Подключение к: {nats_url}")
    
    nc = NATS()
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("✅ NATS сервер доступен")
        await nc.close()
        return True
    except Exception as e:
        print(f"❌ Ошибка подключения к NATS: {e}")
        print(f"   URL: {nats_url}")
        print("\n💡 Убедитесь, что NATS сервер запущен:")
        print("   docker compose up nats -d")
        print("\n💡 Проверьте формат NATS_URL:")
        print("   Правильно: nats://127.0.0.1:4222")
        print("   Правильно: nats://dev:devpass@127.0.0.1:4222")
        print("   Неправильно: nats://127.0.0.1:4222: (лишнее двоеточие)")
        return False


async def test_nats_logs_reception():
    """Тест 2: Проверка получения логов из NATS."""
    print("\n" + "=" * 60)
    print("Тест 2: Проверка получения логов из NATS")
    print("=" * 60)
    
    nats_url = os.getenv("NATS_URL", "nats://127.0.0.1:4222")
    # Убрать лишние символы в конце (двоеточия, пробелы)
    nats_url = nats_url.rstrip(": \t\n\r")
    nc = NATS()
    
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("✅ Подключено к NATS")
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        return False
    
    messages_received = []
    messages_lock = asyncio.Lock()
    
    async def message_handler(msg):
        """Обработчик сообщений."""
        try:
            data = json.loads(msg.data.decode("utf-8"))
            async with messages_lock:
                if isinstance(data, list):
                    messages_received.extend(data)
                else:
                    messages_received.append(data)
        except Exception as e:
            print(f"⚠️  Ошибка обработки сообщения: {e}")
    
    # Подписаться на все логи API
    # Старый формат (закомментирован):
    # await nc.subscribe("lars.logs.api.>", cb=message_handler)
    # await nc.subscribe("lars.logs.all", cb=message_handler)
    # print("✅ Подписались на subjects: lars.logs.api.>, lars.logs.all")
    # Новый формат согласно архитектуре:
    await nc.subscribe("log.api.>", cb=message_handler)
    await nc.subscribe("log.all", cb=message_handler)
    print("✅ Подписались на subjects: log.api.>, log.all")
    
    print("\n⏳ Ожидание логов (10 секунд)...")
    print("💡 В другом терминале запустите API сервис или сделайте запрос:")
    print("   curl http://localhost:8000/telemetry/pose")
    
    # Ждать 10 секунд для получения сообщений
    await asyncio.sleep(10)
    
    await nc.close()
    
    # Проверить результаты
    async with messages_lock:
        if messages_received:
            print(f"\n✅ Получено {len(messages_received)} сообщений")
            
            # Проверить формат первого сообщения
            first_msg = messages_received[0]
            print("\n📋 Проверка формата сообщения:")
            
            required_fields = ["level", "service", "logger", "ts"]
            missing_fields = [f for f in required_fields if f not in first_msg]
            
            if missing_fields:
                print(f"❌ Отсутствуют обязательные поля: {missing_fields}")
                return False
            else:
                print("✅ Все обязательные поля присутствуют")
            
            # Вывести пример сообщения
            print("\n📄 Пример сообщения:")
            print(json.dumps(first_msg, indent=2, ensure_ascii=False))
            
            # Проверить service
            if first_msg.get("service") == "api":
                print("✅ Service: api")
            else:
                print(f"⚠️  Service: {first_msg.get('service')} (ожидалось 'api')")
            
            return True
        else:
            print("\n❌ Сообщения не получены")
            print("\n💡 Возможные причины:")
            print("   1. API сервис не запущен")
            print("   2. API сервис не отправляет логи в NATS")
            print("   3. NATS_URL не настроен правильно")
            print("\n💡 Проверьте:")
            print("   - Запущен ли API сервис: cd services/api && python -m uvicorn app.main:app --reload")
            print("   - Настроен ли NATS_URL в config.toml или env")
            print("   - Есть ли сообщения '[NATS] [OK] NATS logging enabled' в логах API")
            return False


async def test_nats_subjects():
    """Тест 3: Проверка subjects в NATS."""
    print("\n" + "=" * 60)
    print("Тест 3: Проверка subjects в NATS")
    print("=" * 60)
    
    nats_url = os.getenv("NATS_URL", "nats://127.0.0.1:4222")
    # Убрать лишние символы в конце (двоеточия, пробелы)
    nats_url = nats_url.rstrip(": \t\n\r")
    nc = NATS()
    
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("✅ Подключено к NATS")
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        return False
    
    # Проверить JetStream (если доступен)
    try:
        js = nc.jetstream()
        print("✅ JetStream доступен")
    except Exception:
        print("⚠️  JetStream недоступен (это нормально для простой конфигурации)")
    
    await nc.close()
    return True


async def main():
    """Главная функция тестирования."""
    print("🚀 Тестирование NATS логирования перед коммитом")
    print("=" * 60)
    print()
    
    results = []
    
    # Тест 1: Подключение к NATS
    result1 = await test_nats_connection()
    results.append(("Подключение к NATS", result1))
    
    if not result1:
        print("\n❌ Тест 1 провален. Исправьте проблемы перед продолжением.")
        sys.exit(1)
    
    # Тест 2: Получение логов
    result2 = await test_nats_logs_reception()
    results.append(("Получение логов из NATS", result2))
    
    # Тест 3: Проверка subjects
    result3 = await test_nats_subjects()
    results.append(("Проверка subjects", result3))
    
    # Итоги
    print("\n" + "=" * 60)
    print("📊 Итоги тестирования")
    print("=" * 60)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
    
    all_passed = all(result for _, result in results)
    
    if all_passed:
        print("\n✅ Все тесты пройдены! Можно коммитить.")
        sys.exit(0)
    else:
        print("\n❌ Некоторые тесты не прошли. Исправьте проблемы перед коммитом.")
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️  Тестирование прервано пользователем")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

