#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Быстрая проверка NATS конфигурации (без запуска API сервиса).

Проверяет:
1. NATS сервер запущен и доступен
2. Библиотека nats_logger установлена
3. Конфигурация NATS правильная
"""
import asyncio
import sys
import os
from pathlib import Path

# Fix Windows console encoding
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")

try:
    from nats.aio.client import Client as NATS
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    print("❌ nats-py не установлен. Установите: pip install nats-py")
    sys.exit(1)


def test_nats_logger_import():
    """Тест 1: Проверка импорта nats_logger."""
    print("=" * 60)
    print("Тест 1: Проверка библиотеки nats_logger")
    print("=" * 60)
    
    try:
        from nats_logger import NATSHandler, detect_service_name
        print("✅ Библиотека nats_logger установлена")
        print(f"   NATSHandler: {NATSHandler}")
        print(f"   detect_service_name: {detect_service_name}")
        return True
    except ImportError as e:
        print(f"❌ Библиотека nats_logger не установлена: {e}")
        print("\n💡 Установите библиотеку:")
        print("   pip install -e services/nats_logger")
        return False


async def test_nats_connection():
    """Тест 2: Проверка подключения к NATS."""
    print("\n" + "=" * 60)
    print("Тест 2: Проверка подключения к NATS")
    print("=" * 60)
    
    nats_url = os.getenv("NATS_URL", "nats://127.0.0.1:4222")
    # Убрать лишние символы в конце (двоеточия, пробелы)
    nats_url = nats_url.rstrip(": \t\n\r")
    print(f"Подключение к: {nats_url}")
    
    nc = NATS()
    try:
        await nc.connect(nats_url, connect_timeout=5)
        print("✅ NATS сервер доступен")
        
        # Проверить JetStream
        try:
            js = nc.jetstream()
            print("✅ JetStream доступен")
        except Exception:
            print("⚠️  JetStream недоступен (это нормально для простой конфигурации)")
        
        await nc.close()
        return True
    except Exception as e:
        print(f"❌ Ошибка подключения к NATS: {e}")
        print(f"   URL: {nats_url}")
        print("\n💡 Убедитесь, что NATS сервер запущен:")
        print("   docker compose up nats -d")
        print("\n💡 Проверьте формат NATS_URL:")
        print("   Правильно: nats://127.0.0.1:4222")
        print("   Правильно: nats://dev:devpass@127.0.0.1:4222")
        print("   Неправильно: nats://127.0.0.1:4222: (лишнее двоеточие)")
        return False


def test_nats_config():
    """Тест 3: Проверка конфигурации NATS."""
    print("\n" + "=" * 60)
    print("Тест 3: Проверка конфигурации NATS")
    print("=" * 60)
    
    # Проверить переменные окружения
    nats_url = os.getenv("NATS_URL")
    if nats_url:
        print(f"✅ NATS_URL из env: {nats_url}")
    else:
        print("⚠️  NATS_URL не установлен в env (будет использован default: nats://127.0.0.1:4222)")
    
    # Проверить config.toml
    config_path = Path("services/api/src/config/config.toml")
    if config_path.exists():
        print(f"✅ config.toml существует: {config_path}")
        
        # Попробовать прочитать конфигурацию
        try:
            import tomli
            with config_path.open("rb") as f:
                config = tomli.load(f)
            
            if "nats" in config:
                nats_config = config["nats"]
                if "url" in nats_config:
                    print(f"✅ NATS URL в config.toml: {nats_config['url']}")
                else:
                    print("⚠️  NATS URL не указан в config.toml (будет использован default)")
                
                if "logging" in nats_config:
                    logging_config = nats_config["logging"]
                    if "enable" in logging_config:
                        enable = logging_config["enable"]
                        print(f"✅ NATS logging enabled в config.toml: {enable}")
                    else:
                        print("⚠️  NATS logging enable не указан (по умолчанию включен)")
                else:
                    print("⚠️  NATS logging секция не найдена (по умолчанию включен)")
            else:
                print("⚠️  NATS секция не найдена в config.toml (будет использован default)")
        except Exception as e:
            print(f"⚠️  Не удалось прочитать config.toml: {e}")
    else:
        print(f"⚠️  config.toml не найден: {config_path}")
        print("   (будет использован config.example.toml или defaults)")
    
    return True


def test_api_integration():
    """Тест 4: Проверка интеграции в API сервис."""
    print("\n" + "=" * 60)
    print("Тест 4: Проверка интеграции в API сервис")
    print("=" * 60)
    
    # Проверить logging_setup.py
    logging_setup_path = Path("services/api/src/app/logging_setup.py")
    if logging_setup_path.exists():
        print(f"✅ logging_setup.py существует: {logging_setup_path}")
        
        # Проверить наличие импорта NATSHandler
        content = logging_setup_path.read_text(encoding="utf-8")
        if "from nats_logger import" in content:
            print("✅ Импорт NATSHandler найден в logging_setup.py")
        else:
            print("❌ Импорт NATSHandler не найден в logging_setup.py")
            return False
        
        if "NATSHandler" in content:
            print("✅ NATSHandler используется в logging_setup.py")
        else:
            print("❌ NATSHandler не используется в logging_setup.py")
            return False
    else:
        print(f"❌ logging_setup.py не найден: {logging_setup_path}")
        return False
    
    # Проверить main.py
    main_path = Path("services/api/src/app/main.py")
    if main_path.exists():
        print(f"✅ main.py существует: {main_path}")
        
        # Проверить наличие setup_logging с NATS параметрами
        content = main_path.read_text(encoding="utf-8")
        if "setup_logging" in content:
            print("✅ setup_logging вызывается в main.py")
        else:
            print("❌ setup_logging не вызывается в main.py")
            return False
        
        if "enable_nats" in content or "nats_url" in content:
            print("✅ NATS параметры используются в main.py")
        else:
            print("⚠️  NATS параметры не найдены в main.py (может использоваться default)")
    else:
        print(f"❌ main.py не найден: {main_path}")
        return False
    
    return True


async def main():
    """Главная функция тестирования."""
    print("🚀 Быстрая проверка NATS конфигурации")
    print("=" * 60)
    print()
    
    results = []
    
    # Тест 1: Импорт библиотеки
    result1 = test_nats_logger_import()
    results.append(("Библиотека nats_logger", result1))
    
    # Тест 2: Подключение к NATS
    result2 = await test_nats_connection()
    results.append(("Подключение к NATS", result2))
    
    # Тест 3: Конфигурация
    result3 = test_nats_config()
    results.append(("Конфигурация NATS", result3))
    
    # Тест 4: Интеграция в API
    result4 = test_api_integration()
    results.append(("Интеграция в API сервис", result4))
    
    # Итоги
    print("\n" + "=" * 60)
    print("📊 Итоги проверки")
    print("=" * 60)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
    
    all_passed = all(result for _, result in results)
    
    if all_passed:
        print("\n✅ Все проверки пройдены!")
        print("\n💡 Для полной проверки с получением логов:")
        print("   1. Запустите API сервис: cd services/api && python -m uvicorn app.main:app --reload")
        print("   2. Запустите тест: python services/logger/tests/nats/test_nats_before_commit.py")
        print("   3. Или запустите подписчик: python services/logger/tests/nats/test_nats_subscriber.py")
        sys.exit(0)
    else:
        print("\n❌ Некоторые проверки не прошли. Исправьте проблемы перед коммитом.")
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️  Проверка прервана пользователем")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

