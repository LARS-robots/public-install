#!/usr/bin/env python3
"""
Log Reader - утилита для чтения и фильтрации JSONL логов.

Использование:
    python log_reader.py tail                    # tail -f аналог
    python log_reader.py read --service api      # фильтр по сервису
    python log_reader.py read --level ERROR      # фильтр по уровню
    python log_reader.py stats                   # статистика
    python log_reader.py read --from 2024-01-15 --to 2024-01-16  # временной диапазон
"""
import argparse
import json
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any, Iterator
from collections import defaultdict

# Fix Windows console encoding
if sys.platform == "win32":
    try:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")
    except Exception:
        pass


class LogReader:
    """Утилита для чтения JSONL логов."""
    
    def __init__(self, live_dir: str = None, archive_dir: str = None):
        """
        Инициализация LogReader.
        
        Args:
            live_dir: Директория с текущими логами (по умолчанию из env или /var/log/lars/live)
            archive_dir: Директория с архивами (по умолчанию из env или /var/log/lars/archive)
        """
        self.live_dir = Path(live_dir or os.getenv("LOG_LIVE_DIR", "/var/log/lars/live"))
        self.archive_dir = Path(archive_dir or os.getenv("LOG_ARCHIVE_DIR", "/var/log/lars/archive"))
        
        # Проверка существования директорий
        if not self.live_dir.exists():
            print(f"⚠️  Live directory does not exist: {self.live_dir}", file=sys.stderr)
        if not self.archive_dir.exists():
            print(f"⚠️  Archive directory does not exist: {self.archive_dir}", file=sys.stderr)
    
    def _parse_timestamp(self, ts_str: str) -> Optional[datetime]:
        """Парсинг timestamp из строки."""
        if not ts_str:
            return None
        
        # Различные форматы timestamp
        formats = [
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d",
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(ts_str, fmt)
            except ValueError:
                continue
        
        return None
    
    def _matches_filter(self, event: Dict[str, Any], filters: Dict[str, Any]) -> bool:
        """Проверка соответствия события фильтрам."""
        # Фильтр по service
        if "service" in filters:
            if event.get("service") != filters["service"]:
                return False
        
        # Фильтр по level
        if "level" in filters:
            if event.get("level") != filters["level"]:
                return False
        
        # Фильтр по logger
        if "logger" in filters:
            logger_name = event.get("logger", "")
            if filters["logger"] not in logger_name:
                return False
        
        # Фильтр по временному диапазону
        if "from_time" in filters or "to_time" in filters:
            ts_str = event.get("ts", "")
            event_time = self._parse_timestamp(ts_str)
            
            if event_time:
                if "from_time" in filters and event_time < filters["from_time"]:
                    return False
                if "to_time" in filters and event_time > filters["to_time"]:
                    return False
        
        return True
    
    def _read_jsonl_file(self, file_path: Path) -> Iterator[Dict[str, Any]]:
        """Чтение JSONL файла построчно."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        event = json.loads(line)
                        if isinstance(event, dict):
                            yield event
                    except json.JSONDecodeError as e:
                        print(f"⚠️  Error parsing line {line_num} in {file_path}: {e}", file=sys.stderr)
                        continue
        except FileNotFoundError:
            pass
        except Exception as e:
            print(f"❌ Error reading {file_path}: {e}", file=sys.stderr)
    
    def _read_compressed_file(self, file_path: Path) -> Iterator[Dict[str, Any]]:
        """Чтение сжатого .zst файла."""
        try:
            import zstandard as zstd
            
            with open(file_path, "rb") as f:
                dctx = zstd.ZstdDecompressor()
                with dctx.stream_reader(f) as reader:
                    text_stream = reader.read().decode("utf-8")
                    for line in text_stream.splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        
                        try:
                            event = json.loads(line)
                            if isinstance(event, dict):
                                yield event
                        except json.JSONDecodeError:
                            continue
        except ImportError:
            print(f"⚠️  zstandard not available, cannot read compressed file: {file_path}", file=sys.stderr)
        except Exception as e:
            print(f"❌ Error reading compressed file {file_path}: {e}", file=sys.stderr)
    
    def read_logs(
        self,
        service: Optional[str] = None,
        level: Optional[str] = None,
        logger: Optional[str] = None,
        from_time: Optional[str] = None,
        to_time: Optional[str] = None,
        include_archives: bool = False,
    ) -> Iterator[Dict[str, Any]]:
        """
        Чтение логов с фильтрацией.
        
        Args:
            service: Фильтр по сервису
            level: Фильтр по уровню (INFO, WARNING, ERROR, etc.)
            logger: Фильтр по имени логгера (подстрока)
            from_time: Начало временного диапазона (формат: YYYY-MM-DD или YYYY-MM-DDTHH:MM:SS)
            to_time: Конец временного диапазона
            include_archives: Включать архивы в поиск
        
        Yields:
            События логов (dict)
        """
        # Подготовка фильтров
        filters = {}
        if service:
            filters["service"] = service
        if level:
            filters["level"] = level.upper()
        if logger:
            filters["logger"] = logger
        if from_time:
            filters["from_time"] = self._parse_timestamp(from_time)
        if to_time:
            filters["to_time"] = self._parse_timestamp(to_time)
        
        # Чтение текущего файла
        current_file = self.live_dir / "robot-current.json"
        if current_file.exists():
            for event in self._read_jsonl_file(current_file):
                if self._matches_filter(event, filters):
                    yield event
        
        # Чтение архивов (если нужно)
        if include_archives:
            # Несжатые файлы в live_dir
            for file_path in sorted(self.live_dir.glob("robot-*.json")):
                if file_path.name == "robot-current.json":
                    continue
                for event in self._read_jsonl_file(file_path):
                    if self._matches_filter(event, filters):
                        yield event
            
            # Сжатые файлы в archive_dir
            for file_path in sorted(self.archive_dir.glob("robot-*.json.zst")):
                for event in self._read_compressed_file(file_path):
                    if self._matches_filter(event, filters):
                        yield event
    
    def tail_logs(
        self,
        service: Optional[str] = None,
        level: Optional[str] = None,
        logger: Optional[str] = None,
        follow: bool = True,
    ):
        """
        Чтение логов в реальном времени (tail -f).
        
        Args:
            service: Фильтр по сервису
            level: Фильтр по уровню
            logger: Фильтр по имени логгера
            follow: Следить за новыми записями (по умолчанию True)
        """
        import time
        
        filters = {}
        if service:
            filters["service"] = service
        if level:
            filters["level"] = level.upper()
        if logger:
            filters["logger"] = logger
        
        current_file = self.live_dir / "robot-current.json"
        
        if not current_file.exists():
            print(f"⚠️  Log file does not exist: {current_file}", file=sys.stderr)
            return
        
        # Читаем с конца файла
        file_position = current_file.stat().st_size if current_file.exists() else 0
        
        try:
            with open(current_file, "r", encoding="utf-8") as f:
                # Перемещаемся в конец файла
                f.seek(file_position)
                
                while True:
                    line = f.readline()
                    if line:
                        line = line.strip()
                        if line:
                            try:
                                event = json.loads(line)
                                if isinstance(event, dict) and self._matches_filter(event, filters):
                                    self._print_event(event)
                            except json.JSONDecodeError:
                                pass
                    else:
                        if not follow:
                            break
                        time.sleep(0.1)  # Небольшая задержка перед следующей проверкой
                        
                        # Проверка, не был ли файл переименован (ротация)
                        if not current_file.exists():
                            # Ищем новый файл
                            new_file = self.live_dir / "robot-current.json"
                            if new_file.exists():
                                f.close()
                                f = open(new_file, "r", encoding="utf-8")
                                file_position = 0
                                current_file = new_file
        except KeyboardInterrupt:
            print("\n👋 Stopped tailing logs", file=sys.stderr)
        except Exception as e:
            print(f"❌ Error tailing logs: {e}", file=sys.stderr)
    
    def _print_event(self, event: Dict[str, Any], color: bool = True):
        """Вывод события в консоль."""
        level = event.get("level", "UNKNOWN")
        msg = event.get("msg", "")
        service = event.get("service", "unknown")
        logger = event.get("logger", "unknown")
        ts = event.get("ts", "")
        
        # Цветовая подсветка (упрощенная)
        level_markers = {
            "DEBUG": "[DEBUG]",
            "INFO": "[INFO]",
            "WARNING": "[WARN]",
            "ERROR": "[ERROR]",
            "CRITICAL": "[CRIT]",
        }
        marker = level_markers.get(level, f"[{level}]")
        
        # Форматированный вывод
        print(f"{ts} {marker} {service} | {logger}")
        if msg:
            print(f"  {msg}")
        
        # Вывод event данных, если есть
        if "event" in event and isinstance(event["event"], dict):
            event_data = event["event"]
            for key, value in event_data.items():
                if isinstance(value, (dict, list)):
                    print(f"  {key}: {json.dumps(value, ensure_ascii=False)}")
                else:
                    print(f"  {key}: {value}")
        
        print()  # Пустая строка между событиями
    
    def get_stats(self) -> Dict[str, Any]:
        """Получение статистики по логам."""
        stats = {
            "total_events": 0,
            "by_service": defaultdict(int),
            "by_level": defaultdict(int),
            "by_logger": defaultdict(int),
        }
        
        # Читаем все логи (без фильтров)
        for event in self.read_logs(include_archives=True):
            stats["total_events"] += 1
            stats["by_service"][event.get("service", "unknown")] += 1
            stats["by_level"][event.get("level", "UNKNOWN")] += 1
            logger = event.get("logger", "unknown")
            # Берем только первую часть logger (до первой точки)
            logger_base = logger.split(".")[0] if "." in logger else logger
            stats["by_logger"][logger_base] += 1
        
        return stats
    
    def print_stats(self):
        """Вывод статистики."""
        print("📊 Log Statistics")
        print("=" * 60)
        
        stats = self.get_stats()
        
        print(f"Total events: {stats['total_events']}")
        print()
        
        print("By service:")
        for service, count in sorted(stats["by_service"].items(), key=lambda x: -x[1]):
            print(f"  {service}: {count}")
        print()
        
        print("By level:")
        for level, count in sorted(stats["by_level"].items(), key=lambda x: -x[1]):
            print(f"  {level}: {count}")
        print()
        
        print("By logger (top 10):")
        for logger, count in sorted(stats["by_logger"].items(), key=lambda x: -x[1])[:10]:
            print(f"  {logger}: {count}")


def main():
    """Главная функция CLI."""
    parser = argparse.ArgumentParser(
        description="Log Reader - утилита для чтения и фильтрации JSONL логов"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Команда")
    
    # Команда read
    read_parser = subparsers.add_parser("read", help="Чтение логов с фильтрацией")
    read_parser.add_argument("--service", help="Фильтр по сервису")
    read_parser.add_argument("--level", help="Фильтр по уровню (INFO, WARNING, ERROR, etc.)")
    read_parser.add_argument("--logger", help="Фильтр по имени логгера (подстрока)")
    read_parser.add_argument("--from", dest="from_time", help="Начало временного диапазона (YYYY-MM-DD или YYYY-MM-DDTHH:MM:SS)")
    read_parser.add_argument("--to", dest="to_time", help="Конец временного диапазона")
    read_parser.add_argument("--archives", action="store_true", help="Включать архивы")
    read_parser.add_argument("--live-dir", help="Директория с текущими логами")
    read_parser.add_argument("--archive-dir", help="Директория с архивами")
    
    # Команда tail
    tail_parser = subparsers.add_parser("tail", help="Чтение логов в реальном времени (tail -f)")
    tail_parser.add_argument("--service", help="Фильтр по сервису")
    tail_parser.add_argument("--level", help="Фильтр по уровню")
    tail_parser.add_argument("--logger", help="Фильтр по имени логгера")
    tail_parser.add_argument("--no-follow", action="store_true", help="Не следить за новыми записями")
    tail_parser.add_argument("--live-dir", help="Директория с текущими логами")
    
    # Команда stats
    stats_parser = subparsers.add_parser("stats", help="Статистика по логам")
    stats_parser.add_argument("--live-dir", help="Директория с текущими логами")
    stats_parser.add_argument("--archive-dir", help="Директория с архивами")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Создание LogReader
    live_dir = getattr(args, "live_dir", None)
    archive_dir = getattr(args, "archive_dir", None)
    reader = LogReader(live_dir=live_dir, archive_dir=archive_dir)
    
    # Выполнение команды
    if args.command == "read":
        for event in reader.read_logs(
            service=args.service,
            level=args.level,
            logger=args.logger,
            from_time=args.from_time,
            to_time=args.to_time,
            include_archives=args.archives,
        ):
            reader._print_event(event)
    
    elif args.command == "tail":
        reader.tail_logs(
            service=args.service,
            level=args.level,
            logger=args.logger,
            follow=not args.no_follow,
        )
    
    elif args.command == "stats":
        reader.print_stats()


if __name__ == "__main__":
    main()


