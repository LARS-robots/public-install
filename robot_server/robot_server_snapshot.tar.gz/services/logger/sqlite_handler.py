# logger/sqlite_handler.py
"""
SQLite Handler - класс для записи логов в SQLite базу данных.

Записывает логи в SQLite с батч-инсертами, проверкой размера диска,
retention правилами и безопасной обработкой ошибок.
"""
from __future__ import annotations

import json
import sqlite3
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# No global variables - all state in class instance


class SQLiteHandler:
    """
    SQLite Handler - запись логов в SQLite базу данных.
    
    Использует WAL режим для concurrent reads/writes,
    батч-инсерты для производительности,
    проверку размера диска перед записью.
    """
    
    def __init__(
        self,
        db_path: str = "/var/log/lars/sqlite/logs.db",
        wal: bool = True,
        synchronous: str = "NORMAL",
        busy_timeout_ms: int = 5000,
        max_db_size_mb: int = 4096,
        max_age_days: int = 14,
        cleanup_interval_sec: int = 600,
    ) -> None:
        """
        Инициализация SQLite handler.
        
        Args:
            db_path: Путь к SQLite базе данных
            wal: Использовать WAL режим (Write-Ahead Logging)
            synchronous: Режим синхронизации (NORMAL, FULL, OFF)
            busy_timeout_ms: Таймаут ожидания блокировки (мс)
            max_db_size_mb: Максимальный размер БД в МБ
            max_age_days: Максимальный возраст логов в днях
            cleanup_interval_sec: Интервал очистки старых логов (сек)
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.wal = wal
        self.synchronous = synchronous
        self.busy_timeout_ms = busy_timeout_ms
        self.max_db_size_bytes = max_db_size_mb * 1024 * 1024
        self.max_age_days = max_age_days
        self.cleanup_interval_sec = cleanup_interval_sec
        
        self._conn: Optional[sqlite3.Connection] = None
        self._batch: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._last_cleanup = time.time()
        self._batch_size = 50  # Flush batch when it reaches this size
        
        # Инициализация базы данных
        self._init_database()
    
    def _init_database(self) -> None:
        """Инициализация базы данных: создание схемы и настройка PRAGMA."""
        try:
            self._conn = sqlite3.connect(
                str(self.db_path),
                timeout=self.busy_timeout_ms / 1000.0,
                check_same_thread=False,  # Thread-safe через lock
            )
            
            # Настройка PRAGMA для робототехники
            cursor = self._conn.cursor()
            
            if self.wal:
                cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute(f"PRAGMA synchronous={self.synchronous}")
            cursor.execute("PRAGMA temp_store=MEMORY")
            cursor.execute(f"PRAGMA busy_timeout={self.busy_timeout_ms}")
            
            # Создание таблицы, если не существует
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts INTEGER NOT NULL,
                    level TEXT NOT NULL,
                    service TEXT,
                    logger TEXT,
                    msg TEXT,
                    event_json TEXT,
                    exception_json TEXT,
                    hostname TEXT,
                    pid INTEGER,
                    subject TEXT
                )
            """)
            
            # Создание индексов, если не существуют
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_logs_ts ON logs(ts)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_logs_service_ts ON logs(service, ts DESC)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_logs_level_ts ON logs(level, ts DESC)
            """)
            
            # Full-text search (FTS5) - best effort
            try:
                cursor.execute("""
                    CREATE VIRTUAL TABLE IF NOT EXISTS logs_fts USING fts5(
                        msg,
                        event_json,
                        logger,
                        service,
                        level,
                        content='logs',
                        content_rowid='id'
                    )
                """)
                cursor.execute("""
                    CREATE TRIGGER IF NOT EXISTS logs_ai AFTER INSERT ON logs BEGIN
                        INSERT INTO logs_fts(rowid, msg, event_json, logger, service, level)
                        VALUES (new.id, new.msg, new.event_json, new.logger, new.service, new.level);
                    END;
                """)
                cursor.execute("""
                    CREATE TRIGGER IF NOT EXISTS logs_ad AFTER DELETE ON logs BEGIN
                        INSERT INTO logs_fts(logs_fts, rowid, msg, event_json, logger, service, level)
                        VALUES ('delete', old.id, old.msg, old.event_json, old.logger, old.service, old.level);
                    END;
                """)
                cursor.execute("""
                    CREATE TRIGGER IF NOT EXISTS logs_au AFTER UPDATE ON logs BEGIN
                        INSERT INTO logs_fts(logs_fts, rowid, msg, event_json, logger, service, level)
                        VALUES ('delete', old.id, old.msg, old.event_json, old.logger, old.service, old.level);
                        INSERT INTO logs_fts(rowid, msg, event_json, logger, service, level)
                        VALUES (new.id, new.msg, new.event_json, new.logger, new.service, new.level);
                    END;
                """)
                
                # Rebuild FTS index only if empty (avoid heavy rebuild each start)
                cursor.execute("SELECT COUNT(*) FROM logs_fts")
                fts_count = cursor.fetchone()[0]
                if fts_count == 0:
                    cursor.execute("SELECT COUNT(*) FROM logs")
                    logs_count = cursor.fetchone()[0]
                    if logs_count > 0:
                        cursor.execute("INSERT INTO logs_fts(logs_fts) VALUES ('rebuild')")
            except Exception as e:
                try:
                    sys.stderr.write(f"[SQLiteHandler] FTS init skipped: {e}\n")
                except Exception:
                    pass
            
            self._conn.commit()
            
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] Database init error: {e}\n")
            except Exception:
                pass
    
    def _prepare_row(self, event: Dict[str, Any]) -> Tuple:
        """
        Преобразование события в кортеж для SQLite INSERT.
        
        Args:
            event: Словарь с данными события
            
        Returns:
            Кортеж значений для INSERT
        """
        # Парсинг timestamp в epoch milliseconds
        ts_ms = self._parse_timestamp(event.get("ts", ""))
        
        # Сериализация полного события в JSON
        event_json = json.dumps(event, ensure_ascii=False, separators=(',', ':'))
        
        # Сериализация exception, если есть
        exception_json = None
        if "exception" in event:
            exception_json = json.dumps(event["exception"], ensure_ascii=False, separators=(',', ':'))
        
        return (
            ts_ms,
            str(event.get("level", "INFO")).upper(),
            event.get("service"),
            event.get("logger"),
            event.get("msg"),
            event_json,
            exception_json,
            event.get("hostname"),
            event.get("pid"),
            event.get("subject"),
        )
    
    def _parse_timestamp(self, ts_str: Any) -> int:
        """
        Парсинг timestamp в epoch milliseconds.
        
        Args:
            ts_str: Timestamp в различных форматах
            
        Returns:
            Epoch milliseconds (int)
        """
        if not ts_str:
            return int(time.time() * 1000)
        
        # Если уже число (epoch seconds или milliseconds)
        if isinstance(ts_str, (int, float)):
            # Если меньше 1e10, считаем секундами, иначе миллисекундами
            if ts_str < 1e10:
                return int(ts_str * 1000)
            return int(ts_str)
        
        # Парсинг строковых форматов
        ts_str = str(ts_str)
        try:
            # ISO format: "2024-01-27T10:00:00" или "2024-01-27T10:00:00.123"
            if "T" in ts_str:
                # Удаляем timezone если есть
                ts_str = ts_str.split("+")[0].split("Z")[0]
                # Парсим ISO format
                from datetime import datetime
                dt = datetime.fromisoformat(ts_str)
                return int(dt.timestamp() * 1000)
        except Exception:
            pass
        
        # Fallback: текущее время
        return int(time.time() * 1000)
    
    def _check_size_and_cleanup(self) -> None:
        """
        Проверка размера БД и агрессивная очистка при превышении лимита.
        """
        try:
            if not self._conn:
                return
            
            # Проверка размера файла БД
            db_size = self.db_path.stat().st_size
            
            if db_size > self.max_db_size_bytes:
                # Агрессивная очистка: удаляем самые старые записи
                cursor = self._conn.cursor()
                
                # Вычисляем сколько записей нужно удалить (примерно 20% от общего числа)
                cursor.execute("SELECT COUNT(*) FROM logs")
                total_count = cursor.fetchone()[0]
                delete_count = max(1, total_count // 5)  # Удаляем 20%
                
                # Удаляем самые старые записи
                cursor.execute("""
                    DELETE FROM logs
                    WHERE id IN (
                        SELECT id FROM logs
                        ORDER BY ts ASC
                        LIMIT ?
                    )
                """, (delete_count,))
                
                self._conn.commit()
                
                # WAL checkpoint для освобождения места
                cursor.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                
                # Проверяем размер снова
                db_size = self.db_path.stat().st_size
                if db_size > self.max_db_size_bytes:
                    # Если всё ещё превышает лимит, логируем предупреждение
                    try:
                        sys.stderr.write(
                            f"[SQLiteHandler] WARNING: DB size ({db_size / 1024 / 1024:.1f}MB) "
                            f"still exceeds limit ({self.max_db_size_bytes / 1024 / 1024:.1f}MB) "
                            f"after cleanup\n"
                        )
                    except Exception:
                        pass
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] Size check error: {e}\n")
            except Exception:
                pass
    
    def _delete_old_logs(self) -> None:
        """
        Удаление старых логов по retention правилам.
        """
        try:
            if not self._conn:
                return
            
            cutoff_ts = int((time.time() - self.max_age_days * 86400) * 1000)
            
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM logs WHERE ts < ?", (cutoff_ts,))
            deleted_count = cursor.rowcount
            
            self._conn.commit()
            
            # WAL checkpoint после удаления
            if deleted_count > 0:
                cursor.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] Retention cleanup error: {e}\n")
            except Exception:
                pass
    
    def emit_log(self, event: Dict[str, Any]) -> None:
        """
        Добавить лог в батч для записи.
        
        Args:
            event: Словарь с данными события
        """
        try:
            with self._lock:
                self._batch.append(event)
                
                # Flush если батч достиг размера
                if len(self._batch) >= self._batch_size:
                    self.flush()
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] emit_log error: {e}\n")
            except Exception:
                pass
    
    def write_batch(self, events: List[Dict[str, Any]]) -> int:
        """
        Записать список событий одной транзакцией.
        
        Это основной путь для daemon-а: раз в интервал пишет все накопленные записи
        одной операцией executemany (выполнение требования по батчингу).
        """
        if not events or not self._conn:
            return 0
        
        try:
            with self._lock:
                # Проверка размера перед записью
                self._check_size_and_cleanup()
                
                # Периодическая очистка старых логов
                now = time.time()
                if now - self._last_cleanup >= self.cleanup_interval_sec:
                    self._delete_old_logs()
                    self._last_cleanup = now
                
                rows = [self._prepare_row(event) for event in events]
                cursor = self._conn.cursor()
                cursor.executemany("""
                    INSERT INTO logs (
                        ts, level, service, logger, msg,
                        event_json, exception_json, hostname, pid, subject
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, rows)
                self._conn.commit()
                return len(rows)
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] write_batch error: {e}\n")
            except Exception:
                pass
            return 0
    
    def flush(self) -> None:
        """Записать батч в базу данных."""
        if not self._conn:
            return
        
        try:
            with self._lock:
                if not self._batch:
                    return
                
                # Проверка размера перед записью
                self._check_size_and_cleanup()
                
                # Периодическая очистка старых логов
                now = time.time()
                if now - self._last_cleanup >= self.cleanup_interval_sec:
                    self._delete_old_logs()
                    self._last_cleanup = now
                
                # Подготовка данных для батч-инсерта
                rows = [self._prepare_row(event) for event in self._batch]
                
                # Батч-инсерт в транзакции
                cursor = self._conn.cursor()
                cursor.executemany("""
                    INSERT INTO logs (
                        ts, level, service, logger, msg,
                        event_json, exception_json, hostname, pid, subject
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, rows)
                
                self._conn.commit()
                
                # Очистка батча
                self._batch.clear()
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] flush error: {e}\n")
                # Не очищаем батч при ошибке - можно попробовать позже
            except Exception:
                pass
    
    def close(self) -> None:
        """Закрыть соединение с базой данных."""
        try:
            # Flush оставшиеся записи
            self.flush()
            
            with self._lock:
                if self._conn:
                    self._conn.close()
                    self._conn = None
        
        except Exception as e:
            try:
                sys.stderr.write(f"[SQLiteHandler] close error: {e}\n")
            except Exception:
                pass
