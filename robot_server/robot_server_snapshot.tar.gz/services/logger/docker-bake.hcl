group "default" {
  targets = ["logger-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, переопределяется из Python

target "logger-daemon-base" {
  context    = "./services/logger"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Используем переменную вместо hardcoded списка
}

target "logger-daemon-local" {
  inherits = ["logger-daemon-base"]
  tags     = ["logger-daemon:local", "logger-daemon"] 
}


