# Logger Daemon

## Назначение

Демон для централизованного сохранения логов из NATS JetStream в файлы. Подписывается на все логи (`log.*`) через JetStream с durable consumer, создает JetStream Stream при первом запуске, сохраняет логи в JSONL формате с ротацией по размеру/времени, сжатием архивов и retention правилами.

**Основные функции:**
- Подписка на логи из NATS JetStream (топик `log.*`)
- Создание JetStream Stream для `log.*` при первом запуске
- Durable consumer для гарантии доставки (не теряем логи при перезапуске)
- Сохранение логов в JSONL формат (одна строка JSON на событие)
- Ротация файлов по размеру (64 MB) или времени (30 минут)
- Сжатие архивов в `.zst` формат
- Retention правила (удаление старых логов по возрасту и размеру)
- Автоматическое переподключение к NATS при потере соединения
- Graceful shutdown с корректной обработкой сигналов
- Метрики работы демона (обработанные сообщения, ошибки, переподключения)
- Утилита `log_reader.py` для чтения и фильтрации логов

## Архитектура

### Поток данных

```
Сервис (API/camera-daemon/motor-daemon)
  ↓ [log.info("message")]
  ↓
nats_logger (NATSHandler)
  ↓ [JSON: {"level":"INFO", "service":"api", ...}]
  ↓ [Core publish: log.api.INFO]
  ↓
NATS Server (Core)
  ↓ [Автоматически сохраняет в JetStream Stream "LOGS" для log.*]
  ↓
JetStream Stream "LOGS"
  ↓ [Durable Consumer: "logger-daemon"]
  ↓
Logger Daemon
  ↓ [Парсит JSON, записывает в файлы]
  ↓
JSONL файлы (robot-current.json, архив)
```

### Компоненты

1. **NATS JetStream Stream**: Хранит все логи из `log.*` subjects
2. **Durable Consumer**: Сохраняет позицию обработки между перезапусками
3. **JSONLSegmentHandler**: Записывает логи в JSONL формат с ротацией
4. **Rotation**: По размеру (64 MB) или времени (30 минут)
5. **Compression**: Zstandard сжатие архивов (уровень 9)
6. **Retention**: Удаление старых логов (14 дней или 8 GiB)

## Конфигурация

**Приоритет:**
1. Environment variables (высший приоритет)
2. `config.toml` (fallback)
3. Defaults

### Environment Variables

| Параметр | Env Var | Default | Описание |
|----------|---------|---------|----------|
| NATS URL | `NATS_URL` | `nats://nats:4222` | URL NATS сервера |
| Live dir | `LOG_LIVE_DIR` | `/var/log/lars/live` | Директория текущих логов |
| Archive dir | `LOG_ARCHIVE_DIR` | `/var/log/lars/archive` | Директория архивов |
| Segment size | `LOG_SEGMENT_SIZE_MB` | `64` | Размер сегмента (MB) |
| Segment time | `LOG_SEGMENT_MAX_SEC` | `1800` | Время сегмента (сек) |
| Zstd level | `LOG_ZSTD_LEVEL` | `9` | Уровень сжатия (1-22) |
| Max total | `LOG_MAX_TOTAL_BYTES` | `8GiB` | Макс размер архивов |
| Max age | `LOG_MAX_AGE_DAYS` | `14` | Макс возраст (дни) |

### config.toml

```toml
[nats]
url = "nats://nats:4222"

[logger]
live_dir = "/var/log/lars/live"
archive_dir = "/var/log/lars/archive"
segment_size_mb = 64
segment_max_sec = 1800
zstd_level = 9
max_total_bytes = "8GiB"
max_age_days = 14
```

См. `config.example.toml` для полного примера.

## Запуск

### Вариант 1: Standalone (только logger-daemon и nats)

**Для тестирования logger-daemon отдельно:**

```bash
# Из директории robot/
docker compose -f services/logger/compose.standalone.yml up -d
```

**Просмотр логов:**
```bash
docker compose -f services/logger/compose.standalone.yml logs -f logger-daemon
```

**Остановка:**
```bash
docker compose -f services/logger/compose.standalone.yml down
```

### Вариант 2: С основным compose (вместе с другими сервисами)

**С motion_daemon (если нужен полный стек):**

```bash
# Из директории robot/
docker compose -f compose.yml -f services/motor_daemon/compose.linux.yml -f services/logger/compose.yml up logger-daemon -d
```

**Без motion_daemon (только logger-daemon):**

Обратите внимание: если в `compose.yml` есть сервисы с зависимостями от других сервисов (например, `api` зависит от `motion_daemon`), используйте standalone compose для запуска только logger-daemon.

### Переменные окружения для разных платформ

**Linux/Windows:**
```bash
LOGGER_IMAGE=logger-daemon:local
LOGGER_PLATFORM=linux/amd64
LOGGER_NETWORK_MODE=bridge
```

**Raspberry Pi:**
```bash
LOGGER_IMAGE=logger-daemon:local
LOGGER_PLATFORM=linux/arm64
LOGGER_NETWORK_MODE=host  # Если нужно
```

## Формат выходных файлов

### Live файлы

**Файл:** `robot-current.json` (текущий сегмент, не сжатый)

**Формат:** JSONL (JSON Lines) - одна строка JSON на событие

**Пример:**
```jsonl
{"ts":"2024-01-15T10:30:45","level":"INFO","logger":"app.services.motor","msg":"route.plan","service":"api","hostname":"robot-001","pid":12345,"event":{"stage":"route","action":"plan"}}
{"ts":"2024-01-15T10:30:46","level":"WARNING","logger":"app.camera","msg":"Low bandwidth","service":"camera-daemon","hostname":"robot-001","pid":12346}
```

**Почему JSONL:**
- Одна строка на событие (удобно для `tail -f`)
- Можно парсить построчно
- Можно использовать `jq` для фильтрации
- Более читаемый чем MessagePack

### Архивы

**Файлы:** `robot-YYYYMMDD-HHMMSS.json.zst` (сжатые архивы)

**Формат:** Zstandard compressed JSONL

**Расположение:** `archive_dir` (по умолчанию `/var/log/lars/archive`)

**Декомпрессия:**
```bash
# Установить zstd
sudo apt-get install zstd

# Декомпрессия
zstd -d robot-20240115-103045.json.zst

# Или просмотр без декомпрессии
zstdcat robot-20240115-103045.json.zst | jq .
```

## Интеграция с NATS

### JetStream Stream

**Stream name:** `LOGS`

**Subjects:** `log.*`, `log.>`

**Storage:** File (персистентное хранилище)

**Retention:** Limits

**Создание:**
- Stream создается автоматически при первом запуске демона
- Если stream уже существует - игнорируется ошибка
- Сообщения, опубликованные через Core, автоматически попадают в JetStream

### Durable Consumer

**Consumer name:** `logger-daemon`

**Subject:** `log.>`

**Почему durable:**
- Сохраняет позицию обработки между перезапусками
- При перезапуске продолжает с последнего обработанного сообщения
- Не теряем логи даже если демон был остановлен

### Подписка

Демон подписывается на `log.>` (wildcard для всех логов):
- `log.api.INFO` - INFO логи от API
- `log.api.ERROR` - ERROR логи от API
- `log.camera-daemon.WARNING` - WARNING логи от camera-daemon
- `log.api` - агрегированные логи API
- `log.all` - все логи всех сервисов

## Ротация и архивация

### Ротация

**Триггеры:**
- Размер файла >= 64 MB (по умолчанию)
- Время с открытия >= 30 минут (по умолчанию)

**Процесс:**
1. Текущий файл `robot-current.json` закрывается
2. Переименовывается в `robot-YYYYMMDD-HHMMSS.json`
3. Открывается новый `robot-current.json`
4. Сжатие старого файла запускается в фоновом потоке

### Архивация

**Процесс:**
1. Файл `robot-YYYYMMDD-HHMMSS.json` сжимается в `.zst`
2. Сжатый файл перемещается в `archive_dir`
3. Исходный файл удаляется после успешного сжатия
4. Применяются retention правила

### Retention

**Правила:**
1. По возрасту: удаляются файлы старше 14 дней (по умолчанию)
2. По размеру: удаляются самые старые файлы при превышении 8 GiB (по умолчанию)

**Приоритет:**
- Сначала удаляются старые по возрасту
- Затем удаляются старые по размеру до достижения лимита

## Troubleshooting

### Демон не подключается к NATS

**Симптомы:**
```
❌ Failed to connect to NATS: ...
```

**Решения:**
1. Проверить, что NATS сервер запущен:
   ```bash
   docker compose ps nats
   ```

2. Проверить NATS_URL:
   ```bash
   echo $NATS_URL
   # Должно быть: nats://nats:4222
   ```

3. Проверить сеть Docker:
   ```bash
   docker compose logs nats
   ```

### Stream не создается

**Симптомы:**
```
❌ Failed to create stream: ...
```

**Решения:**
1. Проверить, что JetStream включен в NATS:
   ```bash
   # В compose.yml должно быть: command: ["-c","/etc/nats/nats-server.conf", "-js"]
   docker compose logs nats | grep jetstream
   ```

2. Проверить, что stream еще не существует:
   ```bash
   docker exec -it <nats-container> nats stream ls
   ```

### Логи не сохраняются

**Симптомы:**
- Файлы не появляются в `live_dir`

**Решения:**
1. Проверить, что сервисы публикуют логи:
   ```bash
   # Запустить тестовый подписчик
   python services/logger/tests/nats/test_nats_subscriber.py
   ```

2. Проверить, что демон подписался:
   ```bash
   docker compose logs logger-daemon | grep "Subscribed"
   ```

3. Проверить права на запись:
   ```bash
   ls -la /var/log/lars/live
   # Должны быть права на запись
   ```

### Файлы не ротируются

**Симптомы:**
- `robot-current.json` растет без ограничений

**Решения:**
1. Проверить настройки ротации:
   ```bash
   docker compose exec logger-daemon env | grep LOG_SEGMENT
   ```

2. Проверить размер файла:
   ```bash
   ls -lh /var/log/lars/live/robot-current.json
   ```

### Архивы не сжимаются

**Симптомы:**
- Файлы `robot-*.json` остаются в `live_dir` без `.zst`

**Решения:**
1. Проверить, что zstandard установлен:
   ```bash
   docker compose exec logger-daemon python -c "import zstandard; print('OK')"
   ```

2. Проверить логи демона:
   ```bash
   docker compose logs logger-daemon | grep compress
   ```

## Утилита log_reader.py

Утилита для чтения и фильтрации JSONL логов.

### Установка

Утилита доступна в контейнере logger-daemon или может быть запущена локально:

```bash
# В контейнере
docker compose exec logger-daemon python3 log_reader.py --help

# Локально (требуется Python 3.12+ и зависимости)
cd services/logger
pip install -r requirements.txt
python log_reader.py --help
```

### Использование

#### Чтение логов в реальном времени (tail -f)

```bash
# Все логи
python log_reader.py tail

# Фильтр по сервису
python log_reader.py tail --service api

# Фильтр по уровню
python log_reader.py tail --level ERROR

# Комбинированные фильтры
python log_reader.py tail --service api --level WARNING
```

#### Чтение логов с фильтрацией

```bash
# Все логи из текущего файла
python log_reader.py read

# Фильтр по сервису
python log_reader.py read --service api

# Фильтр по уровню
python log_reader.py read --level ERROR

# Временной диапазон
python log_reader.py read --from 2024-01-15 --to 2024-01-16

# Включая архивы
python log_reader.py read --service api --archives

# Комбинированные фильтры
python log_reader.py read --service api --level ERROR --from 2024-01-15T10:00:00
```

#### Статистика

```bash
# Общая статистика
python log_reader.py stats

# Статистика с указанием директорий
python log_reader.py stats --live-dir /var/log/lars/live --archive-dir /var/log/lars/archive
```

### Примеры вывода

**Чтение логов:**
```
2024-01-15T10:30:45 [INFO] api | app.services.motor
  route.plan
  stage: route
  action: plan
  start: {"lat": 55.164, "lon": 61.436}
```

**Статистика:**
```
📊 Log Statistics
============================================================
Total events: 12345

By service:
  api: 8500
  camera-daemon: 2500
  motor-daemon: 1345

By level:
  INFO: 10000
  WARNING: 2000
  ERROR: 345
```

## Улучшения надежности

### Автоматическое переподключение

Демон автоматически переподключается к NATS при потере соединения:
- Проверка соединения перед каждым pull запросом
- Автоматическое переподключение с задержкой 5 секунд
- Счетчик переподключений в метриках

### Graceful Shutdown

Демон корректно обрабатывает сигналы завершения:
- SIGTERM и SIGINT обрабатываются через signal handlers
- Корректное завершение pull task
- Закрытие файлов и NATS соединения
- Вывод финальных метрик

### Метрики

Демон собирает метрики работы:
- `messages_processed` - количество обработанных сообщений
- `events_saved` - количество сохраненных событий
- `errors` - количество ошибок
- `reconnect_count` - количество переподключений
- `uptime_seconds` - время работы (в get_metrics())

Метрики выводятся каждые 5 минут и при завершении работы.

## Дополнительная информация

- Архитектура NATS: `../docs/NATS.md`
- Логирование через NATS: `../docs/nats-logging.md`
- Библиотека nats_logger: `../nats_logger/README.md`
