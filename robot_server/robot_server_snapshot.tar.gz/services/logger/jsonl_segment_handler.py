# logger/jsonl_segment_handler.py
"""
JSONL Segment Handler - класс для записи JSONL с ротацией.

Записывает логи в JSONL формат (одна строка JSON на событие) с ротацией по размеру/времени,
сжатием архивов в .zst и retention правилами.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict

try:
    import zstandard as zstd
except ImportError:
    zstd = None  # позволим работать без компрессии (dev-окружение)


class JSONLSegmentHandler:
    """
    JSONL Segment Handler - запись логов в JSONL формат с ротацией.
    
    Текущий сегмент хранится нежатым (для live-вьюера), закрытые сегменты — сжимаются в .zst.
    После каждой компрессии запускается "reaper" (лимиты по объёму/возрасту).
    """
    
    def __init__(
        self,
        live_dir: str = "/var/log/lars/live",
        archive_dir: str = "/var/log/lars/archive",
        segment_size_mb: int = 64,
        segment_max_sec: int = 1800,
        zstd_level: int = 9,
        max_total_bytes: int | str = 8_589_934_592,  # 8 GiB
        max_age_days: int = 14,
    ) -> None:
        self.live_dir = Path(live_dir)
        self.live_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir = Path(archive_dir)
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        
        self.seg_bytes = int(segment_size_mb) * 1024 * 1024
        self.seg_secs = int(segment_max_sec)
        self.zstd_level = int(zstd_level)
        self.max_total_bytes = self._parse_size(max_total_bytes)
        self.max_age_days = int(max_age_days)
        
        self.cur_path = self.live_dir / "robot-current.json"
        self._f = open(self.cur_path, "a", buffering=1)  # Line buffered for JSONL
        self._opened_at = time.time()
        self._bytes = self._f.tell()
        self._lock = threading.Lock()
    
    @staticmethod
    def _parse_size(v) -> int:
        """Parse size string to bytes."""
        if isinstance(v, int):
            return v
        s = str(v).strip().lower().replace(" ", "")
        mul = 1
        if s.endswith(("k", "kb")): mul, s = 1024, s.rstrip("kb").rstrip("k")
        elif s.endswith(("m", "mb")): mul, s = 1024**2, s.rstrip("mb").rstrip("m")
        elif s.endswith(("g", "gb")): mul, s = 1024**3, s.rstrip("gb").rstrip("g")
        elif s.endswith(("t", "tb")): mul, s = 1024**4, s.rstrip("tb").rstrip("t")
        elif s.endswith("kib"): mul, s = 1024, s[:-3]
        elif s.endswith("mib"): mul, s = 1024**2, s[:-3]
        elif s.endswith("gib"): mul, s = 1024**3, s[:-3]
        elif s.endswith("tib"): mul, s = 1024**4, s[:-3]
        try:
            return int(float(s) * mul)
        except Exception:
            return 8_589_934_592  # дефолт 8 GiB
    
    def emit_log(self, event: Dict[str, Any]) -> None:
        """
        Записать лог в JSONL формат (одна строка JSON).
        
        Args:
            event: Словарь с данными события (будет сериализован в JSON)
        """
        try:
            # Сериализация в JSON (одна строка без форматирования)
            json_line = json.dumps(event, ensure_ascii=False, separators=(',', ':')) + "\n"
            json_bytes = json_line.encode("utf-8")
            
            with self._lock:
                self._f.write(json_line)
                self._f.flush()  # Ensure immediate write for live viewing
                self._bytes += len(json_bytes)
                
                if self._need_rotate():
                    self._rotate_async()
        except Exception as e:
            try:
                sys.stderr.write(f"[JSONLSegmentHandler] emit error: {e}\n")
            except Exception:
                pass  # не роняем демон из-за логгера
    
    def _need_rotate(self) -> bool:
        """Проверить, нужна ли ротация (по размеру или времени)."""
        return (self._bytes >= self.seg_bytes) or ((time.time() - self._opened_at) >= self.seg_secs)
    
    def _rotate_async(self) -> None:
        """Выполнить ротацию файла (закрыть текущий, создать новый)."""
        # Закрыть текущий файл
        try:
            self._f.flush()
            self._f.close()
        except Exception:
            pass
        
        # Переименовать в файл с timestamp
        ts = time.strftime("%Y%m%d-%H%M%S", time.localtime(self._opened_at))
        final = self.live_dir / f"robot-{ts}.json"
        try:
            if self.cur_path.exists():
                os.replace(self.cur_path, final)
        except Exception:
            pass
        
        # Открыть новый файл
        self._f = open(self.cur_path, "a", buffering=1)
        self._opened_at = time.time()
        self._bytes = 0
        
        # Компрессия в фоне (если есть zstd)
        if zstd is not None and final.exists():
            t = threading.Thread(target=self._compress_then_delete, args=(final,), daemon=True)
            t.start()
    
    def _compress_then_delete(self, src: Path) -> None:
        """Сжать файл в .zst и удалить исходный."""
        try:
            dst = self.archive_dir / (src.name + ".zst")
            c = zstd.ZstdCompressor(level=self.zstd_level) if zstd else None
            if c is not None:
                with open(src, "rb") as fi, open(dst, "wb") as fo:
                    c.copy_stream(fi, fo)
        except Exception as e:
            try:
                sys.stderr.write(f"[JSONLSegmentHandler] compress error: {e}\n")
            except Exception:
                pass
            return
        
        # Удаляем исходный сегмент после успешной компрессии
        try:
            src.unlink(missing_ok=True)
        except Exception:
            pass
        
        # Применяем retention-правила
        try:
            self._reap()
        except Exception:
            pass
    
    def _reap(self) -> None:
        """
        Лимиты по возрасту (max_age_days) и общему объёму (max_total_bytes) в archive_dir.
        Удаляем самые старые сегменты.
        """
        import time as _t
        
        # По возрасту
        files = list(self.archive_dir.glob("robot-*.json.zst")) + list(self.archive_dir.glob("robot-*.json"))
        files.sort(key=lambda p: p.stat().st_mtime)
        
        cutoff = _t.time() - self.max_age_days * 86400
        for f in files:
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink(missing_ok=True)
            except FileNotFoundError:
                pass
        
        # По общему размеру
        files = list(self.archive_dir.glob("robot-*.json.zst")) + list(self.archive_dir.glob("robot-*.json"))
        files.sort(key=lambda p: p.stat().st_mtime)
        total = 0
        sized = []
        for f in files:
            try:
                sz = f.stat().st_size
            except FileNotFoundError:
                continue
            total += sz
            sized.append((f, sz))
        
        i = 0
        while total > self.max_total_bytes and i < len(sized):
            f, sz = sized[i]
            try:
                f.unlink(missing_ok=True)
                total -= sz
            except FileNotFoundError:
                pass
            i += 1
    
    def close(self) -> None:
        """Закрыть файл."""
        with self._lock:
            try:
                self._f.flush()
                self._f.close()
            except Exception:
                pass


