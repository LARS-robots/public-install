# motion/mixer.py
# Convert forward/turn commands into left/right track effort

def arcade_to_tracks(forward: float, turn: float):
    """
    forward: [-1.0, 1.0]
    turn:    [-1.0, 1.0]

    returns:
      left, right in [-1.0, 1.0]
    """

    # Mix
    left = forward - turn
    right = forward + turn

    # Clamp to allowed range
    left = max(-1.0, min(1.0, left))
    right = max(-1.0, min(1.0, right))

    return left, right
