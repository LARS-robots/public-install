#!/usr/bin/env python3
"""
Sequence KV store for motor daemon.
Stores sequence state and sequences in NATS JetStream Key-Value store.
"""
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


def _iso_now() -> str:
    """Return ISO8601 UTC timestamp with millisecond precision."""
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


class SequenceKVStore:
    """KV store helper for motor test sequences (shared by sequence processor and tests)."""
    
    def __init__(self, nc=None):
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "motor_test_state"
    
    async def initialize(self):
        """Initialize JetStream and KV store."""
        try:
            if not self.nc:
                log.warning("NATS connection not available for KV store")
                return
            
            # Create JetStream context
            self.js = self.nc.jetstream()
            
            # Create or get KV bucket
            try:
                self.kv = await self.js.create_key_value(bucket=self.bucket_name)
                log.info(f"KV store bucket '{self.bucket_name}' initialized")
            except Exception as e:
                # Try to get existing bucket
                try:
                    self.kv = await self.js.key_value(bucket=self.bucket_name)
                    log.info(f"KV store bucket '{self.bucket_name}' retrieved")
                except Exception:
                    log.error(f"Failed to create or get KV bucket '{self.bucket_name}': {e}")
                    self.kv = None
        except Exception as e:
            log.error(f"Failed to initialize KV store: {e}", exc_info=True)
            self.kv = None
    
    async def update_state(self, state_data: Dict[str, Any]):
        """Update KV store with current state."""
        if not self.kv:
            return
        
        try:
            # Serialize state_data to JSON
            state_json = json.dumps(state_data, separators=(',', ':'))
            # Store in KV bucket with key "current_state"
            await self.kv.put("current_state", state_json.encode())
        except Exception as e:
            log.error(f"Failed to update KV state: {e}", exc_info=True)
            # Don't fail execution on KV errors
    
    async def update_current_sequence(self, sequence_id: Optional[str]):
        """Update current_sequence in KV store."""
        if not self.kv:
            return
        
        try:
            state = await self.load_state()
            state["current_sequence"] = sequence_id
            if sequence_id is None:
                state["current_step_index"] = -1
                state["sequence_state"] = "IDLE"
            else:
                # Always reset sequence_state to RUNNING when starting a new sequence
                # This ensures proper state transition even if previous state was STOPPED or ERROR
                # Also reset current_step_index to -1 so _start_sequence can set it to 0
                state["current_step_index"] = -1
                state["sequence_state"] = "RUNNING"
            state["last_updated"] = _iso_now()
            await self.save_state(state)
            log.info(f"[KV_STORE] Updated current_sequence: {sequence_id}")
        except Exception as e:
            log.error(f"Failed to update current_sequence: {e}", exc_info=True)
    
    async def load_state(self) -> Dict[str, Any]:
        """Load full state from KV store."""
        if not self.kv:
            return self._default_state()
        
        try:
            entry = await self.kv.get("current_state")
            if entry:
                return json.loads(entry.value.decode())
        except Exception as e:
            log.debug(f"No state in KV store: {e}")
        
        return self._default_state()
    
    async def save_state(self, state: Dict[str, Any]):
        """Save full state to KV store."""
        if not self.kv:
            return
        
        try:
            state["last_updated"] = _iso_now()
            state_json = json.dumps(state, separators=(',', ':'))
            await self.kv.put("current_state", state_json.encode())
        except Exception as e:
            log.error(f"Failed to save state: {e}", exc_info=True)
    
    async def update_timestamp(self):
        """Update last_updated timestamp in KV store."""
        if not self.kv:
            return
        
        try:
            state = await self.load_state()
            state["last_updated"] = _iso_now()
            await self.save_state(state)
        except Exception as e:
            log.error(f"Failed to update timestamp: {e}", exc_info=True)
    
    def _default_state(self) -> Dict[str, Any]:
        """Return default state structure."""
        return {
            "current_sequence": None,
            "current_step_index": -1,
            "sequence_state": "IDLE",
            "motor_state": {
                "engine_state": "ENGINE_OFF",
                "permission_active": False,
                "starter_active": False
            },
            "last_updated": _iso_now(),
            "current_step": None
        }
    
    async def get_sequence(self, sequence_id: str) -> Optional[List[Dict]]:
        """Get sequence from KV store by sequence_id."""
        if not self.kv:
            return None
        
        try:
            # Read from KV bucket with key f"sequence_{sequence_id}" (no colon allowed)
            entry = await self.kv.get(f"sequence_{sequence_id}")
            if entry:
                # Deserialize JSON to list of steps
                return json.loads(entry.value.decode())
        except Exception as e:
            log.debug(f"Sequence '{sequence_id}' not found in KV store: {e}")
        
        return None
    
    async def store_sequence(self, sequence_id: str, steps: List[Dict[str, Any]]):
        """Store sequence in KV store."""
        if not self.kv:
            log.warning("KV store not initialized, skipping sequence storage")
            return
        
        try:
            # Serialize steps to JSON
            steps_json = json.dumps(steps, separators=(',', ':'))
            # Store in KV bucket with key f"sequence_{sequence_id}" (no colon allowed)
            await self.kv.put(f"sequence_{sequence_id}", steps_json.encode())
            log.info(f"Stored sequence '{sequence_id}' in KV store ({len(steps)} steps)")
        except Exception as e:
            log.error(f"Failed to store sequence '{sequence_id}' in KV store: {e}", exc_info=True)

