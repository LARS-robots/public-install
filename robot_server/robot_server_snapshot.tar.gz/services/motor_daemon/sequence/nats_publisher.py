#!/usr/bin/env python3
"""
NATS publisher for motor sequences.
Centralized functions for publishing commands to NATS.
"""
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


def _iso_now() -> str:
    """Return ISO8601 UTC timestamp with millisecond precision."""
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


async def publish_command(nc: Optional[NATS], subject: str, cmd: str, args: Dict[str, Any]) -> bool:
    """
    Publish command to NATS.
    
    Args:
        nc: NATS client
        subject: NATS subject (e.g., "motors.move", "motors.relay")
        cmd: Command name (e.g., "move", "relay")
        args: Command arguments
        
    Returns:
        True if published successfully, False otherwise
    """
    if not nc:
        return False
    try:
        message = {"cmd": cmd, "args": args, "timestamp": _iso_now()}
        await nc.publish(subject, json.dumps(message, separators=(',', ':')).encode())
        return True
    except Exception as e:
        log.error(f"Failed to publish to {subject}: {e}")
        return False


async def publish_stop_commands(nc: Optional[NATS]) -> bool:
    """
    Publish stop commands to NATS (stop, zero movement, relay stop).
    
    Args:
        nc: NATS client
        
    Returns:
        True if all commands published successfully, False otherwise
    """
    if not nc:
        return False
    
    try:
        timestamp = _iso_now()
        
        # Publish stop command
        await publish_command(nc, "motors.stop", "stop", {})
        
        # Publish zero movement
        await publish_command(nc, "motors.move", "move", {
            "speed": 0,
            "forward": 0,
            "turn": 0
        })
        
        # Publish relay stop
        await publish_command(nc, "motors.relay", "relay", {
            "relay_name": "stop",
            "relay_on": False
        })
        
        log.info("[NATS_PUBLISHER] Published stop commands to NATS")
        return True
    except Exception as e:
        log.error(f"Error publishing stop commands: {e}")
        return False

