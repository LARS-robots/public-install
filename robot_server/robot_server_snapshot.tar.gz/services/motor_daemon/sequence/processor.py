#!/usr/bin/env python3
"""
Sequence processor for motor daemon.
Handles motors.start_sequence NATS messages and manages sequence execution.
"""
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import nats
from nats.aio.client import Client as NATS

from .kv_store import SequenceKVStore
from .state_machine import MotorStateMachine
from .builder import get_default_startup_sequence, build_sequence_by_id
from .config import SequenceConfig
from .nats_publisher import publish_stop_commands

log = logging.getLogger(__name__)


class SequenceProcessor:
    """Optional sequence processor for handling motors.start_sequence commands."""
    
    def __init__(self, nc: NATS, config: Dict[str, Any]):
        self.nc = nc
        self.config = config
        self.kv_store: Optional[SequenceKVStore] = None
        self.state_machine: Optional[MotorStateMachine] = None
        self.sequence_subscription = None
        self.enabled = False
    
    def _is_enabled(self) -> bool:
        """Check if sequence processor should be enabled."""
        # Check environment variable first
        env_enabled = os.getenv("ENABLE_SEQUENCE_PROCESSOR", "").lower()
        if env_enabled in ("true", "1", "yes"):
            return True
        if env_enabled in ("false", "0", "no"):
            return False
        
        # Check config
        return self.config.get("diktum_test", {}).get("enable_sequence_processor", False)
    
    async def initialize(self):
        """Initialize sequence processor if enabled."""
        if not self._is_enabled():
            log.info("Sequence processor disabled (set ENABLE_SEQUENCE_PROCESSOR=true to enable)")
            return
        
        try:
            # Initialize KV store
            self.kv_store = SequenceKVStore(self.nc)
            await self.kv_store.initialize()
            
            # Reset engine state on startup (engine is always OFF after reboot)
            state = await self.kv_store.load_state()
            motor_state = state.get("motor_state", {})
            motor_state["engine_state"] = "ENGINE_OFF"
            motor_state["permission_active"] = False
            motor_state["starter_active"] = False
            state["motor_state"] = motor_state
            await self.kv_store.save_state(state)
            log.info("[SEQUENCE_PROCESSOR] Reset engine state to ENGINE_OFF on startup")
            
            # Subscribe to motors.start_sequence
            self.sequence_subscription = await self.nc.subscribe(
                "motors.start_sequence",
                cb=self._on_start_sequence_msg
            )
            log.info("Subscribed to motors.start_sequence")
            
            # Store default sequences in KV
            await self.kv_store.store_sequence("startup", get_default_startup_sequence())
            
            # Create and start state machine
            sequences = {"startup": get_default_startup_sequence()}
            self.state_machine = MotorStateMachine(self.kv_store, self.nc, sequences)
            await self.state_machine.start()
            
            self.enabled = True
            log.info("Sequence processor initialized and started")
            
        except Exception as e:
            log.error(f"Failed to initialize sequence processor: {e}", exc_info=True)
    
    async def _on_start_sequence_msg(self, msg):
        """Handle motors.start_sequence NATS messages."""
        if not self.kv_store:
            return
        
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            sequence_id = args.get("sequence_id")
            
            if not sequence_id:
                log.warning("[SEQUENCE_PROCESSOR] Missing sequence_id in start_sequence command")
                return
            
            log.info(f"[SEQUENCE_PROCESSOR] Received start_sequence: {sequence_id}")
            
            # Handle stop command as special case (not a sequence)
            if sequence_id == "stop":
                log.info("[SEQUENCE_PROCESSOR] Stop command received, clearing current sequence")
                state = await self.kv_store.load_state()
                motor_state = state.get("motor_state", {})
                # Force reset engine state to ENGINE_OFF and clear all relay states
                motor_state["engine_state"] = "ENGINE_OFF"
                motor_state["permission_active"] = False
                motor_state["starter_active"] = False
                state["motor_state"] = motor_state
                # Clear pending sequence to prevent it from starting after startup is interrupted
                state["pending_sequence"] = None
                await self.kv_store.save_state(state)
                log.info("[SEQUENCE_PROCESSOR] Reset engine state to ENGINE_OFF on STOP command")
                
                # Publish stop commands immediately to stop motors
                await publish_stop_commands(self.nc)
                
                # Clear sequence immediately instead of setting to "stop"
                await self.kv_store.update_current_sequence(None)
                return
            
            # Always rebuild and store sequence to ensure latest version
            log.info(f"[SEQUENCE_PROCESSOR] Building sequence '{sequence_id}'...")
            
            # Create config helper to build sequence
            config = SequenceConfig()
            
            # Build sequence (always rebuild to get latest version)
            steps = build_sequence_by_id(sequence_id, config)
            
            if not steps:
                log.error(f"[SEQUENCE_PROCESSOR] Failed to build sequence '{sequence_id}'")
                return
            
            # Store sequence in KV store (overwrite existing)
            await self.kv_store.store_sequence(sequence_id, steps)
            log.info(f"[SEQUENCE_PROCESSOR] Stored sequence '{sequence_id}' ({len(steps)} steps)")
            
            # Check engine state and set pending sequence if needed
            state = await self.kv_store.load_state()
            motor_state = state.get("motor_state", {})
            engine_state = motor_state.get("engine_state", "ENGINE_OFF")
            current_sequence = state.get("current_sequence")
            
            log.info(f"[SEQUENCE_PROCESSOR] Engine state: {engine_state}, current_sequence: {current_sequence}")
            
            # If engine not ready and no sequence running, start startup first
            if engine_state != "ENGINE_READY" and not current_sequence:
                log.info(f"[SEQUENCE_PROCESSOR] Engine not ready ({engine_state}), will start startup sequence first")
                state["pending_sequence"] = sequence_id
                # Reset relay states to ensure startup sequence runs completely
                motor_state["permission_active"] = False
                motor_state["starter_active"] = False
                motor_state["engine_state"] = "ENGINE_OFF"
                state["motor_state"] = motor_state
                await self.kv_store.save_state(state)
                # Start startup sequence
                await self.kv_store.update_current_sequence("startup")
            else:
                # Update current_sequence in KV store
                await self.kv_store.update_current_sequence(sequence_id)
            
        except Exception as e:
            log.error(f"Error handling start_sequence: {e}", exc_info=True)
    
    async def shutdown(self):
        """Shutdown sequence processor."""
        if not self.enabled:
            return
        
        try:
            if self.state_machine:
                await self.state_machine.stop()
            log.info("Sequence processor stopped")
        except Exception as e:
            log.error(f"Error shutting down sequence processor: {e}")

