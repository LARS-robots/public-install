#!/usr/bin/env python3
"""
Sequence builder for motor daemon.
Functions for building motor sequences (startup, forward, turn_180).
"""
import logging
from typing import Dict, Any, List, Optional

from .config import SequenceConfig

log = logging.getLogger(__name__)


def _make_relay_step(name: str, relay_name: str, relay_on: bool, description: str) -> Dict[str, Any]:
    """Create a relay step."""
    return {
        "name": name,
        "cmd": "relay",
        "args": {"relay_name": relay_name, "relay_on": relay_on},
        "description": description,
    }


def _make_move_step(name: str, duration: float, speed: int, forward: int, turn: int, description: str) -> Dict[str, Any]:
    """Create a move_loop step."""
    return {
        "name": name,
        "cmd": "move_loop",
        "duration": duration,
        "args": {"speed": speed, "forward": forward, "turn": turn, "description": description},
        "description": description,
    }


def get_default_startup_sequence() -> List[Dict[str, Any]]:
    """Return default startup sequence steps."""
    return [
        _make_relay_step("permission_on", "permission", True, "Enable permission relay"),
        _make_move_step("permission_idle", 2.0, 0, 0, 0, "Idle (permission ON)"),
        _make_relay_step("starter_on", "starter", True, "Enable starter relay"),
        _make_move_step("starter_idle", 3.5, 0, 0, 0, "Idle (starter ON)"),
        _make_relay_step("starter_off", "starter", False, "Disable starter relay"),
        _make_move_step("post_starter_idle", 2.0, 0, 0, 0, "Idle (after starter)"),
    ]


def build_forward_backward_sequence(config: SequenceConfig) -> List[Dict[str, Any]]:
    """Build forward movement sequence using speed from config."""
    speed_mps = config.get_test_speed_mps()
    diktum_speed = config.get_diktum_speed()  # Fixed speed value
    diktum_forward = config.convert_mps_to_diktum_forward(speed_mps)
    desc_forward = f"Forward at {speed_mps} m/s"
    
    return [
        _make_move_step("forward_motion", 5.0, diktum_speed, diktum_forward, 0, desc_forward),
        _make_move_step("forward_stop", 1.0, 0, 0, 0, "Stabilize after forward"),
    ]


def build_turn_180_sequence(config: SequenceConfig) -> List[Dict[str, Any]]:
    """Build 180° clockwise turn sequence using speed from config."""
    speed_mps = config.get_test_speed_mps()
    diktum_speed = config.get_diktum_speed()  # Fixed speed value
    diktum_turn = config.convert_mps_to_diktum_turn(speed_mps)
    desc_turn = f"Clockwise turn at {speed_mps} m/s"
    
    return [
        _make_move_step("turn_clockwise", 5.0, diktum_speed, 0, diktum_turn, desc_turn),
        _make_move_step("turn_stop", 2.0, 0, 0, 0, "Stabilize after turn"),
    ]


def build_sequence_by_id(sequence_id: str, config: SequenceConfig) -> Optional[List[Dict[str, Any]]]:
    """Build sequence by ID using config."""
    if sequence_id == "forward_backward":
        return build_forward_backward_sequence(config)
    elif sequence_id == "turn_180":
        return build_turn_180_sequence(config)
    elif sequence_id == "startup":
        return get_default_startup_sequence()
    else:
        log.warning(f"Unknown sequence_id: {sequence_id}")
        return None

