#!/usr/bin/env python3
"""
Sequence configuration for motor daemon.
Handles configuration loading and speed conversion for sequences.
"""
import logging
from typing import Any, Dict

from config_loader import get_config

log = logging.getLogger(__name__)


class SequenceConfig:
    """Configuration helper for sequence building."""
    
    def __init__(self):
        self.config: Dict[str, Any] = {}
        self._load_config()
    
    def _load_config(self):
        """Load configuration from config.toml."""
        try:
            app_config = get_config()
            self.config = app_config.raw_data
            log.info(f"Loaded config from: {app_config.config_path}")
        except Exception as e:
            log.warning(f"Failed to load config: {e}, using defaults")
            self.config = {}
    
    def get_config_value(self, key: str, default: Any) -> Any:
        """Get value from diktum_test config section."""
        return self.config.get("diktum_test", {}).get(key, default)
    
    def get_test_speed_mps(self) -> float:
        """Get test speed in m/s from config."""
        return float(self.get_config_value("diktum_test_speed_mps", 1.0))
    
    def get_diktum_speed(self) -> int:
        """Get fixed Diktum speed value from config (always 1000 by default)."""
        speed = int(self.get_config_value("diktum_rpm", 1000))
        return max(0, min(2000, speed))
    
    def convert_mps_to_diktum_forward(self, speed_mps: float) -> int:
        """Convert forward speed from m/s to Diktum forward units."""
        constant = float(self.get_config_value("diktum_forward_conversion_constant", 1000.0))
        diktum_forward = int(speed_mps * constant)
        diktum_forward = max(0, min(2000, diktum_forward))
        if diktum_forward <= 280:
            diktum_forward = 0
        return diktum_forward
    
    def convert_mps_to_diktum_turn(self, speed_mps: float) -> int:
        """Convert turn speed from m/s to Diktum turn units."""
        constant = float(self.get_config_value("diktum_turn_conversion_constant", 1000.0))
        diktum_turn = int(speed_mps * constant)
        diktum_turn = max(0, min(2000, diktum_turn))
        if diktum_turn <= 280:
            diktum_turn = 0
        return diktum_turn

    def get_test_duration_forward_s(self) -> float:
        """Get forward movement duration in seconds."""
        return float(self.get_config_value("diktum_test_duration_forward_s", 5.0))

    def get_test_duration_turn_s(self) -> float:
        """Get turn movement duration in seconds."""
        return float(self.get_config_value("diktum_test_duration_turn_s", 5.0))

