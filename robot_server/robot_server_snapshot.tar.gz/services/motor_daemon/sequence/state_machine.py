#!/usr/bin/env python3
"""
State machine for motor sequences.
Processes motor sequences from KV store and executes them step by step.
"""
import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import nats
from nats.aio.client import Client as NATS

from .kv_store import SequenceKVStore, _iso_now
from .nats_publisher import publish_command, publish_stop_commands

log = logging.getLogger(__name__)


class MotorStateMachine:
    """State machine for processing motor sequences from KV store."""
    
    def __init__(self, kv_store: SequenceKVStore, nats_client: Optional[NATS], sequences: Dict[str, List[Dict[str, Any]]]):
        self.kv = kv_store
        self.nc = nats_client
        self.sequences = sequences
        self.running = False
        self._task: Optional[asyncio.Task] = None
    
    async def start(self):
        """Start the state machine loop."""
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._process_loop())
        log.info("[STATE_MACHINE] Started")
    
    async def stop(self):
        """Stop the state machine loop."""
        self.running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("[STATE_MACHINE] Stopped")
    
    async def _process_loop(self):
        """Main state machine processing loop (100Hz)."""
        while self.running:
            try:
                # Load state from KV
                state = await self.kv.load_state()
                
                # Determine next action
                action = self._determine_action(state)
                
                # Execute action
                if action:
                    await self._execute_action(action, state)
                    # Save updated state
                    new_state = await self._get_current_state(state)
                    await self.kv.save_state(new_state)
                
            except Exception as e:
                log.error(f"[STATE_MACHINE] Error in process loop: {e}", exc_info=True)
            
            await asyncio.sleep(0.01)  # 100Hz
    
    async def _load_sequence_from_kv(self, sequence_id: str) -> Optional[List[Dict[str, Any]]]:
        """Load sequence from KV store or use cached."""
        # Check cache first
        if sequence_id in self.sequences and self.sequences[sequence_id]:
            return self.sequences[sequence_id]
        
        # Try to load from KV store
        sequence = await self.kv.get_sequence(sequence_id)
        if sequence:
            self.sequences[sequence_id] = sequence
            return sequence
        
        # If not found, log warning
        if sequence_id not in self.sequences:
            log.warning(f"[STATE_MACHINE] Sequence '{sequence_id}' not found in KV store or cache")
        
        return None
    
    def _determine_action(self, state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Determine next action based on current state."""
        current_sequence = state.get("current_sequence")
        sequence_state = state.get("sequence_state", "IDLE")
        step_index = state.get("current_step_index", -1)
        
        # Handle stop command (for backward compatibility with stop_sequence methods)
        if current_sequence == "stop":
            return {"action": "stop"}
        
        # No sequence active
        if not current_sequence or sequence_state == "IDLE":
            return None
        
        # Sequence completed or stopped
        if sequence_state in {"COMPLETED", "STOPPED", "ERROR"}:
            return None
        
        # Get sequence steps (will be loaded async in execute_action)
        # Return action to load sequence and process it
        return {"action": "get_sequence", "sequence_id": current_sequence, "step_index": step_index}
    
    async def _execute_action(self, action: Dict[str, Any], state: Dict[str, Any]):
        """Execute determined action."""
        action_type = action["action"]
        
        if action_type == "stop":
            await self._handle_stop(state)
        elif action_type == "get_sequence":
            sequence_id = action["sequence_id"]
            step_index = action["step_index"]
            
            # Check if we need to run startup sequence first
            if step_index < 0 and sequence_id not in ("startup", "stop"):
                motor_state = state.get("motor_state", {})
                engine_state = motor_state.get("engine_state", "ENGINE_OFF")
                
                if engine_state != "ENGINE_READY":
                    log.info(f"[STATE_MACHINE] Engine not ready ({engine_state}), starting startup sequence first")
                    # Check if startup sequence exists
                    startup_seq = await self._load_sequence_from_kv("startup")
                    if startup_seq:
                        # Start startup sequence first
                        state["current_sequence"] = "startup"
                        state["current_step_index"] = -1
                        state["sequence_state"] = "RUNNING"
                        await self._start_sequence("startup", state)
                        return
                    else:
                        log.warning("[STATE_MACHINE] Startup sequence not found, proceeding with requested sequence")
            
            sequence = await self._load_sequence_from_kv(sequence_id)
            if not sequence:
                log.warning(f"[STATE_MACHINE] Sequence '{sequence_id}' not found")
                state["sequence_state"] = "ERROR"
                return
            
            if step_index < 0:
                await self._start_sequence(sequence_id, state)
            elif step_index >= len(sequence):
                await self._complete_sequence(sequence_id, state)
            else:
                current_step_data = state.get("current_step") or {}
                step_status = current_step_data.get("status")
                if step_status != "completed":
                    await self._execute_step(sequence[step_index], step_index, state)
                else:
                    await self._move_to_next_step(step_index + 1, state)
        elif action_type == "start_sequence":
            await self._start_sequence(action["sequence_id"], state)
        elif action_type == "execute_step":
            await self._execute_step(action["step"], action["step_index"], state)
        elif action_type == "next_step":
            await self._move_to_next_step(action["step_index"], state)
        elif action_type == "complete_sequence":
            await self._complete_sequence(action["sequence_id"], state)
    
    async def _handle_stop(self, state: Dict[str, Any]):
        """Handle stop command."""
        log.info("[STATE_CHANGE] Handling stop command")
        # Publish stop commands to stop movement immediately
        await publish_stop_commands(self.nc)
        
        # Update motor state to reflect engine is turned off
        motor_state = state.get("motor_state", {})
        motor_state["permission_active"] = False
        motor_state["starter_active"] = False
        motor_state["engine_state"] = "ENGINE_OFF"
        state["motor_state"] = motor_state
        
        # Clear sequence in state immediately to prevent re-processing
        state["current_sequence"] = None
        state["sequence_state"] = "IDLE"
        state["current_step_index"] = -1
        state["current_step"] = None
        # Also update KV store
        await self.kv.update_current_sequence(None)
    
    async def _start_sequence(self, sequence_id: str, state: Dict[str, Any]):
        """Start a new sequence."""
        log.info(f"[STATE_CHANGE] Starting sequence: {sequence_id}")
        state["current_step_index"] = 0
        state["sequence_state"] = "RUNNING"
        state["current_step"] = None
    
    async def _execute_step(self, step: Dict[str, Any], step_index: int, state: Dict[str, Any]):
        """Execute a single step."""
        step_name = step.get("name", f"step_{step_index}")
        cmd = step.get("cmd")
        args = step.get("args", {})
        
        # Update current step in state
        state["current_step"] = {
            "name": step_name,
            "cmd": cmd,
            "args": args,
            "started_at": _iso_now(),
            "status": "executing"
        }
        
        log.info(f"[STATE_MACHINE] Executing step '{step_name}': {cmd}")
        
        try:
            if cmd == "relay":
                relay_name = args.get("relay_name")
                relay_on = args.get("relay_on", True)
                await publish_command(self.nc, "motors.relay", "relay", {"relay_name": relay_name, "relay_on": relay_on})
                
                # Add small delay after relay commands to ensure hardware processes the command
                # This is especially important after stop command, as hardware needs time to reset
                # The delay is minimal (100ms) and only between sequence steps, not during move_loop
                await asyncio.sleep(0.8)
                
                # Update motor state
                motor_state = state.get("motor_state", {})
                if relay_name == "permission":
                    motor_state["permission_active"] = relay_on
                elif relay_name == "starter":
                    motor_state["starter_active"] = relay_on
                elif relay_name == "stop":
                    motor_state["permission_active"] = False
                    motor_state["starter_active"] = False
                
                # Update engine state
                if motor_state.get("permission_active") and motor_state.get("starter_active"):
                    motor_state["engine_state"] = "ENGINE_STARTING"
                elif motor_state.get("permission_active"):
                    motor_state["engine_state"] = "ENGINE_READY"
                else:
                    motor_state["engine_state"] = "ENGINE_OFF"
                
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
                
            elif cmd == "move_loop":
                duration = step.get("duration", 0.0)
                speed = args.get("speed", 0)
                forward = args.get("forward", 0)
                turn = args.get("turn", 0)
                
                # Update engine state to RUNNING if permission is active
                motor_state = state.get("motor_state", {})
                if motor_state.get("permission_active"):
                    motor_state["engine_state"] = "ENGINE_RUNNING"
                
                # Send move commands in loop
                start_time = time.time()
                frame_count = 0
                interrupted = False
                while self.running and (time.time() - start_time) < duration:
                    # Check if sequence was stopped - reload state from KV store to get latest
                    current_state = await self.kv.load_state()
                    current_seq = current_state.get("current_sequence")
                    seq_state = current_state.get("sequence_state", "IDLE")
                    if current_seq is None or current_seq == "stop" or seq_state in {"STOPPED", "IDLE"}:
                        log.info(f"[STATE_MACHINE] {step_name} interrupted by stop command")
                        # Update local state to reflect stop
                        state["current_sequence"] = None
                        state["sequence_state"] = "IDLE"
                        # Reload motor_state from current_state to get actual permission status
                        motor_state = current_state.get("motor_state", {})
                        interrupted = True
                        break
                    
                    await publish_command(self.nc, "motors.move", "move", {
                        "speed": speed,
                        "forward": forward,
                        "turn": turn
                    })
                    frame_count += 1
                    if frame_count % 10 == 0:
                        log.debug(f"[STATE_MACHINE] {step_name} (frame {frame_count})")
                    await asyncio.sleep(0.072)  # 72ms interval
                
                # Reset engine state after movement
                # Only update if not interrupted (if interrupted, motor_state already updated from KV store)
                if not interrupted and motor_state.get("permission_active"):
                    motor_state["engine_state"] = "ENGINE_READY"
                
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
            else:
                log.warning(f"[STATE_MACHINE] Unknown command type: {cmd}")
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
                
        except Exception as e:
            log.error(f"[STATE_MACHINE] Error executing step '{step_name}': {e}", exc_info=True)
            state["current_step"]["status"] = "failed"
            state["current_step"]["error"] = str(e)
            state["sequence_state"] = "ERROR"
    
    async def _move_to_next_step(self, step_index: int, state: Dict[str, Any]):
        """Move to next step in sequence."""
        current_sequence = state.get("current_sequence")
        sequence = await self._load_sequence_from_kv(current_sequence)
        
        if not sequence:
            return
        
        if step_index >= len(sequence):
            await self._complete_sequence(current_sequence, state)
        else:
            state["current_step_index"] = step_index
            state["current_step"] = None
            log.debug(f"[STATE_MACHINE] Moved to step {step_index}")
    
    async def _complete_sequence(self, sequence_id: str, state: Dict[str, Any]):
        """Complete current sequence."""
        log.info(f"[STATE_CHANGE] Sequence completed: {sequence_id}")
        
        # Check if sequence was actually stopped (current_sequence is None or IDLE)
        # If so, don't process pending sequence
        current_seq = state.get("current_sequence")
        seq_state = state.get("sequence_state", "IDLE")
        if current_seq is None or seq_state == "IDLE":
            log.info(f"[STATE_CHANGE] Sequence '{sequence_id}' was interrupted, not completing normally")
            state["sequence_state"] = "IDLE"
            state["current_sequence"] = None
            state["current_step_index"] = -1
            state["current_step"] = None
            # Clear pending sequence if sequence was interrupted
            state["pending_sequence"] = None
            return
        
        # If startup sequence completed, check if there's a pending sequence
        if sequence_id == "startup":
            # Check if there was a pending sequence before startup
            pending_sequence = state.get("pending_sequence")
            if pending_sequence:
                log.info(f"[STATE_CHANGE] Startup completed, starting pending sequence: {pending_sequence}")
                state["current_sequence"] = pending_sequence
                state["pending_sequence"] = None
                state["current_step_index"] = -1
                state["sequence_state"] = "RUNNING"
                state["current_step"] = None
                return
        
        state["sequence_state"] = "COMPLETED"
        state["current_sequence"] = None
        state["current_step_index"] = -1
        state["current_step"] = None
        
        # Reset engine state if permission is off
        motor_state = state.get("motor_state", {})
        if not motor_state.get("permission_active"):
            motor_state["engine_state"] = "ENGINE_OFF"
    
    async def _get_current_state(self, current_state: Dict[str, Any]) -> Dict[str, Any]:
        """Get current state for saving."""
        return current_state

