#!/usr/bin/env python3
"""
State machine for motor sequences.
Processes motor sequences from KV store and executes them step by step.
"""
import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .kv_store import SequenceKVStore, _iso_now

log = logging.getLogger(__name__)


class MotorStateMachine:
    """State machine for processing motor sequences from KV store."""
    
    def __init__(self, kv_store: SequenceKVStore, controller: Any, sequences: Dict[str, List[Dict[str, Any]]]):
        self.kv = kv_store
        self.controller = controller  # MotorDaemon instance
        self.sequences = sequences
        self.running = False
        self._task: Optional[asyncio.Task] = None
        self._processing = False  # Flag to prevent overlapping process() calls
    
    async def start(self):
        """Initialize state machine (event-driven, no polling loop)."""
        if self.running:
            return
        self.running = True
        log.info("[STATE_MACHINE] Started (event-driven mode)")
    
    async def stop(self):
        """Stop the state machine."""
        self.running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("[STATE_MACHINE] Stopped")

    async def process(self):
        """
        Process current state - called externally when state changes.
        Event-driven approach: no polling, only process when needed.
        """
        if not self.running:
            return
        
        # Prevent overlapping process() calls
        if self._processing:
            log.debug("[STATE_MACHINE] process() already in progress, skipping")
            return
        
        self._processing = True
        try:
            # Load state from KV
            state = await self.kv.load_state()
            
            # Determine next action
            action = self._determine_action(state)
            
            # Execute action
            if action:
                await self._execute_action(action, state)
                
        except Exception as e:
            log.error(f"[STATE_MACHINE] Error in process: {e}", exc_info=True)
        finally:
            self._processing = False

    async def _continue_processing(self):
        """Continue processing sequence after step completion."""
        state = await self.kv.load_state()
        current_sequence = state.get("current_sequence")
        sequence_state = state.get("sequence_state", "IDLE")
        step_index = state.get("current_step_index", -1)
        
        # Only continue if sequence is still active
        if not current_sequence or current_sequence == "stop" or sequence_state != "RUNNING":
            return
        
        # Check if current step is completed and we need to move forward
        current_step_data = state.get("current_step") or {}
        step_status = current_step_data.get("status")
        
        if step_status == "completed" and step_index >= 0:
            # Move to next step
            sequence = await self._load_sequence_from_kv(current_sequence)
            if sequence and step_index + 1 < len(sequence):
                # Advance to next step directly (avoid recursive process() call)
                await self._move_to_next_step(step_index + 1, state)
                # Save state after moving to next step
                await self.kv.save_state(state)
                # Execute the next step directly
                await self._execute_step(sequence[step_index + 1], step_index + 1, state)
            elif sequence and step_index + 1 >= len(sequence):
                # Sequence completed
                await self._complete_sequence(current_sequence, state)
                await self.kv.save_state(state)
        elif step_status != "completed" and step_index >= 0:
            # Step is executing, will continue when it completes
            pass

    async def _load_sequence_from_kv(self, sequence_id: str) -> Optional[List[Dict[str, Any]]]:
        """Load sequence from KV store or use cached."""
        # Check cache first
        if sequence_id in self.sequences and self.sequences[sequence_id]:
            return self.sequences[sequence_id]
        
        # Try to load from KV store
        sequence = await self.kv.get_sequence(sequence_id)
        if sequence:
            self.sequences[sequence_id] = sequence
            return sequence
        
        # If not found, log warning
        if sequence_id not in self.sequences:
            log.warning(f"[STATE_MACHINE] Sequence '{sequence_id}' not found in KV store or cache")
        
        return None
    
    def _determine_action(self, state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Determine next action based on current state."""
        current_sequence = state.get("current_sequence")
        sequence_state = state.get("sequence_state", "IDLE")
        step_index = state.get("current_step_index", -1)
        
        # Handle stop command (for backward compatibility with stop_sequence methods)
        if current_sequence == "stop":
            return {"action": "stop"}
        
        # No sequence active
        if not current_sequence or sequence_state == "IDLE":
            return None
        
        # Sequence completed or stopped
        if sequence_state in {"COMPLETED", "STOPPED", "ERROR"}:
            return None
        
        # Get sequence steps (will be loaded async in execute_action)
        # Return action to load sequence and process it
        return {"action": "get_sequence", "sequence_id": current_sequence, "step_index": step_index}
    
    async def _execute_action(self, action: Dict[str, Any], state: Dict[str, Any]):
        """Execute determined action."""
        action_type = action["action"]
        
        if action_type == "stop":
            await self._handle_stop(state)
        elif action_type == "get_sequence":
            sequence_id = action["sequence_id"]
            step_index = action["step_index"]
            
            sequence = await self._load_sequence_from_kv(sequence_id)
            if not sequence:
                log.warning(f"[STATE_MACHINE] Sequence '{sequence_id}' not found")
                state["sequence_state"] = "ERROR"
                return
            
            if step_index < 0:
                await self._start_sequence(sequence_id, state)
                # After starting sequence, execute first step (index 0)
                if len(sequence) > 0:
                    await self._execute_step(sequence[0], 0, state)
            elif step_index >= len(sequence):
                await self._complete_sequence(sequence_id, state)
            else:
                current_step_data = state.get("current_step") or {}
                step_status = current_step_data.get("status")
                if step_status != "completed":
                    await self._execute_step(sequence[step_index], step_index, state)
                else:
                    await self._move_to_next_step(step_index + 1, state)
        elif action_type == "start_sequence":
            await self._start_sequence(action["sequence_id"], state)
        elif action_type == "execute_step":
            await self._execute_step(action["step"], action["step_index"], state)
        elif action_type == "next_step":
            await self._move_to_next_step(action["step_index"], state)
        elif action_type == "complete_sequence":
            await self._complete_sequence(action["sequence_id"], state)
    
    async def _handle_stop(self, state: Dict[str, Any]):
        """Handle stop command - SINGLE source of truth for state reset."""
        log.info("[STATE_CHANGE] Handling stop command")
        
        # Controller executes stop (hardware stop)
        await self.controller.exec_stop()
        
        # Reset all state in one operation
        motor_state = state.get("motor_state", {})
        motor_state["permission_active"] = False
        motor_state["starter_active"] = False
        motor_state["engine_state"] = "ENGINE_OFF"
        state["motor_state"] = motor_state
        
        state["current_sequence"] = None
        state["sequence_state"] = "IDLE"
        state["current_step_index"] = -1
        state["current_step"] = None
        state["pending_sequence"] = None
        
        # Save to KV store
        await self.kv.save_state(state)
        await self.kv.update_current_sequence(None)
    
    async def _start_sequence(self, sequence_id: str, state: Dict[str, Any]):
        """Start a new sequence."""
        log.info(f"[STATE_CHANGE] Starting sequence: {sequence_id}")
        state["current_step_index"] = 0
        state["sequence_state"] = "RUNNING"
        state["current_step"] = None
        # Ensure initial running state is saved
        await self.kv.save_state(state)
    
    async def _execute_step(self, step: Dict[str, Any], step_index: int, state: Dict[str, Any]):
        """Execute a single step."""
        step_name = step.get("name", f"step_{step_index}")
        cmd = step.get("cmd")
        args = step.get("args", {})
        
        # Check if stop was requested before executing step
        current_state = await self.kv.load_state()
        if current_state.get("current_sequence") == "stop":
            log.info(f"[STATE_MACHINE] Step '{step_name}' cancelled - stop command received")
            return
        
        # Guard: Skip if this step is already completed
        kv_step = current_state.get("current_step") or {}
        kv_idx = current_state.get("current_step_index", -1)
        if kv_idx == step_index and kv_step.get("status") == "completed":
            log.debug(f"[STATE_MACHINE] Step '{step_name}' already completed, skipping")
            return
        
        # Update current step in state
        state["current_step"] = {
            "name": step_name,
            "cmd": cmd,
            "args": args,
            "started_at": _iso_now(),
            "status": "executing"
        }
        
        log.info(f"[STATE_MACHINE] Executing step '{step_name}': {cmd}")
        
        try:
            if cmd == "relay":
                relay_name = args.get("relay_name")
                relay_on = args.get("relay_on", True)
                
                # Use controller to execute relay
                await self.controller.exec_relay(relay_name, relay_on, from_sequence=True)
                
                # STOP after sleep to prevent overwriting stop state
                current_state_after_sleep = await self.kv.load_state()
                
                # Refresh state to get latest motor_state (updated by controller)
                state["motor_state"] = current_state_after_sleep.get("motor_state", {})
                
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
                
                # Save state and continue to next step
                await self.kv.save_state(state)
                # Continue processing next step sequentially
                await self._continue_processing()
                
            elif cmd == "move_loop":
                duration = step.get("duration", 0.0)
                speed = args.get("speed", 0)
                forward = args.get("forward", 0)
                turn = args.get("turn", 0)
                
                log.info(f"[STATE_MACHINE] START move_loop '{step_name}': duration={duration}s, speed={speed}, forward={forward}, turn={turn}")
                
                # Send move commands in loop
                start_time = time.time()
                frame_count = 0
                interrupted = False
                while self.running and (time.time() - start_time) < duration:
                    # Check if sequence was stopped
                    current_state = await self.kv.load_state()
                    current_seq = current_state.get("current_sequence")
                    seq_state = current_state.get("sequence_state", "IDLE")
                    if current_seq is None or current_seq == "stop" or seq_state in {"STOPPED", "IDLE"}:
                        log.info(f"[STATE_MACHINE] {step_name} interrupted by stop command")
                        # Do not save state here, as it might overwrite stop state.
                        # Just exit.
                        interrupted = True
                        break
                    
                    # Execute move via controller
                    await self.controller.exec_move(speed, forward, turn)
                    
                    frame_count += 1
                    if frame_count % 10 == 0:
                        log.debug(f"[STATE_MACHINE] {step_name} (frame {frame_count})")
                    await asyncio.sleep(0.072)  # 72ms interval
                
                elapsed = time.time() - start_time
                log.info(f"[STATE_MACHINE] FINISH move_loop '{step_name}': actual_duration={elapsed:.3f}s")
                
                if interrupted:
                    return

                # Reload motor_state from KV to be safe
                latest_kv_state = await self.kv.load_state()
                # Check for stop one last time
                if latest_kv_state.get("current_sequence") == "stop":
                     log.info(f"[STATE_MACHINE] {step_name} aborted at end due to stop")
                     return

                state["motor_state"] = latest_kv_state.get("motor_state", {})
                
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
                
                # Save state and continue to next step
                await self.kv.save_state(state)
                # Continue processing next step sequentially
                await self._continue_processing()
            else:
                log.warning(f"[STATE_MACHINE] Unknown command type: {cmd}")
                state["current_step"]["status"] = "completed"
                state["current_step"]["completed_at"] = _iso_now()
                
                # Save state and continue to next step
                await self.kv.save_state(state)
                asyncio.create_task(self._continue_processing())
                
        except Exception as e:
            log.error(f"[STATE_MACHINE] Error executing step '{step_name}': {e}", exc_info=True)
            state["current_step"]["status"] = "failed"
            state["current_step"]["error"] = str(e)
            state["sequence_state"] = "ERROR"
            await self.kv.save_state(state)
    
    async def _move_to_next_step(self, step_index: int, state: Dict[str, Any]):
        """Move to next step in sequence."""
        current_sequence = state.get("current_sequence")
        sequence = await self._load_sequence_from_kv(current_sequence)
        
        if not sequence:
            return
        
        if step_index >= len(sequence):
            await self._complete_sequence(current_sequence, state)
        else:
            state["current_step_index"] = step_index
            state["current_step"] = None
            log.debug(f"[STATE_MACHINE] Moved to step {step_index}")
    
    async def _complete_sequence(self, sequence_id: str, state: Dict[str, Any]):
        """Complete current sequence."""
        if state.get("sequence_state") == "COMPLETED":
            return
        log.info(f"[STATE_CHANGE] Sequence completed: {sequence_id}")
        
        # Check if sequence was actually stopped
        current_seq = state.get("current_sequence")
        seq_state = state.get("sequence_state", "IDLE")
        if current_seq is None or seq_state == "IDLE":
            log.info(f"[STATE_CHANGE] Sequence '{sequence_id}' was interrupted, not completing normally")
            state["sequence_state"] = "IDLE"
            state["current_sequence"] = None
            state["current_step_index"] = -1
            state["current_step"] = None
            state["pending_sequence"] = None
            return
        
        # If startup sequence completed, check if there's a pending sequence
        if sequence_id == "startup":
            pending_sequence = state.get("pending_sequence")
            if pending_sequence:
                log.info(f"[STATE_CHANGE] Startup completed, starting pending sequence: {pending_sequence}")
                state["current_sequence"] = pending_sequence
                state["pending_sequence"] = None
                state["current_step_index"] = -1
                state["sequence_state"] = "RUNNING"
                state["current_step"] = None
                return
            # Mark engine ready if permission is active
            motor_state = state.get("motor_state", {})
            if motor_state.get("permission_active"):
                motor_state["engine_state"] = "ENGINE_READY"
                state["motor_state"] = motor_state
        
        state["sequence_state"] = "COMPLETED"
        state["current_sequence"] = None
        state["current_step_index"] = -1
        state["current_step"] = None
        
        # Reset engine state if permission is off (check latest state)
        # Actually controller handles this logic usually, but here we just check flags
        latest_kv_state = await self.kv.load_state()
        motor_state = latest_kv_state.get("motor_state", {})
        state["motor_state"] = motor_state # Update local copy
        
        if not motor_state.get("permission_active"):
            motor_state["engine_state"] = "ENGINE_OFF"
            state["motor_state"] = motor_state
    
    async def _get_current_state(self, current_state: Dict[str, Any]) -> Dict[str, Any]:
        """Get current state for saving."""
        return current_state
