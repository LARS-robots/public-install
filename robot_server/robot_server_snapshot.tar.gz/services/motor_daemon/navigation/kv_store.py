#!/usr/bin/env python3
"""
Navigation KV store for motor daemon.

Stores navigation route state in NATS JetStream Key-Value store.
Bucket: motors.navigation
Key: route
"""
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError

log = logging.getLogger(__name__)


def _iso_now() -> str:
    """Return ISO8601 UTC timestamp with millisecond precision."""
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


class NavigationKVStore:
    """KV store helper for navigation routes."""
    
    def __init__(self, nc: Optional[NATS] = None):
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "motors_navigation"
        self.key_name = "route"
    
    async def initialize(self):
        """Initialize JetStream and KV store."""
        if not self.nc:
            log.warning("[NAV_KV] NATS connection not available for KV store")
            return
        
        try:
            self.js = self.nc.jetstream()
            try:
                self.kv = await self.js.create_key_value(bucket=self.bucket_name)
                log.info(f"[NAV_KV] KV store bucket '{self.bucket_name}' initialized")
            except Exception:
                self.kv = await self.js.key_value(bucket=self.bucket_name)
                log.info(f"[NAV_KV] KV store bucket '{self.bucket_name}' retrieved")
        except Exception as e:
            log.error(f"[NAV_KV] Failed to initialize KV store: {e}", exc_info=True)
            self.kv = None
    
    async def load_route(self) -> Optional[Dict[str, Any]]:
        """Load route from KV store."""
        if not self.kv:
            return None
        
        try:
            entry = await self.kv.get(self.key_name)
            if entry:
                return json.loads(entry.value.decode())
        except NotFoundError:
            log.debug("[NAV_KV] No route found in KV store")
        except Exception as e:
            log.error(f"[NAV_KV] Failed to load route: {e}", exc_info=True)
        
        return None
    
    async def save_route(self, route_state: Dict[str, Any]) -> bool:
        """Save route to KV store."""
        if not self.kv:
            log.warning("[NAV_KV] KV store not initialized, skipping route save")
            return False
        
        try:
            # Ensure last_update is set
            route_state["last_update"] = _iso_now()
            route_json = json.dumps(route_state, separators=(',', ':'))
            await self.kv.put(self.key_name, route_json.encode())
            log.debug(f"[NAV_KV] Saved route: {len(route_state.get('path', []))} waypoints, idx={route_state.get('path_idx', 0)}")
            return True
        except Exception as e:
            log.error(f"[NAV_KV] Failed to save route: {e}", exc_info=True)
            return False
    
    async def delete_route(self) -> bool:
        """Delete route from KV store."""
        if not self.kv:
            return False
        
        try:
            await self.kv.delete(self.key_name)
            log.info("[NAV_KV] Deleted route from KV store")
            return True
        except NotFoundError:
            log.debug("[NAV_KV] Route not found in KV store (already deleted)")
            return True
        except Exception as e:
            log.error(f"[NAV_KV] Failed to delete route: {e}", exc_info=True)
            return False

