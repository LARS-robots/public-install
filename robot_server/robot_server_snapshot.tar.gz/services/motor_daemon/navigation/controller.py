#!/usr/bin/env python3
"""
Navigation controller for motor daemon.

Handles autonomous waypoint navigation:
- Reads route from KV store
- Computes navigation commands based on current pose
- Updates motor state through driver.convert_command()
- Integrates with existing command loop
"""
import json
import logging
import math
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError

from .kv_store import NavigationKVStore
from config_loader import get_config

log = logging.getLogger(__name__)


class NavigationController:
    """
    Controller for autonomous waypoint navigation.
    
    Works by updating motor state (state.last_vx/wz or state.diktum_*)
    which is then read by the existing _command_loop.
    """
    
    def __init__(
        self,
        state: Any,
        driver: Any,
        nc: Optional[NATS] = None
    ):
        """
        Initialize navigation controller.
        
        Args:
            state: DaemonState instance
            driver: Motor driver instance (MotorIface)
            nc: NATS connection
        """
        self.state = state
        self.driver = driver
        self.nc = nc
        
        # KV store for route persistence
        self.kv_store = NavigationKVStore(nc)
        
        # Load navigation parameters from config
        self._load_navigation_config()
        
        # State
        self.is_moving_forward = False  # Track if we're currently moving forward
        
        # Waypoint passing detection
        self.last_distance_to_waypoint: Optional[float] = None
        self.last_waypoint_idx: Optional[int] = None
        # Track minimum distance achieved for the current waypoint.
        # Used to avoid marking a waypoint as "passed" unless we actually got close enough at least once.
        self._wp_min_idx: Optional[int] = None
        self._wp_min_dist: Optional[float] = None
        
        # Movement direction tracking (проверка каждые 10м или 1 секунду - что наступит раньше)
        self.last_pose: Optional[Dict[str, float]] = None
        self.last_pose_ts: float = 0.0
        self.last_check_distance: float = 0.0  # Пройденное расстояние с последней проверки
        self.movement_direction_check_interval = 1.0  # Check every 1 second (время)
        self.movement_direction_check_distance = 5.0  # Check every 5 meters (расстояние) - УМЕНЬШЕНО для более частой проверки
        
        # Direction alignment check during movement (каждые 5м останавливаться если сильное отклонение)
        self.last_alignment_check_pose: Optional[Dict[str, float]] = None
        self.distance_since_alignment_check: float = 0.0
        
        # Phase transition hysteresis - prevent rapid switching
        self.last_phase_change_ts: float = 0.0
        self.min_phase_change_interval = 0.3  # Minimum 0.3 seconds between phase changes (prevents jerky movement)
        
        # Oscillation detection for stopping accuracy
        self.distance_history: List[float] = []  # Recent distance measurements
        self.distance_history_max_size = 10  # Keep last 10 measurements (~1 second at 10 Hz)
        
        # State
        self.active_route: Optional[Dict[str, Any]] = None
        self.last_manual_cmd_ts = 0.0
        self.pose_unavailable_count = 0
        # Tight arrival threshold (used for simulator/odometry for higher accuracy)
        self.arrive_eps_tight_m: float = 0.12
        # Soft arrival threshold (may be disabled for intermediate waypoints, see allow_soft_intermediate).
        self.arrive_eps_soft_m: float = 0.25
        # Passing threshold for intermediate waypoints (used by waypoint_passed logic).
        self.pass_eps_m: float = 0.20
        # If False, we do NOT use arrive_eps_soft_m for intermediate waypoints (prevents early switching).
        self.allow_soft_intermediate: bool = False

        # Approach mode (prevents overshoot near the target)
        # УВЕЛИЧЕНЫ лимиты чтобы робот не ползал как черепаха
        self.approach_radius_m: float = 1.0
        self.fine_radius_m: float = 0.5
        self.approach_forward_cap: float = 0.40  # Было 0.20 → +100%
        self.fine_forward_cap: float = 0.25  # Было 0.12 → +108%

        # Progress watchdog (detects moving away from the target)
        self._progress_last_idx: Optional[int] = None
        self._progress_last_dist: Optional[float] = None
        self._progress_bad_ticks: int = 0
        
        # Statistics
        self.stats = {
            "tick_count": 0,
            "waypoint_reached_count": 0,
            "error_count": 0,
            "position_unavailable_count": 0,
        }
    
    def _load_navigation_config(self):
        """Load navigation parameters from config file."""
        try:
            cfg = get_config().raw_data
            nav_cfg = cfg.get("navigation", {})
            
            # Distance parameters
            self.lookahead_distance = float(nav_cfg.get("lookahead_distance_m", 20.0))
            
            # ПАРАМЕТР LOOKAHEAD: включение/выключение алгоритма ближайшей точки
            # Если true, робот будет стремиться к ближайшей точке на сегменте маршрута
            # Это обеспечивает плавное возвращение на маршрут при отклонениях
            # Если false, используется старое поведение (прямо к следующей точке)
            self.use_lookahead_point = bool(nav_cfg.get("use_lookahead_point", True))
            
            self.arrive_eps_m = float(nav_cfg.get("arrive_eps_m", 0.3))
            self.arrive_eps_tight_m = float(nav_cfg.get("arrive_eps_tight_m", 0.12))
            # "Close enough" threshold: if we're within this distance, we consider waypoint reached.
            # Must be >= tight threshold. Useful when we want to avoid "turtle crawling" for the last centimeters.
            self.arrive_eps_soft_m = float(nav_cfg.get("arrive_eps_soft_m", 0.25))
            # Waypoint "passed" threshold (for intermediate waypoints).
            # This is intentionally separate from arrive_eps_soft_m so we can prevent early switching.
            self.pass_eps_m = float(nav_cfg.get("pass_eps_m", self.arrive_eps_soft_m))
            # If False, soft threshold is only applied to the LAST waypoint (simulator).
            self.allow_soft_intermediate = bool(nav_cfg.get("allow_soft_intermediate", False))
            self.approach_radius_m = float(nav_cfg.get("approach_radius_m", 1.0))
            self.fine_radius_m = float(nav_cfg.get("fine_radius_m", 0.5))
            # УВЕЛИЧЕНЫ для более быстрого движения около цели (не черепаха!)
            self.approach_forward_cap = float(nav_cfg.get("approach_forward_cap", 0.40))
            self.fine_forward_cap = float(nav_cfg.get("fine_forward_cap", 0.25))
            self.manual_timeout = float(nav_cfg.get("manual_timeout", 2.0))
            
            # Yaw error thresholds (convert from degrees to radians)
            yaw_error_threshold_deg = float(nav_cfg.get("yaw_error_threshold_deg", 3.0))
            self.yaw_error_threshold = math.radians(yaw_error_threshold_deg)
            
            yaw_error_moving_threshold_deg = float(nav_cfg.get("yaw_error_moving_threshold_deg", 15.0))
            self.yaw_error_moving_threshold = math.radians(yaw_error_moving_threshold_deg)

            # Simplified phase thresholds (user-friendly)
            # СТРОЖЕ: start_moving_yaw уменьшен для более точного начала движения
            start_moving_yaw_deg = float(nav_cfg.get("start_moving_yaw_deg", 3.0))  # Было 8° → 3° (точнее)
            stop_moving_yaw_deg = float(nav_cfg.get("stop_moving_yaw_deg", 25.0))  # Было 18° → 25° (строже)
            self.start_moving_yaw = math.radians(start_moving_yaw_deg)
            self.stop_moving_yaw = math.radians(stop_moving_yaw_deg)
            
            # Проверка направления каждые N метров во время движения
            self.direction_check_distance_threshold = float(nav_cfg.get("direction_check_distance_m", 5.0))
            self.direction_check_yaw_threshold_deg = float(nav_cfg.get("direction_check_yaw_threshold_deg", 12.0))
            self.direction_check_yaw_threshold = math.radians(self.direction_check_yaw_threshold_deg)
            
            # УСКОРЕНИЕ ПОВОРОТА: уменьшаем угол для достижения максимального turn=1.0
            # Было 45° → стало 30° = быстрее достигаем максимальной угловой скорости
            max_yaw_error_for_turn_deg = float(nav_cfg.get("max_yaw_error_for_turn_deg", 30.0))
            self.max_yaw_error_for_turn = math.radians(max_yaw_error_for_turn_deg)
            
            # Course correction during movement - УВЕЛИЧЕНА коррекция для более точного движения
            self.enable_moving_correction = bool(nav_cfg.get("enable_moving_correction", True))
            # Было 0.25 → стало 0.4 = более агрессивная коррекция курса во время движения
            self.kp_yaw_moving = float(nav_cfg.get("kp_yaw_moving", 0.4))
            # Было 0.3 → стало 0.5 = больший допустимый поворот во время движения
            self.max_turn_during_movement = float(nav_cfg.get("max_turn_during_movement", 0.5))
            
            # Speed parameters - УВЕЛИЧЕНЫ для более быстрого движения
            self.min_forward_speed = float(nav_cfg.get("min_forward_speed", 0.5))
            self.max_forward_speed = float(nav_cfg.get("max_forward_speed", 0.8))
            
            # Clamp tight arrival to a sane range
            if self.arrive_eps_tight_m <= 0:
                self.arrive_eps_tight_m = 0.12
            # Do not allow tight threshold to exceed the legacy arrive_eps_m
            self.arrive_eps_tight_m = min(self.arrive_eps_tight_m, self.arrive_eps_m)
            # Soft threshold must be >= tight and <= legacy arrive_eps_m
            if self.arrive_eps_soft_m <= 0:
                self.arrive_eps_soft_m = max(self.arrive_eps_tight_m, 0.25)
            self.arrive_eps_soft_m = max(self.arrive_eps_soft_m, self.arrive_eps_tight_m)
            self.arrive_eps_soft_m = min(self.arrive_eps_soft_m, self.arrive_eps_m)
            # Pass threshold must be >= tight and <= legacy arrive_eps_m
            if self.pass_eps_m <= 0:
                self.pass_eps_m = self.arrive_eps_soft_m
            self.pass_eps_m = max(self.pass_eps_m, self.arrive_eps_tight_m)
            self.pass_eps_m = min(self.pass_eps_m, self.arrive_eps_m)
            if self.fine_radius_m <= 0:
                self.fine_radius_m = 0.5
            if self.approach_radius_m <= self.fine_radius_m:
                self.approach_radius_m = max(self.fine_radius_m * 2.0, 1.0)

            log.info(
                "[NAV] Loaded navigation config: "
                f"start_moving_yaw={start_moving_yaw_deg:.1f}°, "
                f"stop_moving_yaw={stop_moving_yaw_deg:.1f}°, "
                f"direction_check_distance={self.direction_check_distance_threshold:.1f}m, "
                f"direction_check_yaw={self.direction_check_yaw_threshold_deg:.1f}°, "
                f"kp_yaw_moving={self.kp_yaw_moving:.2f}, "
                f"enable_moving_correction={self.enable_moving_correction}, "
                f"arrive_eps_m={self.arrive_eps_m:.2f}m, "
                f"arrive_eps_tight_m={self.arrive_eps_tight_m:.2f}m, "
                f"arrive_eps_soft_m={self.arrive_eps_soft_m:.2f}m, "
                f"pass_eps_m={self.pass_eps_m:.2f}m, "
                f"allow_soft_intermediate={self.allow_soft_intermediate}, "
                f"approach_radius_m={self.approach_radius_m:.2f}m, "
                f"fine_radius_m={self.fine_radius_m:.2f}m, "
                f"use_lookahead_point={self.use_lookahead_point}"
            )
        except Exception as e:
            log.warning(f"[NAV] Failed to load navigation config: {e}, using defaults")
            # Default values
            self.lookahead_distance = 20.0
            self.use_lookahead_point = True  # По умолчанию включен
            self.arrive_eps_m = 0.3
            self.arrive_eps_tight_m = 0.12
            self.arrive_eps_soft_m = 0.25
            self.pass_eps_m = 0.20
            self.allow_soft_intermediate = False
            self.approach_radius_m = 1.0
            self.fine_radius_m = 0.5
            self.approach_forward_cap = 0.40  # УВЕЛИЧЕНО
            self.fine_forward_cap = 0.25  # УВЕЛИЧЕНО
            self.manual_timeout = 2.0
            self.yaw_error_threshold = math.pi / 60  # 3 degrees (recommended)
            self.yaw_error_moving_threshold = math.pi / 12  # 15 degrees (recommended)
            self.start_moving_yaw = math.radians(3.0)  # СТРОЖЕ: было 8° → 3°
            self.stop_moving_yaw = math.radians(25.0)  # СТРОЖЕ: было 18° → 25°
            self.direction_check_distance_threshold = 5.0  # Каждые 5 метров
            self.direction_check_yaw_threshold = math.radians(12.0)  # Порог 12°
            self.max_yaw_error_for_turn = math.radians(30.0)  # 30 degrees (УСКОРЕНО)
            self.enable_moving_correction = True
            self.kp_yaw_moving = 0.4  # УВЕЛИЧЕНО для более агрессивной коррекции
            self.max_turn_during_movement = 0.5  # УВЕЛИЧЕНО
            self.min_forward_speed = 0.5  # УВЕЛИЧЕНО для более быстрого движения
            self.max_forward_speed = 0.8  # УВЕЛИЧЕНО для более быстрого движения
    
    async def initialize(self):
        """Initialize KV store and load active route if exists."""
        await self.kv_store.initialize()
        
        # Load active route from KV store (survives restarts)
        route = await self.kv_store.load_route()
        if route and route.get("status") == "RUNNING":
            self.active_route = route
            log.info(f"[NAV] Loaded active route from KV: {len(route.get('path', []))} waypoints, idx={route.get('path_idx', 0)}")
        else:
            self.active_route = None
    
    async def handle_start(self, waypoints: List[Dict[str, Any]]):
        """
        Start navigation with given waypoints.
        
        Args:
            waypoints: List of destination waypoints with 'lat' and 'lon' keys
            Note: UI now sends only destination waypoints, without robot position
        """
        log.info(f"[NAV] handle_start called with {len(waypoints) if waypoints else 0} waypoints")
        
        if not waypoints or len(waypoints) < 1:
            log.warning(f"[NAV] Cannot start navigation: need at least 1 waypoint, got {len(waypoints) if waypoints else 0}")
            return
        
        # Load route_state from KV store to get origin (if saved)
        route_state_from_kv = await self.kv_store.load_route()
        origin = None
        if route_state_from_kv and "origin" in route_state_from_kv:
            origin = route_state_from_kv["origin"]
            log.info(f"[NAV] Using origin from route_state: lat={origin.get('lat'):.6f}, lon={origin.get('lon'):.6f}")
        
        # Log all waypoints for debugging with high precision
        log.info(f"[NAV] 📍 Route plan: {len(waypoints)} waypoints")
        for i, wp in enumerate(waypoints):
            # Use 1-based indexing for user-friendly display (1/1, 2/3, etc.)
            log.info(f"[NAV]   Waypoint {i+1}/{len(waypoints)}: lat={wp.get('lat', 'N/A'):.9f}, lon={wp.get('lon', 'N/A'):.9f}")
        
        # Get current pose to check if first waypoint is already reached
        current_pose = await self._get_current_pose()
        if current_pose:
            log.info(f"[NAV] Current pose: lat={current_pose['lat']:.6f}, lon={current_pose['lon']:.6f}, yaw={current_pose.get('yaw', 0):.3f}")
        else:
            log.warning("[NAV] Could not get current pose, will start from first waypoint")
        
        start_idx = 0
        
        if current_pose and len(waypoints) > 0:
            first_waypoint = waypoints[0]
            # Use unified check to verify first waypoint is reached
            is_reached, dist_to_first = await self._check_waypoint_reached(
                current_pose, first_waypoint, is_last_waypoint=(len(waypoints) == 1), path_idx=0
            )
            
            log.info(f"[NAV] Distance to first waypoint: {dist_to_first:.2f}m")
            
            if is_reached:
                # First waypoint already reached - skip it
                log.info(f"[NAV] First waypoint too close ({dist_to_first:.2f}m), starting from second waypoint")
                start_idx = 1
                if start_idx >= len(waypoints):
                    # All waypoints already reached - verify completion
                    is_completed = await self._verify_route_completion(current_pose, waypoints)
                    if is_completed:
                        log.info("[NAV] All waypoints already reached - route completed")
                        route_state = {
                            "path": waypoints,
                            "path_idx": len(waypoints),
                            "status": "COMPLETED",
                            "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "last_update": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "error": None
                        }
                        await self.kv_store.save_route(route_state)
                        return
                    else:
                        log.warning("[NAV] All waypoints too close to current position")
                        return
        
        route_state = {
            "path": waypoints,
            "path_idx": start_idx,
            "status": "RUNNING",
            "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "last_update": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "error": None
        }
        
        # Сохранить origin если был загружен из KV store
        if origin:
            route_state["origin"] = origin
        
        # Save to KV store
        log.info(f"[NAV] Saving route to KV store: {len(waypoints)} waypoints, start_idx={start_idx}")
        success = await self.kv_store.save_route(route_state)
        if not success:
            log.error("[NAV] Failed to save route to KV store during start")
            return
        
        self.active_route = route_state
        self.pose_unavailable_count = 0
        # Reset phase + progress tracking for a clean start
        self.is_moving_forward = False
        self._progress_last_idx = None
        self._progress_last_dist = None
        self._progress_bad_ticks = 0
        # Reset waypoint tracking
        self.last_distance_to_waypoint = None
        self.last_waypoint_idx = None
        # Reset movement direction tracking
        # КРИТИЧНО: инициализируем last_pose сразу текущей позицией для проверки каждые 5м
        if current_pose:
            self.last_pose = {
                'lat': current_pose['lat'],
                'lon': current_pose['lon'],
                'yaw': current_pose.get('yaw', 0.0)
            }
            self.last_pose_ts = time.time()
            # Инициализируем проверку выравнивания
            self.last_alignment_check_pose = {
                'lat': current_pose['lat'],
                'lon': current_pose['lon'],
                'yaw': current_pose.get('yaw', 0.0)
            }
            self.distance_since_alignment_check = 0.0
            log.info(f"[NAV] Initialized last_pose for direction tracking: lat={current_pose['lat']:.6f}, lon={current_pose['lon']:.6f}")
        else:
            self.last_pose = None
            self.last_pose_ts = 0.0
            self.last_alignment_check_pose = None
            self.distance_since_alignment_check = 0.0
        self.last_check_distance = 0.0  # Сброс счетчика расстояния
        # Clear distance history for oscillation detection
        if hasattr(self, 'distance_history'):
            self.distance_history.clear()
        # Reset phase transition timing
        self.last_phase_change_ts = 0.0
        log.info(f"[NAV] ✅ Navigation started successfully: {len(waypoints)} waypoints, starting from idx={start_idx}, first_target=({waypoints[start_idx].get('lat'):.6f}, {waypoints[start_idx].get('lon'):.6f})")
        # Reset tick count to ensure immediate logging
        self.stats["tick_count"] = 0
    
    async def handle_cancel(self):
        """Cancel active navigation."""
        if self.active_route:
            # Update status in KV store
            self.active_route["status"] = "CANCELLED"
            self.active_route["last_update"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            await self.kv_store.save_route(self.active_route)
            
            # Stop movement by clearing state
            if self.driver:
                self.driver.convert_command(self.state, speed=0.0, forward=0.0, turn=0.0)
            
            log.info("[NAV] Navigation cancelled")
        
        # Delete from KV store
        await self.kv_store.delete_route()
        self.active_route = None
        # Reset phase + progress tracking
        self.is_moving_forward = False
        self._progress_last_idx = None
        self._progress_last_dist = None
        self._progress_bad_ticks = 0
    
    async def tick(self):
        """
        Main navigation tick (called at 20 Hz).
        
        Computes navigation commands and updates motor state.
        """
        # Log first tick after start to verify it's being called
        if self.stats["tick_count"] == 0 and self.active_route:
            log.info(f"[NAV] tick: First tick after start, active_route exists with {len(self.active_route.get('path', []))} waypoints")
        
        # Check if navigation is active
        if not self.active_route:
            # Log periodically when no active route (every 100 ticks = 5 seconds)
            if self.stats["tick_count"] % 100 == 0:
                log.debug("[NAV] tick: no active route")
            return
        
        # Check manual control priority
        if time.time() - self.last_manual_cmd_ts < self.manual_timeout:
            # Log periodically when paused due to manual control (every 20 ticks = 1 second)
            if self.stats["tick_count"] % 20 == 0:
                log.debug(f"[NAV] tick: paused due to manual control (timeout in {self.manual_timeout - (time.time() - self.last_manual_cmd_ts):.1f}s)")
            return  # Pause navigation when manual control is active
        
        # Reload route from KV store periodically (in case it was updated externally)
        if self.stats["tick_count"] % 20 == 0:  # Every second at 20 Hz
            route = await self.kv_store.load_route()
            if route:
                # Debug-only: log route loaded from KV
                log.debug(f"[NAV] Route from KV: "
                         f"path_len={len(route.get('path', []))}, "
                         f"path_idx={route.get('path_idx', 0)}, "
                         f"status={route.get('status')}")
                if route.get('path'):
                    for i, wp in enumerate(route['path']):
                        log.debug(f"[NAV]   WP{i+1}/{len(route['path'])}: lat={wp.get('lat'):.9f}, lon={wp.get('lon'):.9f}")
                # Check if route is marked as completed - verify we actually reached the last waypoint
                if route.get("status") == "COMPLETED":
                    pose = await self._get_current_pose()
                    if pose and len(route.get("path", [])) > 0:
                        is_completed = await self._verify_route_completion(pose, route["path"])
                        if not is_completed:
                            # Not actually reached - resume navigation
                            route["status"] = "RUNNING"
                            route["path_idx"] = len(route["path"]) - 1
                            await self.kv_store.save_route(route)
                            self.active_route = route
                            # Continue navigation below
                        else:
                            # Actually completed
                            self.active_route = None
                            return
                    else:
                        # No pose available or empty path - assume completed
                        self.active_route = None
                        return
                elif route.get("status") != "RUNNING":
                    # Route was cancelled or completed externally
                    log.info(f"[NAV] Route status changed to {route.get('status')}, stopping navigation")
                    self.active_route = None
                    return
                
                # Only update if local path_idx is not ahead of KV store path_idx
                # This prevents losing progress when reloading
                kv_path_idx = route.get("path_idx", 0)
                local_path_idx = self.active_route.get("path_idx", 0) if self.active_route else 0
                if kv_path_idx >= local_path_idx:
                    # KV store has same or newer progress, use it
                    self.active_route = route
                # Otherwise keep local progress (it will be saved soon)
        
        self.stats["tick_count"] += 1
        
        try:
            # Get current pose from KV store
            pose = await self._get_current_pose()
            if not pose:
                log.warning(f"[NAV] Position unavailable (count={self.pose_unavailable_count + 1})")
                await self._handle_position_unavailable()
                return
            
            # Reset pose unavailable counter
            self.pose_unavailable_count = 0
            
            # Compute navigation command
            cmd = await self._compute_navigation_command(pose)
            
            # Log navigation status periodically (every 10 ticks = 1 second at 10 Hz)
            if self.stats["tick_count"] % 10 == 0:
                path = self.active_route.get("path", []) if self.active_route else []
                path_idx = self.active_route.get("path_idx", 0) if self.active_route else 0
                
                # Calculate distance to target
                distance_to_target = None
                if path and path_idx < len(path):
                    target = path[path_idx]
                    distance_to_target = await self._euclidean_distance(
                        pose['lat'], pose['lon'],
                        target['lat'], target['lon']
                    )
                
                phase = "MOVING" if self.is_moving_forward else "TURNING"
                distance_str = f"{distance_to_target:.3f}m" if distance_to_target is not None else "N/A"
                # Use 1-based indexing for user-friendly display
                waypoint_str = f"{path_idx+1}/{len(path)}" if path else "0/0"
                log.info(f"[NAV] Status: phase={phase}, waypoint={waypoint_str}, "
                        f"distance={distance_str}, "
                        f"cmd: forward={cmd['forward']:.3f}, turn={cmd['turn']:.3f}, "
                        f"pose: lat={pose['lat']:.9f}, lon={pose['lon']:.9f}, yaw={math.degrees(pose.get('yaw', 0)):.2f}°")
            
            # Update motor state through driver
            if self.driver:
                self.driver.convert_command(
                    self.state,
                    speed=cmd['speed'],
                    forward=cmd['forward'],
                    turn=cmd['turn']
                )
                
                # Log what was actually set in state
                if self.stats["tick_count"] % 20 == 0:
                    if hasattr(self.state, 'last_vx') and hasattr(self.state, 'last_wz'):
                        log.info(f"[NAV] State updated: vx={self.state.last_vx:.3f} m/s, wz={self.state.last_wz:.3f} rad/s")
            else:
                log.warning("[NAV] Driver not available, cannot send navigation command")
            
            # Update route status in KV store periodically
            if self.stats["tick_count"] % 10 == 0:  # Every 0.5 seconds at 20 Hz
                await self._update_route_status()
                
        except Exception as e:
            self.stats["error_count"] += 1
            log.error(f"[NAV] Error in navigation tick: {e}", exc_info=True)
    
    async def _compute_navigation_command(self, pose: Dict[str, float]) -> Dict[str, float]:
        """
        Compute navigation command based on current pose and route.
        
        Args:
            pose: Current pose with 'lat', 'lon', 'yaw' keys
            
        Returns:
            Command dict with 'speed', 'forward', 'turn' (normalized -1.0 to 1.0)
        """
        if not self.active_route:
            return {'speed': 0.0, 'forward': 0.0, 'turn': 0.0}
        
        path = self.active_route.get("path", [])
        path_idx = self.active_route.get("path_idx", 0)
        
        # Safety check: if path_idx is out of bounds, reset to last waypoint
        # This should not happen in normal operation, but protects against corrupted state
        if path_idx >= len(path):
            if len(path) > 0:
                log.warning(f"[NAV] path_idx ({path_idx}) >= len(path) ({len(path)}) - resetting to last waypoint")
                self.active_route["path_idx"] = len(path) - 1
                path_idx = len(path) - 1
                # Continue to normal navigation logic below
            else:
                # Empty path - completed
                self.active_route["status"] = "COMPLETED"
                self.active_route["last_update"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                await self.kv_store.save_route(self.active_route)
                self.active_route = None
                log.info("[NAV] Route completed (empty path)")
                return {'speed': 0.0, 'forward': 0.0, 'turn': 0.0}
        
        # ВЫБОР ЦЕЛЕВОЙ ТОЧКИ: используем lookahead алгоритм для плавного следования по маршруту
        # Вместо движения напрямую к следующей точке маршрута, вычисляем ближайшую точку
        # на сегменте между текущей и следующей точкой. Это обеспечивает возврат на маршрут
        # при отклонениях, вместо движения по большой дуге.
        
        # Проверяем, включен ли lookahead и есть ли следующая точка
        use_lookahead = getattr(self, 'use_lookahead_point', True)  # По умолчанию включен
        if use_lookahead and path_idx < len(path) - 1:
            # Вычисляем ближайшую точку на сегменте маршрута
            # Это точка, к которой робот должен стремиться для возврата на маршрут
            lookahead_point, dist_to_segment, t_param = await self._get_closest_point_on_segment(
                pose, path, path_idx
            )
            
            # ОПТИМИЗАЦИЯ: если робот очень близко к сегменту и уже прошел текущую точку,
            # используем следующую точку напрямую. Это предотвращает осцилляции из-за "прыгающей" lookahead точки
            # УЛУЧШЕНИЕ: более строгие условия для стабильности во время поворотов
            if dist_to_segment < 0.15 and t_param > 0.4:
                # Робот уже на маршруте и движется к следующей точке - используем её напрямую
                target = path[path_idx + 1]
                if self.stats["tick_count"] % 20 == 0:
                    log.info(f"[NAV] Close to segment (dist={dist_to_segment:.2f}m, t={t_param:.2f}), "
                             f"using next waypoint directly")
            else:
                target = lookahead_point  # Используем lookahead точку как цель
            
            # Логируем информацию о lookahead для отладки (каждую секунду)
            if self.stats["tick_count"] % 20 == 0:
                target_type = "next_wp_direct" if (dist_to_segment < 0.15 and t_param > 0.4) else "lookahead_point"
                log.info(f"[NAV] Lookahead: t={t_param:.2f} "
                         f"(0=current_wp, 1=next_wp), "
                         f"dist_to_segment={dist_to_segment:.2f}m, "
                         f"target_type={target_type}, "
                         f"target=({target['lat']:.9f}, {target['lon']:.9f})")
        else:
            # Fallback: если lookahead отключен или это последняя точка,
            # используем точку маршрута напрямую (старое поведение)
            target = path[path_idx]
            if self.stats["tick_count"] % 20 == 0:
                log.info(f"[NAV] Using direct waypoint (no lookahead): "
                         f"waypoint {path_idx+1}/{len(path)}")
        
        # ВАЖНО: для проверки достижения точки маршрута используем фактическую точку,
        # а не lookahead точку. Это позволяет корректно переходить к следующей точке.
        actual_target = path[path_idx]  # Фактическая точка маршрута для проверки достижения

        # Check if waypoint reached using unified check
        # ВАЖНО: проверяем достижение фактической точки маршрута, а не lookahead точки
        is_last = (path_idx == len(path) - 1)
        
        is_reached, dist = await self._check_waypoint_reached(
            pose, actual_target, is_last_waypoint=is_last, path_idx=path_idx
        )
        
        # Log current target waypoint coordinates (every second for visibility)
        # КРИТИЧНО: логируем ПОСЛЕ вычисления dist!
        if self.stats["tick_count"] % 20 == 0:
            # Use 1-based indexing for user-friendly display
            log.info(f"[NAV] 🎯 Current TARGET: waypoint {path_idx+1}/{len(path)} (path_idx={path_idx})")
            log.info(f"[NAV]    Visual target coords: lat={target['lat']:.9f}, lon={target['lon']:.9f}")
            log.info(f"[NAV]    Actual waypoint coords: lat={actual_target['lat']:.9f}, lon={actual_target['lon']:.9f}")
            log.info(f"[NAV]    Distance to actual waypoint: {dist:.3f}m")
            
            # Also log all remaining waypoints for reference
            if path_idx < len(path) - 1:
                log.info(f"[NAV] Remaining waypoints after {path_idx+1}:")
                for i in range(path_idx + 1, len(path)):
                    wp = path[i]
                    dist_to_wp = await self._euclidean_distance(
                        pose['lat'], pose['lon'], wp['lat'], wp['lon']
                    )
                    log.info(f"[NAV]   WP {i+1}/{len(path)}: lat={wp['lat']:.6f}, lon={wp['lon']:.6f}, dist={dist_to_wp:.2f}m")
        # (detailed reach logging is handled inside _check_waypoint_reached)

        # Track minimum distance achieved for this waypoint (used by waypoint_passed logic).
        if self._wp_min_idx != path_idx:
            self._wp_min_idx = path_idx
            self._wp_min_dist = dist
        else:
            if self._wp_min_dist is None or dist < self._wp_min_dist:
                self._wp_min_dist = dist

        # Progress watchdog (detect overshoot / moving away while MOVING).
        # This prevents the "turn a bit -> drive a bit -> overshoot -> turn back" loop.
        if self._progress_last_idx != path_idx:
            self._progress_last_idx = path_idx
            self._progress_last_dist = dist
            self._progress_bad_ticks = 0
        else:
            if self._progress_last_dist is not None and self.is_moving_forward:
                # Count consecutive ticks where we get farther from the target
                # Be more sensitive near target
                eps = 0.02 if dist < self.approach_radius_m else 0.05
                if dist > self._progress_last_dist + eps:
                    self._progress_bad_ticks += 1
                else:
                    self._progress_bad_ticks = max(0, self._progress_bad_ticks - 1)
            self._progress_last_dist = dist

        # Also check if waypoint was passed (robot went past it)
        # Only check if we haven't reached it yet and it's not the last waypoint
        waypoint_passed = False
        if not is_reached and not is_last:
            # Check if robot has passed the current waypoint
            # This should only happen if:
            # 1. Robot was close to waypoint (within pass_eps_m) at least once AND
            # 2. Robot is now moving away from it (distance increasing) AND
            # 3. Robot is closer to next waypoint than to current
            next_target = path[path_idx + 1]
            dist_to_next = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                next_target['lat'], next_target['lon']
            )
            
            # Check if we're moving away from current waypoint
            moving_away = False
            was_close = False
            if self.last_waypoint_idx == path_idx and self.last_distance_to_waypoint is not None:
                # Same waypoint as last time - check if distance increased
                if dist > self.last_distance_to_waypoint + 0.15:  # Increased by at least 15cm
                    moving_away = True
            # Check if we were close to the waypoint at any point (min distance achieved).
            if self._wp_min_idx == path_idx and self._wp_min_dist is not None:
                if self._wp_min_dist <= self.pass_eps_m:
                    was_close = True
            
            # КРИТИЧНО: только mark as passed если все условия выполнены
            # И ОБЯЗАТЕЛЬНО логируем для отладки
            if was_close and moving_away and dist_to_next < dist:
                waypoint_passed = True
                log.warning(
                    f"[NAV] ⚠️ Waypoint {path_idx+1}/{len(path)} PASSED (не достигнут!): "
                    f"min_dist={self._wp_min_dist:.3f}m <= pass_eps={self.pass_eps_m:.3f}m, "
                    f"dist_to_current={dist:.2f}m, dist_to_next={dist_to_next:.2f}m, "
                    f"next_waypoint={path_idx+2}/{len(path)}"
                )
            elif self.stats["tick_count"] % 20 == 0 and not is_reached:
                # Логируем почему НЕ passed (для отладки)
                log.debug(
                    f"[NAV] Waypoint {path_idx+1} not passed yet: "
                    f"was_close={was_close}, moving_away={moving_away}, "
                    f"dist={dist:.2f}m, dist_to_next={dist_to_next:.2f}m, "
                    f"min_dist={self._wp_min_dist:.3f}m if self._wp_min_dist else 'N/A'"
                )
        
        # Update tracking for next tick
        self.last_distance_to_waypoint = dist
        self.last_waypoint_idx = path_idx
        
        # Track distance history for oscillation detection
        self.distance_history.append(dist)
        if len(self.distance_history) > self.distance_history_max_size:
            self.distance_history.pop(0)
        
        # Check for oscillation (distance keeps going up and down)
        # Soft response: slow down instead of hard stop.
        if len(self.distance_history) >= 5 and dist < self.arrive_eps_m * 2:
            # Check if distance is oscillating (alternating increases/decreases)
            direction_changes = 0
            for i in range(1, len(self.distance_history)):
                prev_change = self.distance_history[i] - self.distance_history[i-1]
                if i > 1:
                    curr_change = self.distance_history[i] - self.distance_history[i-1]
                    if (prev_change > 0 and curr_change < 0) or (prev_change < 0 and curr_change > 0):
                        direction_changes += 1
            
            if direction_changes >= 3:
                log.warning(
                    f"[NAV] ⚠️ Oscillation detected near waypoint: direction_changes={direction_changes}, "
                    f"dist={dist:.3f}m. Slowing down (no hard stop)."
                )
                # Mark a slowdown hint via a small forward cap stored on the instance for this tick.
                # (Used later when computing forward speed.)
                self._oscillation_slowdown = True
            else:
                self._oscillation_slowdown = False
        else:
            self._oscillation_slowdown = False
        
        if is_reached or waypoint_passed:
            # Process waypoint reached/passed atomically
            log.debug(f"[NAV] Processing waypoint reached/passed: is_reached={is_reached}, waypoint_passed={waypoint_passed}, dist={dist:.3f}m, path_idx={path_idx}")
            should_stop, stop_cmd = await self._process_waypoint_reached(pose, path, path_idx, dist)
            log.debug(f"[NAV] After _process_waypoint_reached: should_stop={should_stop}, stop_cmd={stop_cmd}")
            if should_stop:
                return stop_cmd
            # If not stopped, waypoint was intermediate and path_idx was incremented
            # Re-read path_idx and target to get the next waypoint
            path_idx = self.active_route.get("path_idx", 0)
            if path_idx >= len(path):
                # This should not happen, but handle gracefully
                log.error(f"[NAV] path_idx ({path_idx}) >= len(path) ({len(path)}) after waypoint reached")
                return {'speed': 0.0, 'forward': 0.0, 'turn': 0.0}
            target = path[path_idx]
            # Reset tracking for new waypoint
            self.last_distance_to_waypoint = None
            self.last_waypoint_idx = None
            self._wp_min_idx = None
            self._wp_min_dist = None
            # Reset movement direction tracking for new waypoint
            # КРИТИЧНО: обновляем last_pose текущей позицией для проверки каждые 5м
            self.last_pose = {
                'lat': pose['lat'],
                'lon': pose['lon'],
                'yaw': pose.get('yaw', 0.0)
            }
            self.last_pose_ts = time.time()
            self.last_check_distance = 0.0  # Сброс счетчика расстояния при переходе к новой точке
            # Сбрасываем alignment check для новой точки
            self.last_alignment_check_pose = {
                'lat': pose['lat'],
                'lon': pose['lon'],
                'yaw': pose.get('yaw', 0.0)
            }
            self.distance_since_alignment_check = 0.0
            log.info(f"[NAV] Initialized last_pose and alignment check for new waypoint {path_idx+1}")
            # Reset state for new waypoint
            self.is_moving_forward = False  # Reset moving state for new waypoint
            # Reset progress tracking for new waypoint
            self._progress_last_idx = None
            self._progress_last_dist = None
            self._progress_bad_ticks = 0
            # Clear distance history for oscillation detection
            self.distance_history.clear()
            # Clear distance history for oscillation detection
            self.distance_history.clear()
            # Log transition with detailed coordinates
            # Use 1-based indexing for user-friendly display
            log.info(f"[NAV] 🔄 Transitioning to waypoint {path_idx+1}/{len(path)}")
            log.info(f"[NAV]   Current robot position: lat={pose['lat']:.9f}, lon={pose['lon']:.9f}, yaw={math.degrees(pose.get('yaw', 0)):.1f}°")
            log.info(f"[NAV]   Target waypoint {path_idx+1}: lat={target['lat']:.9f}, lon={target['lon']:.9f}")
            # Calculate and log bearing to new target
            new_bearing = self._bearing_rad(pose['lat'], pose['lon'], target['lat'], target['lon'])
            # Нормализуем текущий yaw перед вычислением ошибки
            current_yaw = pose.get('yaw', 0.0)
            current_yaw = self._normalize_angle(current_yaw)
            new_yaw_error_raw = new_bearing - current_yaw
            new_yaw_error = self._normalize_angle(new_yaw_error_raw)
            log.info(f"[NAV]   Bearing to new target: {math.degrees(new_bearing):.1f}°")
            log.info(f"[NAV]   Current yaw: {math.degrees(current_yaw):.1f}°")
            log.info(f"[NAV]   Yaw error to new target: {math.degrees(new_yaw_error):.1f}° (raw: {math.degrees(new_yaw_error_raw):.1f}°)")
            
            # ОПРЕДЕЛЕНИЕ НАПРАВЛЕНИЯ ПОВОРОТА
            # После нормализации yaw_error находится в диапазоне [-π, π]
            # 
            # СИСТЕМА КООРДИНАТ:
            # - Bearing использует географическую систему: 0=Север, положительное=Восток (по часовой)
            # - Yaw робота должен использовать ту же систему
            # - Положительный yaw_error = нужно повернуть вправо (по часовой стрелке)
            # - Отрицательный yaw_error = нужно повернуть влево (против часовой стрелки)
            #
            # После нормализации yaw_error всегда в [-π, π], поэтому проверка abs < π всегда true
            # Но оставляем для ясности и защиты от edge cases
            if abs(new_yaw_error) < math.pi:
                # Нормальный случай: ошибка в допустимом диапазоне
                # Положительная ошибка = поворот вправо, отрицательная = поворот влево
                turn_direction = "RIGHT" if new_yaw_error > 0 else "LEFT"
            else:
                # Edge case: после нормализации этого не должно происходить,
                # но оставляем для защиты от численных ошибок
                turn_direction = "RIGHT" if new_yaw_error > 0 else "LEFT"
            
            log.info(f"[NAV]   ⚠️ REQUIRED TURN: {turn_direction} ({abs(math.degrees(new_yaw_error)):.1f}°)")
            # Force recalculation of distance to new target
            dist = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                target['lat'], target['lon']
            )
            log.info(f"[NAV]   Distance to new target: {dist:.2f}m")
        else:
            # Not reached yet
            log.debug(f"[NAV] Waypoint {path_idx} not reached yet (dist={dist:.2f}m)")
        
        # ВЫЧИСЛЕНИЕ BEARING (направления к цели)
        # Bearing - это географический азимут от текущей позиции к цели
        # Использует формулу для сферических координат (lat/lon)
        # Результат в радианах: 0 = Север, π/2 = Восток, π = Юг, -π/2 = Запад
        bearing = self._bearing_rad(
            pose['lat'], pose['lon'],
            target['lat'], target['lon']
        )
        
        # НОРМАЛИЗАЦИЯ ТЕКУЩЕГО YAW РОБОТА
        # Yaw робота может быть в любом диапазоне из-за накопления поворотов
        # Нормализуем его в диапазон [-π, π] для корректных вычислений
        # Это важно, так как bearing уже в этом диапазоне
        current_yaw = pose.get('yaw', 0.0)
        current_yaw = self._normalize_angle(current_yaw)
        
        # ВЫЧИСЛЕНИЕ СЫРОЙ ОШИБКИ YAW
        # Это разница между направлением к цели и текущим направлением робота
        # Может быть в диапазоне [-2π, 2π] или больше
        yaw_error_raw = bearing - current_yaw
        
        # НОРМАЛИЗАЦИЯ ОШИБКИ YAW
        # _normalize_angle() нормализует в [-π, π], но не всегда выбирает кратчайший путь
        # Нужно ВСЕГДА проверить оба направления и выбрать кратчайшее
        yaw_error = self._normalize_angle(yaw_error_raw)
        
        # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: всегда выбираем кратчайший путь поворота
        # Проверяем оба возможных направления и выбираем меньшее по модулю
        # Это исправляет баг с поворотом "не в ту сторону" (например, вправо на 173° вместо влево на 90°)
        if yaw_error > 0:
            alt_error = yaw_error - 2 * math.pi  # Альтернатива: повернуть в другую сторону
        else:
            alt_error = yaw_error + 2 * math.pi
        
        # Выбираем направление с меньшей абсолютной ошибкой (кратчайший путь)
        # СРАВНЕНИЕ ПО МОДУЛЮ как предложено пользователем
        if abs(alt_error) < abs(yaw_error):
            original_deg = math.degrees(yaw_error)
            alternative_deg = math.degrees(alt_error)
            log.info(f"[NAV] 🔄 Choosing shorter rotation: "
                     f"original={original_deg:.1f}° → alternative={alternative_deg:.1f}° "
                     f"(saved {abs(original_deg) - abs(alternative_deg):.1f}°)")
            yaw_error = alt_error
        
        # ЛОГИРОВАНИЕ для отладки (каждую секунду)
        if self.stats["tick_count"] % 20 == 0:
            log.info(f"[NAV] Yaw calculation: "
                     f"bearing={math.degrees(bearing):.1f}°, "
                     f"current_yaw={math.degrees(current_yaw):.1f}°, "
                     f"raw_error={math.degrees(yaw_error_raw):.1f}°, "
                     f"normalized_error={math.degrees(yaw_error):.1f}°")
        
        # Detailed logging with visualization (every tick for diagnostics)
        yaw_dir = self._angle_to_direction(current_yaw)
        bearing_dir = self._angle_to_direction(bearing)
        # Use 1-based indexing for user-friendly display
        log.debug(f"[NAV] 📍 Navigation tick: waypoint {path_idx+1}/{len(path)}, dist={dist:.2f}m")
        log.debug(f"[NAV]   Robot: yaw={math.degrees(current_yaw):.1f}° ({yaw_dir}), "
                 f"Target bearing={math.degrees(bearing):.1f}° ({bearing_dir}), "
                 f"Error={math.degrees(yaw_error):.1f}°")
        
        # More detailed logging every second
        if self.stats["tick_count"] % 20 == 0:
            log.info(f"[NAV] Navigation details: current_yaw={math.degrees(current_yaw):.1f}° ({yaw_dir}), "
                    f"bearing_to_target={math.degrees(bearing):.1f}° ({bearing_dir}), "
                    f"yaw_error={math.degrees(yaw_error):.1f}°")
            log.info(f"[NAV] Target coordinates: lat={target['lat']:.9f}, lon={target['lon']:.9f}")
            log.info(f"[NAV] Robot coordinates: lat={pose['lat']:.9f}, lon={pose['lon']:.9f}")
        
        # Check movement direction: проверяем каждую секунду ИЛИ каждые 5 метров (что наступит раньше)
        # Вычисляем пройденное расстояние с последней проверки
        distance_since_check = 0.0
        if self.last_pose is not None:
            distance_since_check = await self._euclidean_distance(
                self.last_pose['lat'], self.last_pose['lon'],
                pose['lat'], pose['lon']
            )
        
        time_since_check = time.time() - self.last_pose_ts
        should_check_direction = (
            time_since_check >= self.movement_direction_check_interval or
            distance_since_check >= self.movement_direction_check_distance
        )
        
        # КРИТИЧНО: логируем когда проверка НЕ срабатывает для отладки
        if self.stats["tick_count"] % 20 == 0:
            log.info(f"[NAV] Direction check status: dist_since_check={distance_since_check:.2f}m, "
                     f"time_since_check={time_since_check:.1f}s, should_check={should_check_direction}, "
                     f"last_pose_exists={self.last_pose is not None}")
        
        if should_check_direction:
            is_correct_dir, angle_error, movement_bearing = await self._check_movement_direction(pose, target, distance_since_check)
            if movement_bearing is not None:
                if not is_correct_dir:
                    # Более агрессивная коррекция при отклонении
                    log.warning(
                        f"[NAV] ⚠️ Movement direction correction: moving {math.degrees(movement_bearing):.1f}°, "
                        f"target {math.degrees(bearing):.1f}°, angle_error={math.degrees(angle_error):.1f}°, "
                        f"dist_since_check={distance_since_check:.1f}m, time_since_check={time_since_check:.1f}s"
                    )
                    yaw_error = self._normalize_angle(yaw_error + angle_error * 0.5)
                else:
                    # Логируем даже когда направление правильное
                    log.info(f"[NAV] ✅ Direction OK: moving {math.degrees(movement_bearing):.1f}°, "
                             f"target {math.degrees(bearing):.1f}°, error={math.degrees(angle_error):.1f}°")
        
        # Two-phase approach: turn first until aligned, then move straight forward
        # Use hysteresis to prevent rapid switching between TURNING and MOVING
        yaw_error_abs = abs(yaw_error)
        
        # Track previous phase for transition logging
        was_moving_before = self.is_moving_forward
        
        # НОВАЯ ПРОВЕРКА: Каждые 5 метров во время движения проверяем направление
        # Если отклонение больше порога - останавливаемся и поворачиваемся
        alignment_check_forced_turn = False
        if self.is_moving_forward:
            # Вычисляем пройденное расстояние с последней проверки
            if self.last_alignment_check_pose is not None:
                self.distance_since_alignment_check = await self._euclidean_distance(
                    self.last_alignment_check_pose['lat'], self.last_alignment_check_pose['lon'],
                    pose['lat'], pose['lon']
                )
            else:
                self.distance_since_alignment_check = 0.0
            
            # Проверка каждые N метров
            if self.distance_since_alignment_check >= self.direction_check_distance_threshold:
                # Проверяем yaw_error
                if yaw_error_abs > self.direction_check_yaw_threshold:
                    alignment_check_forced_turn = True
                    log.warning(
                        f"[NAV] ⚠️ ALIGNMENT CHECK: traveled {self.distance_since_alignment_check:.1f}m, "
                        f"yaw_error={math.degrees(yaw_error_abs):.1f}° > threshold={math.degrees(self.direction_check_yaw_threshold):.1f}° "
                        f"→ STOPPING to correct direction"
                    )
                else:
                    log.info(
                        f"[NAV] ✅ ALIGNMENT CHECK OK: traveled {self.distance_since_alignment_check:.1f}m, "
                        f"yaw_error={math.degrees(yaw_error_abs):.1f}° <= threshold={math.degrees(self.direction_check_yaw_threshold):.1f}°"
                    )
                
                # Сбрасываем счетчик после проверки
                self.last_alignment_check_pose = {
                    'lat': pose['lat'],
                    'lon': pose['lon'],
                    'yaw': pose.get('yaw', 0.0)
                }
                self.distance_since_alignment_check = 0.0
        
        # Hysteresis logic:
        # - To START moving: yaw_error must be <= threshold
        # - To STOP moving: yaw_error must be > moving_threshold
        # This prevents rapid switching when bearing changes slightly during movement
        
        # Phase transition hysteresis with minimum interval between changes
        current_time = time.time()
        time_since_last_change = current_time - self.last_phase_change_ts
        
        speed_cmd = 1.0

        # Simplified phase logic:
        # - TURNING: keep turning until yaw_error <= start_moving_yaw
        # - MOVING: keep moving until yaw_error >= stop_moving_yaw
        # yaw_error drives phase choice; progress watchdog can force TURNING if we are moving away.
        progress_guard = self.is_moving_forward and self._progress_bad_ticks >= 3
        if self.is_moving_forward:
            should_turn = (
                (yaw_error_abs > self.stop_moving_yaw) or progress_guard or alignment_check_forced_turn
            ) and (time_since_last_change >= self.min_phase_change_interval)
        else:
            should_turn = yaw_error_abs > self.start_moving_yaw
            # Prevent rapid toggling: require min interval before switching to MOVING
            if not should_turn and time_since_last_change < self.min_phase_change_interval:
                should_turn = True
        
        # Phase 1: If not aligned (yaw error > threshold), turn in place
        if should_turn:
            # TURNING: by default no forward movement
            forward = 0.0
            self.is_moving_forward = False
            
            # ВЫЧИСЛЕНИЕ КОМАНДЫ ПОВОРОТА
            # Команда поворота пропорциональна ошибке yaw
            # 
            # СИСТЕМА КООРДИНАТ:
            # - Положительный yaw_error = поворот вправо (по часовой стрелке)
            # - Отрицательный yaw_error = поворот влево (против часовой стрелки)
            # - Команда turn ограничена диапазоном [-1.0, 1.0]
            #
            # max_yaw_error_for_turn - это максимальная ошибка, при которой
            # команда поворота достигает максимума (обычно 45°)
            # Например: если yaw_error = 45° и max_yaw_error_for_turn = 45°,
            # то turn = 1.0 (максимальный поворот)
            turn = max(-1.0, min(1.0, yaw_error / self.max_yaw_error_for_turn))

            # Far-from-target: allow a small arc move while turning to avoid "turn-stop" behavior.
            # Only do this when yaw error is not extreme, otherwise it can spiral/circle.
            if dist > self.approach_radius_m:
                if yaw_error_abs < math.radians(60.0):
                    forward = max(forward, self.min_forward_speed * 0.20)
                    speed_cmd = min(speed_cmd, 0.60)
                else:
                    forward = 0.0

            # Near-target "crawl while turning" to avoid stop-go pattern.
            # BUT: only allow crawl when yaw error is already small; otherwise it causes orbiting.
            if dist < self.approach_radius_m:
                if yaw_error_abs <= math.radians(25.0) and abs(turn) < 0.8:
                    # УВЕЛИЧЕН crawl: было 0.18 → стало 0.30
                    crawl_forward = max(0.08, self.min_forward_speed * 0.30)
                    if dist < self.fine_radius_m:
                        forward = min(crawl_forward, self.fine_forward_cap)
                        speed_cmd = min(speed_cmd, 0.50)  # Было 0.25 → 0.50
                    else:
                        forward = min(crawl_forward, self.approach_forward_cap)
                        speed_cmd = min(speed_cmd, 0.60)  # Было 0.35 → 0.60
                else:
                    # Turn in place when far from aligned to prevent circular motion around target
                    forward = 0.0
            
            # Log phase transition and update timestamp
            if was_moving_before and not self.is_moving_forward:
                if alignment_check_forced_turn:
                    reason = "alignment_check"
                elif progress_guard:
                    reason = "progress_guard"
                else:
                    reason = "yaw_error"
                log.info(
                    f"[NAV] 🔄 Phase transition: MOVING → TURNING "
                    f"(reason={reason}, yaw_error={math.degrees(yaw_error_abs):.1f}°, dist={dist:.2f}m, bad_ticks={self._progress_bad_ticks})"
                )
                self.last_phase_change_ts = current_time
            
            # Log periodically with detailed bearing info
            if self.stats["tick_count"] % 20 == 0:
                direction = "RIGHT" if yaw_error > 0 else "LEFT"
                log.info(
                    f"[NAV] 🔄 TURNING: yaw_error={math.degrees(yaw_error_abs):.1f}° ({direction}) "
                    f"> {math.degrees(self.start_moving_yaw):.1f}°, "
                    f"bearing={math.degrees(bearing):.1f}°, current_yaw={math.degrees(current_yaw):.1f}°, "
                    f"turn_cmd={turn:.2f}, forward_cmd={forward:.2f}, dist={dist:.2f}m"
                )
        else:
            # Phase 2: Aligned - move forward with optional course correction
            self.is_moving_forward = True
            
            # Log phase transition and update timestamp
            if not was_moving_before and self.is_moving_forward:
                log.info(
                    f"[NAV] 🔄 Phase transition: TURNING → MOVING "
                    f"(yaw_error={math.degrees(yaw_error_abs):.1f}° <= {math.degrees(self.start_moving_yaw):.1f}°, dist={dist:.2f}m)"
                )
                self.last_phase_change_ts = current_time
            
            # Simplified forward speed profile (2–3 zones) + guaranteed crawl near target.
            # Use the same arrival threshold family as _check_waypoint_reached.
            is_sim = hasattr(self.driver, "get_pose")
            arrive = self.arrive_eps_tight_m if is_sim else (self.arrive_eps_m * 0.9)
            speed_cmd = 1.0

            ramp_dist = max(1.0, min(self.lookahead_distance, 3.0))
            # "Crawl" is a safety net near the target, but if it's too small the robot feels like a turtle.
            # УВЕЛИЧЕН коэффициент: было 0.30 → стало 0.50 (не черепаха!)
            crawl_forward = max(0.15, self.min_forward_speed * 0.50)

            if dist >= ramp_dist:
                forward = self.max_forward_speed
            elif dist >= 2.0 * arrive:
                # Linear ramp from min -> max within [2*arrive .. ramp_dist]
                t = max(0.0, min(1.0, (dist - 2.0 * arrive) / max(1e-6, (ramp_dist - 2.0 * arrive))))
                forward = self.min_forward_speed + (self.max_forward_speed - self.min_forward_speed) * t
            else:
                # Close to target: crawl forward until reach threshold
                forward = crawl_forward

            # Approach mode: cap speed near target to prevent overshoot
            # УВЕЛИЧЕНЫ speed_cmd для более быстрого подъезда к цели
            if dist < self.fine_radius_m:
                forward = min(forward, self.fine_forward_cap)
                speed_cmd = min(speed_cmd, 0.50)  # Было 0.25 → 0.50 (+100%)
            elif dist < self.approach_radius_m:
                forward = min(forward, self.approach_forward_cap)
                speed_cmd = min(speed_cmd, 0.60)  # Было 0.40 → 0.60 (+50%)

            # If we're showing bad progress (moving away), reduce throttle aggressively.
            if self._progress_bad_ticks > 0:
                speed_cmd = min(speed_cmd, 0.25)

            # Soft oscillation response: cap forward speed instead of stopping completely.
            if getattr(self, "_oscillation_slowdown", False):
                forward = min(forward, self.min_forward_speed * 0.15)
                speed_cmd = min(speed_cmd, 0.25)
            
            # Course correction during movement (if enabled)
            if self.enable_moving_correction and self.kp_yaw_moving > 0.0:
                # Proportional correction: turn = kp * yaw_error, limited to prevent excessive turning
                turn = max(-self.max_turn_during_movement, min(self.max_turn_during_movement, 
                                                              self.kp_yaw_moving * yaw_error))
            else:
                # No turning when aligned - move straight
                turn = 0.0
            
            # Log periodically
            if self.stats["tick_count"] % 20 == 0:
                correction_str = f"turn={turn:.3f}" if (self.enable_moving_correction and self.kp_yaw_moving > 0.0) else "turn=0"
                log.info(
                    f"[NAV] ➡️ MOVING: yaw_error={math.degrees(yaw_error_abs):.1f}° "
                    f"(start<= {math.degrees(self.start_moving_yaw):.1f}°, stop>= {math.degrees(self.stop_moving_yaw):.1f}°), "
                    f"moving forward (forward={forward:.2f}, {correction_str}, dist={dist:.2f}m)"
                )
        
        # Ensure values are in valid range
        forward = max(0.0, min(1.0, forward))
        turn = max(-1.0, min(1.0, turn))
        
        # Update last pose for movement direction tracking (after check triggered)
        # Проверка уже выполнена выше, если сработала - обновляем last_pose
        if should_check_direction:
            self.last_pose = {
                'lat': pose['lat'],
                'lon': pose['lon'],
                'yaw': pose.get('yaw', 0.0)
            }
            self.last_pose_ts = time.time()
            self.last_check_distance = 0.0  # Сбрасываем счетчик расстояния
        
        return {
            'speed': speed_cmd,
            'forward': forward,
            'turn': turn
        }
    
    async def _get_current_pose(self) -> Optional[Dict[str, float]]:
        """
        Get current robot pose from KV store or simulator.
        
        Tries:
        1. Simulator pose (if available) - has lat/lon directly
        2. loc_state/current (from localization daemon) - may have lat/lon
        
        Returns:
            Pose dict with 'lat', 'lon', 'yaw' or None if unavailable
        """
        # Try simulator pose first (if driver is simulator)
        if hasattr(self.driver, 'get_pose'):
            try:
                sim_pose = self.driver.get_pose()
                if sim_pose and 'lat' in sim_pose and 'lon' in sim_pose:
                    self.last_pose_read_ts = time.time()
                    pose = {
                        'lat': float(sim_pose['lat']),
                        'lon': float(sim_pose['lon']),
                        'yaw': float(sim_pose.get('yaw', 0.0))
                    }
                    # Log pose read periodically (every 20 ticks = 1 second at 20 Hz)
                    if self.stats["tick_count"] % 20 == 0:
                        log.info(f"[NAV] Got simulator pose: lat={pose['lat']:.6f}, lon={pose['lon']:.6f}, yaw={math.degrees(pose['yaw']):.1f}°")
                    return pose
                else:
                    if self.stats["tick_count"] % 20 == 0:
                        log.warning(f"[NAV] Simulator pose missing lat/lon: {sim_pose}")
            except Exception as e:
                if self.stats["tick_count"] % 20 == 0:
                    log.warning(f"[NAV] Failed to get simulator pose: {e}")
        
        if not self.nc:
            return None
        
        try:
            js = self.nc.jetstream()
            kv = await js.key_value("loc_state")
            
            # Try current (from localization daemon) - may have lat/lon
            try:
                entry = await kv.get("current")
                if entry:
                    data = json.loads(entry.value.decode())
                    if 'lat' in data and 'lon' in data:
                        return {
                            'lat': float(data['lat']),
                            'lon': float(data['lon']),
                            'yaw': float(data.get('yaw', 0.0))
                        }
            except NotFoundError:
                pass
            
        except Exception as e:
            log.debug(f"[NAV] Failed to read pose from KV store: {e}")
        
        return None
    
    async def _handle_position_unavailable(self):
        """Handle case when position is unavailable - stop navigation."""
        self.pose_unavailable_count += 1
        self.stats["position_unavailable_count"] += 1
        
        if self.pose_unavailable_count == 1:
            log.warning("[NAV] ⚠️ Position unavailable, stopping navigation")
        elif self.pose_unavailable_count % 20 == 0:  # Log every second
            log.warning(f"[NAV] ⚠️ Position still unavailable (count={self.pose_unavailable_count})")
        
        # Stop movement
        if self.driver:
            self.driver.convert_command(self.state, speed=0.0, forward=0.0, turn=0.0)
            log.debug("[NAV] Stopped movement due to position unavailability")
        
        # Only mark as error after multiple failures (give it a chance to recover)
        if self.pose_unavailable_count > 50:  # 2.5 seconds at 20 Hz
            log.error("[NAV] ❌ Position unavailable for too long, marking route as ERROR")
            if self.active_route:
                self.active_route["status"] = "ERROR"
                self.active_route["error"] = "position_unavailable"
                self.active_route["last_update"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                await self.kv_store.save_route(self.active_route)
                self.active_route = None
    
    async def _update_route_status(self):
        """Update route status in KV store."""
        if self.active_route:
            await self.kv_store.save_route(self.active_route)
    
    async def _get_origin(self) -> Optional[Dict[str, float]]:
        """
        Get origin from active route, or from KV store/config as fallback.
        
        Returns:
            Dict with 'lat' and 'lon' keys, or None if unavailable
        """
        # Priority 1: origin from active route (if provided by UI)
        if self.active_route and "origin" in self.active_route:
            origin = self.active_route["origin"]
            if origin and "lat" in origin and "lon" in origin:
                log.info(f"[NAV] Using origin from active_route: lat={origin['lat']:.6f}, lon={origin['lon']:.6f}")
                return {
                    "lat": float(origin["lat"]),
                    "lon": float(origin["lon"])
                }
        
        # Priority 2: origin from KV store (existing logic)
        if not self.nc:
            return None
        
        try:
            js = self.nc.jetstream()
            kv = await js.key_value("loc_state")
            
            # Try motor_odom first (has start_lat/start_lon)
            try:
                entry = await kv.get("motor_odom")
                if entry:
                    data = json.loads(entry.value.decode())
                    if 'start_lat' in data and 'start_lon' in data:
                        origin = {
                            'lat': float(data['start_lat']),
                            'lon': float(data['start_lon'])
                        }
                        log.debug(f"[NAV] Using origin from KV store (motor_odom): lat={origin['lat']:.6f}, lon={origin['lon']:.6f}")
                        return origin
            except NotFoundError:
                pass
            
            # Fallback: try current (may have start_lat/start_lon)
            try:
                entry = await kv.get("current")
                if entry:
                    data = json.loads(entry.value.decode())
                    if 'start_lat' in data and 'start_lon' in data:
                        origin = {
                            'lat': float(data['start_lat']),
                            'lon': float(data['start_lon'])
                        }
                        log.debug(f"[NAV] Using origin from KV store (current): lat={origin['lat']:.6f}, lon={origin['lon']:.6f}")
                        return origin
            except NotFoundError:
                pass
                
        except Exception as e:
            log.debug(f"[NAV] Failed to read origin from KV store: {e}")
        
        # Ultimate fallback
        log.warning("[NAV] Using hardcoded fallback origin - this may cause inaccurate distance calculations")
        return {'lat': 55.164441, 'lon': 61.436843}

    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculate Haversine distance in meters between two lat/lon points.
        
        Args:
            lat1, lon1: First point
            lat2, lon2: Second point
            
        Returns:
            Distance in meters
        """
        R = 6378137.0  # Earth radius in meters
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat/2)**2 + 
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
             math.sin(dlon/2)**2)
        # Protect against numerical errors
        a = min(1.0, max(0.0, a))
        return 2 * R * math.asin(math.sqrt(a))
    
    def _latlon_to_meters(self, lat: float, lon: float, ref_lat: float, ref_lon: float) -> tuple[float, float]:
        """
        Convert lat/lon to meters relative to reference point.
        
        Args:
            lat, lon: Target coordinates
            ref_lat, ref_lon: Reference point (origin)
            
        Returns:
            Tuple of (x, y) in meters (x=east, y=north)
        """
        R = 6378137.0  # Earth radius in meters
        dlat = math.radians(lat - ref_lat)
        dlon = math.radians(lon - ref_lon)
        y = dlat * R  # North (latitude)
        x = dlon * R * math.cos(math.radians(ref_lat))  # East (longitude)
        return x, y

    async def _euclidean_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculate distance in meters using Euclidean distance in local coordinate system.
        
        This is more accurate for local navigation than Haversine when both points
        are converted from the same metric coordinate system.
        
        Args:
            lat1, lon1: First point
            lat2, lon2: Second point
            
        Returns:
            Distance in meters
        """
        origin = await self._get_origin()
        if not origin:
            # Fallback to Haversine if origin unavailable
            dist_haversine = self._haversine_distance(lat1, lon1, lat2, lon2)
            log.info(f"[NAV] No origin available, using Haversine: dist={dist_haversine:.2f}m")
            return dist_haversine
        
        # Проверка валидности origin (защита от неверного origin)
        # Если origin слишком далеко от точек, использовать Haversine
        dist_to_origin1 = self._haversine_distance(lat1, lon1, origin['lat'], origin['lon'])
        dist_to_origin2 = self._haversine_distance(lat2, lon2, origin['lat'], origin['lon'])
        
        # Если origin слишком далеко (>10км), вероятно он неверный - использовать Haversine
        if dist_to_origin1 > 10000 or dist_to_origin2 > 10000:
            log.warning(f"[NAV] Origin seems invalid (too far: {dist_to_origin1:.0f}m, {dist_to_origin2:.0f}m), using Haversine")
            return self._haversine_distance(lat1, lon1, lat2, lon2)
        
        # Convert both points to meters relative to origin
        x1, y1 = self._latlon_to_meters(lat1, lon1, origin['lat'], origin['lon'])
        x2, y2 = self._latlon_to_meters(lat2, lon2, origin['lat'], origin['lon'])
        
        # Euclidean distance
        dist = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        
        # Debug-only: distance calculation details (can be chatty)
        if dist < 2.0 and (self.stats.get("tick_count", 0) % 20 == 0):
            log.debug(f"[NAV] Distance calc: "
                     f"robot=({lat1:.9f}, {lon1:.9f}) -> ({x1:.3f}, {y1:.3f})m, "
                     f"target=({lat2:.9f}, {lon2:.9f}) -> ({x2:.3f}, {y2:.3f})m, "
                     f"origin=({origin['lat']:.9f}, {origin['lon']:.9f}), "
                     f"dist={dist:.3f}m")
        
        # Log only at DEBUG level to avoid spam (called very frequently during navigation)
        log.debug(f"[NAV] Euclidean distance: origin=({origin['lat']:.6f}, {origin['lon']:.6f}), "
                  f"point1=({lat1:.6f}, {lon1:.6f}) -> ({x1:.2f}, {y1:.2f})m, "
                  f"point2=({lat2:.6f}, {lon2:.6f}) -> ({x2:.2f}, {y2:.2f})m, "
                  f"dist={dist:.3f}m")
        
        return dist
    
    async def _get_closest_point_on_segment(
        self,
        pose: Dict[str, float],
        path: List[Dict[str, Any]],
        path_idx: int
    ) -> tuple[Dict[str, float], float, float]:
        """
        Вычисляет ближайшую точку на сегменте маршрута между текущей и следующей точкой.
        
        Этот метод решает проблему больших дуг: вместо движения напрямую к следующей точке,
        робот стремится к ближайшей точке на линии маршрута, что обеспечивает плавное
        возвращение на маршрут при отклонениях.
        
        Алгоритм:
        1. Проецирует позицию робота на прямую линию между текущей и следующей точкой
        2. Находит ближайшую точку на этом сегменте
        3. Если робот уже прошел текущую точку (t > 0.5), может использовать следующую точку
        
        Args:
            pose: Текущая позиция робота с ключами 'lat', 'lon'
            path: Список точек маршрута (waypoints)
            path_idx: Индекс текущей точки маршрута
            
        Returns:
            Кортеж из трех элементов:
            - target_point: Ближайшая точка на сегменте (dict с 'lat', 'lon')
            - distance_to_segment: Расстояние от робота до ближайшей точки (метры)
            - t_parameter: Параметр позиции вдоль сегмента (0.0 = текущая точка, 1.0 = следующая)
        """
        # Проверка: если это последняя точка маршрута, используем её напрямую
        # Нет следующей точки для формирования сегмента
        if path_idx >= len(path):
            # Защита от выхода за границы - возвращаем последнюю точку
            if len(path) > 0:
                last_wp = path[-1]
                dist = await self._euclidean_distance(
                    pose['lat'], pose['lon'],
                    last_wp['lat'], last_wp['lon']
                )
                return last_wp, dist, 1.0
            else:
                # Пустой маршрут - возвращаем текущую позицию
                return pose, 0.0, 0.0
        
        current_wp = path[path_idx]
        
        # Если это последняя точка маршрута, нет следующей точки для сегмента
        # Используем текущую точку напрямую
        if path_idx == len(path) - 1:
            dist = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                current_wp['lat'], current_wp['lon']
            )
            return current_wp, dist, 1.0
        
        # Получаем следующую точку для формирования сегмента
        next_wp = path[path_idx + 1]
        
        # Для вычислений используем метрическую систему координат
        # Получаем origin (начало координат) для преобразования lat/lon в метры
        origin = await self._get_origin()
        if not origin:
            # Если origin недоступен, используем Haversine расстояние
            # В этом случае возвращаем текущую точку напрямую
            dist = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                current_wp['lat'], current_wp['lon']
            )
            return current_wp, dist, 0.0
        
        # Преобразуем все точки в метрическую систему координат относительно origin
        # Это позволяет использовать простую евклидову геометрию для вычислений
        robot_x, robot_y = self._latlon_to_meters(
            pose['lat'], pose['lon'],
            origin['lat'], origin['lon']
        )
        wp1_x, wp1_y = self._latlon_to_meters(
            current_wp['lat'], current_wp['lon'],
            origin['lat'], origin['lon']
        )
        wp2_x, wp2_y = self._latlon_to_meters(
            next_wp['lat'], next_wp['lon'],
            origin['lat'], origin['lon']
        )
        
        # Вычисляем вектор сегмента от текущей точки к следующей
        # Это направление маршрута
        seg_dx = wp2_x - wp1_x  # Разница по оси X (восток)
        seg_dy = wp2_y - wp1_y  # Разница по оси Y (север)
        seg_len_sq = seg_dx * seg_dx + seg_dy * seg_dy  # Квадрат длины сегмента
        
        # Если сегмент слишком короткий (< 10см), используем следующую точку напрямую
        # Это предотвращает деление на ноль и проблемы с численной точностью
        if seg_len_sq < 0.01:
            dist_to_next = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                next_wp['lat'], next_wp['lon']
            )
            return next_wp, dist_to_next, 1.0
        
        # Вычисляем вектор от текущей точки маршрута к позиции робота
        # Это показывает, насколько робот отклонился от маршрута
        to_robot_dx = robot_x - wp1_x
        to_robot_dy = robot_y - wp1_y
        
        # Проецируем позицию робота на сегмент маршрута
        # Используем скалярное произведение для нахождения проекции
        # t - это параметр вдоль сегмента: 0 = текущая точка, 1 = следующая точка
        # Формула: t = (to_robot · seg) / |seg|²
        t = (to_robot_dx * seg_dx + to_robot_dy * seg_dy) / seg_len_sq
        
        # Ограничиваем t диапазоном [0, 1], чтобы точка оставалась на сегменте
        # Если t < 0, робот еще не достиг текущей точки (используем текущую точку)
        # Если t > 1, робот уже прошел следующую точку (используем следующую точку)
        t = max(0.0, min(1.0, t))
        
        # Вычисляем координаты ближайшей точки на сегменте
        # Используем параметрическое уравнение прямой: P = P1 + t * (P2 - P1)
        closest_x = wp1_x + t * seg_dx
        closest_y = wp1_y + t * seg_dy
        
        # Преобразуем обратно в географические координаты (lat/lon)
        # Обратное преобразование из метрической системы в lat/lon
        R = 6378137.0  # Радиус Земли в метрах
        closest_lat = origin['lat'] + (closest_y / R) * (180.0 / math.pi)
        closest_lon = origin['lon'] + (closest_x / (R * math.cos(math.radians(origin['lat'])))) * (180.0 / math.pi)
        
        # Формируем целевую точку в формате lat/lon
        lookahead_point = {
            'lat': closest_lat,
            'lon': closest_lon
        }
        
        # Вычисляем расстояние от робота до ближайшей точки на сегменте
        # Это расстояние отклонения от маршрута
        dist_to_segment = math.sqrt(
            (robot_x - closest_x) ** 2 + (robot_y - closest_y) ** 2
        )
        
        # Оптимизация: если робот уже прошел середину сегмента (t > 0.5)
        # и находится близко к сегменту, можно использовать следующую точку
        # Это ускоряет переход к следующему сегменту маршрута
        if t > 0.5 and dist_to_segment < 2.0:
            # Проверяем, не ближе ли робот к следующей точке
            dist_to_next = await self._euclidean_distance(
                pose['lat'], pose['lon'],
                next_wp['lat'], next_wp['lon']
            )
            # Если следующая точка значительно ближе, используем её
            # Коэффициент 1.5 предотвращает частые переключения
            if dist_to_next < dist_to_segment * 1.5:
                return next_wp, dist_to_next, 1.0
        
        # Возвращаем ближайшую точку на сегменте
        return lookahead_point, dist_to_segment, t
    
    async def _check_movement_direction(
        self,
        current_pose: Dict[str, float],
        target: Dict[str, float],
        distance_since_check: float = 0.0
    ) -> tuple[bool, float, Optional[float]]:
        """
        Check if robot is moving in the correct direction towards the target.
        
        This function compares the actual movement direction (from last pose to current)
        with the desired direction (from current pose to target).
        
        Проверка выполняется каждые 5 метров или 1 секунду (что наступит раньше).
        
        Args:
            current_pose: Current robot pose with 'lat', 'lon'
            target: Target waypoint with 'lat', 'lon'
            distance_since_check: Distance traveled since last check (meters)
            
        Returns:
            Tuple of (is_correct_direction: bool, angle_error: float, movement_bearing: Optional[float])
            - is_correct_direction: True if movement is towards target (angle < 45 degrees)
            - angle_error: Angle between movement direction and target direction in radians
            - movement_bearing: Bearing of actual movement in radians (None if not enough data)
        """
        if not self.last_pose:
            # No previous pose - skip check
            return True, 0.0, None
        
        # Calculate movement vector (from last pose to current pose)
        origin = await self._get_origin()
        if not origin:
            return True, 0.0, None
        
        # Convert to meters
        last_x, last_y = self._latlon_to_meters(
            self.last_pose['lat'], self.last_pose['lon'],
            origin['lat'], origin['lon']
        )
        curr_x, curr_y = self._latlon_to_meters(
            current_pose['lat'], current_pose['lon'],
            origin['lat'], origin['lon']
        )
        target_x, target_y = self._latlon_to_meters(
            target['lat'], target['lon'],
            origin['lat'], origin['lon']
        )
        
        # Movement vector (how robot actually moved)
        move_dx = curr_x - last_x
        move_dy = curr_y - last_y
        move_dist = math.sqrt(move_dx**2 + move_dy**2)
        
        # If movement is too small (< 10cm), skip check
        if move_dist < 0.1:
            return True, 0.0, None
        
        # Direction to target (where robot should go)
        target_dx = target_x - curr_x
        target_dy = target_y - curr_y
        target_dist = math.sqrt(target_dx**2 + target_dy**2)
        
        # If target is too close, skip check
        if target_dist < 0.1:
            return True, 0.0, None
        
        # Calculate bearings
        movement_bearing = math.atan2(move_dx, move_dy)  # atan2(x, y) gives angle from north
        target_bearing = math.atan2(target_dx, target_dy)
        
        # Calculate angle difference
        angle_error = self._normalize_angle(target_bearing - movement_bearing)
        angle_error_abs = abs(angle_error)
        
        # Check if movement is in correct direction (within 45 degrees)
        is_correct = angle_error_abs < math.pi / 4  # 45 degrees
        
        return is_correct, angle_error, movement_bearing
    
    def _bearing_rad(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculate bearing in radians from point 1 to point 2.
        
        Always uses geographic bearing formula for lat/lon coordinates.
        """
        dlon = math.radians(lon2 - lon1)
        y = math.sin(dlon) * math.cos(math.radians(lat2))
        x = (math.cos(math.radians(lat1)) * math.sin(math.radians(lat2))
             - math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(dlon))
        return math.atan2(y, x)
    
    def _normalize_angle(self, angle: float) -> float:
        """Normalize angle to [-pi, pi] range."""
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle
    
    def _angle_to_direction(self, angle_rad: float) -> str:
        """
        Convert angle in radians to cardinal direction string for visualization.
        
        Args:
            angle_rad: Angle in radians (0 = North, π/2 = East)
            
        Returns:
            Direction string (e.g., "N", "NE", "E", "SE", etc.)
        """
        deg = math.degrees(angle_rad)
        # Normalize to [0, 360)
        deg = deg % 360
        if deg < 0:
            deg += 360
        
        # Map to cardinal directions
        if deg < 22.5 or deg >= 337.5:
            return "N"
        elif deg < 67.5:
            return "NE"
        elif deg < 112.5:
            return "E"
        elif deg < 157.5:
            return "SE"
        elif deg < 202.5:
            return "S"
        elif deg < 247.5:
            return "SW"
        elif deg < 292.5:
            return "W"
        else:
            return "NW"
    
    async def _check_waypoint_reached(
        self, 
        pose: Dict[str, float], 
        waypoint: Dict[str, float], 
        is_last_waypoint: bool = False,
        path_idx: Optional[int] = None
    ) -> tuple[bool, float]:
        """
        Unified check if waypoint is reached.
        
        Args:
            pose: Current robot pose with 'lat', 'lon'
            waypoint: Target waypoint with 'lat', 'lon'
            is_last_waypoint: True if this is the last waypoint in route
            
        Returns:
            Tuple of (is_reached: bool, distance: float)
            - is_reached: True if waypoint is reached according to threshold
            - distance: Distance to waypoint in meters
        """
        dist = await self._euclidean_distance(
            pose['lat'], pose['lon'],
            waypoint['lat'], waypoint['lon']
        )

        # Tight arrival for simulator/odometry (higher precision)
        # Fallback to legacy threshold for non-simulator setups.
        is_sim = hasattr(self.driver, "get_pose")
        threshold_tight = self.arrive_eps_tight_m if is_sim else (self.arrive_eps_m * 0.9)
        threshold_soft = self.arrive_eps_soft_m if is_sim else self.arrive_eps_m
        # ensure soft >= tight
        threshold_soft = max(threshold_soft, threshold_tight)
        # Important policy for "almost guaranteed arrival":
        # In simulator, do not let soft threshold advance intermediate waypoints unless explicitly enabled.
        # This prevents switching to the next waypoint 20-30cm early.
        if is_sim and (not is_last_waypoint) and (not self.allow_soft_intermediate):
            threshold_soft = threshold_tight

        # Use <= to handle edge case when distance exactly equals threshold
        # Policy:
        # - If within tight threshold -> definitely reached
        # - Else if within soft threshold -> "close enough", mark reached to avoid turtle-crawling forever
        is_reached = dist <= threshold_tight or dist <= threshold_soft

        # Minimal high-signal logging only (avoid spam)
        if is_reached:
            used = "tight" if dist <= threshold_tight else "soft"
            log.info(
                f"[NAV] ✅ Waypoint REACHED ({used}): dist={dist:.3f}m "
                f"(tight={threshold_tight:.3f}m, soft={threshold_soft:.3f}m, legacy={self.arrive_eps_m:.3f}m), "
                f"is_last={is_last_waypoint}"
            )
        else:
            log.debug(
                f"[NAV] Waypoint not reached: dist={dist:.3f}m > tight={threshold_tight:.3f}m (soft={threshold_soft:.3f}m), is_last={is_last_waypoint}"
            )

        return is_reached, dist
    
    async def _verify_route_completion(
        self, 
        pose: Dict[str, float], 
        path: List[Dict[str, Any]]
    ) -> bool:
        """
        Verify if route is actually completed by checking distance to last waypoint.
        
        Args:
            pose: Current robot pose
            path: List of waypoints
            
        Returns:
            True if route is actually completed, False otherwise
        """
        if not path or len(path) == 0:
            return True  # Empty path is completed
        
        # Add detailed logging
        log.info(f"[NAV] Route completion verification: path_len={len(path)}, "
                 f"current_pose=({pose['lat']:.9f}, {pose['lon']:.9f})")
        
        # Log the exact waypoint coordinates with high precision
        for i, wp in enumerate(path):
            if isinstance(wp, dict) and 'lat' in wp and 'lon' in wp:
                dist_to_wp = await self._euclidean_distance(
                    pose['lat'], pose['lon'],
                    wp['lat'], wp['lon']
                )
                # Use 1-based indexing for user-friendly display
                log.info(f"[NAV]   Waypoint {i+1}: lat={wp['lat']:.9f}, lon={wp['lon']:.9f}, dist={dist_to_wp:.3f}m")
        
        last_waypoint = path[-1]
        is_reached, dist = await self._check_waypoint_reached(pose, last_waypoint, is_last_waypoint=True, path_idx=None)
        
        log.info(f"[NAV] Route completion verification result: "
                 f"last_waypoint=({last_waypoint['lat']:.6f}, {last_waypoint['lon']:.6f}), "
                 f"dist={dist:.2f}m, is_reached={is_reached}")
        
        if not is_reached:
            log.warning("[NAV] Route completion verification failed: last waypoint not reached")
        
        return is_reached
    
    async def _process_waypoint_reached(
        self,
        pose: Dict[str, float],
        path: List[Dict[str, Any]],
        path_idx: int,
        dist: float
    ) -> tuple[bool, Optional[Dict[str, float]]]:
        """
        Process waypoint reached event - atomic operation.
        
        This method ensures path_idx is only incremented after verification,
        preventing race conditions and premature route completion.
        
        Args:
            pose: Current robot pose
            path: List of waypoints
            path_idx: Current waypoint index
            dist: Distance to waypoint
            
        Returns:
            Tuple of (should_stop: bool, command: Optional[Dict])
            - should_stop: True if should stop (waypoint reached or route completed)
            - command: Stop command if should_stop, None otherwise
        """
        is_last = (path_idx == len(path) - 1)
        
        # Получаем координаты текущей точки для логирования
        current_wp = path[path_idx]
        log.info(f"[NAV] Processing waypoint {path_idx+1}/{len(path)} reached: "
                 f"is_last={is_last}, dist={dist:.2f}m, "
                 f"coords=({current_wp['lat']:.6f}, {current_wp['lon']:.6f})")
        
        # Safety check: verify this is actually the last waypoint
        if not is_last:
            # Not last waypoint - КРИТИЧНО: инкрементируем ТОЛЬКО на +1
            old_idx = path_idx
            new_idx = path_idx + 1
            
            # ЗАЩИТА: никогда не пропускаем точки!
            if new_idx != old_idx + 1:
                log.error(f"[NAV] ❌ CRITICAL: Attempting to skip waypoint! "
                         f"old={old_idx+1}, new={new_idx+1}, expected={old_idx+2}")
                new_idx = old_idx + 1  # Принудительно +1
            
            self.active_route["path_idx"] = new_idx
            self.stats["waypoint_reached_count"] += 1
            
            # Логируем с координатами следующей точки
            next_wp = path[new_idx]
            log.info(f"[NAV] ✅ Waypoint {old_idx+1}/{len(path)} completed (dist={dist:.2f}m)")
            log.info(f"[NAV] 🎯 Moving to waypoint {new_idx+1}/{len(path)}: "
                     f"coords=({next_wp['lat']:.6f}, {next_wp['lon']:.6f})")
            
            await self.kv_store.save_route(self.active_route)
            # Don't stop - continue to next waypoint immediately
            # Return None to continue navigation
            return False, None
        
        # This is the last waypoint - verify completion BEFORE incrementing path_idx
        is_completed = await self._verify_route_completion(pose, path)
        if is_completed:
            # Only now increment and mark as completed
            self.active_route["path_idx"] = path_idx + 1
            self.stats["waypoint_reached_count"] += 1
            self.active_route["status"] = "COMPLETED"
            self.active_route["last_update"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            await self.kv_store.save_route(self.active_route)
            self.active_route = None
            
            # КРИТИЧНО: явно останавливаем робота через driver
            if self.driver:
                self.driver.convert_command(self.state, speed=0.0, forward=0.0, turn=0.0)
                log.info("[NAV] ✅ Route completed - STOPPED robot via driver")
            else:
                log.info("[NAV] ✅ Route completed - all waypoints reached")
            
            return True, {'speed': 0.0, 'forward': 0.0, 'turn': 0.0}
        else:
            # Verification failed - don't increment path_idx
            log.warning(f"[NAV] Last waypoint verification failed (dist={dist:.2f}m), continuing navigation")
            return False, None
    
    def get_stats(self) -> Dict[str, Any]:
        """Get navigation statistics."""
        stats = self.stats.copy()
        stats["active_route"] = self.active_route is not None
        if self.active_route:
            stats["current_waypoint"] = self.active_route.get("path_idx", 0)
            stats["total_waypoints"] = len(self.active_route.get("path", []))
        return stats

