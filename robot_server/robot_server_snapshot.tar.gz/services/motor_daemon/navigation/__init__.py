#!/usr/bin/env python3
"""
Navigation module for motor daemon.

Provides autonomous waypoint navigation functionality.
"""
from .controller import NavigationController

__all__ = ["NavigationController"]

