# Common utilities for motor daemon

