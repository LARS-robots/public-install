from __future__ import annotations
from typing import Protocol, Optional, runtime_checkable

@runtime_checkable
class MotorIface(Protocol):
    """
    Minimal interface all motor drivers must implement.
    Values:
      - speed: 0-2000 (speed multiplier)
      - forward: -2000 to 2000 (+ = forward, - = backward)
      - turn: -2000 to 2000 (+ = left, - = right)
    """

    name: str

    def connect(self, app_state) -> None: ...
    def set_throttle(self, value: float) -> None: ...
    def set_steer(self, value: float) -> None: ...
    def command_joystick(self, speed: int, forward: int, turn: int) -> None: ...
    def stop(self) -> None: ...
    def shutdown(self) -> None: ...

