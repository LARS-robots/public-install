from __future__ import annotations
from typing import Protocol, Optional, runtime_checkable

@runtime_checkable
class MotorIface(Protocol):
    """
    Minimal interface all motor drivers must implement.
    Values:
      - speed: 0-2000 (speed multiplier)
      - forward: -2000 to 2000 (+ = forward, - = backward)
      - turn: -2000 to 2000 (+ = left, - = right)
    """

    name: str

    def connect(self, app_state) -> None: ...
    def set_throttle(self, value: float) -> None: ...
    def set_steer(self, value: float) -> None: ...
    def command_joystick(self, speed: int, forward: int, turn: int) -> None: ...
    def stop(self) -> None: ...
    def shutdown(self) -> None: ...
    
    # Unified relay interface (for all robot types)
    def set_relay(self, state, name: str, on: bool) -> None: ...
    def is_permission_active(self) -> bool: ...
    def is_starter_active(self) -> bool: ...
    
    # Command conversion interface
    def convert_command(self, state, speed: float, forward: float, turn: float) -> None:
        """
        Convert normalized command (-1.0 to 1.0) to driver-specific format.
        Updates state with converted values.
        
        Args:
            state: DaemonState instance to update
            speed: Normalized speed (0.0 to 1.0) or None
            forward: Normalized forward (-1.0 to 1.0) or None
            turn: Normalized turn (-1.0 to 1.0) or None
        """
        ...

