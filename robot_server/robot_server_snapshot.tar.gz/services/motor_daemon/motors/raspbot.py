import logging
from common.motor_iface import MotorIface

log = logging.getLogger(__name__)

class RaspbotMotor(MotorIface):
    """
    Raspbot motor driver (placeholder).
    Insert actual GPIO / lib calls where indicated by 'pass'.
    """
    name = "raspbot"

    def __init__(self):
        self._connected = False

    def connect(self, app_state) -> None:
        # TODO: init pigpio / RPi.GPIO / motor HAT
        # pass
        self._connected = True
        log.info("motor.connect", extra={"event": {
            "stage": "motion",
            "action": "connect",
            "driver": self.name,
            "result": "ok"
        }})

    def set_throttle(self, value: float) -> None:
        # TODO: map to left/right wheel power or PWM
        # pass
        log.info("motor.throttle", extra={"event": {
            "stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)
        }})

    def set_steer(self, value: float) -> None:
        # TODO: map to differential steering
        # pass
        log.info("motor.steer", extra={"event": {
            "stage": "motion", "action": "steer", "driver": self.name, "value": float(value)
        }})

    def command_velocity(self, vx: float, wz: float) -> None:
        # TODO: convert (vx, wz) to left/right wheel speeds and write them
        # pass
        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity", "driver": self.name,
            "effective": {"vx": float(vx), "wz": float(wz)}
        }})

    def stop(self) -> None:
        # TODO: stop wheels
        # pass
        log.info("motor.stop", extra={"event": {
            "stage": "motion", "action": "stop", "driver": self.name
        }})

    def shutdown(self) -> None:
        # TODO: cleanup GPIO
        # pass
        log.info("motor.shutdown", extra={"event": {
            "stage": "motion", "action": "shutdown", "driver": self.name
        }})

