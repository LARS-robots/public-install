import logging
import math
from common.motor_iface import MotorIface
from config_loader import get_config

log = logging.getLogger(__name__)

class RaspbotMotor(MotorIface):
    """
    Raspbot motor driver (placeholder).
    Insert actual GPIO / lib calls where indicated by 'pass'.
    """
    name = "raspbot"

    def __init__(self):
        self._connected = False
        self.state = None  # Will be set in connect()

    def connect(self, app_state) -> None:
        self.state = app_state
        # TODO: init pigpio / RPi.GPIO / motor HAT
        # pass
        self._connected = True
        log.info("motor.connect", extra={"event": {
            "stage": "motion",
            "action": "connect",
            "driver": self.name,
            "result": "ok"
        }})

    def set_throttle(self, value: float) -> None:
        # TODO: map to left/right wheel power or PWM
        # pass
        log.info("motor.throttle", extra={"event": {
            "stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)
        }})

    def set_steer(self, value: float) -> None:
        # TODO: map to differential steering
        # pass
        log.info("motor.steer", extra={"event": {
            "stage": "motion", "action": "steer", "driver": self.name, "value": float(value)
        }})

    def command_velocity(self, vx: float, wz: float) -> None:
        # TODO: convert (vx, wz) to left/right wheel speeds and write them
        # pass
        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity", "driver": self.name,
            "effective": {"vx": float(vx), "wz": float(wz)}
        }})

    def stop(self) -> None:
        # TODO: stop wheels
        # pass
        log.info("motor.stop", extra={"event": {
            "stage": "motion", "action": "stop", "driver": self.name
        }})

    def shutdown(self) -> None:
        # TODO: cleanup GPIO
        # pass
        log.info("motor.shutdown", extra={"event": {
            "stage": "motion", "action": "shutdown", "driver": self.name
        }})
    
    def set_relay(self, state, name: str, on: bool) -> None:
        """Hardware control only - state already updated in main.py."""
        # TODO: Control GPIO pin for relay
        log.info("motor.relay", extra={"event": {
            "stage": "motion", "action": "relay",
            "driver": self.name, "relay": name, "on": on
        }})
    
    def is_permission_active(self) -> bool:
        """Check if permission relay is active."""
        if not self._connected or not self.state:
            return False
        return getattr(self.state, 'permission_active', False)
    
    def is_starter_active(self) -> bool:
        """Check if starter relay is active."""
        if not self._connected or not self.state:
            return False
        return getattr(self.state, 'starter_active', False)
    
    def convert_command(self, state, speed: float, forward: float, turn: float) -> None:
        """Convert normalized command to raspbot format (vx, wz velocities)."""
        # Clamp normalized values
        forward_norm = max(-1.0, min(1.0, forward)) if forward is not None else 0.0
        turn_norm = max(-1.0, min(1.0, turn)) if turn is not None else 0.0
        speed_norm = max(0.0, min(1.0, speed)) if speed is not None else 0.0
        
        # Load config for motion parameters
        try:
            cfg = get_config().raw_data
            motion_cfg = cfg.get("motion", {})
            speed_mps = float(motion_cfg.get("speed_mps", 0.6))
            turn_speed_dps = float(motion_cfg.get("turn_speed_dps", 90.0))
            turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
            max_yaw_rate = turn_speed_dps * math.pi / 180.0
        except Exception as e:
            log.warning(f"Failed to load config for convert_command, using defaults: {e}")
            speed_mps = 0.6
            max_yaw_rate = 90.0 * math.pi / 180.0
        
        # Convert to velocities
        state.last_vx = forward_norm * speed_norm * speed_mps
        state.last_wz = turn_norm * speed_norm * max_yaw_rate  # Умножаем на speed_norm, чтобы при speed=0 поворот не применялся

