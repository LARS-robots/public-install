try:
    from rpi_hardware_pwm import HardwarePWM
except Exception:
    HardwarePWM = None

class ElectricTrainMotor:
    name = "electric_train"

    def __init__(self, config: dict):
        cfg = config["pwm_motors"]

        # Hardware PWM channels (not GPIO numbers)
        self.left_channel = cfg["left_pwm_channel"]
        self.right_channel = cfg["right_pwm_channel"]

        self.pwm_chip = cfg.get("pwm_chip", 0)
        self.freq = cfg.get("pwm_freq", 50)

        # Duty cycle in percent (0–100)
        self.ppm_min = cfg["ppm_min_dc"]
        self.ppm_neutral = cfg["ppm_neutral_dc"]
        self.ppm_max = cfg["ppm_max_dc"]

        self.invert_pwm = bool(cfg.get("invert_pwm", False))

        self.left_pwm = HardwarePWM(
            pwm_channel=self.left_channel,
            chip=self.pwm_chip,
            hz=self.freq
        )

        self.right_pwm = HardwarePWM(
            pwm_channel=self.right_channel,
            chip=self.pwm_chip,
            hz=self.freq
        )

        # Start in neutral
        self.left_pwm.start(self.ppm_neutral)
        self.right_pwm.start(self.ppm_neutral)

    def _throttle_to_dc(self, throttle: float) -> float:
        throttle = max(-1.0, min(1.0, throttle))

        if throttle >= 0.0:
            return self.ppm_neutral + throttle * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + throttle * (self.ppm_neutral - self.ppm_min)

    # Если у нас стоит оптрон после Распберри и инвертирует сигнал
    def _apply_inversion(self, dc: float) -> float:
        dc = self._clamp_dc(dc)
        if self.invert_pwm:
            return 100.0 - dc
        return dc    

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        dc = self._apply_inversion(dc)
        self.left_pwm.change_duty_cycle(dc)

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        dc = self._apply_inversion(dc)
        self.right_pwm.change_duty_cycle(dc)

    def stop(self):
        ppm_neutral = self._apply_inversion(self.ppm_neutral)
        self.left_pwm.change_duty_cycle(ppm_neutral)
        self.right_pwm.change_duty_cycle(ppm_neutral)

    def shutdown(self):
        self.stop()
        self.left_pwm.stop()
        self.right_pwm.stop()


if __name__ == "__main__":
    import time
    import sys
    from pathlib import Path
    
    # Add parent directory to path to import config_loader
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config_loader import find_config_file
    
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        import tomli as tomllib  # Fallback for Python < 3.11

    print("=== ElectricTrainMotor hardware PWM test ===")

    config_path = find_config_file()
    if not config_path:
        raise FileNotFoundError("config.toml not found")
    
    with open(config_path, "rb") as f:
        config = tomllib.load(f)

    motor = ElectricTrainMotor(config)

    try:
        print("Neutral (2s)")
        time.sleep(2)

        print("Left motor forward")
        motor.set_left(1.0)
        motor.set_right(0.0)
        time.sleep(3)

        print("Right motor forward")
        motor.set_left(0.0)
        motor.set_right(1.0)
        time.sleep(3)

        print("Both motors forward")
        motor.set_left(1.0)
        motor.set_right(1.0)
        time.sleep(3)

        print("Stop")
        motor.stop()
        time.sleep(2)

    finally:
        print("Shutdown")
        motor.shutdown()
