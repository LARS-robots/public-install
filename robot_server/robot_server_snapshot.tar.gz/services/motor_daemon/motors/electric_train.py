import os
import time
import lgpio
try:
    from gpiozero import PWMOutputDevice
    from gpiozero.pins import Factory
except Exception as e:
    print(f"Error importing gpiozero: {e}")
    PWMOutputDevice = None
    Factory = None
    


# =============================================================
# SAFE LGPIO PIN IMPLEMENTATION (bypasses gpiozero board_info)
# =============================================================

class SafeLGPIOPin:
    """
    Minimal raw LGPIO pin wrapper for gpiozero.
    Used only for PWMOutputDevice.
    """

    def __init__(self, factory, number):
        self.factory = factory
        self.number = int(number)
        self.handle = factory._handle

        # Claim pin as OUTPUT
        lgpio.gpio_claim_output(self.handle, self.number)

    def close(self):
        # No cleanup needed – chip closes in factory
        pass

    def output_with_state(self, state: bool):
        lgpio.gpio_write(self.handle, self.number, 1 if state else 0)


# =============================================================
# SAFE LGPIO FACTORY
# =============================================================

class SafeLGPIOFactory(Factory):
    """
    Replacement for gpiozero.lgpio.LGPIOFactory
    that:
      ✘ does NOT use board_info
      ✘ does NOT reserve pins
      ✔ uses BCM numbers directly
      ✔ works inside Docker
    """

    def __init__(self, chip=0):
        super().__init__()
        self._chip = chip
        print(f"[SAFE] Opening gpiochip{chip}")
        self._handle = lgpio.gpiochip_open(chip)
        print(f"[SAFE] Handle: {self._handle}")

    #
    # Disable gpiozero's board mapping system
    #
    @property
    def board_info(self):
        return None

    def reserve_pins(self, *args, **kwargs):
        return  # skip reservation entirely

    #
    # Provide raw BCM pin object
    #
    def pin(self, number):
        return SafeLGPIOPin(self, number)

    #
    # Cleanup
    #
    def close(self):
        print("[SAFE] Closing chip")
        lgpio.gpiochip_close(self._handle)


# =============================================================
# ELECTRIC TRAIN MOTOR DRIVER
# =============================================================

class ElectricTrainMotor:
    name = "electric_train"

    def __init__(self, config: dict):
        self._assert_gpiochips_exist()

        cfg = config["pwm_motors"]

        self.left_pin = int(cfg["left_gpio"])
        self.right_pin = int(cfg["right_gpio"])
        self.freq = cfg.get("pwm_freq", 50)

        self.ppm_min = cfg["ppm_min_dc"]
        self.ppm_neutral = cfg["ppm_neutral_dc"]
        self.ppm_max = cfg["ppm_max_dc"]
        self.invert_pwm = bool(cfg.get("invert_pwm", False))

        self.working_chip = 0
        print(f"[GPIO] Initializing SafeLGPIOFactory on gpiochip{self.working_chip}")

        self.pin_factory = SafeLGPIOFactory(chip=self.working_chip)

        # Create PWM outputs
        self.left_pwm = PWMOutputDevice(
            pin=self.left_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral),
            pin_factory=self.pin_factory
        )

        self.right_pwm = PWMOutputDevice(
            pin=self.right_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral),
            pin_factory=self.pin_factory
        )

        print("[GPIO] PWM devices initialized successfully")

    # =============================================================
    # INTERNAL HELPERS
    # =============================================================

    @staticmethod
    def _assert_gpiochips_exist():
        available = [
            f"/dev/gpiochip{i}"
            for i in range(8)
            if os.path.exists(f"/dev/gpiochip{i}")
        ]

        if not available:
            raise RuntimeError(
                "No /dev/gpiochip* devices found.\n"
                "Check Docker compose device mappings."
            )

        print(f"[GPIO] Detected chips: {', '.join(available)}")

    def _inv(self, dc: float):
        v = dc / 100.0
        return 1.0 - v if self.invert_pwm else v

    def _throttle_to_dc(self, throttle: float) -> float:
        t = max(-1.0, min(1.0, throttle))

        if t >= 0:
            return self.ppm_neutral + t * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + t * (self.ppm_neutral - self.ppm_min)

    # =============================================================
    # MOTOR CONTROL PUBLIC API
    # =============================================================

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.left_pwm.value = self._inv(dc)

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.right_pwm.value = self._inv(dc)

    def stop(self):
        v = self._inv(self.ppm_neutral)
        self.left_pwm.value = v
        self.right_pwm.value = v

    def shutdown(self):
        print("[GPIO] Shutting down motors")
        self.stop()
        self.left_pwm.close()
        self.right_pwm.close()
        self.pin_factory.close()


# =============================================================
# FULL SELF-TEST
# =============================================================
if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent))

    from config_loader import get_config

    cfg = get_config().raw_data

    print("\n========== ELECTRIC TRAIN MOTOR TEST ==========\n")

    motor = ElectricTrainMotor(cfg)

    print("Neutral...")
    motor.set_left(0)
    motor.set_right(0)
    time.sleep(2)

    print("Forward...")
    motor.set_left(1)
    motor.set_right(1)
    time.sleep(3)

    print("Reverse...")
    motor.set_left(-1)
    motor.set_right(-1)
    time.sleep(3)

    print("Stop...")
    motor.shutdown()

