import time
from rpi_hardware_pwm import HardwarePWM


class ElectricTrainMotor:
    name = "electric_train"

    def __init__(self, config: dict):
        cfg = config["pwm_motors"]

        # === PWM hardware parameters ===
        self.left_channel  = int(cfg["left_pwm_channel"])     # 0
        self.right_channel = int(cfg["right_pwm_channel"])    # 1
        self.pwm_chip = int(cfg["pwm_chip"])                  # usually 0
        self.freq = int(cfg["pwm_freq"])                      # 50 Hz

        # === Duty cycle limits ===
        self.ppm_min = cfg["ppm_min_dc"]        # 5.0
        self.ppm_neutral = cfg["ppm_neutral_dc"] # 7.5
        self.ppm_max = cfg["ppm_max_dc"]        # 10.0

        # === Inversion flag ===
        self.invert_pwm = bool(cfg["invert_pwm"])

        # === Initialize hardware PWM drivers ===
        print(f"[PWM] Initializing hardware PWM: chip={self.pwm_chip}, freq={self.freq}")

        self.left_pwm = HardwarePWM(
            pwm_channel=self.left_channel,
            chip=self.pwm_chip,
            hz=self.freq
        )

        self.right_pwm = HardwarePWM(
            pwm_channel=self.right_channel,
            chip=self.pwm_chip,
            hz=self.freq
        )

        # Start in neutral
        self.left_pwm.start(self._inv(self.ppm_neutral))
        self.right_pwm.start(self._inv(self.ppm_neutral))

        print("[PWM] Motors initialized successfully")

    # =============================================================
    # INTERNAL HELPERS
    # =============================================================

    def _inv(self, dc: float) -> float:
        """Invert duty cycle if required."""
        return 100.0 - dc if self.invert_pwm else dc

    def _throttle_to_dc(self, throttle: float) -> float:
        """
        Converts throttle (-1..1) to RC-PWM duty cycle:
        -1 → ppm_min  
         0 → neutral  
         1 → ppm_max
        """
        t = max(-1.0, min(1.0, throttle))

        if t >= 0:
            return self.ppm_neutral + t * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + t * (self.ppm_neutral - self.ppm_min)

    # =============================================================
    # PUBLIC MOTOR CONTROL API
    # =============================================================

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.left_pwm.change_duty_cycle(self._inv(dc))

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.right_pwm.change_duty_cycle(self._inv(dc))

    def stop(self):
        neutral = self._inv(self.ppm_neutral)
        self.left_pwm.change_duty_cycle(neutral)
        self.right_pwm.change_duty_cycle(neutral)

    def shutdown(self):
        print("[PWM] Shutting down motors")
        self.stop()
        self.left_pwm.stop()
        self.right_pwm.stop()
        print("[PWM] Motors stopped")


if __name__ == "__main__":
    import sys
    from pathlib import Path

    # Добавляем путь к корню проекта для загрузки конфига
    sys.path.insert(0, str(Path(__file__).parent.parent))

    from config_loader import get_config

    print("\n========== ELECTRIC TRAIN MOTOR SELF-TEST ==========\n")

    cfg = get_config().raw_data
    motor = ElectricTrainMotor(cfg)

    try:
        print("Neutral (2s)")
        motor.set_left(0)
        motor.set_right(0)
        time.sleep(4)

        print("Forward full throttle (3s)")
        motor.set_left(0.5)
        motor.set_right(0.5)
        time.sleep(5)

        print("Neutral (2s)")
        motor.set_left(0)
        motor.set_right(0)
        time.sleep(4)

        print("Reverse full throttle (3s)")
        motor.set_left(-0.5)
        motor.set_right(-0.5)
        time.sleep(5)

        print("Neutral (2s)")
        motor.set_left(0)
        motor.set_right(0)
        time.sleep(2)

    finally:
        print("Stopping motors...")
        motor.shutdown()
        print("Self-test finished.")
