import os

try:
    from gpiozero import PWMOutputDevice, Device
    from gpiozero.pins.lgpio import LGPIOFactory
except ImportError:
    PWMOutputDevice = None
    LGPIOFactory = None
    print("WARNING: gpiozero is not installed; using mock mode")


class ElectricTrainMotor:
    name = "electric_train"

    def __init__(self, config: dict):
        """
        Initialize motor driver with safe, runtime-only GPIO setup.
        """

        # Sanity checks
        self._assert_gpiochips_exist()

        cfg = config["pwm_motors"]

        self.left_pin = cfg["left_gpio"]
        self.right_pin = cfg["right_gpio"]
        self.freq = cfg.get("pwm_freq", 50)

        self.ppm_min = cfg["ppm_min_dc"]
        self.ppm_neutral = cfg["ppm_neutral_dc"]
        self.ppm_max = cfg["ppm_max_dc"]
        self.invert_pwm = bool(cfg.get("invert_pwm", False))

        # Always use chip0 on RPi5 — validated manually
        self.working_chip = 0
        print(f"[GPIO] Initializing LGPIOFactory on gpiochip{self.working_chip}")

        # IMPORTANT: factory created at runtime only
        self.pin_factory = LGPIOFactory(chip=self.working_chip)

        # Create PWM devices bound to this pin factory
        self.left_pwm = PWMOutputDevice(
            pin=self.left_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral),
            pin_factory=self.pin_factory
        )

        self.right_pwm = PWMOutputDevice(
            pin=self.right_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral),
            pin_factory=self.pin_factory
        )

        print("[GPIO] PWM devices initialized successfully")

    # ----------------------------------------------------------------------
    # INTERNALS
    # ----------------------------------------------------------------------

    @staticmethod
    def _assert_gpiochips_exist():
        """Verify GPIO chip devices exist."""
        chips = [f"/dev/gpiochip{i}" for i in range(8)]
        available = [c for c in chips if os.path.exists(c)]

        if not available:
            raise RuntimeError(
                "No /dev/gpiochip* devices found — LGPIO cannot operate.\n"
                "Check Docker device mappings."
            )

        print(f"[GPIO] Detected chips: {', '.join(available)}")

        # gpiomem is NOT required for LGPIO, but log if missing
        if not os.path.exists("/dev/gpiomem"):
            print("[GPIO] Note: /dev/gpiomem missing (not required for LGPIO)")

    # ----------------------------------------------------------------------

    def _inv(self, dc: float):
        """Convert duty cycle to gpiozero value."""
        v = dc / 100.0
        return 1.0 - v if self.invert_pwm else v

    def _throttle_to_dc(self, throttle: float) -> float:
        """Convert throttle [-1..1] to duty-cyclce."""
        t = max(-1.0, min(1.0, throttle))

        if t >= 0:
            return self.ppm_neutral + t * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + t * (self.ppm_neutral - self.ppm_min)

    # ----------------------------------------------------------------------
    # MOTOR CONTROL API
    # ----------------------------------------------------------------------

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.left_pwm.value = self._inv(dc)

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.right_pwm.value = self._inv(dc)

    def stop(self):
        v = self._inv(self.ppm_neutral)
        self.left_pwm.value = v
        self.right_pwm.value = v

    def shutdown(self):
        print("[GPIO] Shutting down motors")
        self.stop()
        self.left_pwm.close()
        self.right_pwm.close()


# ----------------------------------------------------------------------
# Standalone test runner
# ----------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    import time
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent.parent))

    from config_loader import get_config

    config = get_config().raw_data

    motor = ElectricTrainMotor(config)

    motor.set_left(0)
    motor.set_right(0)
    time.sleep(3)

    motor.set_left(1)
    motor.set_right(1)
    time.sleep(4)

    motor.set_left(-1)
    motor.set_right(-1)
    time.sleep(4)

    motor.shutdown()
