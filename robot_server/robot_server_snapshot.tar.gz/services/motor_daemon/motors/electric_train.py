try:
    from gpiozero import PWMOutputDevice
except ImportError:
    print("WARNING: gpiozero is not installed, using mock PWMOutputDevice")
    PWMOutputDevice = None

class ElectricTrainMotor:
    name = "electric_train"

    def __init__(self, config: dict):
        cfg = config["pwm_motors"]

        # GPIO pin numbers (REAL pins, not PWM channels)
        self.left_pin = cfg["left_gpio"]
        self.right_pin = cfg["right_gpio"]

        self.freq = cfg.get("pwm_freq", 50)

        # Duty cycle ranges
        self.ppm_min = cfg["ppm_min_dc"]
        self.ppm_neutral = cfg["ppm_neutral_dc"]
        self.ppm_max = cfg["ppm_max_dc"]

        self.invert_pwm = bool(cfg.get("invert_pwm", False))

        # Create PWM devices (lgpio backend is provided by env var)
        self.left_pwm = PWMOutputDevice(
            pin=self.left_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral)
        )

        self.right_pwm = PWMOutputDevice(
            pin=self.right_pin,
            frequency=self.freq,
            active_high=True,
            initial_value=self._inv(self.ppm_neutral)
        )

    # Convert 0–100% duty to gpiozero 0.0–1.0 value
    def _inv(self, dc: float):
        v = dc / 100.0
        if self.invert_pwm:
            return 1.0 - v
        return v

    def _throttle_to_dc(self, throttle: float) -> float:
        t = max(-1.0, min(1.0, throttle))

        if t >= 0:
            return self.ppm_neutral + t * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + t * (self.ppm_neutral - self.ppm_min)

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.left_pwm.value = self._inv(dc)

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.right_pwm.value = self._inv(dc)

    def stop(self):
        v = self._inv(self.ppm_neutral)
        self.left_pwm.value = v
        self.right_pwm.value = v

    def shutdown(self):
        self.stop()
        self.left_pwm.close()
        self.right_pwm.close()
