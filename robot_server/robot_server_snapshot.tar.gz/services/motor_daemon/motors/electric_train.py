import RPi.GPIO as GPIO
from common.motor_iface import MotorIface


class ElectricTrainMotor:
    name = "electric_train"
    
    def __init__(self, config: dict):
        cfg = config["pwm_motors"]

        self.left_pin = cfg["left_pin"]
        self.right_pin = cfg["right_pin"]

        self.freq = cfg.get("pwm_freq", 50)

        self.ppm_min = cfg["ppm_min_dc"]
        self.ppm_neutral = cfg["ppm_neutral_dc"]
        self.ppm_max = cfg["ppm_max_dc"]

        GPIO.setmode(GPIO.BCM)

        self.left_pwm = self._init_pwm(self.left_pin)
        self.right_pwm = self._init_pwm(self.right_pin)

        # safety: always start from neutral
        self.stop()

    def _init_pwm(self, pin: int):
        GPIO.setup(pin, GPIO.OUT)
        pwm = GPIO.PWM(pin, self.freq)
        pwm.start(self.ppm_neutral)
        return pwm

    def _throttle_to_dc(self, throttle: float) -> float:
        throttle = max(-1.0, min(1.0, throttle))

        if throttle >= 0.0:
            return self.ppm_neutral + throttle * (self.ppm_max - self.ppm_neutral)
        else:
            return self.ppm_neutral + throttle * (self.ppm_neutral - self.ppm_min)

    def set_left(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.left_pwm.ChangeDutyCycle(dc)

    def set_right(self, throttle: float):
        dc = self._throttle_to_dc(throttle)
        self.right_pwm.ChangeDutyCycle(dc)

    def stop(self):
        self.set_left(0.0)
        self.set_right(0.0)

    def shutdown(self):
        self.stop()
        self.left_pwm.stop()
        self.right_pwm.stop()
        # Don't call GPIO.cleanup() here - let PWM objects clean up themselves
        self.left_pwm = None
        self.right_pwm = None
        
        
if __name__ == "__main__":
    # for the local testing
    import time
    import tomllib

    print("PWM motor driver self-test")

    # Load config
    with open("config.toml", "rb") as f:
        config = tomllib.load(f)

    driver = ElectricTrainMotor(config)

    try:
        print("Neutral (stop)")
        time.sleep(2)

        print("Forward faster")
        driver.set_left(1.0)
        driver.set_right(1.0)
        time.sleep(5)

        print("Stop")
        driver.stop()
        time.sleep(2)

    finally:
        print("Shutdown")
        driver.shutdown()
