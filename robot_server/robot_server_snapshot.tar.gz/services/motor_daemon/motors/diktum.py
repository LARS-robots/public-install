# motor_daemon/motors/diktum.py
import asyncio
import logging
import struct
import time
from typing import Dict, Any, Optional
from pathlib import Path

from common.motor_iface import MotorIface
from config_loader import get_config

log = logging.getLogger(__name__)

try:
    import serial  # pyserial
except Exception:  # pragma: no cover
    serial = None


class DiktumMotor(MotorIface):
    """
    Diktum motor driver with UART-based control.
    - No globals: serial handle & counters live in app.state or instance fields.
    - Reads parameters from config.toml ([diktum] & [motion]).
    """
    name = "diktum"

    def __init__(self):
        self._connected = False
        self._cfg: Dict[str, Any] = {}
        self._last_packet: Optional[bytes] = None
        self._seq: int = 0  # per-instance counter (NOT global)
        self._app_state = None # To hold app_state reference
        # Permission heartbeat state
        self._permission_enabled = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._heartbeat_interval = 0.10  # 100 ms

    # ---------- config ----------
    def _load_config(self) -> Dict[str, Any]:
        """Load config using centralized config loader."""
        if self._cfg:
            return self._cfg
        try:
            app_config = get_config()
            self._cfg = app_config.raw_data
            return self._cfg
        except Exception as e:
            log.warning(f"[diktum] failed to load config: {e}")
            self._cfg = {}
            return self._cfg

    def _cfg_diktum(self) -> Dict[str, Any]:
        return (self._load_config().get("diktum") or {})

    def _cfg_motion(self) -> Dict[str, Any]:
        return (self._load_config().get("motion") or {})

    def _control_index(self) -> int:
        dcfg = self._cfg_diktum()
        try:
            idx = int(dcfg.get("control_byte_index", 8))
        except Exception:
            idx = 8
        return max(0, min(25, idx))

    def _keep_mask(self) -> int:
        dcfg = self._cfg_diktum()
        m = dcfg.get("control_keep_mask", "0x3C")
        try:
            mask = int(m, 0) if isinstance(m, str) else int(m)
        except Exception:
            mask = 0x3C
        return mask & 0xFF

    def _relay_bits_cfg(self) -> Dict[str, int]:
        dcfg = self._cfg_diktum()
        default = {"permission": 5, "starter": 4, "speed2": 3, "sound": 2}
        rb = dcfg.get("relay_bits")
        if isinstance(rb, dict):
            try:
                return {str(k): int(v) for k, v in rb.items()}
            except Exception:
                return default
        return default

    # ---------- serial ----------
    def _ensure_serial(self, app_state):
        """
        Open and cache serial connection in app.state to avoid globals.
        """
        self._app_state = app_state # Keep a reference
        if getattr(app_state, "diktum_serial", None):
            return app_state.diktum_serial
        if serial is None:
            raise RuntimeError("pyserial is not installed. Install with: uv pip install pyserial")
        dcfg = self._cfg_diktum()
        device = dcfg.get("serial_device") or "/dev/ttyAMA0"
        baud = int(dcfg.get("baudrate", 115200))
        ser = serial.Serial(device, baud)
        app_state.diktum_serial = ser
        log.info("motor.connect", extra={"event": {
            "stage": "motion", "action": "serial_open",
            "driver": self.name, "device": device, "baud": baud
        }})
        return ser

    # ---------- helpers ----------
    @staticmethod
    def _hex_to_bytes(hex_str: str) -> bytearray:
        cleaned = "".join(hex_str.split())
        return bytearray.fromhex(cleaned)

    def _base_frame(self) -> bytearray:
        base_hex = (self._cfg_diktum().get("base_command") or "").strip()
        if not base_hex:
            raise ValueError("[diktum] base_command is missing in config.toml")
        pkt = self._hex_to_bytes(base_hex)
        if len(pkt) != 26 or pkt[-2:] != b"\x0D\x0A":
            raise ValueError("[diktum] base_command must be 26 bytes and end with 0D 0A")
        return pkt

    def _get_current_control(self, app_state) -> int:
        val = getattr(app_state, "diktum_control", None)
        if val is None:
            try:
                base = self._base_frame()
                idx = self._control_index()
                val = int(base[idx])
            except Exception:
                val = 0
            val &= self._keep_mask()
            setattr(app_state, "diktum_control", int(val))
        return int(val)

    def _set_current_control(self, app_state, control: int) -> None:
        setattr(app_state, "diktum_control", int(control & self._keep_mask()))

    def _pack_i16_le(self, value: int) -> bytes:
        return struct.pack("<h", int(value))

    def _clamp(self, x: float, lo: float, hi: float) -> float:
        return max(lo, min(x, hi))

    def _build_joystick_frame(self, app_state, forward: int, turn: int, speed: int) -> bytearray:
        """
        Build the 26-byte Diktum frame using raw joystick values directly.
        Matches the working implementation in diktum_packets.py.
        
        Args:
            app_state: Application state
            forward: Raw forward/backward value (-2000 to 2000), + = forward
            turn: Raw turn value (-2000 to 2000), + = left
            speed: Raw speed value (0 to 2000)
        """
        pkt = self._base_frame()

        micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
        pkt[0:4] = struct.pack("<I", micros)

        self._seq = (self._seq + 1) & 0xFFFFFFFF
        pkt[4:8] = struct.pack("<I", self._seq)

        pkt[self._control_index()] = self._get_current_control(app_state) & 0xFF
        pkt[9] = 0x00

        # Clamp raw values to valid range
        clamped_speed = max(0, min(2000, speed))
        if clamped_speed <= 280:
            clamped_speed = 0
        pkt[10:12] = self._pack_i16_le(clamped_speed)

        # Match working code byte order: turn at 12-14, forward at 14-16
        # joy1: turn (bytes 12-14) - Diktum spec: positive = clockwise (right), negative = counter-clockwise (left)
        # Backend convention: positive = left, so we pass turn_value directly (no negation needed based on working code)
        clamped_turn = max(-2000, min(2000, turn))
        pkt[12:14] = self._pack_i16_le(clamped_turn)

        # joy0: forward/backward (bytes 14-16)
        clamped_forward = max(-2000, min(2000, forward))
        pkt[14:16] = self._pack_i16_le(clamped_forward)

        # Zero out remaining channels (bytes 16-24)
        for i in range(4):
            pkt[16 + i*2 : 18 + i*2] = b"\x00\x00"
        
        log.info("pakaged frame: %s", " ".join(f"{b:02X}" for b in pkt))
        return pkt

    # ---------- MotorIface ----------
    def connect(self, app_state) -> None:
        self._load_config()
        self._ensure_serial(app_state)
        self._connected = True
        log.info("motor.connect", extra={"event": {"stage": "motion", "action": "connect", "driver": self.name}})

    def set_throttle(self, value: float) -> None:
        log.info("motor.throttle", extra={"event": {"stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)}})

    def set_steer(self, value: float) -> None:
        log.info("motor.steer", extra={"event": {"stage": "motion", "action": "steer", "driver": self.name, "value": float(value)}})

    def command_velocity(self, vx: float, wz: float) -> None:
        """
        Command velocity - for Diktum, we use raw joystick values directly from app_state.
        Raw values (speed/forward/turn) are set by motion daemon from NATS commands.
        Matches working implementation from diktum_test_service.py.
        """
        if not self._app_state:
            log.warning("Diktum driver not connected, cannot send velocity command.")
            return
        
        # Block motion commands if permission is not enabled
        if not self._permission_enabled:
            log.warning("[diktum] Permission not enabled, ignoring velocity command")
            return

        # Get raw joystick values from app_state (set by motion daemon from NATS)
        forward_value = getattr(self._app_state, "diktum_forward", None)
        turn_value = getattr(self._app_state, "diktum_turn", None)
        speed_value = getattr(self._app_state, "diktum_speed", None)
        
        # Use defaults if not provided
        if forward_value is None:
            forward_value = 0
        if turn_value is None:
            turn_value = 0
        if speed_value is None:
            speed_value = 0
        
        # Build frame with raw values directly (no normalization)
        pkt = self._build_joystick_frame(
            app_state=self._app_state,
            forward=forward_value,
            turn=turn_value,
            speed=speed_value
        )

        n = self.write_packet(self._app_state, pkt)

        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity",
            "driver": self.name,
            "raw_values": {"speed": speed_value, "forward": forward_value, "turn": turn_value},
            "bytes": int(n),
            "frame": " ".join(f"{b:02X}" for b in pkt)
        }})

    def stop(self) -> None:
        log.info("motor.stop", extra={"event": {"stage": "motion", "action": "stop", "driver": self.name}})

    def shutdown(self) -> None:
        log.info("motor.shutdown", extra={"event": {"stage": "motion", "action": "shutdown", "driver": self.name}})

    # ---------- Relay control ----------
    def _base_control_from_config(self) -> int:
        try:
            pkt = self._base_frame()
            return int(pkt[self._control_index()])
        except Exception:
            return 0

    def set_relay(self, app_state, name: str, on: bool) -> Dict[str, Any]:
        if name == "stop":
            pkt = self._build_command_with_control("00")
            n = self.write_packet(app_state, pkt)
            self._set_current_control(app_state, 0)
            log.info("diktum.relay.stop", extra={"event": {
                "stage": "motion", "action": "relay_stop", "driver": self.name, "bytes": int(n)
            }})
            return {"ok": True, "driver": self.name, "relay": "stop", "on": False, "bytes_written": int(n)}
        
        if name != "permission" and not self._permission_enabled:
            error_msg = f"[diktum] Permission not enabled, cannot set relay: {name}"
            log.warning(error_msg)
            raise ValueError(error_msg)

        rb = self._relay_bits_cfg()
        if name not in rb:
            raise ValueError(f"[diktum] unknown relay: {name}")
        bit = int(rb[name])

        current = self._get_current_control(app_state)
        new_val = (current | (1 << bit)) if on else (current & ~(1 << bit))
        new_val &= self._keep_mask()

        pkt = self._build_command_with_control(f"{new_val:02X}")
        n = self.write_packet(app_state, pkt)
        self._set_current_control(app_state, new_val)

        # Update permission heartbeat state if permission relay toggled
        if name == "permission":
            self.set_permission_enabled(bool(on))

        log.info("diktum.relay", extra={"event": {
            "stage": "motion", "action": "relay_write", "driver": self.name,
            "relay": name, "on": bool(on), "control_hex": f"{new_val:02X}", "bytes": int(n)
        }})
        return {"ok": True, "driver": self.name, "relay": name, "on": bool(on), "bytes_written": int(n)}

    # ---------- low-level write & cache ----------
    def _build_command_with_control(self, control_hex: str) -> bytearray:
        pkt = self._base_frame()
        idx = self._control_index()
        try:
            pkt[idx] = int(control_hex, 16) & 0xFF
        except Exception:
            raise ValueError(f"[diktum] invalid control hex: {control_hex}")
        return pkt

    def write_packet(self, app_state, packet: bytes | bytearray) -> int:
        ser = self._ensure_serial(app_state)
        data = bytes(packet)
        n = ser.write(data)
        self._last_packet = data
        return int(n)

    def get_last_packet(self) -> Optional[bytes]:
        return self._last_packet

    # ---------- public helpers for MotorService ----------
    def send_permission(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "permission")

    def send_starter(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "starter")

    def send_stop(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "stop")

    def _send_named_control(self, app_state, name: str) -> Dict[str, Any]:
        mapping: Dict[str, str] = (self._cfg_diktum().get("command_bytes") or {})
        if name not in mapping:
            raise ValueError(f"[diktum] command_bytes.{name} is missing in config.toml")
        control_hex = mapping[name]
        pkt = self._build_command_with_control(control_hex)
        n = self.write_packet(app_state, pkt)
        self._set_current_control(app_state, int(control_hex, 16))
        log.info("diktum.control", extra={"event": {
            "stage": "motion", "action": "uart_write", "driver": self.name,
            "command": name, "control_hex": control_hex, "bytes": int(n)
        }})
        return {"ok": True, "driver": self.name, "command": name, "bytes_written": int(n)}

    # ---------- Permission heartbeat ----------
    def set_permission_enabled(self, enabled: bool) -> None:
        """Enable or disable permission heartbeat."""
        self._permission_enabled = bool(enabled)

    def is_permission_active(self) -> bool:
        """Returns current permission state (for telemetry)."""
        return bool(self._permission_enabled)

    async def start_background_tasks(self, app_state) -> None:
        """Start background tasks (permission heartbeat loop)."""
        if self._heartbeat_task is None:
            self._heartbeat_task = asyncio.create_task(self._permission_heartbeat_loop(app_state))
            log.info("diktum.heartbeat", extra={"event": {
                "stage": "motion", "action": "heartbeat_start", "driver": self.name
            }})

    async def stop_background_tasks(self) -> None:
        """Stop background tasks (permission heartbeat loop)."""
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
            self._heartbeat_task = None
            log.info("diktum.heartbeat", extra={"event": {
                "stage": "motion", "action": "heartbeat_stop", "driver": self.name
            }})

    async def _permission_heartbeat_loop(self, app_state) -> None:
        """Internal loop that sends permission pulse every 100ms when enabled."""
        while True:
            if self._permission_enabled:
                try:
                    # Send the same command as relay(permission=on)
                    self.set_relay(app_state, "permission", True)
                except Exception as e:
                    log.error(f"[heartbeat] Failed to send permission pulse: {e}")
            await asyncio.sleep(self._heartbeat_interval)

