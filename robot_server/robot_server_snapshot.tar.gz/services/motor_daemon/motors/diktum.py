import asyncio
import logging
import struct
import time
import serial
from typing import Dict, Any, Optional

from common.motor_iface import MotorIface
from config_loader import get_config

log = logging.getLogger(__name__)


class DiktumMotor(MotorIface):
    name = "diktum"

    def __init__(self):
        self.cfg: Dict[str, Any] = {}
        self.seq = 0
        self.state = None
        self.serial_handle = None

        self.permission = False

        self.receive_period = 0.01  # 100Hz - fast command processing (used in main.py)
        self.send_period = 0.072    # ~14Hz - command sending (used in main.py)
        self.motion_timeout_ms = 1000
        
        # Queue for packets ready to send (keeps last 100)
        self.packet_queue = asyncio.Queue(maxsize=100)

        self.last_packet = None

    # ---------------- CONFIG ----------------
    def load_cfg(self):
        if not self.cfg:
            try:
                self.cfg = get_config().raw_data
            except Exception:
                self.cfg = {}
        return self.cfg

    def cfg_diktum(self):
        return self.load_cfg().get("diktum", {})

    # ---------------- CONNECTION ----------------
    def connect(self, app_state) -> None:
        """Initialize driver with app state."""
        self.state = app_state

    # ---------------- SERIAL ----------------
    def ensure_serial(self, state):
        self.state = state
        if self.serial_handle:
            return self.serial_handle

        if serial is None:
            raise RuntimeError("pyserial missing")

        d = self.cfg_diktum()
        dev = d.get("serial_device", "/dev/ttyAMA0")
        baud = int(d.get("baudrate", 115200))

        self.serial_handle = serial.Serial(dev, baud)
        return self.serial_handle

    # ---------------- FRAME HELPERS ----------------
    def base_frame(self):
        base_hex = self.cfg_diktum().get("base_command", "").strip()
        pkt = bytearray.fromhex(base_hex)
        if len(pkt) != 26 or pkt[-2:] != b"\x0D\x0A":
            raise ValueError("Invalid base frame")
        return pkt

    def pack16(self, value: int) -> bytes:
        return struct.pack("<h", int(value))

    # ---------------- RELAY CONTROL ----------------
    def relay_bits(self):
        return self.cfg_diktum().get("relay_bits", {
            "permission": 5,
            "starter": 4,
            "speed2": 3,
            "sound": 2
        })

    def set_relay(self, state, name: str, on: bool):
        if name == "stop":
            pkt = self.base_frame()
            idx = self.cfg_diktum().get("control_byte_index", 8)
            pkt[idx] = 0
            self.write(state, pkt)
            self.permission = False
            # Force diktum_control to 0 in state to ensure it's cleared
            setattr(state, "diktum_control", 0)
            # Also clear any cached control values
            log.info("[DIKTUM] Stop command: cleared permission and diktum_control")
            return

        if name != "permission" and not self.permission:
            raise ValueError("Permission required")

        bits = self.relay_bits()
        bit = 1 << bits[name]

        current = getattr(state, "diktum_control", 0)
        new_val = (current | bit) if on else (current & ~bit)

        setattr(state, "diktum_control", new_val)

        if name == "permission":
            self.permission = bool(on)

        pkt = self.base_frame()
        idx = self.cfg_diktum().get("control_byte_index", 8)
        pkt[idx] = new_val

        self.write(state, pkt)

    # ---------------- BUILD JOYSTICK FRAME ----------------
    def frame(self, state, forward: int, turn: int, speed: int):
        pkt = self.base_frame()

        micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
        pkt[0:4] = struct.pack("<I", micros)

        self.seq = (self.seq + 1) & 0xFFFFFFFF
        pkt[4:8] = struct.pack("<I", self.seq)

        idx = self.cfg_diktum().get("control_byte_index", 8)
        # Always get fresh diktum_control from state to ensure it's up to date
        # If permission is False, force control byte to 0
        if not self.permission:
            ctrl = 0
            setattr(state, "diktum_control", 0)
        else:
            ctrl = getattr(state, "diktum_control", 0)
        pkt[idx] = ctrl

        pkt[9] = 0x00

        spd = max(0, min(2000, speed))
        if spd <= 280:
            spd = 0
        pkt[10:12] = self.pack16(spd)

        pkt[12:14] = self.pack16(max(-2000, min(2000, turn)))
        pkt[14:16] = self.pack16(max(-2000, min(2000, forward)))

        for i in range(4):
            pkt[16 + i*2 : 18 + i*2] = b"\x00\x00"

        return pkt

    # ---------------- UART WRITE ----------------
    def write(self, state, packet: bytes | bytearray):
        """Write packet directly to serial (used for immediate relay commands)."""
        ser = self.ensure_serial(state)
        n = ser.write(bytes(packet))
        self.last_packet = bytes(packet)
        return n

    # ---------------- PUBLIC VELOCITY ----------------
    def command_velocity(self):
        """Build command packet and add to queue for sending."""
        if not self.permission:
            return

        forward = getattr(self.state, "diktum_forward", 0)
        turn = getattr(self.state, "diktum_turn", 0)
        speed = getattr(self.state, "diktum_speed", 0)

        pkt = self.frame(self.state, forward, turn, speed)
        
        # Add to queue (drops oldest if full)
        try:
            self.packet_queue.put_nowait(bytes(pkt))
        except asyncio.QueueFull:
            # Queue full, try to drop oldest
            try:
                self.packet_queue.get_nowait()
                self.packet_queue.put_nowait(bytes(pkt))
            except asyncio.QueueEmpty:
                pass


