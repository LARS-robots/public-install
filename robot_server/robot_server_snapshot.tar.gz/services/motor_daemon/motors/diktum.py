import asyncio
import logging
import struct
import time
import serial
from typing import Dict, Any, Optional

from common.motor_iface import MotorIface
from config_loader import get_config

log = logging.getLogger(__name__)


class DiktumMotor(MotorIface):
    name = "diktum"

    def __init__(self):
        self.cfg: Dict[str, Any] = {}
        self.seq = 0
        self.state = None
        self.serial_handle = None

        self.receive_period = 0.01  # 100Hz - fast command processing (used in main.py)
        self.send_period = 0.072    # ~14Hz - command sending (used in main.py)
        self.motion_timeout_ms = 1000
        
        # Queue for packets ready to send (keeps last 100)
        self.packet_queue = asyncio.Queue(maxsize=100)

        self.last_packet = None

    # ---------------- CONFIG ----------------
    def load_cfg(self):
        if not self.cfg:
            try:
                self.cfg = get_config().raw_data
            except Exception:
                self.cfg = {}
        return self.cfg

    def cfg_diktum(self):
        return self.load_cfg().get("diktum", {})

    # ---------------- CONNECTION ----------------
    def connect(self, app_state) -> None:
        """Initialize driver with app state."""
        self.state = app_state

    # ---------------- SERIAL ----------------
    def ensure_serial(self, state):
        self.state = state
        if self.serial_handle:
            return self.serial_handle

        if serial is None:
            raise RuntimeError("pyserial missing")

        d = self.cfg_diktum()
        dev = d.get("serial_device", "/dev/ttyAMA0")
        baud = int(d.get("baudrate", 115200))

        self.serial_handle = serial.Serial(dev, baud)
        return self.serial_handle

    # ---------------- FRAME HELPERS ----------------
    def base_frame(self):
        base_hex = self.cfg_diktum().get("base_command", "").strip()
        pkt = bytearray.fromhex(base_hex)
        if len(pkt) != 26 or pkt[-2:] != b"\x0D\x0A":
            raise ValueError("Invalid base frame")
        return pkt

    def pack16(self, value: int) -> bytes:
        return struct.pack("<h", int(value))

    # ---------------- RELAY CONTROL ----------------
    def relay_bits(self):
        return self.cfg_diktum().get("relay_bits", {
            "permission": 5,
            "starter": 4,
            "speed2": 3,
            "sound": 2
        })

    def set_relay(self, state, name: str, on: bool):
        """Hardware control only - state already updated in main.py."""
        # State is already updated in main.py
        # Only need to handle diktum_control byte and UART frame building
        
        if name == "stop":
            pkt = self.base_frame()
            idx = self.cfg_diktum().get("control_byte_index", 8)
            pkt[idx] = 0
            self.write(state, pkt)
            # Force diktum_control to 0 in state to ensure it's cleared
            # Unified state (permission_active, starter_active) already cleared in main.py
            old_control = getattr(state, "diktum_control", 0)
            state.diktum_control = 0
            # Clear movement values to stop command loop from sending old commands
            state.diktum_forward = 0
            state.diktum_turn = 0
            state.diktum_speed = 0
            # Clear packet queue to prevent sending old packets with enabled relays
            while not self.packet_queue.empty():
                try:
                    self.packet_queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
            # Also clear any cached control values
            # Read actual diktum_control from state after clearing to log real value
            current_control = getattr(state, "diktum_control", 0)
            log.info(f"[DIKTUM] set_relay('stop'): diktum_control cleared from 0x{old_control:02x} to 0x{current_control:02x}, cleared permission, and packet queue")
            return

        if name != "permission":
            diktum_control = getattr(state, "diktum_control", 0)
            bits = self.relay_bits()
            permission_bit = 1 << bits.get("permission", 5)
            if not (diktum_control & permission_bit):
                log.warning(f"[DIKTUM] set_relay('{name}', on={on}): permission required")
                raise ValueError("Permission required")

        bits = self.relay_bits()
        bit = 1 << bits[name]

        current = getattr(state, "diktum_control", 0)
        
        # CRITICAL: When enabling permission, ensure starter is OFF and diktum_control is clean
        # This prevents both relays from being active simultaneously after restart
        # In startup sequence, permission is enabled first, then starter
        if name == "permission" and on:
            starter_bit = 1 << bits.get("starter", 4)
            # Clear starter bit to ensure only permission is active
            current = current & ~starter_bit
            # CRITICAL: If current is not 0 and not just permission bit, force it to 0 first
            # This handles race condition where old diktum_control value might be in state
            permission_bit = 1 << bits.get("permission", 5)
            if current != 0 and current != permission_bit:
                log.warning(f"[DIKTUM] set_relay('permission', on=True): diktum_control was not clean (0x{current:02x}), forcing to 0 first")
                current = 0
        
        new_val = (current | bit) if on else (current & ~bit)

        # Update diktum_control byte for UART (unified state already updated in main.py)
        state.diktum_control = new_val
        
        log.info(f"[DIKTUM] set_relay('{name}', on={on}): diktum_control changed from 0x{current:02x} to 0x{new_val:02x}")

        # Build full frame with timestamp/sequence for relay writes
        pkt = self.base_frame()
        micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
        pkt[0:4] = struct.pack("<I", micros)
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        pkt[4:8] = struct.pack("<I", self.seq)
        idx = self.cfg_diktum().get("control_byte_index", 8)
        pkt[idx] = new_val & 0xFF
        # Zero velocity fields for relay-only packet
        pkt[10:16] = b"\x00\x00\x00\x00\x00\x00"

        # Log only relay packets (not every write from send loop)
        try:
            log.info("[UART_RELAY] ctrl=0x%02x len=%d pkt=%s", new_val & 0xFF, len(pkt), bytes(pkt).hex()[:64])
        except Exception:
            pass

        # Send a small burst to improve latch reliability
        for _ in range(10):
            self.write(state, pkt)
            time.sleep(0.001)

    # ---------------- BUILD JOYSTICK FRAME ----------------
    def frame(self, state, forward: int, turn: int, speed: int):
        pkt = self.base_frame()

        micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
        pkt[0:4] = struct.pack("<I", micros)

        self.seq = (self.seq + 1) & 0xFFFFFFFF
        pkt[4:8] = struct.pack("<I", self.seq)

        idx = self.cfg_diktum().get("control_byte_index", 8)
        diktum_control = getattr(state, "diktum_control", 0)
        bits = self.relay_bits()
        permission_bit = 1 << bits.get("permission", 5)
        permission_active = bool(diktum_control & permission_bit)
        
        if not permission_active:
            ctrl = 0
            if diktum_control != 0:
                setattr(state, "diktum_control", 0)
        else:
            ctrl = diktum_control
        
        pkt[idx] = ctrl

        pkt[9] = 0x00

        spd = max(0, min(2000, speed))
        if spd <= 280:
            spd = 0
        pkt[10:12] = self.pack16(spd)

        pkt[12:14] = self.pack16(max(-2000, min(2000, turn)))
        pkt[14:16] = self.pack16(max(-2000, min(2000, forward)))

        for i in range(4):
            pkt[16 + i*2 : 18 + i*2] = b"\x00\x00"

        return pkt

    # ---------------- UART WRITE ----------------
    def write(self, state, packet: bytes | bytearray):
        """Write packet directly to serial (used for immediate relay commands)."""
        ser = self.ensure_serial(state)
        n = ser.write(bytes(packet))
        self.last_packet = bytes(packet)
        return n

    # ---------------- PUBLIC VELOCITY ----------------
    def command_velocity(self):
        """Build command packet and add to queue for sending."""
        if not self.state:
            return
        
        diktum_control = getattr(self.state, "diktum_control", 0)
        bits = self.relay_bits()
        permission_bit = 1 << bits.get("permission", 5)
        if not (diktum_control & permission_bit):
            return

        forward = getattr(self.state, "diktum_forward", 0)
        turn = getattr(self.state, "diktum_turn", 0)
        speed = getattr(self.state, "diktum_speed", 0)

        # Track previous values to log only on changes
        if not hasattr(self, '_last_motion_params'):
            self._last_motion_params = (None, None, None)
        
        last_forward, last_turn, last_speed = self._last_motion_params
        
        # Log only when motion parameters change
        if (forward != last_forward or turn != last_turn or speed != last_speed):
            log.info(f"[DIKTUM] command_velocity(): motion changed - speed={speed}, forward={forward}, turn={turn}")
            self._last_motion_params = (forward, turn, speed)

        pkt = self.frame(self.state, forward, turn, speed)
        
        try:
            self.packet_queue.put_nowait(bytes(pkt))
        except asyncio.QueueFull:
            try:
                self.packet_queue.get_nowait()
                self.packet_queue.put_nowait(bytes(pkt))
            except asyncio.QueueEmpty:
                pass

    def stop(self) -> None:
        """Stop motor and turn off all relays."""
        if self.state:
            self.set_relay(self.state, "stop", False)

    def is_permission_active(self) -> bool:
        """Check if permission relay is active by reading from unified state."""
        if not self.state:
            return False
        # Use unified state instead of diktum_control
        return getattr(self.state, 'permission_active', False)
    
    def is_starter_active(self) -> bool:
        """Check if starter relay is active by reading from unified state."""
        if not self.state:
            return False
        # Use unified state instead of diktum_control
        return getattr(self.state, 'starter_active', False)
    
    def convert_command(self, state, speed: float, forward: float, turn: float) -> None:
        """Convert normalized command (-1.0 to 1.0) to diktum format (-2000 to 2000)."""
        if speed is not None:
            state.diktum_speed = int(max(0, min(2000, speed * 2000)))
        if forward is not None:
            state.diktum_forward = int(max(-2000, min(2000, forward * 2000)))
        if turn is not None:
            state.diktum_turn = int(max(-2000, min(2000, turn * 2000)))

