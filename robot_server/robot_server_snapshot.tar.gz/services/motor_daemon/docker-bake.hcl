group "default" {
  targets = ["motor-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, overridden from Python

target "motor-daemon-base" {
  context    = "./services/motor_daemon"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Use variable
}

target "motor-daemon-local" {
  inherits = ["motor-daemon-base"]
  tags     = ["motor-daemon:local"]
  output   = ["type=docker"]  # Load into local Docker for compose
}