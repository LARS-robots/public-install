/*
group "default" {
  targets = ["motor-daemon-local"]
}

variable "PLATFORM" { default = "linux/amd64" }

target "motor-daemon-base" {
  context    = "./services/motor_daemon"
  dockerfile = "Dockerfile"
  target     = "base"
  platforms  = ["linux/amd64"]
}

target "motor-daemon-arm64" {
  context    = "./services/motor_daemon"
  dockerfile = "Dockerfile"
  target     = "rpi"
  platforms  = ["linux/arm64"]
}

# Chooses correct target based on PLATFORM variable
target "motor-daemon-local" {
  inherits = ["motor-daemon-${PLATFORM == "linux/arm64" ? "arm64" : "base"}"]
  output   = ["type=docker"]
  tags     = ["motor-daemon:local"]
}
*/
group "default" {
  targets = ["motor-daemon-local"]
}

variable "VERSION" { default = "dev" }
variable "PLATFORM" { default = "linux/amd64" }  # Default, overridden from Python

target "motor-daemon-base" {
  context    = "./services/motor_daemon"
  dockerfile = "Dockerfile"
  platforms  = [PLATFORM]  # Use variable
}

target "motor-daemon-local" {
  inherits = ["motor-daemon-base"]
  tags     = ["motor-daemon:local"]
  output   = ["type=docker"]  # Load into local Docker for compose
}
