#!/usr/bin/env python3
"""
Logging setup for motor daemon.
No global variables - returns logger instance.
"""
import logging
import os
import sys
from pathlib import Path


def _normalize_nats_url(nats_url: str) -> str:
    """Normalize NATS URL: replace 127.0.0.1/localhost with 'nats' in Docker."""
    if not nats_url:
        return ""
    
    nats_url = nats_url.strip().rstrip(':').rstrip()
    
    # In Docker container, use service name "nats" instead of 127.0.0.1 or localhost
    if os.path.exists("/app"):
        if "127.0.0.1" in nats_url:
            nats_url = nats_url.replace("127.0.0.1", "nats")
        elif "localhost" in nats_url:
            nats_url = nats_url.replace("localhost", "nats")
        nats_url = nats_url.strip().rstrip(':').rstrip()
    
    return nats_url


def _setup_nats_logger_path():
    """Add nats_logger to sys.path if available as volume."""
    nats_logger_path = Path("/nats_logger")
    if nats_logger_path.exists():
        sys.path.insert(0, str(nats_logger_path))
    else:
        alt_path = Path("/app") / "nats_logger"
        if alt_path.exists():
            sys.path.insert(0, str(alt_path))


def setup_logging(service_name: str) -> logging.Logger:
    """
    Setup logging and return logger instance.
    No global variables - logger is returned and should be passed as dependency.
    
    Args:
        service_name: Name of the service for logging
        
    Returns:
        Configured logger instance
    """
    _setup_nats_logger_path()
    
    # Try to use unified logging from nats_logger
    try:
        from nats_logger import setup_unified_logging
        
        nats_url = os.getenv("NATS_URL")
        if not nats_url:
            nats_url = "nats://dev:devpass@nats:4222"
        
        nats_url = _normalize_nats_url(nats_url)
        
        try:
            setup_unified_logging(
                service_name=service_name,
                nats_url=nats_url,
            )
            # Get logger and ensure it propagates to root logger
            logger = logging.getLogger(service_name)
            logger.setLevel(logging.INFO)  # Ensure level is set
            logger.propagate = True  # Ensure propagation to root logger
            return logger
        except (AttributeError, TypeError) as e:
            # Fallback if setup_unified_logging fails
            logging.getLogger(__name__).warning(
                f"setup_unified_logging failed ({e}), using fallback logging"
            )
            return _setup_fallback_logging(service_name, nats_url)
            
    except ImportError:
        # Fallback if nats_logger is not available
        logging.getLogger(__name__).warning(
            "nats_logger not available, using standard logging only"
        )
        return _setup_fallback_logging(service_name, None)


def _setup_fallback_logging(service_name: str, nats_url: str | None) -> logging.Logger:
    """Setup fallback logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )
    
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.ERROR)
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root.addHandler(sh)
    
    # Try to add NATSHandler if available
    try:
        from nats_logger import NATSHandler
        
        if nats_url is None:
            nats_url = os.getenv("NATS_URL", "nats://dev:devpass@nats:4222")
        
        nats_url = _normalize_nats_url(nats_url)
        
        nats_handler = NATSHandler(
            nats_url=nats_url,
            service_name=service_name,
            enable_secondary_subjects=False,
        )
        root.addHandler(nats_handler)
    except ImportError:
        pass  # NATSHandler not available, continue with standard logging
    
    # Get logger and ensure it propagates to root logger
    logger = logging.getLogger(service_name)
    logger.setLevel(logging.INFO)  # Ensure level is set
    logger.propagate = True  # Ensure propagation to root logger
    return logger

