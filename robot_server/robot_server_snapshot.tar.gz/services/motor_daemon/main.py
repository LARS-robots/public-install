#!/usr/bin/env python3
import asyncio
import json
import logging
import math
import os
import sys
import time
from datetime import datetime
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS

from common.motor_iface import MotorIface
from motors.simulator import SimulatorMotor
from motors.raspbot import RaspbotMotor
from motors.diktum import DiktumMotor
from config_loader import get_config
from odometry.manager import OdometryManager
from sequence import SequenceProcessor

# Добавляем путь к nats_logger если он доступен как volume
from pathlib import Path
nats_logger_path = Path("/nats_logger")
if nats_logger_path.exists():
    sys.path.insert(0, str(nats_logger_path))
else:
    # Попробуем альтернативный путь
    alt_path = Path("/app") / "nats_logger"
    if alt_path.exists():
        sys.path.insert(0, str(alt_path))

# Опциональная поддержка NATS логирования
try:
    from nats_logger import NATSHandler
    NATS_LOGGER_AVAILABLE = True
except ImportError:
    NATS_LOGGER_AVAILABLE = False
    NATSHandler = None  # type: ignore

# Унифицированная настройка логирования
try:
    from nats_logger import setup_unified_logging
    try:
        # Нормализация NATS_URL перед передачей в setup_unified_logging
        nats_url = os.getenv("NATS_URL")
        if nats_url:
            nats_url = nats_url.strip().rstrip(':').rstrip()
            # В Docker контейнере используем имя сервиса "nats" вместо 127.0.0.1
            if os.path.exists("/app") and "127.0.0.1" in nats_url:
                nats_url = nats_url.replace("127.0.0.1", "nats")
                nats_url = nats_url.strip().rstrip(':').rstrip()
        
        setup_unified_logging(
            service_name="motor-daemon",
            nats_url=nats_url,
        )
    except (AttributeError, TypeError) as e:
        # Ошибка вызова setup_unified_logging (неправильные параметры)
        # Используем fallback настройку
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s"
        )
        root = logging.getLogger()
        for handler in list(root.handlers):
            root.removeHandler(handler)
        sh = logging.StreamHandler(sys.stdout)
        sh.setLevel(logging.ERROR)
        sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        root.addHandler(sh)
        # Добавляем NATSHandler если доступен
        if NATS_LOGGER_AVAILABLE and NATSHandler:
            # Нормализация NATS_URL: убираем лишние двоеточия и пробелы
            nats_url = os.getenv("NATS_URL", "nats://dev:devpass@nats:4222")
            if nats_url:
                nats_url = nats_url.strip().rstrip(':').rstrip()
                # В Docker контейнере используем имя сервиса "nats" вместо 127.0.0.1
                if os.path.exists("/app") and "127.0.0.1" in nats_url:
                    nats_url = nats_url.replace("127.0.0.1", "nats")
                    nats_url = nats_url.strip().rstrip(':').rstrip()
            
            nats_handler = NATSHandler(
                nats_url=nats_url,
                service_name="motor-daemon",
                enable_secondary_subjects=False,
            )
            root.addHandler(nats_handler)
        logging.getLogger(__name__).warning(f"setup_unified_logging failed ({e}), using fallback logging")
except ImportError:
    # Fallback на стандартную настройку если nats_logger не доступен
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.ERROR)
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root.addHandler(sh)
    logging.getLogger(__name__).warning("nats_logger not available, using standard logging only")

log = logging.getLogger(__name__)


# -------------------------------------------------------------------
# STATE OBJECT (replaces all globals)
# -------------------------------------------------------------------
class DaemonState:
    """Container for daemon state (like FastAPI app.state)."""
    pass


# -------------------------------------------------------------------
# MOTION TIMEOUT SAFETY
# -------------------------------------------------------------------
class MotionTimeout:
    def __init__(self, state: DaemonState, driver: MotorIface, timeout_ms: int = 200):
        self.state = state
        self.driver = driver
        self.timeout_ms = timeout_ms
        self.last_motion_ts = time.time()
        self.last_permission_enable_ts = 0  # Track when permission was last enabled
        self._task: Optional[asyncio.Task] = None

    def record(self):
        self.last_motion_ts = time.time()

    def record_permission_enable(self):
        """Record when permission is enabled to prevent immediate timeout."""
        self.last_permission_enable_ts = time.time()
        self.last_motion_ts = time.time()  # Also reset motion timer

    async def start(self):
        self._task = asyncio.create_task(self._loop())

    async def _loop(self):
        while True:
            try:
                delta_ms = (time.time() - self.last_motion_ts) * 1000

                # Only stop if permission is active
                if delta_ms > self.timeout_ms:
                    if hasattr(self.driver, "is_permission_active"):
                        if not self.driver.is_permission_active():
                            await asyncio.sleep(0.05)
                            continue

                        # Don't stop if permission was enabled recently (within 500ms)
                        # This prevents stop() from being called during startup sequence
                        permission_enable_age_ms = (time.time() - self.last_permission_enable_ts) * 1000
                        if permission_enable_age_ms < 500:
                            await asyncio.sleep(0.05)
                            continue

                    # Hard stop: use stop() method available for all drivers
                    self.driver.stop()

            except Exception as e:
                log.error(f"[timeout] Failed to stop: {e}")

            await asyncio.sleep(0.1)

    def last_motion_age_ms(self) -> float:
        return (time.time() - self.last_motion_ts) * 1000


# -------------------------------------------------------------------
# MOTOR DAEMON
# -------------------------------------------------------------------
class MotorDaemon:
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.driver: Optional[MotorIface] = None
        self.config: Dict[str, Any] = {}
        self.robot_type: str = "simulator"
        self.state = DaemonState()
        self.motion_timeout: Optional[MotionTimeout] = None
        self.subscriptions = []
        self.sequence_processor: Optional[SequenceProcessor] = None  # Optional sequence processor
        
        # Odometry manager (инкапсулирует всю логику одометрии)
        self.odometry_manager: Optional[OdometryManager] = None
        
        # Command sending loops
        self._command_task: Optional[asyncio.Task] = None
        self._send_task: Optional[asyncio.Task] = None
        self.is_stopped = False
        self.last_stop_ts = 0.0

        # Command sending periods
        self.send_period = 0.072
        self.receive_period = 0.01

    # ---------------- CONFIG LOAD ----------------
    def load_config(self):
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"Loaded config: {cfg.config_path}")
        except Exception as e:
            log.warning(f"Failed to load config: {e}")
            self.config = {}
        return self.config

    # ---------------- ROBOT TYPE ----------------
    def detect_robot_type(self) -> str:
        env = os.getenv("ROBOT_TYPE")
        if env:
            return env.lower()
        return self.config.get("default", {}).get("robot_type", "simulator").lower()

    # ---------------- DRIVER FACTORY ----------------
    def create_driver(self) -> MotorIface:
        rt = self.detect_robot_type()
        self.robot_type = rt
        log.info(f"Driver selected: {rt}")

        if rt == "simulator":
            driver = SimulatorMotor()
        elif rt == "raspbot":
            driver = RaspbotMotor()
        elif rt == "diktum":
            driver = DiktumMotor()
        else:
            raise RuntimeError(f"Unknown robot type: {rt}")

        driver.connect(self.state)
        return driver

    # ---------------- TELEMETRY ----------------
    async def publish_telemetry(self, state: str, last_cmd=None, error=None):
        if not self.nc:
            return
        try:
            t = {
                "state": state,
                "lastCmd": last_cmd,
                "error": error,
                "ts": time.time(),
                "robot_type": self.robot_type,
                "permission_active": self.driver.is_permission_active() if hasattr(self.driver, "is_permission_active") else False,
                "last_motion_ms": self.motion_timeout.last_motion_age_ms() if self.motion_timeout else None,
            }
            msg = json.dumps(t, separators=(",", ":"))
            await self.nc.publish("motors.telemetry.status", msg.encode())
        except Exception as e:
            log.debug(f"Telemetry error: {e}")

    # ---------------- CONTROLLER METHODS (SINGLE WRITER) ----------------
    async def exec_move(self, speed: float, forward: float, turn: float):
        """Execute move command: update state and drive hardware."""
        if not self.driver:
            return

        setattr(self.state, "last_motion_ts", time.time())

        if self.robot_type == "diktum":
            if speed is not None:
                setattr(self.state, "diktum_speed", speed)
            if forward is not None:
                setattr(self.state, "diktum_forward", forward)
            if turn is not None:
                setattr(self.state, "diktum_turn", turn)
        else:
            # Simulator/Raspbot conversion logic
            forward_norm = 0.0
            turn_norm = 0.0
            speed_norm = 0.0
            
            if forward is not None:
                forward_norm = max(-1.0, min(1.0, forward / 2000.0))
            if turn is not None:
                turn_norm = max(-1.0, min(1.0, turn / 2000.0))
            if speed is not None:
                speed_norm = max(0.0, min(1.0, speed / 2000.0))
            
            motion_cfg = self.config.get("motion", {})
            speed_mps = float(motion_cfg.get("speed_mps", 0.6))
            turn_speed_dps = float(motion_cfg.get("turn_speed_dps", 90.0))
            turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
            max_yaw_rate = turn_speed_dps * math.pi / 180.0
            
            vx = forward_norm * speed_norm * speed_mps
            wz = turn_norm * max_yaw_rate
            
            setattr(self.state, "last_vx", vx)
            setattr(self.state, "last_wz", wz)

        log.debug(f"[EXEC] move: speed={speed}, forward={forward}, turn={turn}")

    async def exec_relay(self, relay_name: str, on: bool, from_sequence: bool = False):
        """Execute relay command: update hardware and KV."""
        if not self.driver:
            return
            
        # Allow sequence-driven relays to run even if a recent stop was issued.
        # External relay commands still respect the stop latch to avoid races.
        if self.is_stopped and relay_name != "stop" and not from_sequence:
            return

        if hasattr(self.driver, "set_relay"):
            self.driver.set_relay(self.state, relay_name, on)

            # If Diktum and not a stop relay, push a few immediate frames into the queue
            if self.robot_type == "diktum" and relay_name != "stop" and hasattr(self.driver, "command_velocity"):
                try:
                    for _ in range(3):
                        # command_velocity enqueues a full frame with current diktum_control and motion
                        self.driver.command_velocity()
                except Exception as e:
                    log.debug(f"[EXEC] relay enqueue kick failed: {e}")

            # Sync to KV if diktum
            if self.robot_type == "diktum" and self.sequence_processor and self.sequence_processor.kv_store:
                if relay_name != "stop":
                    diktum_control = getattr(self.state, "diktum_control", 0)
                    await self.sequence_processor.kv_store.sync_diktum_control_to_kv(diktum_control)

        log.debug(f"[EXEC] relay: {relay_name}={on}")

    async def exec_stop(self):
        """Execute stop command: clear state, stop hardware."""
        self.is_stopped = True
        self.last_stop_ts = time.time()
        
        # Clear local state
        if self.robot_type == "diktum":
            setattr(self.state, "diktum_control", 0)
            setattr(self.state, "diktum_forward", 0)
            setattr(self.state, "diktum_turn", 0)
            setattr(self.state, "diktum_speed", 0)
        else:
            setattr(self.state, "last_vx", 0.0)
            setattr(self.state, "last_wz", 0.0)
        
        if self.driver:
            self.driver.stop()
            
        log.info("[EXEC] stop executed")
        
        await asyncio.sleep(0.1)
        self.is_stopped = False

    # ---------------- COMMAND HANDLERS ----------------
    async def handle_move(self, args: Dict[str, Any], timestamp: Optional[float] = None):
        if not self.driver:
            await self.publish_telemetry("error", "move", "driver_not_initialized")
            return

        speed = args.get("speed")
        forward = args.get("forward")
        turn = args.get("turn")

        await self.exec_move(speed, forward, turn)
        await self.publish_telemetry("running", "move")
        
    async def handle_start_engine(self):
        """Start engine using startup sequence if not already started."""
        if not self.sequence_processor or not self.sequence_processor.kv_store:
            log.warning("[MAIN] Sequence processor not available")
            return
        
        # Check current engine state
        state = await self.sequence_processor.kv_store.load_state()
        motor_state = state.get("motor_state", {})
        engine_state = motor_state.get("engine_state", "ENGINE_OFF")
        permission_active = motor_state.get("permission_active", False)
        seq = state.get("current_sequence")
        seq_state = state.get("sequence_state", "IDLE")
        
        # Log current KV snapshot for visibility
        log.info("[MAIN] start_engine KV: engine=%s perm=%s starter=%s seq=%s seq_state=%s",
                 motor_state.get("engine_state"),
                 motor_state.get("permission_active"),
                 motor_state.get("starter_active"),
                 seq,
                 seq_state)
        
        # If no active sequence and sequence is idle/stopped, force engine state to OFF
        # unless we are already ready with permission (including completed sequences).
        if seq in (None, "stop") or seq_state in ("IDLE", "STOPPED"):
            if not (engine_state == "ENGINE_READY" and permission_active) and seq_state != "COMPLETED":
                motor_state["engine_state"] = "ENGINE_OFF"
                motor_state["permission_active"] = False
                motor_state["starter_active"] = False
                state["motor_state"] = motor_state
                await self.sequence_processor.kv_store.save_state(state)
                engine_state = "ENGINE_OFF"
                permission_active = False
                log.info("[MAIN] start_engine force_off KV: %s", state)
        
        if engine_state == "ENGINE_READY" and permission_active:
            log.info("[MAIN] Engine already started (KV READY+perm)")
            await self.publish_telemetry("ready", "start_engine")
            return
        if seq_state == "COMPLETED" and permission_active:
            log.info("[MAIN] Engine already started (COMPLETED+perm)")
            await self.publish_telemetry("ready", "start_engine")
            return
        
        # Start startup sequence via NATS
        log.info("[MAIN] Starting engine via startup sequence (publish motors.start_sequence startup)")
        await self.nc.publish("motors.start_sequence", json.dumps({
            "cmd": "start_sequence",
            "args": {"sequence_id": "startup"}
        }).encode())
        await self.publish_telemetry("running", "start_engine")

    async def handle_stop(self):
        await self.exec_stop()
        # Update KV so any running sequence loops see the stop immediately
        if self.sequence_processor and self.sequence_processor.kv_store:
            await self.sequence_processor.kv_store.update_current_sequence("stop")
            if self.sequence_processor.state_machine:
                await self.sequence_processor.state_machine.process()
        
        await self.publish_telemetry("stopped", "stop")

    async def handle_reset_odometry(self, args: Dict[str, Any]):
        if not self.odometry_manager:
            await self.publish_telemetry("error", "reset_odometry", "odometry_not_initialized")
            return
        
        x = float(args.get("x", 0.0))
        y = float(args.get("y", 0.0))
        yaw = float(args.get("yaw", 0.0))
        
        self.odometry_manager.reset(x, y, yaw)
        await self.publish_telemetry("ready", "reset_odometry")
        log.info(f"[MAIN] Odometry reset to: x={x:.3f}, y={y:.3f}, yaw={yaw:.3f}")

    async def handle_relay(self, args: Dict[str, Any]):
        relay = args.get("relay_name")
        on = args.get("relay_on", True)
        
        # Guard logic is still valid, but we should do it before exec
        last_stop_ts = getattr(self.state, "last_stop_ts", 0.0)
        if last_stop_ts > 0:
            if (time.time() - last_stop_ts) < 0.5:
                return

        # Refresh motion timeout when permission is enabled so it doesn't immediately auto-stop
        if relay == "permission" and on and self.motion_timeout:
            self.motion_timeout.record_permission_enable()

        await self.exec_relay(relay, on, from_sequence=False)
        await self.publish_telemetry("running", f"relay.{relay}")

    # ---------------- COMMAND LOOPS ----------------
    async def _command_loop(self):
        while True:
            try:
                if not self.driver:
                    await asyncio.sleep(0.1)
                    continue
                
                if self.robot_type == "diktum":
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity()
                    await asyncio.sleep(self.receive_period)  # 100Hz for Diktum
                else:
                    vx = getattr(self.state, "last_vx", 0.0)
                    wz = getattr(self.state, "last_wz", 0.0)
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity(vx, wz)
                    await asyncio.sleep(self.receive_period)  # 10Hz for others
                    
            except Exception as e:
                log.error(f"[command_loop] {e}")
                await asyncio.sleep(0.1)

    async def _send_loop(self):
        if self.robot_type != "diktum":
            return
        
        while True:
            try:
                if not self.driver or not hasattr(self.driver, 'packet_queue'):
                    await asyncio.sleep(0.1)
                    continue
                
                if self.is_stopped:
                    await asyncio.sleep(0.072)
                    continue
                
                if hasattr(self.driver, 'is_permission_active'):
                    if not self.driver.is_permission_active():
                        await asyncio.sleep(self.send_period)
                        continue
                
                try:
                    packet = self.driver.packet_queue.get_nowait()
                    await asyncio.to_thread(self.driver.write, self.state, packet)
                except asyncio.QueueEmpty:
                    pass
                    
            except Exception as e:
                log.error(f"[send_loop] {e}")
            
            await asyncio.sleep(self.send_period)  # ~14Hz for UART

    # ---------------- NATS MESSAGE ROUTER ----------------
    async def on_msg(self, msg):
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            
            raw_ts = data.get("ts")
            if isinstance(raw_ts, (int, float)):
                timestamp = float(raw_ts)
            else:
                timestamp = time.time()

            if cmd == "move" or cmd == "move_loop":
                await self.handle_move(args, timestamp)
            elif cmd == "stop":
                await self.handle_stop()
            elif cmd == "start_engine":
                await self.handle_start_engine()
            elif cmd == "relay":
                await self.handle_relay(args)
            elif cmd == "reset_odometry":
                await self.handle_reset_odometry(args)
            else:
                await self.publish_telemetry("error", cmd, "unknown_command")

        except Exception as e:
            log.error(f"Command error: {e}")

    # ---------------- STARTUP ----------------
    async def start(self):
        # Старт сервиса - важное событие, выводим в stdout для гарантированной видимости
        print("[START] Motor daemon starting...", file=sys.stdout, flush=True)
        
        self.load_config()
        self.driver = self.create_driver()

        self._command_task = asyncio.create_task(self._command_loop())
        if self.robot_type == "diktum":
            self._send_task = asyncio.create_task(self._send_loop())

        url = os.getenv("NATS_URL", "nats://nats:4222")
        # Очистка URL: убрать лишние двоеточия и пробелы
        if url:
            url = url.strip().rstrip(":")
            # В Docker контейнере заменить 127.0.0.1 на имя сервиса 'nats'
            if "127.0.0.1" in url or "localhost" in url:
                url = url.replace("127.0.0.1", "nats").replace("localhost", "nats")
        self.nc = await nats.connect(url)
        
        # Логирование уже настроено при импорте модуля через setup_unified_logging()

        self.odometry_manager = OdometryManager(
            self.state,
            self.config,
            self.robot_type,
            self.nc
        )
        await self.odometry_manager.initialize()
        await self.odometry_manager.start()
        log.info("[ODOMETRY] Odometry manager started")

        sub = await self.nc.subscribe("motors.*", cb=self.on_msg)
        self.subscriptions.append(sub)

        # Initialize sequence processor (optional, only for diktum)
        if self.robot_type == "diktum":
            # Pass SELF as controller to SequenceProcessor
            self.sequence_processor = SequenceProcessor(self.nc, self.config, controller=self)
            await self.sequence_processor.initialize()

        await self.publish_telemetry("ready")
        log.info("Motor daemon started.")
        # Старт сервиса завершен - выводим в stdout
        print("[START] Motor daemon started successfully", file=sys.stdout, flush=True)

        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            # Остановка сервиса - важное событие, выводим в stdout
            print("[STOP] Motor daemon shutting down...", file=sys.stdout)
            log.info("Shutting down...")
            if self.odometry_manager:
                await self.odometry_manager.stop()
            if self.sequence_processor:
                await self.sequence_processor.shutdown()
            print("[STOP] Motor daemon stopped", file=sys.stdout)


async def main():
    daemon = MotorDaemon()
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Остановка сервиса - важное событие, выводим в stdout
        print("[STOP] Motor daemon stopped by user", file=sys.stdout)
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

