#!/usr/bin/env python3
import asyncio
import json
import logging
import math
import os
import sys
import time
from datetime import datetime
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS

from common.motor_iface import MotorIface
from motors.simulator import SimulatorMotor
from motors.raspbot import RaspbotMotor
from motors.diktum import DiktumMotor
from motors.electric_train import ElectricTrainMotor
from config_loader import get_config
from odometry.manager import OdometryManager
from sequence import SequenceProcessor
from navigation import NavigationController
from logging_setup import setup_logging
from nats.js.errors import NotFoundError
from motion.mixer import arcade_to_tracks


# -------------------------------------------------------------------
# STATE OBJECT (replaces all globals)
# -------------------------------------------------------------------
class DaemonState:
    """Container for daemon state (like FastAPI app.state)."""
    # Unified relay state (for all robot types)
    permission_active: bool = False
    starter_active: bool = False
    engine_state: str = "ENGINE_OFF"
    
    # Motion state
    last_vx: float = 0.0
    last_wz: float = 0.0
    last_motion_ts: float = 0.0
    last_stop_ts: float = 0.0
    
    # Diktum-specific state
    diktum_control: int = 0
    diktum_forward: int = 0
    diktum_turn: int = 0
    diktum_speed: int = 0


# -------------------------------------------------------------------
# MOTOR DAEMON
# -------------------------------------------------------------------
class MotorDaemon:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.nc: Optional[NATS] = None
        self.driver: Optional[MotorIface] = None
        self.config: Dict[str, Any] = {}
        self.robot_type: str = "simulator"
        self.state = DaemonState()
        self.subscriptions = []
        self.sequence_processor: Optional[SequenceProcessor] = None  # Optional sequence processor
        
        # Odometry manager (инкапсулирует всю логику одометрии)
        self.odometry_manager: Optional[OdometryManager] = None
        
        # Navigation controller (автономная навигация по точкам)
        self.navigation_controller: Optional[NavigationController] = None
        
        # Command sending loops
        self._command_task: Optional[asyncio.Task] = None
        self._send_task: Optional[asyncio.Task] = None
        self._nav_task: Optional[asyncio.Task] = None
        self.is_stopped = False
        self.last_stop_ts = 0.0

        # Command sending periods
        self.send_period = 0.072
        self.receive_period = 0.01

    # ---------------- CONFIG LOAD ----------------
    def load_config(self):
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            self.logger.info(f"Loaded config: {cfg.config_path}")
        except Exception as e:
            self.logger.warning(f"Failed to load config: {e}")
            self.config = {}
        return self.config

    # ---------------- ROBOT TYPE ----------------
    def detect_robot_type(self) -> str:
        env = os.getenv("ROBOT_TYPE")
        if env:
            return env.lower()
        return self.config.get("default", {}).get("robot_type", "simulator").lower()

    # ---------------- DRIVER FACTORY ----------------
    def create_driver(self) -> MotorIface:
        rt = self.detect_robot_type()
        self.robot_type = rt
        self.logger.info(f"Driver selected: {rt}")

        if rt == "simulator":
            driver = SimulatorMotor()
        elif rt == "raspbot":
            driver = RaspbotMotor()
        elif rt == "diktum":
            driver = DiktumMotor()
        elif rt == "electric_train":
            driver = ElectricTrainMotor(self.config)
        else:
            raise RuntimeError(f"Unknown robot type: {rt}")

        if hasattr(driver, 'connect'):
            driver.connect(self.state)
            
        # Log robot mode selection
        self.logger.info(f"Robot mode: {rt}", extra={"event": {"stage": "startup", "action": "robot_mode", "robot_type": rt}})
        
        return driver

    # ---------------- TELEMETRY ----------------
    async def publish_telemetry(self, state: str, last_cmd=None, error=None):
        if not self.nc:
            return
        try:
            t = {
                "state": state,
                "lastCmd": last_cmd,
                "error": error,
                "ts": time.time(),
                "robot_type": self.robot_type,
                "permission_active": self.state.permission_active,
                "starter_active": self.state.starter_active,
                "engine_state": self.state.engine_state,
                "last_motion_ms": (time.time() - self.state.last_motion_ts) * 1000 if self.state.last_motion_ts > 0 else None,
            }
            msg = json.dumps(t, separators=(",", ":"))
            await self.nc.publish("motors.telemetry.status", msg.encode())
        except Exception as e:
            self.logger.debug(f"Telemetry error: {e}")

    # ---------------- CONTROLLER METHODS (SINGLE WRITER) ----------------
    
    async def exec_move(self, speed: float, forward: float, turn: float):
        """Execute move command: update state and drive hardware."""
        if not self.driver:
            return

        self.state.last_motion_ts = time.time()

        # Electric train uses mixer directly
        if self.robot_type == "electric_train":
            left, right = arcade_to_tracks(forward, turn)
            self.driver.set_left(left)
            self.driver.set_right(right)
            # Update state for compatibility
            self.state.last_vx = forward * (speed if speed else 1.0)
            self.state.last_wz = turn * (speed if speed else 1.0)
        else:
            # Other robots use driver's convert_command
            self.driver.convert_command(self.state, speed, forward, turn)

        # Log converted values to trace command flow
        self.logger.info(f"[EXEC] move processed: speed={speed}, forward={forward}, turn={turn}, "
                        f"converted: vx={self.state.last_vx:.3f}, wz={self.state.last_wz:.3f}")

    async def exec_relay(self, relay_name: str, on: bool, from_sequence: bool = False):
        """Execute relay command: unified logic in main.py."""
        if not self.driver:
            return
            
        # Allow sequence-driven relays to run even if a recent stop was issued.
        # External relay commands still respect the stop latch to avoid races.
        if self.is_stopped and relay_name != "stop" and not from_sequence:
            return

        # CENTRALIZED: Update unified state FIRST (for all robot types)
        if relay_name == "permission":
            self.state.permission_active = on
        elif relay_name == "starter":
            self.state.starter_active = on
        elif relay_name == "stop":
            self.state.permission_active = False
            self.state.starter_active = False
        
        # THEN: Let driver handle hardware-specific control only
        self.driver.set_relay(self.state, relay_name, on)

        # Diktum-specific: push frames to queue for immediate effect
        if self.robot_type == "diktum" and relay_name != "stop" and hasattr(self.driver, "command_velocity"):
            try:
                for _ in range(3):
                    # command_velocity enqueues a full frame with current diktum_control and motion
                    self.driver.command_velocity()
            except Exception as e:
                self.logger.debug(f"[EXEC] relay enqueue kick failed: {e}")

        # Unified KV sync for all robot types
        if self.sequence_processor and self.sequence_processor.kv_store:
            if relay_name != "stop":
                await self._sync_relay_state_to_kv()

        self.logger.debug(f"[EXEC] relay: {relay_name}={on}")
    
    async def _sync_relay_state_to_kv(self):
        """Sync unified relay state to KV store."""
        if not self.sequence_processor or not self.sequence_processor.kv_store:
            return
        
        # Use unified relay state for all robot types
        await self.sequence_processor.kv_store.sync_relay_state_to_kv(
            permission_active=self.state.permission_active,
            starter_active=self.state.starter_active
        )

    async def exec_stop(self):
        """Execute stop command: clear state, stop hardware."""
        self.is_stopped = True
        self.state.last_stop_ts = time.time()
        
        # Clear local state
        if self.robot_type == "diktum":
            self.state.diktum_control = 0
            self.state.diktum_forward = 0
            self.state.diktum_turn = 0
            self.state.diktum_speed = 0
        else:
            self.state.last_vx = 0.0
            self.state.last_wz = 0.0
        
        if self.driver:
            self.driver.stop()
            
        self.logger.info("[EXEC] stop executed")
        
        await asyncio.sleep(0.1)
        self.is_stopped = False

    # ---------------- COMMAND HANDLERS ----------------
    async def handle_move(self, args: Dict[str, Any], timestamp: Optional[float] = None):
        if not self.driver:
            await self.publish_telemetry("error", "move", "driver_not_initialized")
            return

        speed = args.get("speed")
        forward = args.get("forward")
        turn = args.get("turn")

        self.logger.info(f"[HANDLE] move command: speed={speed}, forward={forward}, turn={turn}")

        # Update manual command timestamp for navigation priority
        if self.navigation_controller:
            self.navigation_controller.last_manual_cmd_ts = time.time()

        await self.exec_move(speed, forward, turn)
        await self.publish_telemetry("running", "move")
        
    async def _check_engine_state(self):
        """Check current engine state from KV store."""
        if not self.sequence_processor or not self.sequence_processor.kv_store:
            return None
        
        state = await self.sequence_processor.kv_store.load_state()
        motor_state = state.get("motor_state", {})
        engine_state = motor_state.get("engine_state", "ENGINE_OFF")
        permission_active = motor_state.get("permission_active", False)
        seq = state.get("current_sequence")
        seq_state = state.get("sequence_state", "IDLE")
        
        return (state, motor_state, engine_state, permission_active, seq, seq_state)
    
    async def _force_engine_off_if_needed(self, state, motor_state, engine_state, permission_active, seq, seq_state):
        """Force engine state to OFF if needed."""
        if seq in (None, "stop") or seq_state in ("IDLE", "STOPPED"):
            if not (engine_state == "ENGINE_READY" and permission_active) and seq_state != "COMPLETED":
                motor_state["engine_state"] = "ENGINE_OFF"
                motor_state["permission_active"] = False
                motor_state["starter_active"] = False
                state["motor_state"] = motor_state
                await self.sequence_processor.kv_store.save_state(state)
                self.logger.info("[MAIN] start_engine force_off KV: %s", state)
                return "ENGINE_OFF", False
        return engine_state, permission_active
    
    async def _start_startup_sequence(self):
        """Start startup sequence via NATS."""
        self.logger.info("[MAIN] Starting engine via startup sequence (publish motors.start_sequence startup)")
        await self.nc.publish("motors.start_sequence", json.dumps({
            "cmd": "start_sequence",
            "args": {"sequence_id": "startup"}
        }).encode())
    
    async def handle_start_engine(self):
        """Start engine using startup sequence if not already started."""
        if not self.sequence_processor or not self.sequence_processor.kv_store:
            self.logger.warning("[MAIN] Sequence processor not available")
            return
        
        # Check current engine state
        result = await self._check_engine_state()
        if result is None:
            return
        
        state, motor_state, engine_state, permission_active, seq, seq_state = result
        
        # Log current KV snapshot for visibility
        self.logger.info("[MAIN] start_engine KV: engine=%s perm=%s starter=%s seq=%s seq_state=%s",
                         motor_state.get("engine_state"),
                         motor_state.get("permission_active"),
                         motor_state.get("starter_active"),
                         seq,
                         seq_state)
        
        # Force engine off if needed
        engine_state, permission_active = await self._force_engine_off_if_needed(
            state, motor_state, engine_state, permission_active, seq, seq_state
        )
        
        if engine_state == "ENGINE_READY" and permission_active:
            self.logger.info("[MAIN] Engine already started (KV READY+perm)")
            await self.publish_telemetry("ready", "start_engine")
            return
        if seq_state == "COMPLETED" and permission_active:
            self.logger.info("[MAIN] Engine already started (COMPLETED+perm)")
            await self.publish_telemetry("ready", "start_engine")
            return
        
        # Start startup sequence
        await self._start_startup_sequence()
        await self.publish_telemetry("running", "start_engine")

    async def handle_stop(self):
        await self.exec_stop()
        
        # Cancel navigation route when stopping
        if self.navigation_controller:
            await self.navigation_controller.handle_cancel()
        
        # Update KV so any running sequence loops see the stop immediately
        if self.sequence_processor and self.sequence_processor.kv_store:
            await self.sequence_processor.kv_store.update_current_sequence("stop")
            if self.sequence_processor.state_machine:
                await self.sequence_processor.state_machine.process()
        
        await self.publish_telemetry("stopped", "stop")

    async def handle_reset_odometry(self, args: Dict[str, Any]):
        if not self.odometry_manager:
            await self.publish_telemetry("error", "reset_odometry", "odometry_not_initialized")
            return
        
        x = float(args.get("x", 0.0))
        y = float(args.get("y", 0.0))
        yaw = float(args.get("yaw", 0.0))
        
        self.odometry_manager.reset(x, y, yaw)
        await self.publish_telemetry("ready", "reset_odometry")
        self.logger.info(f"[MAIN] Odometry reset to: x={x:.3f}, y={y:.3f}, yaw={yaw:.3f}")

    async def handle_relay(self, args: Dict[str, Any]):
        relay = args.get("relay_name")
        on = args.get("relay_on", True)
        
        # Guard logic is still valid, but we should do it before exec
        if self.state.last_stop_ts > 0:
            if (time.time() - self.state.last_stop_ts) < 0.5:
                return

        await self.exec_relay(relay, on, from_sequence=False)
        await self.publish_telemetry("running", f"relay.{relay}")

    # ---------------- COMMAND LOOPS ----------------
    async def _command_loop(self):
        while True:
            try:
                if not self.driver:
                    await asyncio.sleep(0.1)
                    continue
                
                if self.robot_type == "diktum":
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity()
                    await asyncio.sleep(self.receive_period)  # 100Hz for Diktum
                else:
                    vx = self.state.last_vx
                    wz = self.state.last_wz
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity(vx, wz)
                    await asyncio.sleep(self.receive_period)  # 10Hz for others
                    
            except Exception as e:
                self.logger.error(f"[command_loop] {e}")
                await asyncio.sleep(0.1)

    async def _send_loop(self):
        if self.robot_type != "diktum":
            return
        
        while True:
            try:
                if not self.driver or not hasattr(self.driver, 'packet_queue'):
                    await asyncio.sleep(0.1)
                    continue
                
                if self.is_stopped:
                    await asyncio.sleep(0.072)
                    continue
                
                if hasattr(self.driver, 'is_permission_active'):
                    if not self.driver.is_permission_active():
                        await asyncio.sleep(self.send_period)
                        continue
                
                try:
                    packet = self.driver.packet_queue.get_nowait()
                    await asyncio.to_thread(self.driver.write, self.state, packet)
                except asyncio.QueueEmpty:
                    pass
                    
            except Exception as e:
                self.logger.error(f"[send_loop] {e}")
            
            await asyncio.sleep(self.send_period)  # ~14Hz for UART

    # ---------------- NATS MESSAGE ROUTER ----------------
    async def on_msg(self, msg):
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            
            # Log received commands for debugging
            self.logger.info(f"[NATS] Received command: {cmd}, args={args}")
            
            raw_ts = data.get("ts")
            if isinstance(raw_ts, (int, float)):
                timestamp = float(raw_ts)
            else:
                timestamp = time.time()

            if cmd == "move" or cmd == "move_loop":
                await self.handle_move(args, timestamp)
            elif cmd == "stop":
                await self.handle_stop()
            elif cmd == "start_engine":
                await self.handle_start_engine()
            elif cmd == "relay":
                await self.handle_relay(args)
            elif cmd == "reset_odometry":
                await self.handle_reset_odometry(args)
            else:
                await self.publish_telemetry("error", cmd, "unknown_command")

        except Exception as e:
            self.logger.error(f"Command error: {e}")

    # ---------------- NAVIGATION HANDLERS ----------------
    async def on_nav_msg(self, msg):
        """Handle navigation commands from NATS."""
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            
            self.logger.info(f"[NAV] Received navigation command: {cmd}, args keys: {list(args.keys())}")
            
            if not self.navigation_controller:
                self.logger.warning("[NAV] Navigation controller not initialized")
                return
            
            if cmd == "start":
                waypoints = args.get("path", [])
                self.logger.info(f"[NAV] Start command: {len(waypoints)} waypoints received")
                if waypoints:
                    await self.navigation_controller.handle_start(waypoints)
                else:
                    self.logger.warning("[NAV] Start command missing path")
            elif cmd == "cancel":
                self.logger.info("[NAV] Cancel command received")
                await self.navigation_controller.handle_cancel()
            else:
                self.logger.warning(f"[NAV] Unknown navigation command: {cmd}")
                
        except Exception as e:
            self.logger.error(f"[NAV] Navigation command error: {e}", exc_info=True)
    
    async def _navigation_loop(self):
        """Navigation loop running at 20 Hz (50ms period)."""
        while True:
            try:
                if self.navigation_controller:
                    await self.navigation_controller.tick()
            except Exception as e:
                self.logger.error(f"[NAV] Navigation loop error: {e}", exc_info=True)
            await asyncio.sleep(0.05)  # 20 Hz

    # ---------------- STARTUP ----------------
    async def start(self):
        # Старт сервиса - важное событие, выводим в stdout для гарантированной видимости
        print("[START] Motor daemon starting...", file=sys.stdout, flush=True)
        
        self.load_config()
        self.driver = self.create_driver()

        self._command_task = asyncio.create_task(self._command_loop())
        if self.robot_type == "diktum":
            self._send_task = asyncio.create_task(self._send_loop())

        url = os.getenv("NATS_URL")
        if not url:
            # Choose fallback based on network mode
            network_mode = os.getenv("MOTOR_NETWORK_MODE", "")
            if network_mode == "host":
                url = "nats://dev:devpass@127.0.0.1:4222"
            else:
                url = "nats://dev:devpass@nats:4222"
        
        print(f"[DEBUG] main.py: Initial NATS_URL from env: {url}", flush=True)
        
        # Use normalization function for consistency
        from logging_setup import _normalize_nats_url
        url = _normalize_nats_url(url)
        
        print(f"[DEBUG] main.py: Final NATS URL to connect: {url}", flush=True)
        self.nc = await nats.connect(url)

        # Publish svc_state: starting/ready
        try:
            await self._svc_state_set("motor-daemon", "starting", {"robot_type": self.robot_type})
        except Exception:
            self.logger.debug("[SVC_STATE] Failed to publish starting status", exc_info=True)
        
        # Логирование уже настроено при импорте модуля через setup_unified_logging()

        self.odometry_manager = OdometryManager(
            self.state,
            self.config,
            self.robot_type,
            self.nc,
            driver=self.driver,
        )
        await self.odometry_manager.initialize()
        await self.odometry_manager.start()
        self.logger.info("[ODOMETRY] Odometry manager started")

        sub = await self.nc.subscribe("motors.*", cb=self.on_msg)
        self.subscriptions.append(sub)

        # Initialize navigation controller
        self.navigation_controller = NavigationController(
            self.state,
            self.driver,
            self.nc
        )
        await self.navigation_controller.initialize()
        
        # Subscribe to navigation commands
        nav_sub = await self.nc.subscribe("motors.navigation.*", cb=self.on_nav_msg)
        self.subscriptions.append(nav_sub)
        
        # Start navigation loop (20 Hz)
        self._nav_task = asyncio.create_task(self._navigation_loop())

        # Initialize sequence processor for all robot types
        self.sequence_processor = SequenceProcessor(self.nc, self.config, controller=self)
        await self.sequence_processor.initialize()

        await self.publish_telemetry("ready")
        try:
            await self._svc_state_set("motor-daemon", "ready", {"robot_type": self.robot_type})
        except Exception:
            self.logger.debug("[SVC_STATE] Failed to publish ready status", exc_info=True)
        self.logger.info("Motor daemon started.")
        # Старт сервиса завершен - выводим в stdout
        print("[START] Motor daemon started successfully", file=sys.stdout, flush=True)

        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            # Остановка сервиса - важное событие, выводим в stdout
            print("[STOP] Motor daemon shutting down...", file=sys.stdout)
            self.logger.info("Shutting down...")
            if self.odometry_manager:
                await self.odometry_manager.stop()
            if self.navigation_controller:
                await self.navigation_controller.handle_cancel()
            if self._nav_task:
                self._nav_task.cancel()
                try:
                    await self._nav_task
                except asyncio.CancelledError:
                    pass
            if self.sequence_processor:
                await self.sequence_processor.shutdown()
            print("[STOP] Motor daemon stopped", file=sys.stdout)

    async def _svc_state_set(self, service: str, status: str, details: Optional[Dict[str, Any]] = None):
        """Publish service status into NATS KV svc_state using existing connection."""
        if not self.nc:
            return
        try:
            js = self.nc.jetstream()
            try:
                kv = await js.key_value("svc_state")
            except NotFoundError:
                kv = await js.create_key_value("svc_state")
            payload = {
                "service": service,
                "status": status,
                "ts": time.time(),
                "details": details or {},
            }
            await kv.put(service, json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        except Exception:
            # Best-effort only, no raising
            pass


async def main():
    logger = setup_logging("motor-daemon")
    daemon = MotorDaemon(logger)
    await daemon.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Остановка сервиса - важное событие, выводим в stdout
        print("[STOP] Motor daemon stopped by user", file=sys.stdout)
        sys.exit(0)
    except Exception as e:
        logger = setup_logging("motor-daemon")
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

