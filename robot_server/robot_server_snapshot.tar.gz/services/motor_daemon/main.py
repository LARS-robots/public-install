#!/usr/bin/env python3
import asyncio
import json
import logging
import os
import sys
import time
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

from common.motor_iface import MotorIface
from motors.simulator import SimulatorMotor
from motors.raspbot import RaspbotMotor
from motors.diktum import DiktumMotor
from config_loader import get_config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


# -------------------------------------------------------------------
# STATE OBJECT (replaces all globals)
# -------------------------------------------------------------------
class DaemonState:
    """Container for daemon state (like FastAPI app.state)."""
    pass


# -------------------------------------------------------------------
# MOTION TIMEOUT SAFETY
# -------------------------------------------------------------------
class MotionTimeout:
    def __init__(self, state: DaemonState, driver: MotorIface, timeout_ms: int = 200):
        self.state = state
        self.driver = driver
        self.timeout_ms = timeout_ms
        self.last_motion_ts = time.time()
        self._task: Optional[asyncio.Task] = None

    def record(self):
        self.last_motion_ts = time.time()

    async def start(self):
        self._task = asyncio.create_task(self._loop())

    async def _loop(self):
        while True:
            try:
                delta_ms = (time.time() - self.last_motion_ts) * 1000

                # Only stop if permission is active
                if delta_ms > self.timeout_ms:
                    if hasattr(self.driver, "is_permission_active"):
                        if not self.driver.is_permission_active():
                            await asyncio.sleep(0.05)
                            continue

                    # Hard stop: zero raw values
                    setattr(self.state, "diktum_forward", 0)
                    setattr(self.state, "diktum_turn", 0)
                    setattr(self.state, "diktum_speed", 0)
                    self.driver.command_velocity()

            except Exception as e:
                log.error(f"[timeout] Failed to stop: {e}")

            await asyncio.sleep(0.1)

    def last_motion_age_ms(self) -> float:
        return (time.time() - self.last_motion_ts) * 1000


# -------------------------------------------------------------------
# MOTOR DAEMON
# -------------------------------------------------------------------
class MotorDaemon:
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.driver: Optional[MotorIface] = None
        self.config: Dict[str, Any] = {}
        self.robot_type: str = "simulator"
        self.state = DaemonState()
        self.motion_timeout: Optional[MotionTimeout] = None
        self.subscriptions = []

    # ---------------- CONFIG LOAD ----------------
    def load_config(self):
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"Loaded config: {cfg.config_path}")
        except Exception as e:
            log.warning(f"Failed to load config: {e}")
            self.config = {}
        return self.config

    # ---------------- ROBOT TYPE ----------------
    def detect_robot_type(self) -> str:
        env = os.getenv("ROBOT_TYPE")
        if env:
            return env.lower()
        return self.config.get("default", {}).get("robot_type", "simulator").lower()

    # ---------------- DRIVER FACTORY ----------------
    def create_driver(self) -> MotorIface:
        rt = self.detect_robot_type()
        self.robot_type = rt
        log.info(f"Driver selected: {rt}")

        if rt == "simulator":
            driver = SimulatorMotor()
        elif rt == "raspbot":
            driver = RaspbotMotor()
        elif rt == "diktum":
            driver = DiktumMotor()
        else:
            raise RuntimeError(f"Unknown robot type: {rt}")

        driver.connect(self.state)
        return driver

    # ---------------- TELEMETRY ----------------
    async def publish_telemetry(self, state: str, last_cmd=None, error=None):
        if not self.nc:
            return
        try:
            t = {
                "state": state,
                "lastCmd": last_cmd,
                "error": error,
                "ts": time.time(),
                "robot_type": self.robot_type,
                "permission_active": self.driver.is_permission_active() if hasattr(self.driver, "is_permission_active") else False,
                "last_motion_ms": self.motion_timeout.last_motion_age_ms() if self.motion_timeout else None,
            }
            msg = json.dumps(t, separators=(",", ":"))
            await self.nc.publish("motors.telemetry.status", msg.encode())
        except Exception as e:
            log.debug(f"Telemetry error: {e}")

    # ---------------- COMMAND HANDLERS ----------------
    async def handle_move(self, args: Dict[str, Any]):
        if not self.driver:
            await self.publish_telemetry("error", "move", "driver_not_initialized")
            return

        self.motion_timeout.record()
        setattr(self.state, "last_motion_ts", time.time())

        speed = args.get("speed")
        forward = args.get("forward")
        turn = args.get("turn")

        # Store raw joystick values for Diktum
        if self.robot_type == "diktum":
            if speed is not None:
                setattr(self.state, "diktum_speed", speed)
            if forward is not None:
                setattr(self.state, "diktum_forward", forward)
            if turn is not None:
                setattr(self.state, "diktum_turn", turn)

            self.driver.command_velocity()

        else:
            self.driver.command_velocity()

        log.info(f"[MOVE] speed={speed} forward={forward} turn={turn}")
        await self.publish_telemetry("running", "move")

    async def handle_stop(self):
        if self.driver:
            self.driver.stop()
        await self.publish_telemetry("stopped", "stop")

    async def handle_relay(self, args: Dict[str, Any]):
        if not self.driver:
            return

        relay = args.get("relay_name")
        on = args.get("relay_on", True)

        if hasattr(self.driver, "set_relay"):
            self.driver.set_relay(self.state, relay, on)

        await self.publish_telemetry("running", f"relay.{relay}")

    # ---------------- NATS MESSAGE ROUTER ----------------
    async def on_msg(self, msg):
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})

            if cmd == "move":
                await self.handle_move(args)
            elif cmd == "stop":
                await self.handle_stop()
            elif cmd == "relay":
                await self.handle_relay(args)
            else:
                await self.publish_telemetry("error", cmd, "unknown_command")

        except Exception as e:
            log.error(f"Command error: {e}")

    # ---------------- STARTUP ----------------
    async def start(self):
        self.load_config()
        self.driver = self.create_driver()

        if hasattr(self.driver, "start_background_tasks"):
            await self.driver.start_background_tasks(self.state)

        self.motion_timeout = MotionTimeout(self.state, self.driver)
        await self.motion_timeout.start()

        # Connect NATS
        url = os.getenv("NATS_URL", "nats://nats:4222")
        self.nc = await nats.connect(url)

        # Subscribe
        for s in ["motors.move", "motors.stop", "motors.relay"]:
            sub = await self.nc.subscribe(s, cb=self.on_msg)
            self.subscriptions.append(sub)

        await self.publish_telemetry("ready")
        log.info("Motor daemon started.")

        while True:
            await asyncio.sleep(1)


async def main():
    daemon = MotorDaemon()
    await daemon.start()


if __name__ == "__main__":
    asyncio.run(main())
