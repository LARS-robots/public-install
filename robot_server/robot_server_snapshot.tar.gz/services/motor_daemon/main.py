#!/usr/bin/env python3
import asyncio
import json
import logging
import math
import os
import sys
import time
from datetime import datetime
from typing import Dict, Any, Optional, List

import nats
from nats.aio.client import Client as NATS

from common.motor_iface import MotorIface
from motors.simulator import SimulatorMotor
from motors.raspbot import RaspbotMotor
from motors.diktum import DiktumMotor
from config_loader import get_config
from odometry import OdometryCalculator, OdometryKVStore
from sequence import SequenceProcessor

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


# -------------------------------------------------------------------
# STATE OBJECT (replaces all globals)
# -------------------------------------------------------------------
class DaemonState:
    """Container for daemon state (like FastAPI app.state)."""
    pass


# -------------------------------------------------------------------
# MOTION TIMEOUT SAFETY
# -------------------------------------------------------------------
class MotionTimeout:
    def __init__(self, state: DaemonState, driver: MotorIface, timeout_ms: int = 200):
        self.state = state
        self.driver = driver
        self.timeout_ms = timeout_ms
        self.last_motion_ts = time.time()
        self._task: Optional[asyncio.Task] = None

    def record(self):
        self.last_motion_ts = time.time()

    async def start(self):
        self._task = asyncio.create_task(self._loop())

    async def _loop(self):
        while True:
            try:
                delta_ms = (time.time() - self.last_motion_ts) * 1000

                # Only stop if permission is active
                if delta_ms > self.timeout_ms:
                    if hasattr(self.driver, "is_permission_active"):
                        if not self.driver.is_permission_active():
                            await asyncio.sleep(0.05)
                            continue

                    # Hard stop: use stop() method available for all drivers
                    # For Diktum, also reset values in state
                    if hasattr(self.state, "diktum_forward"):
                        setattr(self.state, "diktum_forward", 0)
                        setattr(self.state, "diktum_turn", 0)
                        setattr(self.state, "diktum_speed", 0)
                    # Call stop() - universal method for all drivers
                    self.driver.stop()

            except Exception as e:
                log.error(f"[timeout] Failed to stop: {e}")

            await asyncio.sleep(0.1)

    def last_motion_age_ms(self) -> float:
        return (time.time() - self.last_motion_ts) * 1000


# -------------------------------------------------------------------
# MOTOR DAEMON
# -------------------------------------------------------------------
class MotorDaemon:
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.driver: Optional[MotorIface] = None
        self.config: Dict[str, Any] = {}
        self.robot_type: str = "simulator"
        self.state = DaemonState()
        self.motion_timeout: Optional[MotionTimeout] = None
        self.subscriptions = []
        self.sequence_processor: Optional[SequenceProcessor] = None  # Optional sequence processor
        
        # Odometry tracking
        # Odometry calculator for calculating position from motor commands
        self.odometry: Optional[OdometryCalculator] = None
        # KV store for publishing odometry data
        self.odometry_kv: Optional[OdometryKVStore] = None
        
        # Command sending loops
        self._command_task: Optional[asyncio.Task] = None
        self._send_task: Optional[asyncio.Task] = None

    # ---------------- CONFIG LOAD ----------------
    def load_config(self):
        try:
            cfg = get_config()
            self.config = cfg.raw_data
            log.info(f"Loaded config: {cfg.config_path}")
        except Exception as e:
            log.warning(f"Failed to load config: {e}")
            self.config = {}
        return self.config

    # ---------------- ROBOT TYPE ----------------
    def detect_robot_type(self) -> str:
        env = os.getenv("ROBOT_TYPE")
        if env:
            return env.lower()
        return self.config.get("default", {}).get("robot_type", "simulator").lower()

    # ---------------- DRIVER FACTORY ----------------
    def create_driver(self) -> MotorIface:
        rt = self.detect_robot_type()
        self.robot_type = rt
        log.info(f"Driver selected: {rt}")

        if rt == "simulator":
            driver = SimulatorMotor()
        elif rt == "raspbot":
            driver = RaspbotMotor()
        elif rt == "diktum":
            driver = DiktumMotor()
        else:
            raise RuntimeError(f"Unknown robot type: {rt}")

        driver.connect(self.state)
        return driver

    # ---------------- TELEMETRY ----------------
    async def publish_telemetry(self, state: str, last_cmd=None, error=None):
        if not self.nc:
            return
        try:
            t = {
                "state": state,
                "lastCmd": last_cmd,
                "error": error,
                "ts": time.time(),
                "robot_type": self.robot_type,
                "permission_active": self.driver.is_permission_active() if hasattr(self.driver, "is_permission_active") else False,
                "last_motion_ms": self.motion_timeout.last_motion_age_ms() if self.motion_timeout else None,
            }
            msg = json.dumps(t, separators=(",", ":"))
            await self.nc.publish("motors.telemetry.status", msg.encode())
        except Exception as e:
            log.debug(f"Telemetry error: {e}")

    # ---------------- COMMAND HANDLERS ---------------- 
    async def handle_move(self, args: Dict[str, Any], timestamp: Optional[float] = None):
        if not self.driver:
            await self.publish_telemetry("error", "move", "driver_not_initialized")
            return

        self.motion_timeout.record()
        current_ts = timestamp if timestamp is not None else time.time()
        setattr(self.state, "last_motion_ts", current_ts)

        speed = args.get("speed")
        forward = args.get("forward")
        turn = args.get("turn")

        # Update odometry from command
        # This allows tracking robot position based on motor commands
        if self.odometry:
            self.odometry.update_from_command(speed, forward, turn, current_ts)
            
            # Publish to KV store for access by other services (localization, mapping)
            if self.odometry_kv:
                odom_state = self.odometry.get_state()
                await self.odometry_kv.publish_odometry(odom_state, current_ts)

        # Save command in state for all drivers
        # Commands will be processed in _command_loop
        if self.robot_type == "diktum":
            # For Diktum: save raw values
            if speed is not None:
                setattr(self.state, "diktum_speed", speed)
            if forward is not None:
                setattr(self.state, "diktum_forward", forward)
            if turn is not None:
                setattr(self.state, "diktum_turn", turn)
            # command_velocity will be called in _command_loop
        else:
            # For Simulator/Raspbot: convert and save vx, wz
            forward_norm = 0.0
            turn_norm = 0.0
            speed_norm = 0.0
            
            if forward is not None:
                forward_norm = max(-1.0, min(1.0, forward / 2000.0))
            if turn is not None:
                turn_norm = max(-1.0, min(1.0, turn / 2000.0))
            if speed is not None:
                speed_norm = max(0.0, min(1.0, speed / 2000.0))
            
            # Get motion configuration for speed calculation
            motion_cfg = self.config.get("motion", {})
            speed_mps = float(motion_cfg.get("speed_mps", 0.6))
            turn_speed_dps = float(motion_cfg.get("turn_speed_dps", 90.0))
            turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
            max_yaw_rate = turn_speed_dps * math.pi / 180.0
            
            # Calculate velocities
            vx = forward_norm * speed_norm * speed_mps
            wz = turn_norm * max_yaw_rate
            
            # Save for use in _command_loop
            setattr(self.state, "last_vx", vx)
            setattr(self.state, "last_wz", wz)
            # command_velocity will be called in _command_loop

        log.info(f"[MOVE] speed={speed} forward={forward} turn={turn}")
        await self.publish_telemetry("running", "move")

    async def handle_stop(self):
        if self.driver:
            self.driver.stop()
        await self.publish_telemetry("stopped", "stop")

    async def handle_relay(self, args: Dict[str, Any]):
        if not self.driver:
            return

        relay = args.get("relay_name")
        on = args.get("relay_on", True)

        if hasattr(self.driver, "set_relay"):
            self.driver.set_relay(self.state, relay, on)

        await self.publish_telemetry("running", f"relay.{relay}")

    # ---------------- COMMAND LOOPS ----------------
    async def _command_loop(self):
        """
        Common command generation loop for all drivers.
        Reads latest command from state and calls driver.command_velocity()
        """
        while True:
            try:
                if not self.driver:
                    await asyncio.sleep(0.1)
                    continue
                
                if self.robot_type == "diktum":
                    # For Diktum: call command_velocity without parameters
                    # It reads from state and forms packet itself
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity()
                    await asyncio.sleep(0.01)  # 100Hz for Diktum
                else:
                    # For Simulator/Raspbot: use last calculated vx, wz
                    vx = getattr(self.state, "last_vx", 0.0)
                    wz = getattr(self.state, "last_wz", 0.0)
                    if hasattr(self.driver, 'command_velocity'):
                        self.driver.command_velocity(vx, wz)
                    await asyncio.sleep(0.1)  # 10Hz for others
                    
            except Exception as e:
                log.error(f"[command_loop] {e}")
                await asyncio.sleep(0.1)

    async def _send_loop(self):
        """
        Packet sending loop via UART (only for Diktum).
        """
        if self.robot_type != "diktum":
            return
        
        while True:
            try:
                if not self.driver or not hasattr(self.driver, 'packet_queue'):
                    await asyncio.sleep(0.1)
                    continue
                
                # Check permission through driver
                if hasattr(self.driver, 'permission') and not self.driver.permission:
                    await asyncio.sleep(0.072)
                    continue
                
                # Get packet from queue
                try:
                    packet = self.driver.packet_queue.get_nowait()
                    # Send via UART
                    await asyncio.to_thread(self.driver.write, self.state, packet)
                except asyncio.QueueEmpty:
                    pass
                    
            except Exception as e:
                log.error(f"[send_loop] {e}")
            
            await asyncio.sleep(0.072)  # ~14Hz for UART

    # ---------------- NATS MESSAGE ROUTER ---------------- 
    async def on_msg(self, msg):
        try:
            data = json.loads(msg.data.decode())
            cmd = data.get("cmd")
            args = data.get("args", {})
            
            # Extract timestamp from message if available
            # For odometry, we use relative time between commands, so current time is sufficient
            # If precise timestamp is needed, it can be parsed from ISO8601 format
            timestamp = time.time()

            if cmd == "move" or cmd == "move_loop":
                await self.handle_move(args, timestamp)
            elif cmd == "stop":
                await self.handle_stop()
            elif cmd == "relay":
                await self.handle_relay(args)
            else:
                await self.publish_telemetry("error", cmd, "unknown_command")

        except Exception as e:
            log.error(f"Command error: {e}")

    # ---------------- STARTUP ----------------
    async def start(self):
        self.load_config()
        self.driver = self.create_driver()

        # Start command loops instead of start_background_tasks
        self._command_task = asyncio.create_task(self._command_loop())
        if self.robot_type == "diktum":
            self._send_task = asyncio.create_task(self._send_loop())

        self.motion_timeout = MotionTimeout(self.state, self.driver)
        await self.motion_timeout.start()

        # Connect to NATS
        url = os.getenv("NATS_URL", "nats://nats:4222")
        self.nc = await nats.connect(url)

        # Initialize odometry calculator and KV store
        # This allows tracking robot position and publishing it to KV store
        self.odometry = OdometryCalculator(self.config)
        self.odometry_kv = OdometryKVStore(self.nc)
        await self.odometry_kv.initialize()
        log.info("[ODOMETRY] Odometry calculator and KV store initialized")

        # Subscribe to basic motor commands
        sub = await self.nc.subscribe("motors.*", cb=self.on_msg)
        self.subscriptions.append(sub)

        # Initialize sequence processor (optional, only for diktum)
        if self.robot_type == "diktum":
            self.sequence_processor = SequenceProcessor(self.nc, self.config)
            await self.sequence_processor.initialize()

        await self.publish_telemetry("ready")
        log.info("Motor daemon started.")

        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            log.info("Shutting down...")
            if self.sequence_processor:
                await self.sequence_processor.shutdown()


async def main():
    daemon = MotorDaemon()
    await daemon.start()


if __name__ == "__main__":
    asyncio.run(main())

