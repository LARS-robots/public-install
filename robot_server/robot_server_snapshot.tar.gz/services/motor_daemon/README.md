# Motor Daemon

## Назначение

Сервис для управления моторами через NATS. Подписывается на команды движения и выполняет их через соответствующие драйверы моторов.

**Основные функции:**
- Подписка на команды движения из NATS (топик `motors`)
- Обработка команд последовательно (одна команда за раз)
- Поддержка разных типов роботов через Factory pattern
- Публикация телеметрии в NATS

## Архитектура

- **NATS subscriber** с Core подпиской (не JetStream, для минимальной задержки)
- **Factory pattern** для создания драйверов по типу робота
- **Последовательная обработка команд** (idempotent)
- **Драйверы моторов** (`motors/`): simulator, raspbot, diktum
- **Общие интерфейсы** (`common/`): `MotorIface` для унификации драйверов

## Драйверы моторов

| Драйвер | Статус | Описание | Платформа |
|---------|--------|----------|-----------|
| `simulator` | ✅ Полный | Физическая симуляция движения с одометрией | Linux/Windows |
| `raspbot` | ⚠️ Placeholder | Робот Raspbot через GPIO/PWM | Raspberry Pi |
| `diktum` | ✅ UART | Робот Diktum через UART (/dev/ttyAMA0) | Raspberry Pi |

**Для реальных роботов необходимо:**
1. Реализовать hardware команды в `command_velocity()`
2. Добавить GPS/одометрию для позиции
3. Или использовать dead-reckoning (интегрировать velocity → pose как в симуляторе)

## Конфигурация

**Основные файлы:**
- `config.toml` - основная конфигурация
- `config.example.toml` - пример конфигурации
- `config.example.compose.toml` - маппинг compose файлов на env файлы
- `env/*.env` - переменные окружения для разных типов роботов
  - `simulator.env` - для симулятора
  - `raspbot.env` - для робота Raspbot
  - `diktum.env` - для робота Diktum

**Определение типа робота (приоритет):**
1. `ROBOT_TYPE` env var (из `/etc/lars/robot.env` - создаётся `unpack.py`) - **высший приоритет**
2. `config.toml` → `[default] robot_type` - fallback для локальной разработки
3. Автоматическое определение платформы (rpi/linux/windows)

**Compose файлы:**
- `compose.linux.yml` / `compose.windows.yml` - для симулятора
- `compose.rpi.raspbot.yml` - для робота Raspbot
- `compose.rpi.diktum.yml` - для робота Diktum (с /dev/ttyAMA0)

**Основные секции конфигурации:**
- `[default]` - тип робота
- `[motion]` - параметры движения (speed_mps, orient_then_move, dead_zone, turn_speed_dps)
- `[diktum]` - настройки UART для робота Diktum (serial_device, baudrate, frame template)
- `[start_pose]` - начальная позиция для симулятора (lat, lon, yaw)

## Интеграция с NATS

**Подписка:**
- Топик `motors` (в текущей реализации: `motors.move`, `motors.stop`, `motors.relay`)
- Использует NATS Core для минимальной задержки
- Последовательная обработка команд

**Публикация:**
- Телеметрия: `motors.telemetry.status`
- Логи: через `nats_logger` в топик `log.*`

**Чтение:**
- Локализация: из NATS Key-Value store (топик `localization`)

**Подробности:** см. `../docs/NATS.md` и `../docs/nats-motor-commands.md`

## Tank Mode

Режим управления танком с ориентацией по горизонтальному джойстику.

**Конфигурация:**
```toml
[motion]
speed_mps = 10.0             # Скорость движения (м/с) 
orient_then_move = true      # Режим танка: поворот + движение вперед
dead_zone = 0.12             # Мертвая зона джойстика
turn_speed_dps = 1           # Скорость поворота (градусы/сек)
```

**Поведение:**
- **Только steer (без throttle)**: Робот поворачивается и едет вперед
- **С explicit throttle**: Классический аркадный режим  
- **Мертвая зона**: Игнорирует малые случайные движения джойстика
- **Ручное прерывание**: Джойстик прерывает автономную навигацию

Подробнее см. `../services/api/README.md#tank-mode-управление`.

## Diktum Mode

Для управления реальным оборудованием Diktum:

1. Редактируйте `config.toml` и установите тип робота:
```toml
[default]
robot_type = "diktum"
```

Убедитесь, что секции `[diktum]` и `[motion]` настроены под ваше оборудование (серийный порт, скорость передачи (baud), максимальные скорости).

2. Перезапустите сервис

3. Диагностика:
- Живые фреймы данных и события управления отображаются в веб‑просмотрщике логов по адресу `/admin/logs` с полем `stage="motion"`

**Формат команд:**
- `speed`: Целое число 0-2000 (множитель скорости, 0 = остановка, 2000 = максимум)
- `forward`: Целое число -2000 до 2000 (+ = вперёд, - = назад)
- `turn`: Целое число -2000 до 2000 (+ = влево, - = вправо)
- Все значения - сырые целые числа (без нормализации к -1.0 до 1.0)

**Реле:**
- `permission` - разрешение работы
- `starter` - стартер
- `speed2` - скорость 2
- `sound` - звук
- `stop` - аварийная остановка (отключает все реле)

## Документация

- Архитектура NATS: `../docs/NATS.md`
- Протокол команд: `../docs/nats-motor-commands.md`
- Логирование: `../docs/nats-logging.md`
- Diktum startup: `../docs/dictum_startup.md`
- Diktum joystick: `../docs/dictum_joystic.md`

