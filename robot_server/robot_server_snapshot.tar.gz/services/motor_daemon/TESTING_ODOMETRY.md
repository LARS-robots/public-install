# Проверка автоматического обновления одометрии

Этот документ описывает пошаговую проверку автоматического обновления одометрии в `motor_daemon`.

## Цель проверки

Убедиться, что одометрия:
- Обновляется автоматически в `OdometryManager` с частотой 50 Гц
- Не зависит от частоты команд через NATS
- Публикуется в KV store (`loc_state/motor_odom`)
- Корректно отражает движение робота
- Поддерживает команду `reset_odometry` для сброса позиции

## Предварительные требования

- Windows + Git Bash
- Docker и Docker Compose установлены
- `nats.exe` находится в каталоге `robot/`
- NATS сервер доступен на `nats://dev:devpass@127.0.0.1:4222`

## Шаг 1: Остановка всех сервисов (clean start)

Выполните в Git Bash:

```bash
cd /c/Users/datsa/Sync/Metu/slava_proj/LARS/robot

# Остановить все сервисы
docker compose -f compose.yml -f services/motor_daemon/compose.windows.yml down

# Убедиться, что все контейнеры остановлены
docker ps -a | grep -E "robot|nats|motion"
```

Если есть запущенные контейнеры, остановите их:

```bash
# Остановить все контейнеры проекта
docker ps --format "{{.Names}}" | grep -E "robot|nats|motion" | xargs -r docker stop

# Удалить все контейнеры проекта (опционально, для полной очистки)
docker ps -a --format "{{.Names}}" | grep -E "robot|nats|motion" | xargs -r docker rm
```

---

## Шаг 2: Запуск NATS и motor_daemon

```bash
# Запустить только NATS и motor_daemon
docker compose -f compose.yml -f services/motor_daemon/compose.windows.yml up -d nats motion_daemon

# Проверить, что сервисы запустились
docker ps --format "table {{.Names}}\t{{.Status}}" | grep -E "nats|motion"
```

**Ожидаемый вывод:**
```
robot-nats-1          Up X seconds
robot-motion_daemon-1 Up X seconds
```

Подождите 2-3 секунды, чтобы сервисы инициализировались:

```bash
sleep 3
```

---

## Шаг 3: Проверка начального состояния одометрии

Проверьте, что KV bucket `loc_state` существует и есть ли начальное значение:

```bash
# Проверить список KV buckets
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv ls

# Попробовать прочитать начальное значение (может быть пустым)
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom
```

**Если ключа нет** — это нормально, он появится после первой команды.

---

## Шаг 4: Отправка одной команды движения

Отправьте **одну** команду движения:

```bash
# Отправить команду: скорость 1000, вперёд 500, поворот 0
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.move \
'{"cmd":"move","args":{"speed":1000,"forward":500,"turn":0},"ts":'$(date +%s)'}'
```

**Параметры команды:**
- `speed=1000` — половина максимальной скорости
- `forward=500` — движение вперёд (четверть максимального)
- `turn=0` — без поворота

**Важно:** Отправляем только одну команду. Одометрия должна продолжать обновляться автоматически в `_command_loop()`.

---

## Шаг 5: Проверка автоматического обновления одометрии

Одометрия должна обновляться автоматически в `OdometryManager` с частотой **50 Гц** (каждые 20 мс).

### 5.1. Первая проверка (сразу после команды)

```bash
# Подождать 0.5 секунды (чтобы прошло несколько циклов обновления)
sleep 0.5

# Прочитать одометрию
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom
```

**Ожидаемый результат (пример):**
```json
{
  "ts": 1732973723.456,
  "frame": "robot",
  "x": 0.125,
  "y": 0.000,
  "yaw": 0.000,
  "vx": 0.150,
  "vy": 0.0,
  "omega": 0.0,
  "cov_x": 0.002,
  "cov_y": 0.002,
  "cov_yaw": 0.0001,
  "status": "ok",
  "source": "motor_commands"
}
```

**Проверки:**
- ✅ `x > 0` (робот двинулся вперёд)
- ✅ `vx > 0` (скорость вперёд положительная, примерно 0.15 м/с)
- ✅ `ts` — актуальный таймштамп

### 5.2. Вторая проверка (через 1 секунду)

```bash
# Подождать ещё 1 секунду
sleep 1

# Прочитать одометрию снова
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom
```

**Ожидаемые изменения:**
- ✅ `x` увеличился (робот продолжает двигаться)
- ✅ `ts` обновился (автоматическое обновление работает)
- ✅ `vx` остаётся положительным (команда всё ещё активна)

**Пример изменений:**
- Первая проверка: `x = 0.125`, `ts = 1732973723.456`
- Вторая проверка: `x = 0.275`, `ts = 1732973724.556` (x увеличился, ts обновился)

### 5.3. Третья проверка (через 2 секунды)

```bash
# Подождать ещё 2 секунды
sleep 2

# Прочитать одометрию в третий раз
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom
```

**Ожидаемые изменения:**
- ✅ `x` продолжает увеличиваться
- ✅ `ts` продолжает обновляться

**Пример изменений:**
- Вторая проверка: `x = 0.275`, `ts = 1732973724.556`
- Третья проверка: `x = 0.575`, `ts = 1732973726.656` (x увеличился ещё больше)

---

## Шаг 6: Проверка частоты обновления (опционально)

Чтобы увидеть, что одометрия обновляется регулярно, можно мониторить KV в реальном времени:

```bash
# В отдельном терминале Git Bash запустите цикл проверки
for i in {1..10}; do
  echo "=== Проверка $i ==="
  OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
  echo "$OUTPUT" | grep -oE '"ts"[^,}]*'
  echo "$OUTPUT" | grep -oE '"x"[^,}]*'
  sleep 0.1
done
```

**Ожидаемое поведение:**
- ✅ `ts` обновляется каждые ~0.02 секунды (50 Гц)
- ✅ `x` плавно увеличивается

**Альтернативный вариант (только числовые значения):**

```bash
for i in {1..10}; do
  echo "=== Проверка $i ==="
  OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
  echo "$OUTPUT" | sed -n 's/.*"ts"[^0-9]*\([0-9.]*\).*/\1/p'
  echo "$OUTPUT" | sed -n 's/.*"x"[^0-9]*\([0-9.-]*\).*/\1/p'
  sleep 0.1
done
```

---

## Шаг 7: Остановка движения

Отправьте команду остановки:

```bash
# Отправить команду остановки
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.stop \
'{"cmd":"stop","args":{},"ts":'$(date +%s)'}'

# Подождать и проверить, что скорость стала нулевой
sleep 0.5
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "$OUTPUT" | grep -oE '"vx"[^,}]*'
echo "$OUTPUT" | grep -oE '"omega"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `vx ≈ 0` (скорость вперёд стала нулевой)
- ✅ `omega ≈ 0` (угловая скорость стала нулевой)

### 7.1. Проверка, что позиция не меняется

```bash
# Записать текущий x
OUTPUT_BEFORE=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
X_BEFORE=$(echo "$OUTPUT_BEFORE" | sed -n 's/.*"x"[^0-9]*\([0-9.-]*\).*/\1/p')
echo "X before: $X_BEFORE"

# Подождать 1 секунду
sleep 1

# Записать x после ожидания
OUTPUT_AFTER=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
X_AFTER=$(echo "$OUTPUT_AFTER" | sed -n 's/.*"x"[^0-9]*\([0-9.-]*\).*/\1/p')
echo "X after: $X_AFTER"

# Сравнить значения
echo "Разница: $(echo "scale=3; $X_AFTER - $X_BEFORE" | bc 2>/dev/null || echo "вычислите вручную") м"
```

**Ожидаемый результат:**
- ✅ `x` не увеличивается (робот остановился)
- ✅ Разница между `X_BEFORE` и `X_AFTER` минимальна (≤ 0.01 м)

## Шаг 8: Проверка команды reset_odometry

### 8.1. Запись позиции до reset

```bash
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "=== Позиция ДО reset ==="
echo "$OUTPUT" | grep -oE '"x"[^,}]*'
echo "$OUTPUT" | grep -oE '"y"[^,}]*'
echo "$OUTPUT" | grep -oE '"yaw"[^,}]*'
```

### 8.2. Остановка движения перед reset

**Важно:** Перед reset_odometry нужно остановить движение, иначе одометрия продолжит обновляться и позиция будет меняться даже после reset.

```bash
# Остановить движение
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.stop \
'{"cmd":"stop","args":{},"ts":'$(date +%s)'}'

# Подождать, чтобы команда stop обработалась
sleep 0.5

# Проверить, что скорости обнулились
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "=== Проверка остановки ==="
echo "$OUTPUT" | grep -oE '"vx"[^,}]*'
echo "$OUTPUT" | grep -oE '"omega"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `vx ≈ 0` (скорость остановлена)
- ✅ `omega ≈ 0` (угловая скорость остановлена)

### 8.3. Отправка команды reset_odometry

```bash
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.reset_odometry \
'{"cmd":"reset_odometry","args":{"x":0.0,"y":0.0,"yaw":0.0},"ts":'$(date +%s)'}'
```

### 8.4. Проверка позиции после reset

```bash
sleep 0.5
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "=== Позиция ПОСЛЕ reset ==="
echo "$OUTPUT" | grep -oE '"x"[^,}]*'
echo "$OUTPUT" | grep -oE '"y"[^,}]*'
echo "$OUTPUT" | grep -oE '"yaw"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `x = 0.0` (или близко к 0.0, если была небольшая задержка)
- ✅ `y = 0.0`
- ✅ `yaw = 0.0`
- ✅ В логах есть `[MAIN] Odometry reset to: x=0.000, y=0.000, yaw=0.000`

### 8.5. Проверка продолжения движения после reset

```bash
# Отправить команду движения
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.move \
'{"cmd":"move","args":{"speed":1000,"forward":500,"turn":0},"ts":'$(date +%s)'}'

# Проверить через 1 секунду
sleep 1
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "=== Проверка движения после reset ==="
echo "$OUTPUT" | grep -oE '"x"[^,}]*'
echo "$OUTPUT" | grep -oE '"vx"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `x > 0` (одометрия продолжает работать после reset)
- ✅ `vx > 0` (скорость корректная)

---

## Критерии успеха

✅ **Одометрия обновляется автоматически** после одной команды:
- `x` увеличивается со временем (робот движется)
- `ts` обновляется регулярно (каждые ~0.02 секунды, 50 Гц)
- `vx` соответствует команде (положительная при движении вперёд)

✅ **После остановки:**
- `vx` и `omega` становятся нулевыми
- `x` больше не увеличивается (позиция стабильна)

✅ **Команда reset_odometry:**
- Позиция сбрасывается корректно (x, y, yaw = 0.0)
- Одометрия продолжает работать после reset

✅ **Независимость от NATS:**
- Одометрия обновляется даже если команды не приходят через NATS
- Обновление происходит в `OdometryManager` с фиксированной частотой 50 Гц

---

## Диагностика проблем

### Проблема: Одометрия не обновляется

**Проверьте логи motor_daemon:**
```bash
docker logs robot-motion_daemon-1 --tail 50
```

Ищите сообщения:
- `[ODOMETRY_MANAGER] Initialized with update rate 50.0Hz` — одометрия инициализирована
- `[ODOMETRY_MANAGER] Started` — менеджер одометрии запущен
- `[ODOMETRY_KV] KV store bucket 'loc_state' initialized` — KV store инициализирован
- `[ODOMETRY_KV] Published odometry:` — публикация в KV работает

**Возможные причины:**
- Драйвер не инициализирован
- NATS не подключён
- KV bucket не создан

### Проблема: Одометрия обновляется, но значения не меняются

**Проверьте:**
1. Команда действительно отправлена:
   ```bash
   docker logs robot-motion_daemon-1 | grep -i "move"
   ```

2. Значения в state:
   - Для Simulator/Raspbot: `last_vx`, `last_wz`
   - Для Diktum: `diktum_speed`, `diktum_forward`, `diktum_turn`

3. Конфигурацию движения:
   ```bash
   docker exec robot-motion_daemon-1 cat /app/config.toml | grep -A 5 "\[motion\]"
   ```

### Проблема: KV bucket не существует

**Создайте bucket вручную:**
```bash
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv add loc_state
```

Или проверьте логи инициализации:
```bash
docker logs robot-motion_daemon-1 | grep -i "kv\|odometry"
```

---

## Шаг 9: Дополнительные тесты

### 9.1. Поворот

```bash
# Остановить движение (если было)
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.stop \
'{"cmd":"stop","args":{},"ts":'$(date +%s)'}'
sleep 0.5

# Reset одометрии
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.reset_odometry \
'{"cmd":"reset_odometry","args":{"x":0.0,"y":0.0,"yaw":0.0},"ts":'$(date +%s)'}'
sleep 0.5

# Отправить команду поворота
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.move \
'{"cmd":"move","args":{"speed":1000,"forward":0,"turn":500},"ts":'$(date +%s)'}'

# Проверить через 1 секунду
sleep 1
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "$OUTPUT" | grep -oE '"yaw"[^,}]*'
echo "$OUTPUT" | grep -oE '"omega"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `yaw ≠ 0` (робот повернулся)
- ✅ `omega > 0` (угловая скорость положительная)

### 9.2. Движение назад

```bash
# Остановить движение (если было)
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.stop \
'{"cmd":"stop","args":{},"ts":'$(date +%s)'}'
sleep 0.5

# Reset одометрии
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.reset_odometry \
'{"cmd":"reset_odometry","args":{"x":0.0,"y":0.0,"yaw":0.0},"ts":'$(date +%s)'}'
sleep 0.5

# Отправить команду движения назад
./nats.exe --server nats://dev:devpass@127.0.0.1:4222 pub motors.move \
'{"cmd":"move","args":{"speed":1000,"forward":-500,"turn":0},"ts":'$(date +%s)'}'

# Проверить через 1 секунду
sleep 1
OUTPUT=$(./nats.exe --server nats://dev:devpass@127.0.0.1:4222 kv get loc_state motor_odom)
echo "$OUTPUT" | grep -oE '"x"[^,}]*'
echo "$OUTPUT" | grep -oE '"vx"[^,}]*'
```

**Ожидаемый результат:**
- ✅ `x < 0` (робот движется назад)
- ✅ `vx < 0` (скорость вперёд отрицательная)

---

## Заключение

После успешного прохождения всех шагов вы должны убедиться, что:

1. ✅ Одометрия обновляется автоматически в `OdometryManager` с частотой 50 Гц
2. ✅ Не зависит от частоты команд через NATS
3. ✅ Публикуется в KV store регулярно
4. ✅ Корректно отражает движение робота (x, y, yaw, vx, vy, omega)
5. ✅ Команда `reset_odometry` работает корректно

Если все проверки пройдены успешно, автоматическое обновление одометрии работает корректно.



