#!/usr/bin/env python3
"""
Менеджер одометрии для демона моторов.

Инкапсулирует всю логику работы с одометрией:
- чтение команд из state
- непрерывное обновление позиции с фиксированной частотой
- публикация в KV store
- обработка остановки и edge cases
- метрики и диагностика
"""
import asyncio
import logging
import time
from typing import Dict, Any, Optional

from .calculator import OdometryCalculator
from .kv_store import OdometryKVStore

log = logging.getLogger(__name__)


class OdometryManager:
    """
    Менеджер одометрии, работающий как отдельная асинхронная задача.
    
    Читает команды движения из state и обновляет одометрию независимо
    от основного цикла команд. Это гарантирует, что одометрия продолжает
    считать движение даже если новые команды не приходят.
    """
    
    def __init__(
        self,
        state: Any,
        config: Dict[str, Any],
        robot_type: str,
        nc: Optional[Any] = None
    ):
        """
        Инициализация менеджера одометрии.
        
        Args:
            state: объект состояния демона (DaemonState)
            config: конфигурация демона
            robot_type: тип робота ("diktum", "simulator", "raspbot")
            nc: соединение NATS (опционально, для KV store)
        """
        self.state = state
        self.config = config
        self.robot_type = robot_type
        self.nc = nc
        
        # Инициализируем компоненты одометрии
        self.odometry: Optional[OdometryCalculator] = None
        self.odometry_kv: Optional[OdometryKVStore] = None
        
        # Параметры из конфига
        odom_cfg = config.get("odometry", {})
        self.update_rate_hz = float(odom_cfg.get("update_rate_hz", 50.0))
        self.update_period = 1.0 / self.update_rate_hz if self.update_rate_hz > 0 else 0.02
        
        # Задача обновления
        self._task: Optional[asyncio.Task] = None
        self._running = False
        
        # Статистика
        self.stats = {
            "update_count": 0,
            "error_count": 0,
            "last_update_ts": None,
            "kv_publish_count": 0,
            "kv_error_count": 0,
        }
        
    async def initialize(self):
        """
        Инициализировать калькулятор одометрии и KV store.
        
        Должен быть вызван после установки соединения NATS.
        """
        try:
            # Создаём калькулятор одометрии
            self.odometry = OdometryCalculator(self.config)
            
            # Создаём KV store для публикации
            if self.nc:
                self.odometry_kv = OdometryKVStore(self.nc, self.config)
                await self.odometry_kv.initialize()
            
            log.info(f"[ODOMETRY_MANAGER] Initialized with update rate {self.update_rate_hz}Hz")
        except Exception as e:
            log.error(f"[ODOMETRY_MANAGER] Failed to initialize: {e}", exc_info=True)
            raise
    
    async def start(self):
        """Запустить менеджер одометрии как отдельную задачу."""
        if self._running:
            log.warning("[ODOMETRY_MANAGER] Already running")
            return
        
        if not self.odometry:
            log.error("[ODOMETRY_MANAGER] Not initialized, call initialize() first")
            return
        
        self._running = True
        self._task = asyncio.create_task(self._update_loop())
        log.info("[ODOMETRY_MANAGER] Started")
    
    async def stop(self):
        """Остановить менеджер одометрии."""
        self._running = False
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=1.0)
            except asyncio.TimeoutError:
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass
        log.info("[ODOMETRY_MANAGER] Stopped")
    
    async def _update_loop(self):
        """
        Основной цикл обновления одометрии.
        
        Читает команды из state и обновляет одометрию с фиксированной частотой.
        Это гарантирует плавное и непрерывное обновление позиции.
        """
        while self._running:
            try:
                if not self.odometry:
                    await asyncio.sleep(0.1)
                    continue
                
                current_ts = time.time()
                
                # Читаем команды из state в зависимости от типа робота
                if self.robot_type == "diktum":
                    # Для Diktum: читаем команды в формате джойстика
                    speed = getattr(self.state, "diktum_speed", 0)
                    forward = getattr(self.state, "diktum_forward", 0)
                    turn = getattr(self.state, "diktum_turn", 0)
                    
                    # Обновляем одометрию из команд
                    self.odometry.update_from_command(speed, forward, turn, current_ts)
                else:
                    # Для Simulator/Raspbot: читаем вычисленные скорости
                    vx = getattr(self.state, "last_vx", 0.0)
                    wz = getattr(self.state, "last_wz", 0.0)
                    
                    # Обновляем одометрию напрямую из скоростей
                    self.odometry.update_from_velocities(vx, 0.0, wz, current_ts)
                
                # Обновляем статистику
                self.stats["update_count"] += 1
                self.stats["last_update_ts"] = current_ts
                
                # Публикуем в KV store
                if self.odometry_kv:
                    try:
                        odom_state = self.odometry.get_state()
                        await self.odometry_kv.publish_odometry(odom_state, current_ts)
                        self.stats["kv_publish_count"] += 1
                    except Exception as e:
                        self.stats["kv_error_count"] += 1
                        log.debug(f"[ODOMETRY_MANAGER] KV publish error: {e}")
                
                # Обновляем с фиксированной частотой
                await asyncio.sleep(self.update_period)
                    
            except Exception as e:
                self.stats["error_count"] += 1
                log.error(f"[ODOMETRY_MANAGER] Error in update loop: {e}", exc_info=True)
                await asyncio.sleep(0.1)
    
    def get_state(self) -> Optional[Dict[str, float]]:
        """
        Получить текущее состояние одометрии.
        
        Returns:
            Словарь с состоянием одометрии или None если не инициализирован.
        """
        if self.odometry:
            return self.odometry.get_state()
        return None
    
    def reset(self, x: float = 0.0, y: float = 0.0, yaw: float = 0.0):
        """
        Сбросить одометрию в заданное состояние.
        
        Args:
            x: начальное значение x (метры, вперёд)
            y: начальное значение y (метры, влево)
            yaw: начальный угол курса (радианы)
        """
        if self.odometry:
            self.odometry.reset(x, y, yaw)
            log.info(f"[ODOMETRY_MANAGER] Reset to: x={x:.3f}, y={y:.3f}, yaw={yaw:.3f}")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы менеджера одометрии.
        
        Returns:
            Словарь со статистикой
        """
        stats = self.stats.copy()
        if self.odometry:
            odom_state = self.odometry.get_state()
            stats["current_position"] = {
                "x": odom_state["x"],
                "y": odom_state["y"],
                "yaw": odom_state["yaw"],
            }
            stats["current_velocity"] = {
                "vx": odom_state["vx"],
                "omega": odom_state["omega"],
            }
        return stats

