#!/usr/bin/env python3
"""
Odometry calculator for motor daemon.
Calculates robot position from motor commands using dead reckoning.
"""
import math
import time
import logging
from typing import Dict, Any, Optional

log = logging.getLogger(__name__)


class OdometryCalculator:
    """
    Odometry calculator from motor commands (dead reckoning).
    
    Converts motor commands (speed/forward/turn) to velocities (vx, vy, omega)
    and integrates them over time to get position (x, y, yaw).
    
    Coordinate system: "robot" (local, origin at start point)
    - x: forward direction (meters)
    - y: left direction (meters) 
    - yaw: heading angle (radians, 0 = forward)
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize odometry calculator.
        
        Args:
            config: Configuration dictionary with motion parameters
        """
        # Current position in robot coordinate system
        self.x = 0.0  # meters, forward
        self.y = 0.0  # meters, left
        self.yaw = 0.0  # radians, 0 = forward
        
        # Current velocities
        self.vx = 0.0  # m/s, forward
        self.vy = 0.0  # m/s, left (usually 0 for car-like robots)
        self.omega = 0.0  # rad/s, rotation around vertical axis
        
        # Last update timestamp
        self.last_ts = time.time()
        
        # Motion configuration from config
        motion_cfg = config.get("motion", {})
        self.speed_mps = float(motion_cfg.get("speed_mps", 0.6))  # maximum speed in m/s
        self.turn_speed_dps = float(motion_cfg.get("turn_speed_dps", 90.0))  # maximum turn speed in deg/s
        self.turn_speed_dps = max(10.0, min(360.0, self.turn_speed_dps))
        self.max_yaw_rate = self.turn_speed_dps * math.pi / 180.0  # convert to rad/s
        
        # Covariance estimates (measurement uncertainty)
        self.cov_v = 0.02  # linear velocity uncertainty in m/s
        self.cov_omega = 0.001  # angular velocity uncertainty in rad/s
        
        log.info(f"[ODOMETRY] Initialized: speed_mps={self.speed_mps}, max_yaw_rate={self.max_yaw_rate:.3f} rad/s")
    
    def update_from_command(self, speed: Optional[int], forward: Optional[int], turn: Optional[int], timestamp: float):
        """
        Update odometry from motor command.
        
        Args:
            speed: Speed multiplier 0-2000 (Diktum format)
            forward: Forward/backward -2000 to 2000 (+ = forward)
            turn: Turn -2000 to 2000 (+ = left, counter-clockwise)
            timestamp: Command timestamp (seconds)
        """
        # Calculate time delta since last update
        # Limit dt to reasonable range to protect against time jumps
        dt = max(0.0, min(0.5, timestamp - self.last_ts))
        
        if dt <= 0:
            # No time passed, skip update
            return
        
        # Convert raw joystick values to normalized range [-1, 1]
        # Diktum format: values from -2000 to 2000
        forward_norm = 0.0
        turn_norm = 0.0
        speed_norm = 0.0
        
        if forward is not None:
            forward_norm = max(-1.0, min(1.0, forward / 2000.0))
        if turn is not None:
            turn_norm = max(-1.0, min(1.0, turn / 2000.0))
        if speed is not None:
            speed_norm = max(0.0, min(1.0, speed / 2000.0))
        
        # Calculate velocities in robot coordinate system
        # vx: forward velocity (positive = forward)
        self.vx = forward_norm * speed_norm * self.speed_mps
        
        # vy: lateral velocity (usually 0 for car-like robots, but kept for future)
        self.vy = 0.0  # No lateral movement yet
        
        # omega: angular velocity (positive = counter-clockwise, turn left)
        self.omega = turn_norm * self.max_yaw_rate
        
        # Integrate velocities to update position (dead reckoning)
        # First update yaw (rotation)
        self.yaw = self._normalize_angle(self.yaw + self.omega * dt)
        
        # Update position (movement in robot coordinate system)
        # x - forward, y - left
        # Use trigonometry to convert velocities to coordinate increments
        dx = self.vx * math.cos(self.yaw) * dt - self.vy * math.sin(self.yaw) * dt
        dy = self.vx * math.sin(self.yaw) * dt + self.vy * math.cos(self.yaw) * dt
        
        self.x += dx
        self.y += dy
        
        # Update timestamp
        self.last_ts = timestamp
        
        log.debug(f"[ODOMETRY] Updated: x={self.x:.3f}, y={self.y:.3f}, yaw={self.yaw:.3f}, vx={self.vx:.3f}, omega={self.omega:.3f}")
    
    def get_state(self) -> Dict[str, float]:
        """
        Get current odometry state.
        
        Returns:
            Dictionary with position and velocities in robot coordinate system
        """
        return {
            "x": self.x,
            "y": self.y,
            "yaw": self.yaw,
            "vx": self.vx,
            "vy": self.vy,
            "omega": self.omega,
            "cov_v": self.cov_v,
            "cov_omega": self.cov_omega
        }
    
    def reset(self, x: float = 0.0, y: float = 0.0, yaw: float = 0.0):
        """
        Reset odometry to given position (useful for relocalization).
        
        Args:
            x: Initial x position (meters)
            y: Initial y position (meters)
            yaw: Initial heading angle (radians)
        """
        self.x = x
        self.y = y
        self.yaw = yaw
        self.vx = 0.0
        self.vy = 0.0
        self.omega = 0.0
        self.last_ts = time.time()
        log.info(f"[ODOMETRY] Reset to: x={x:.3f}, y={y:.3f}, yaw={yaw:.3f}")
    
    def _normalize_angle(self, angle: float) -> float:
        """
        Normalize angle to range [-π, π].
        
        Args:
            angle: Angle in radians
            
        Returns:
            Normalized angle in range [-π, π]
        """
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

