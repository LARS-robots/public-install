#!/usr/bin/env python3
"""
Модуль одометрии для демона моторов.

Задача: по командам на движение (speed / forward / turn) оценивать
линейные и угловые скорости робота и интегрировать их по времени,
чтобы получить текущую позицию (x, y) и угол курса (yaw).

Метод: dead reckoning (накапливаем ошибку, но работаем автономно,
без внешних датчиков).
"""
import math
import time
import logging
from typing import Dict, Any, Optional

log = logging.getLogger(__name__)


class OdometryCalculator:
    """
    Калькулятор одометрии по моторным командам (dead reckoning).

    Что делает:
    - Принимает команды движения (speed / forward / turn)
      в «джойстиковом» формате Diktum (-2000..2000).
    - Переводит их в линейные и угловые скорости (vx, vy, omega).
    - Интегрирует скорости по времени и обновляет позицию (x, y, yaw).

    Система координат: "robot" (локальная, начало в точке старта).
    - x: вперёд (метры)
    - y: влево (метры)
    - yaw: угол курса в радианах (0 = «смотрим вперёд», против часовой — плюс)
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Инициализация калькулятора одометрии.

        Args:
            config: словарь конфигурации с параметрами движения.
                    Ожидается секция config["motion"].
        """
        # Текущая оценка позиции в системе координат робота
        self.x = 0.0  # м, вперёд
        self.y = 0.0  # м, влево
        self.yaw = 0.0  # рад, 0 = вперёд
        
        # Текущие скорости
        self.vx = 0.0  # м/с, вперёд
        self.vy = 0.0  # м/с, влево (для нашей кинематики обычно 0)
        self.omega = 0.0  # рад/с, вращение вокруг вертикальной оси
        
        # Последний таймштамп обновления
        self.last_ts = time.time()
        
        # Параметры движения из конфига
        motion_cfg = config.get("motion", {})
        # Максимальная линейная скорость (м/с)
        self.speed_mps = float(motion_cfg.get("speed_mps", 0.6))
        # Максимальная угловая скорость в град/с (из конфига)
        self.turn_speed_dps = float(motion_cfg.get("turn_speed_dps", 90.0))
        # Ограничиваем диапазон поворота разумными значениями,
        # чтобы не получить «безумно быстро крутящийся» робот.
        self.turn_speed_dps = max(10.0, min(360.0, self.turn_speed_dps))
        # Переводим в рад/с — это верхний предел |omega|
        self.max_yaw_rate = self.turn_speed_dps * math.pi / 180.0
        
        # Параметры одометрии из конфига
        odom_cfg = config.get("odometry", {})
        # Оценки ковариаций (неопределённость измерений)
        # Эти значения используются далее при публикации в KV,
        # чтобы дать локализации и другим модулям представление о доверии к одометрии.
        self.cov_v = float(odom_cfg.get("cov_v", 0.02))  # неопределённость по линейной скорости, м/с
        self.cov_omega = float(odom_cfg.get("cov_omega", 0.001))  # неопределённость по угловой скорости, рад/с
        
        # Максимальные значения для валидации
        self.max_dt_seconds = float(odom_cfg.get("max_dt_seconds", 0.5))
        self.max_velocity = float(odom_cfg.get("max_velocity", 10.0))  # м/с
        self.max_angular_velocity = float(odom_cfg.get("max_angular_velocity", 5.0))  # рад/с
        
        # Статистика
        self.stats = {
            "update_count": 0,
            "error_count": 0,
            "validation_fail_count": 0,
            "total_distance": 0.0,
        }
        
        log.info(f"[ODOMETRY] Initialized: speed_mps={self.speed_mps}, max_yaw_rate={self.max_yaw_rate:.3f} rad/s, cov_v={self.cov_v}, cov_omega={self.cov_omega}")
    
    def update_from_command(self, speed: Optional[int], forward: Optional[int], turn: Optional[int], timestamp: float):
        """
        Обновить одометрию по команде движения.

        Args:
            speed: коэффициент скорости 0–2000 (формат Diktum, «газ»),
                   масштабирует максимальную скорость.
            forward: движение вперёд/назад -2000..2000 (+ = вперёд).
            turn: поворот -2000..2000 (+ = влево, против часовой).
            timestamp: таймштамп команды (секунды, float).
        """
        # Считаем дельту времени с прошлого обновления.
        # Ограничиваем dt сверху, чтобы защититься от скачков времени
        # (например, если долго не было команд или системные часы прыгнули).
        dt = max(0.0, min(self.max_dt_seconds, timestamp - self.last_ts))
        
        # Валидация входных данных
        if not self._validate_inputs(dt, timestamp):
            return
        
        # Переводим «сырые» значения джойстика в нормализованный диапазон [-1, 1]
        # Формат Diktum: значения от -2000 до 2000.
        forward_norm = 0.0
        turn_norm = 0.0
        speed_norm = 0.0
        
        if forward is not None:
            forward_norm = max(-1.0, min(1.0, forward / 2000.0))
        if turn is not None:
            turn_norm = max(-1.0, min(1.0, turn / 2000.0))
        if speed is not None:
            speed_norm = max(0.0, min(1.0, speed / 2000.0))
        
        # Считаем скорости в системе координат робота.
        # vx: линейная скорость вперёд (м/с, >0 = вперёд).
        vx = forward_norm * speed_norm * self.speed_mps
        
        # vy: боковая скорость (для нашей кинематики считаем нулевой,
        # но поле оставляем для совместимости и будущих роботов).
        vy = 0.0
        
        # omega: угловая скорость (рад/с, >0 = поворот против часовой, влево).
        omega = turn_norm * self.max_yaw_rate
        
        # Валидация и ограничение скоростей
        vx = max(-self.max_velocity, min(self.max_velocity, vx))
        omega = max(-self.max_angular_velocity, min(self.max_angular_velocity, omega))
        
        if not self._validate_velocities(vx, vy, omega):
            return
        
        self.vx = vx
        self.vy = vy
        self.omega = omega
        
        # Интегрируем скорости, чтобы обновить позицию (dead reckoning).
        # Сначала обновляем угол курса (поворот).
        self.yaw = self._normalize_angle(self.yaw + self.omega * dt)
        
        # Затем обновляем положение. x — вперёд, y — влево.
        # Используем простую модель дифференциального привода:
        # преобразуем скорости в приращения координат, учитывая текущий yaw.
        dx = self.vx * math.cos(self.yaw) * dt - self.vy * math.sin(self.yaw) * dt
        dy = self.vx * math.sin(self.yaw) * dt + self.vy * math.cos(self.yaw) * dt
        
        self.x += dx
        self.y += dy
        
        # Обновляем статистику
        self.stats["update_count"] += 1
        distance = math.sqrt(dx * dx + dy * dy)
        self.stats["total_distance"] += distance
        
        # Обновляем последний таймштамп — он нужен для расчёта следующего dt.
        self.last_ts = timestamp
        
        log.debug(f"[ODOMETRY] Updated: x={self.x:.3f}, y={self.y:.3f}, yaw={self.yaw:.3f}, vx={self.vx:.3f}, omega={self.omega:.3f}")
    
    def update_from_velocities(self, vx: float, vy: float, omega: float, timestamp: float):
        """
        Обновить одометрию напрямую из скоростей (для Simulator/Raspbot).
        
        Этот метод используется когда у нас уже есть вычисленные скорости vx, vy, omega
        (например, из handle_move для Simulator/Raspbot), и не нужно конвертировать
        из команд джойстика.
        
        Args:
            vx: линейная скорость вперёд (м/с, >0 = вперёд)
            vy: боковая скорость (м/с, обычно 0)
            omega: угловая скорость (рад/с, >0 = поворот против часовой, влево)
            timestamp: таймштамп обновления (секунды, float)
        """
        # Считаем дельту времени с прошлого обновления.
        # Ограничиваем dt сверху, чтобы защититься от скачков времени.
        dt = max(0.0, min(self.max_dt_seconds, timestamp - self.last_ts))
        
        # Валидация входных данных
        if not self._validate_inputs(dt, timestamp):
            return
        
        # Валидация и ограничение скоростей
        vx = max(-self.max_velocity, min(self.max_velocity, vx))
        vy = max(-self.max_velocity, min(self.max_velocity, vy))
        omega = max(-self.max_angular_velocity, min(self.max_angular_velocity, omega))
        
        if not self._validate_velocities(vx, vy, omega):
            return
        
        # Сохраняем скорости напрямую (они уже в правильных единицах)
        self.vx = vx
        self.vy = vy
        self.omega = omega
        
        # Интегрируем скорости, чтобы обновить позицию (dead reckoning).
        # Сначала обновляем угол курса (поворот).
        self.yaw = self._normalize_angle(self.yaw + self.omega * dt)
        
        # Затем обновляем положение. x — вперёд, y — влево.
        # Используем простую модель дифференциального привода:
        # преобразуем скорости в приращения координат, учитывая текущий yaw.
        dx = self.vx * math.cos(self.yaw) * dt - self.vy * math.sin(self.yaw) * dt
        dy = self.vx * math.sin(self.yaw) * dt + self.vy * math.cos(self.yaw) * dt
        
        self.x += dx
        self.y += dy
        
        # Обновляем статистику
        self.stats["update_count"] += 1
        distance = math.sqrt(dx * dx + dy * dy)
        self.stats["total_distance"] += distance
        
        # Обновляем последний таймштамп — он нужен для расчёта следующего dt.
        self.last_ts = timestamp
        
        log.debug(f"[ODOMETRY] Updated from velocities: x={self.x:.3f}, y={self.y:.3f}, yaw={self.yaw:.3f}, vx={self.vx:.3f}, omega={self.omega:.3f}")
    
    def get_state(self) -> Dict[str, float]:
        """
        Получить текущую оценку состояния одометрии.

        Returns:
            Словарь с позицией и скоростями в системе координат робота.
        """
        return {
            "x": self.x,
            "y": self.y,
            "yaw": self.yaw,
            "vx": self.vx,
            "vy": self.vy,
            "omega": self.omega,
            "cov_v": self.cov_v,
            "cov_omega": self.cov_omega
        }
    
    def reset(self, x: float = 0.0, y: float = 0.0, yaw: float = 0.0):
        """
        Сбросить одометрию в заданное состояние (используется при релокализации).

        Args:
            x: начальное значение x (метры, вперёд).
            y: начальное значение y (метры, влево).
            yaw: начальный угол курса (радианы).
        """
        self.x = x
        self.y = y
        self.yaw = yaw
        self.vx = 0.0
        self.vy = 0.0
        self.omega = 0.0
        self.last_ts = time.time()
        log.info(f"[ODOMETRY] Reset to: x={x:.3f}, y={y:.3f}, yaw={yaw:.3f}")
    
    def _validate_inputs(self, dt: float, timestamp: float) -> bool:
        """
        Валидация входных данных для обновления одометрии.
        
        Args:
            dt: дельта времени
            timestamp: текущий таймштамп
            
        Returns:
            True если данные валидны, False иначе
        """
        if dt <= 0:
            # Времени не прошло или оно «пошло назад» — пропускаем обновление.
            return False
        
        if not math.isfinite(dt) or not math.isfinite(timestamp):
            self.stats["validation_fail_count"] += 1
            log.warning(f"[ODOMETRY] Invalid timestamp or dt: dt={dt}, timestamp={timestamp}")
            return False
        
        return True
    
    def _validate_velocities(self, vx: float, vy: float, omega: float) -> bool:
        """
        Валидация скоростей перед обновлением одометрии.
        
        Args:
            vx: линейная скорость вперёд
            vy: боковая скорость
            omega: угловая скорость
            
        Returns:
            True если скорости валидны, False иначе
        """
        if not all(math.isfinite(v) for v in [vx, vy, omega]):
            self.stats["validation_fail_count"] += 1
            log.warning(f"[ODOMETRY] Invalid velocities: vx={vx}, vy={vy}, omega={omega}")
            return False
        
        return True
    
    def _normalize_angle(self, angle: float) -> float:
        """
        Нормализовать угол в диапазон [-π, π].

        Args:
            angle: угол в радианах.

        Returns:
            Угол, приведённый к диапазону [-π, π].
        """
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы калькулятора одометрии.
        
        Returns:
            Словарь со статистикой
        """
        return self.stats.copy()

