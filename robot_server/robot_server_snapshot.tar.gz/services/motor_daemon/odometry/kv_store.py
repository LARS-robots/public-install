#!/usr/bin/env python3
"""
Odometry KV store for motor daemon.
Publishes odometry data to NATS JetStream Key-Value store.
"""
import json
import logging
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class OdometryKVStore:
    """
    Publish odometry data to NATS JetStream Key-Value store.
    
    Bucket: loc_state
    Key: motor_odom
    
    Data is published in format matching localization specification
    from localization_daemon/README.md
    """
    
    def __init__(self, nc: Optional[NATS]):
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "loc_state"
        self.key_name = "motor_odom"
    
    async def initialize(self):
        """
        Initialize JetStream and KV store.
        
        Creates or retrieves existing bucket 'loc_state' in NATS JetStream.
        """
        try:
            if not self.nc:
                log.warning("[ODOMETRY_KV] NATS connection not available")
                return
            
            # Create JetStream context
            self.js = self.nc.jetstream()
            
            # Create or get KV bucket
            try:
                # Try to create new bucket
                self.kv = await self.js.create_key_value(bucket=self.bucket_name)
                log.info(f"[ODOMETRY_KV] KV store bucket '{self.bucket_name}' initialized")
            except Exception as e:
                # If bucket already exists, try to get it
                try:
                    self.kv = await self.js.key_value(bucket=self.bucket_name)
                    log.info(f"[ODOMETRY_KV] KV store bucket '{self.bucket_name}' retrieved")
                except Exception:
                    log.error(f"[ODOMETRY_KV] Failed to create or get KV bucket '{self.bucket_name}': {e}")
                    self.kv = None
        except Exception as e:
            log.error(f"[ODOMETRY_KV] Failed to initialize KV store: {e}", exc_info=True)
            self.kv = None
    
    async def publish_odometry(self, odom_state: Dict[str, float], timestamp: float):
        """
        Publish odometry state to KV store.
        
        Args:
            odom_state: State dictionary from OdometryCalculator.get_state()
            timestamp: Current timestamp (seconds)
        """
        if not self.kv:
            return
        
        try:
            # Format data according to localization_daemon/README.md specification
            # Include position (x, y, yaw) as we calculate it
            odom_data = {
                "ts": timestamp,  # Timestamp
                "frame": "robot",  # Local coordinate system
                "x": odom_state["x"],  # Position x (meters, forward)
                "y": odom_state["y"],  # Position y (meters, left)
                "yaw": odom_state["yaw"],  # Heading angle (radians)
                "vx": odom_state["vx"],  # Forward velocity (m/s)
                "vy": odom_state["vy"],  # Left velocity (m/s, usually 0)
                "omega": odom_state["omega"],  # Angular velocity (rad/s)
                # Position uncertainty estimate (rough estimate: position uncertainty grows with velocity uncertainty)
                "cov_x": odom_state["cov_v"] * 0.1,
                "cov_y": odom_state["cov_v"] * 0.1,
                "cov_yaw": odom_state["cov_omega"] * 0.1,
                "status": "ok",  # Localization status
                "source": "motor_commands"  # Data source
            }
            
            # Serialize to JSON (compact format without spaces)
            odom_json = json.dumps(odom_data, separators=(',', ':'))
            
            # Save to KV bucket with key 'motor_odom'
            await self.kv.put(self.key_name, odom_json.encode())
            
            log.debug(f"[ODOMETRY_KV] Published odometry: x={odom_state['x']:.3f}, y={odom_state['y']:.3f}, yaw={odom_state['yaw']:.3f}")
        except Exception as e:
            log.error(f"[ODOMETRY_KV] Failed to publish odometry: {e}", exc_info=True)
            # Don't fail execution on KV errors

