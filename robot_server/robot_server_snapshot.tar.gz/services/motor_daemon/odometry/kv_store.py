#!/usr/bin/env python3
"""
Публикация одометрии в KV‑хранилище NATS JetStream для демона моторов.

Задача модуля:
- взять текущее состояние одометрии (x, y, yaw, vx, vy, omega и ковариации),
- упаковать в JSON в формате, совместимом со спецификацией локализации,
- записать в KV‑бакет `loc_state` под ключом `motor_odom`.
"""
import asyncio
import json
import logging
from typing import Dict, Any, Optional

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class OdometryKVStore:
    """
    Класс для публикации одометрии в KV‑хранилище NATS JetStream.

    Назначение:
    - Хранить «последнее известное» состояние одометрии, доступное другим сервисам
      (локализация, карта, диагностика и т.п.).

    Параметры KV:
    - Bucket: `loc_state`
    - Key: `motor_odom`

    Формат данных:
    - Соответствует спецификации в `localization_daemon/README.md`
      и документу по локализации (x, y, yaw, скорости, ковариации, статус, source).
    """
    
    def __init__(self, nc: Optional[NATS], config: Optional[Dict[str, Any]] = None):
        self.nc = nc
        self.js = None
        self.kv = None
        self.bucket_name = "loc_state"
        self.key_name = "motor_odom"
        
        # Параметры из конфига
        if config:
            odom_cfg = config.get("odometry", {})
            self.retry_count = int(odom_cfg.get("kv_retry_count", 3))
            self.retry_delay = float(odom_cfg.get("kv_retry_delay", 0.1))
            self.enable_kv_publish = bool(odom_cfg.get("enable_kv_publish", True))
        else:
            self.retry_count = 3
            self.retry_delay = 0.1
            self.enable_kv_publish = True
        
        # Статистика
        self.stats = {
            "publish_count": 0,
            "error_count": 0,
            "retry_count": 0,
            "last_publish_ts": None,
            "last_error_ts": None,
            "consecutive_errors": 0,  # Счётчик последовательных ошибок
        }
    
    async def initialize(self):
        """
        Инициализировать доступ к JetStream и KV‑хранилищу.

        Логика:
        - создаём контекст JetStream на существующем соединении NATS;
        - пробуем создать KV‑бакет `loc_state`;
        - если бакет уже существует — просто получаем его.

        В случае ошибок логируем и не сваливаем демон (kv остаётся None).
        """
        if not self.enable_kv_publish:
            log.info("[ODOMETRY_KV] KV publishing disabled in config")
            return
        
        try:
            if not self.nc:
                log.warning("[ODOMETRY_KV] NATS connection not available")
                return
            
            # Создаём контекст JetStream поверх существующего соединения
            self.js = self.nc.jetstream()
            
            # Пробуем создать или получить KV‑бакет
            try:
                # Пытаемся создать новый бакет
                self.kv = await self.js.create_key_value(bucket=self.bucket_name)
                log.info(f"[ODOMETRY_KV] KV store bucket '{self.bucket_name}' initialized")
            except Exception as e:
                # Если бакет уже существует, пробуем просто к нему подключиться
                try:
                    self.kv = await self.js.key_value(bucket=self.bucket_name)
                    log.info(f"[ODOMETRY_KV] KV store bucket '{self.bucket_name}' retrieved")
                except Exception:
                    log.error(f"[ODOMETRY_KV] Failed to create or get KV bucket '{self.bucket_name}': {e}")
                    self.kv = None
        except Exception as e:
            log.error(f"[ODOMETRY_KV] Failed to initialize KV store: {e}", exc_info=True)
            self.kv = None
    
    async def publish_odometry(self, odom_state: Dict[str, float], timestamp: float):
        """
        Опубликовать текущее состояние одометрии в KV‑хранилище.

        Args:
            odom_state: словарь с состоянием одометрии из OdometryCalculator.get_state().
            timestamp: текущий таймштамп (секунды, float), кладём в поле "ts".
        """
        if not self.enable_kv_publish:
            return
        
        if not self.kv:
            return
        
        # Формируем структуру данных в формате, ожидаемом локализацией.
        # Здесь уже используем координаты в системе "robot":
        #  - x, y — метры относительно стартовой точки робота,
        #  - yaw  — угол курса в радианах.
        odom_data = {
            "ts": timestamp,          # Таймштамп измерения
            "frame": "robot",         # Локальная система координат робота
            "x": odom_state["x"],     # Положение x (м, вперёд)
            "y": odom_state["y"],     # Положение y (м, влево)
            "yaw": odom_state["yaw"], # Угол курса (рад)
            "vx": odom_state["vx"],   # Линейная скорость вперёд (м/с)
            "vy": odom_state["vy"],   # Боковая скорость (м/с, обычно 0)
            "omega": odom_state["omega"],  # Угловая скорость (рад/с)
            # Грубая оценка неопределённости по положению.
            # Здесь мы просто масштабируем ковариации скорости,
            # чтобы дать downstream‑сервисам хоть какую‑то оценку доверия.
            "cov_x": odom_state["cov_v"] * 0.1,
            "cov_y": odom_state["cov_v"] * 0.1,
            "cov_yaw": odom_state["cov_omega"] * 0.1,
            "status": "ok",            # Статус локализации по одометрии
            "source": "motor_commands" # Источник данных — команды моторов
        }
        
        # Сериализуем в компактный JSON без лишних пробелов
        odom_json = json.dumps(odom_data, separators=(',', ':'))
        
        # Публикуем с retry логикой
        success = await self._publish_with_retry(odom_json.encode())
        
        if success:
            self.stats["publish_count"] += 1
            self.stats["last_publish_ts"] = timestamp
            # Сбрасываем счётчик последовательных ошибок при успешной публикации
            if self.stats["consecutive_errors"] > 0:
                self.stats["consecutive_errors"] = 0
            log.debug(f"[ODOMETRY_KV] Published odometry: x={odom_state['x']:.3f}, y={odom_state['y']:.3f}, yaw={odom_state['yaw']:.3f}")
        else:
            self.stats["error_count"] += 1
            self.stats["last_error_ts"] = timestamp
            self.stats["consecutive_errors"] += 1
            
            # Предупреждение при частых ошибках
            if self.stats["consecutive_errors"] >= 10:
                log.warning(f"[ODOMETRY_KV] Multiple consecutive publish errors ({self.stats['consecutive_errors']}). "
                           f"Check NATS connection and KV bucket 'loc_state'.")
                # Сбрасываем счётчик, чтобы не спамить логи
                self.stats["consecutive_errors"] = 0
    
    async def _publish_with_retry(self, data: bytes) -> bool:
        """
        Публикация в KV store с повторными попытками.
        
        Args:
            data: данные для публикации (JSON в байтах)
            
        Returns:
            True если публикация успешна, False иначе
        """
        for attempt in range(self.retry_count):
            try:
                await self.kv.put(self.key_name, data)
                return True
            except Exception as e:
                if attempt < self.retry_count - 1:
                    self.stats["retry_count"] += 1
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    log.debug(f"[ODOMETRY_KV] Retry {attempt + 1}/{self.retry_count}: {e}")
                else:
                    log.error(f"[ODOMETRY_KV] Failed to publish after {self.retry_count} attempts: {e}", exc_info=True)
                    return False
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику работы KV store.
        
        Returns:
            Словарь со статистикой
        """
        return self.stats.copy()

