"""
интрускуиця по использованию 
1) source ~/venvs/pwm-env/bin/activate (просто пример, нужно вирутуальное окружение, которое имеет lgpio и gpiozero)
2) cd LARS/services/
3) export GPIOZERO_PIN_FACTORY=lgpio
4) python services/motor_daemon/tests/pwm_test.py  
"""
from gpiozero import PWMOutputDevice
import time

PWM_FREQ = 50
RIGHT_PINS = [16]
LEFT_PINS = [13]

PPM_MIN_DC = 5.0
PPM_NEUTRAL_DC = 7.5
PPM_MAX_DC = 10.0

def inv(dc):
    return 1.0 - (dc / 100.0)

motors = []

for pin in RIGHT_PINS + LEFT_PINS:
    dev = PWMOutputDevice(
        pin=pin,
        frequency=PWM_FREQ,
        active_high=True,
        initial_value=inv(PPM_NEUTRAL_DC)
    )
    motors.append(dev)

print("NEUTRAL")
time.sleep(3)

print("FORWARD")
for m in motors:
    m.value = inv(PPM_MAX_DC)
time.sleep(5)

print("NEUTRAL")
for m in motors:
    m.value = inv(PPM_NEUTRAL_DC)
time.sleep(3)

print("BACKWARD")
for m in motors:
    m.value = inv(PPM_MIN_DC)
time.sleep(5)

for m in motors:
    m.close()
