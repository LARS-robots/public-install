#!/usr/bin/env python3
"""
Standalone test script for Diktum robot 180° clockwise turn via NATS.

Usage:
    python -m motor_daemon.tests.test_turn_180
"""
import asyncio
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from test_base import DiktumNatsTestBase

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


class Turn180Test(DiktumNatsTestBase):
    """Test 180° clockwise turn via NATS."""
    
    async def run(self) -> dict:
        """Execute 180° clockwise turn test."""
        log.info("Starting 180° clockwise turn test")
        
        self._load_config()
        if not await self._connect_nats():
            return {"ok": False, "error": "Failed to connect to NATS"}
        
        speed_mps = self._get_test_speed_mps()
        diktum_speed = self._convert_mps_to_diktum_units(speed_mps)
        
        try:
            # Startup sequence
            if not await self._startup_sequence():
                return {"ok": False, "error": "Startup sequence failed"}
            
            # Step 5: Perform 180° clockwise turn for 5 seconds
            log.info(f"Step 5: Performing 180° clockwise turn at {speed_mps} m/s ({diktum_speed} units) for 5 seconds...")
            await self._send_commands_loop(5.0, diktum_speed, 0, -diktum_speed, "Turn clockwise")
            
            # Step 6: Stop and disable permission
            log.info("Step 6: Stopping and disabling permission...")
            await self._send_commands_loop(2.0, 0, 0, 0, "Stop")
            await self._send_relay_command("permission", False)
            
            await self._send_commands_loop(2.0, 0, 0, 0, "Stop")
            
            log.info("180° turn test completed successfully")
            return {
                "ok": True,
                "test": "turn_180",
                "speed_mps": speed_mps,
                "diktum_speed": diktum_speed
            }
            
        except Exception as e:
            log.error(f"Test failed: {e}", exc_info=True)
            return {"ok": False, "error": str(e)}
        finally:
            await self._disconnect_nats()


async def main():
    """Main entry point."""
    test = Turn180Test()
    result = await test.run()
    
    if result.get("ok"):
        log.info("=" * 60)
        log.info("Test PASSED")
        log.info("=" * 60)
        sys.exit(0)
    else:
        log.error("=" * 60)
        log.error("Test FAILED")
        log.error(f"Error: {result.get('error')}")
        log.error("=" * 60)
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Test interrupted by user")
        sys.exit(130)
