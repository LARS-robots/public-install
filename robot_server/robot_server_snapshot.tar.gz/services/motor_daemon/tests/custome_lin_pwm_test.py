import time
from rpi_hardware_pwm import HardwarePWM

# =========================
# НАСТРОЙКИ
# =========================

PWM_CHANNEL = 0     # для GPIO12 → обычно channel 0
PWM_CHIP = 0        # pwmchip0
PWM_FREQ = 50       # 50 Hz для servo / ESC

# Duty cycle в процентах
DC_NEUTRAL = 7.5
DC_FORWARD = 10.0
DC_BACKWARD = 5.0

print("Starting hardware PWM test")

# =========================
# ИНИЦИАЛИЗАЦИЯ
# =========================

pwm = HardwarePWM(
    pwm_channel=PWM_CHANNEL,
    chip=PWM_CHIP,
    hz=PWM_FREQ
)

try:
    print("Neutral (2s)")
    pwm.start(DC_NEUTRAL)
    time.sleep(2)

    print("Forward (3s)")
    pwm.change_duty_cycle(DC_FORWARD)
    time.sleep(3)

    print("Neutral (2s)")
    pwm.change_duty_cycle(DC_NEUTRAL)
    time.sleep(2)

    print("Backward (3s)")
    pwm.change_duty_cycle(DC_BACKWARD)
    time.sleep(3)

    print("Neutral (2s)")
    pwm.change_duty_cycle(DC_NEUTRAL)
    time.sleep(2)

finally:
    print("Stopping PWM")
    pwm.stop()
    print("Done")
