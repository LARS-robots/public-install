import time
from rpi_hardware_pwm import HardwarePWM

def inv(dc):
    return 100.0 - dc

# =========================
# НАСТРОЙКИ
# =========================

PWM_CHIP = 0         # pwmchip0 на Raspberry Pi 5
PWM_FREQ = 50        # 50 Hz (RC-PWM)

# Каналы
PWM_LEFT_CH  = 0     # PWM0 → GPIO18
PWM_RIGHT_CH = 1     # PWM1 → GPIO13

# Duty cycle в процентах
DC_NEUTRAL  = 7.5
DC_FORWARD  = 10.0
DC_BACKWARD = 5.0

print("Starting dual hardware PWM test")

# =========================
# ИНИЦИАЛИЗАЦИЯ
# =========================

left_pwm = HardwarePWM(
    pwm_channel=PWM_LEFT_CH,
    chip=PWM_CHIP,
    hz=PWM_FREQ
)

right_pwm = HardwarePWM(
    pwm_channel=PWM_RIGHT_CH,
    chip=PWM_CHIP,
    hz=PWM_FREQ
)

try:
    print("Neutral (2s)")
    left_pwm.start(inv(DC_NEUTRAL))
    right_pwm.start(inv(DC_NEUTRAL))
    time.sleep(2)

    print("Forward both motors (3s)")
    left_pwm.change_duty_cycle(inv(DC_FORWARD))
    right_pwm.change_duty_cycle(inv(DC_FORWARD))
    time.sleep(3)

    print("Neutral (2s)")
    left_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    right_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    time.sleep(2)

    print("Backward both motors (3s)")
    left_pwm.change_duty_cycle(inv(DC_BACKWARD))
    right_pwm.change_duty_cycle(inv(DC_BACKWARD))
    time.sleep(3)

    print("Neutral (2s)")
    left_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    right_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    time.sleep(2)

finally:
    print("Stopping PWM")
    left_pwm.stop()
    right_pwm.stop()
    print("Done")
