import time
from rpi_hardware_pwm import HardwarePWM

# =========================
# НАСТРОЙКИ
# =========================

PWM_CHIP = 0          # pwmchip0
PWM_FREQ = 50         # 50 Hz (серво / ESC)

PWM_LEFT_CH  = 0      # канал 0 → GPIO16 (BCM16, pin 36)
PWM_RIGHT_CH = 1      # канал 1 → GPIO13 (BCM13, pin 33)

INVERT_PWM = True    # ← тут только меняешь True/False

# Duty cycle в процентах (как обычно)
DC_NEUTRAL  = 7.5     # стоп
DC_FORWARD  = 10.0    # вперёд
DC_BACKWARD = 5.0     # назад

def inv(dc: float) -> float:
    """Инверсия сигнала по флагу INVERT_PWM (в процентах)."""
    return 100.0 - dc if INVERT_PWM else dc

print("Starting dual hardware PWM test")

# =========================
# ИНИЦИАЛИЗАЦИЯ
# =========================

left_pwm = HardwarePWM(
    pwm_channel=PWM_LEFT_CH,
    chip=PWM_CHIP,
    hz=PWM_FREQ,
)
right_pwm = HardwarePWM(
    pwm_channel=PWM_RIGHT_CH,
    chip=PWM_CHIP,
    hz=PWM_FREQ,
)

try:
    print("Neutral (2s)")
    left_pwm.start(inv(DC_NEUTRAL))
    right_pwm.start(inv(DC_NEUTRAL))
    time.sleep(2)

    print("Forward both motors (3s)")
    left_pwm.change_duty_cycle(inv(DC_FORWARD))
    right_pwm.change_duty_cycle(inv(DC_FORWARD))
    time.sleep(3)

    print("Neutral (2s)")
    left_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    right_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    time.sleep(2)

    print("Backward both motors (3s)")
    left_pwm.change_duty_cycle(inv(DC_BACKWARD))
    right_pwm.change_duty_cycle(inv(DC_BACKWARD))
    time.sleep(3)

    print("Neutral (2s)")
    left_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    right_pwm.change_duty_cycle(inv(DC_NEUTRAL))
    time.sleep(2)

finally:
    print("Stopping PWM")
    left_pwm.stop()
    right_pwm.stop()
    print("Done")