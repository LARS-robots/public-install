#!/usr/bin/env python3
"""
Test script for single waypoint navigation accuracy.

Tests robot movement to a single point at different distances and measures accuracy.
Records trajectory and logs all navigation parameters.
"""
import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

import nats
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
log = logging.getLogger(__name__)


class SingleWaypointTest:
    """Test single waypoint navigation accuracy."""
    
    def __init__(self, nats_url: str = "nats://dev:devpass@127.0.0.1:4222"):
        self.nc: Optional[NATS] = None
        self.js = None
        self.nats_url = nats_url
        self.trajectory: List[Dict[str, Any]] = []
        
    async def connect(self):
        """Connect to NATS."""
        log.info(f"Connecting to NATS at {self.nats_url}")
        self.nc = await nats.connect(self.nats_url)
        self.js = self.nc.jetstream()
        log.info("Connected to NATS")
    
    async def disconnect(self):
        """Disconnect from NATS."""
        if self.nc:
            await self.nc.close()
            log.info("Disconnected from NATS")
    
    async def get_current_pose(self) -> Optional[Dict[str, float]]:
        """Get current robot pose from KV store."""
        try:
            kv = await self.js.key_value("loc_state")
            try:
                entry = await kv.get("current")
                if entry:
                    data = json.loads(entry.value.decode())
                    return {
                        'lat': float(data.get('lat', 0)),
                        'lon': float(data.get('lon', 0)),
                        'yaw': float(data.get('yaw', 0)),
                        'x': float(data.get('x', 0)),
                        'y': float(data.get('y', 0))
                    }
            except NotFoundError:
                pass
            
            # Fallback to motor_odom
            try:
                entry = await kv.get("motor_odom")
                if entry:
                    data = json.loads(entry.value.decode())
                    return {
                        'lat': float(data.get('lat', 0)),
                        'lon': float(data.get('lon', 0)),
                        'yaw': float(data.get('yaw', 0)),
                        'x': float(data.get('x', 0)),
                        'y': float(data.get('y', 0))
                    }
            except NotFoundError:
                pass
        except Exception as e:
            log.debug(f"Failed to read pose: {e}")
        return None
    
    async def get_route_status(self) -> Optional[Dict[str, Any]]:
        """Get current route status from KV store."""
        try:
            kv = await self.js.key_value("motors_navigation")
            try:
                entry = await kv.get("route")
                if entry:
                    return json.loads(entry.value.decode())
            except NotFoundError:
                pass
        except Exception as e:
            log.debug(f"Failed to read route: {e}")
        return None
    
    async def start_route(self, waypoint: Dict[str, float]) -> bool:
        """Start navigation to single waypoint."""
        import requests
        
        # Use API endpoint to start route
        api_url = os.getenv("API_URL", "http://127.0.0.1:8000")
        try:
            response = requests.post(
                f"{api_url}/route/follow",
                json={
                    "path": [waypoint]
                },
                timeout=5.0
            )
            if response.status_code == 200:
                log.info(f"Route started successfully to waypoint ({waypoint['lat']:.6f}, {waypoint['lon']:.6f})")
                return True
            else:
                log.error(f"Failed to start route: HTTP {response.status_code}, {response.text}")
                return False
        except Exception as e:
            log.error(f"Failed to start route: {e}")
            return False
    
    async def cancel_route(self):
        """Cancel current route."""
        import requests
        
        api_url = os.getenv("API_URL", "http://127.0.0.1:8000")
        try:
            response = requests.post(f"{api_url}/route/cancel", timeout=5.0)
            if response.status_code == 200:
                log.info("Route cancelled")
            else:
                log.warning(f"Failed to cancel route: HTTP {response.status_code}")
        except Exception as e:
            log.warning(f"Failed to cancel route: {e}")
    
    def haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate Haversine distance in meters."""
        import math
        R = 6378137.0  # Earth radius in meters
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat/2)**2 + 
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
             math.sin(dlon/2)**2)
        a = min(1.0, max(0.0, a))
        return 2 * R * math.asin(math.sqrt(a))
    
    async def wait_for_route_completion(self, timeout: float = 300.0) -> Dict[str, Any]:
        """Wait for route to complete and record trajectory."""
        start_time = time.time()
        last_log_time = 0.0
        
        self.trajectory = []
        
        while (time.time() - start_time) < timeout:
            pose = await self.get_current_pose()
            route = await self.get_route_status()
            
            if pose:
                # Calculate distance to target if route exists
                distance = None
                if route and route.get("path"):
                    target = route["path"][-1]  # Last waypoint
                    distance = self.haversine_distance(
                        pose['lat'], pose['lon'],
                        target['lat'], target['lon']
                    )
                
                # Record trajectory point
                self.trajectory.append({
                    'timestamp': time.time(),
                    'pose': pose.copy(),
                    'route': {
                        'status': route.get('status') if route else None,
                        'path_idx': route.get('path_idx') if route else None,
                        'distance_to_target': distance
                    }
                })
                
                # Log periodically (every 2 seconds)
                if time.time() - last_log_time >= 2.0:
                    if route:
                        log.info(f"Status: route={route.get('status')}, "
                               f"waypoint={route.get('path_idx', 0)}/{len(route.get('path', []))-1}, "
                               f"distance={distance:.2f}m" if distance else "distance=N/A")
                    last_log_time = time.time()
            
            # Check if route completed
            if route:
                if route.get("status") == "COMPLETED":
                    log.info("Route completed!")
                    break
                elif route.get("status") in ("CANCELLED", "ERROR"):
                    log.warning(f"Route ended with status: {route.get('status')}")
                    break
            
            await asyncio.sleep(0.5)  # Poll every 500ms
        
        # Get final pose
        final_pose = await self.get_current_pose()
        final_route = await self.get_route_status()
        
        result = {
            'completed': final_route.get("status") == "COMPLETED" if final_route else False,
            'final_pose': final_pose,
            'trajectory_length': len(self.trajectory),
            'duration': time.time() - start_time
        }
        
        # Calculate final accuracy if we have target
        if final_route and final_route.get("path") and final_pose:
            target = final_route["path"][-1]
            result['final_distance'] = self.haversine_distance(
                final_pose['lat'], final_pose['lon'],
                target['lat'], target['lon']
            )
            result['target'] = target
        else:
            result['final_distance'] = None
        
        return result
    
    async def test_single_waypoint(
        self,
        start_lat: float,
        start_lon: float,
        distance_m: float,
        direction_deg: float = 0.0  # 0 = north, 90 = east
    ) -> Dict[str, Any]:
        """
        Test movement to a single waypoint at given distance and direction.
        
        Args:
            start_lat, start_lon: Starting position
            distance_m: Distance to waypoint in meters
            direction_deg: Direction to waypoint in degrees (0=north, 90=east)
        """
        import math
        
        # Calculate target waypoint
        # Simple approximation: 1 degree lat ≈ 111320m, 1 degree lon ≈ 111320m * cos(lat)
        R = 6378137.0  # Earth radius
        dlat = (distance_m / R) * (180.0 / math.pi) * math.cos(math.radians(direction_deg))
        dlon = (distance_m / (R * math.cos(math.radians(start_lat)))) * (180.0 / math.pi) * math.sin(math.radians(direction_deg))
        
        target_lat = start_lat + dlat
        target_lon = start_lon + dlon
        
        log.info(f"=" * 60)
        log.info(f"Testing single waypoint navigation")
        log.info(f"Start: ({start_lat:.9f}, {start_lon:.9f})")
        log.info(f"Target: ({target_lat:.9f}, {target_lon:.9f})")
        log.info(f"Distance: {distance_m:.2f}m, Direction: {direction_deg:.1f}°")
        log.info(f"=" * 60)
        
        # Wait a bit for robot to be ready
        await asyncio.sleep(1.0)
        
        # Start route
        success = await self.start_route({
            'lat': target_lat,
            'lon': target_lon
        })
        
        if not success:
            return {
                'ok': False,
                'error': 'Failed to start route'
            }
        
        # Wait for completion
        result = await self.wait_for_route_completion(timeout=300.0)
        
        # Cancel route if still active
        await self.cancel_route()
        
        result['ok'] = result.get('completed', False)
        result['test_config'] = {
            'start_lat': start_lat,
            'start_lon': start_lon,
            'target_lat': target_lat,
            'target_lon': target_lon,
            'distance_m': distance_m,
            'direction_deg': direction_deg
        }
        
        # Log results
        log.info(f"=" * 60)
        log.info(f"Test completed: {'SUCCESS' if result['ok'] else 'FAILED'}")
        if result.get('final_distance') is not None:
            log.info(f"Final accuracy: {result['final_distance']:.3f}m")
            log.info(f"Target accuracy threshold: 0.3m (arrive_eps_m)")
        log.info(f"Duration: {result['duration']:.1f}s")
        log.info(f"Trajectory points: {result['trajectory_length']}")
        log.info(f"=" * 60)
        
        return result
    
    def save_trajectory(self, filename: str):
        """Save trajectory to JSON file."""
        if self.trajectory:
            output_path = Path(__file__).parent.parent / "tests" / "results" / filename
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w') as f:
                json.dump(self.trajectory, f, indent=2)
            log.info(f"Trajectory saved to {output_path}")


async def main():
    """Run test suite."""
    nats_url = os.getenv("NATS_URL", "nats://dev:devpass@127.0.0.1:4222")
    
    test = SingleWaypointTest(nats_url)
    
    try:
        await test.connect()
        
        # Get current pose
        current_pose = await test.get_current_pose()
        if not current_pose:
            log.error("Cannot get current pose. Make sure robot is running and localization is active.")
            return
        
        start_lat = current_pose['lat']
        start_lon = current_pose['lon']
        
        log.info(f"Current robot position: ({start_lat:.9f}, {start_lon:.9f})")
        
        # Test different distances
        test_distances = [1.0, 5.0, 10.0, 20.0]  # meters
        results = []
        
        for distance in test_distances:
            # Test movement north (0 degrees)
            result = await test.test_single_waypoint(
                start_lat, start_lon,
                distance_m=distance,
                direction_deg=0.0
            )
            results.append(result)
            
            # Save trajectory
            test.save_trajectory(f"trajectory_{distance}m.json")
            
            # Wait between tests
            await asyncio.sleep(2.0)
        
        # Summary
        log.info("\n" + "=" * 60)
        log.info("TEST SUMMARY")
        log.info("=" * 60)
        for i, result in enumerate(results):
            dist = result['test_config']['distance_m']
            final_dist = result.get('final_distance')
            status = "PASS" if (final_dist is not None and final_dist < 0.5) else "FAIL"
            log.info(f"Distance {dist:.1f}m: {status} (final accuracy: {final_dist:.3f}m)" if final_dist else f"Distance {dist:.1f}m: FAIL (no final distance)")
        log.info("=" * 60)
        
    except KeyboardInterrupt:
        log.info("Test interrupted by user")
        await test.cancel_route()
    except Exception as e:
        log.error(f"Test failed: {e}", exc_info=True)
        await test.cancel_route()
    finally:
        await test.disconnect()


if __name__ == "__main__":
    asyncio.run(main())




