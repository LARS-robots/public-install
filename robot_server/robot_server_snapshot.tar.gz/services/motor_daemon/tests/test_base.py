#!/usr/bin/env python3
"""
Base class for Diktum NATS test scripts.
Provides shared functionality for config loading, NATS communication, and startup sequence.
"""
import asyncio
import logging
import os
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

import nats
from nats.aio.client import Client as NATS

# Import from new sequence module
from sequence import (
    SequenceKVStore,
    MotorStateMachine,
    get_default_startup_sequence,
    build_sequence_by_id,
    SequenceConfig,
)
from sequence.nats_publisher import publish_command

log = logging.getLogger(__name__)


class DiktumNatsTestBase:
    """Base class for Diktum NATS test scripts."""
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.config_helper = SequenceConfig()  # Use SequenceConfig instead of internal methods
        self.nats_url = os.getenv("NATS_URL", "nats://nats:4222")
        self._stop_flag = False
        self.kv_store = SequenceKVStore()  # Use SequenceKVStore instead of MotorTestKVStore
        self.state_machine: Optional[MotorStateMachine] = None
        self.sequence_subscription = None
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS server and initialize state machine."""
        try:
            log.info(f"Connecting to NATS at {self.nats_url}")
            self.nc = await nats.connect(self.nats_url)
            log.info("Connected to NATS")
            
            # Initialize KV store
            self.kv_store.nc = self.nc
            await self.kv_store.initialize()
            
            # Store default sequences in KV
            await self.kv_store.store_sequence("startup", get_default_startup_sequence())
            
            # Create and start state machine (sequences will be loaded from KV store)
            sequences = {
                "startup": get_default_startup_sequence()
            }
            self.state_machine = MotorStateMachine(self.kv_store, self.nc, sequences)
            await self.state_machine.start()
            
            return True
        except Exception as e:
            log.error(f"Failed to connect to NATS: {e}")
            return False
    
    async def _disconnect_nats(self):
        """Disconnect from NATS and stop state machine."""
        if self.state_machine:
            await self.state_machine.stop()
        if self.nc:
            await self.nc.close()
            log.info("Disconnected from NATS")
    
    async def _send_relay_command(self, relay_name: str, relay_on: bool) -> bool:
        """Send relay command via NATS."""
        success = await publish_command(self.nc, "motors.relay", "relay", {"relay_name": relay_name, "relay_on": relay_on})
        if success:
            log.info(f"Sent relay: {relay_name}={relay_on}")
        return success
    
    async def _send_move_command(self, speed: int, forward: int, turn: int) -> bool:
        """Send move command via NATS."""
        return await publish_command(self.nc, "motors.move", "move", {"speed": speed, "forward": forward, "turn": turn})
    
    def get_sequence_status(self) -> Dict[str, Any]:
        """Expose state machine status for tests."""
        # For backward compatibility, return status from KV store
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, we can't use run_until_complete
                # Return a placeholder that indicates we need async access
                return {"note": "Use async method to get status"}
            else:
                return loop.run_until_complete(self.kv_store.load_state())
        except:
            return {"error": "Cannot get status synchronously"}

    async def get_sequence_status_async(self) -> Dict[str, Any]:
        """Get state machine status asynchronously."""
        return await self.kv_store.load_state()

    def stop_sequence(self, reason: str = "external_stop"):
        """
        Forcefully stop current sequence.
        
        Note: When called from async context (event loop running), this schedules
        the stop command but returns immediately. For guaranteed completion, use
        stop_sequence_async() instead.
        """
        # For backward compatibility, set stop sequence in KV
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Schedule task and ensure it's tracked to prevent garbage collection
                task = asyncio.create_task(self.kv_store.update_current_sequence("stop"))
                if not hasattr(self, '_stop_tasks'):
                    self._stop_tasks = []
                self._stop_tasks.append(task)
                # Clean up completed tasks to prevent memory leak
                self._stop_tasks = [t for t in self._stop_tasks if not t.done()]
                log.debug("Stop sequence task scheduled (async context)")
            else:
                loop.run_until_complete(self.kv_store.update_current_sequence("stop"))
        except Exception as e:
            log.warning(f"Could not stop sequence synchronously: {e}")

    async def stop_sequence_async(self, reason: str = "external_stop"):
        """Forcefully stop current sequence asynchronously."""
        await self.kv_store.update_current_sequence("stop")

    def engine_ready(self) -> bool:
        """
        Check if engine is ready.
        
        Returns:
            True if engine is ready, False otherwise
        """
        # For backward compatibility, check KV store
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                return False  # Can't check synchronously
            state = loop.run_until_complete(self.kv_store.load_state())
            motor_state = state.get("motor_state", {})
            return motor_state.get("engine_state") == "ENGINE_READY"
        except:
            return False

    async def run_test_sequence(self, sequence_id: str, sequence_builder, test_name: str) -> dict:
        """Run test sequence with automatic startup if needed (backward compatible)."""
        if not await self._connect_nats():
            return {"ok": False, "error": "Failed to connect to NATS"}
        
        try:
            # Store sequence in KV
            steps = []
            state = await self.kv_store.load_state()
            motor_state = state.get("motor_state", {})
            
            if motor_state.get("engine_state") != "ENGINE_READY":
                log.info("Engine not ready - will prepend startup sequence")
                startup_steps = deepcopy(get_default_startup_sequence())
                await self.kv_store.store_sequence("startup", startup_steps)
                steps.extend(startup_steps)
            
            # Build sequence using SequenceConfig
            test_steps = sequence_builder(self.config_helper)
            await self.kv_store.store_sequence(sequence_id, test_steps)
            steps.extend(test_steps)
            
            # For standalone tests, run startup first if needed, then test sequence
            if motor_state.get("engine_state") != "ENGINE_READY":
                # Start startup sequence
                await self.kv_store.update_current_sequence("startup")
                # Wait for startup to complete
                await self._wait_for_sequence_completion("startup", timeout=30.0)
            
            # Start test sequence
            await self.kv_store.update_current_sequence(sequence_id)
            # Wait for sequence to complete
            success = await self._wait_for_sequence_completion(sequence_id, timeout=60.0)
            
            if not success:
                return {"ok": False, "error": f"{test_name} sequence failed or timed out"}
            
            log.info(f"{test_name} test completed successfully")
            speed_mps = self.config_helper.get_test_speed_mps()
            diktum_speed = self.config_helper.get_diktum_speed()
            return {
                "ok": True,
                "test": sequence_id,
                "speed_mps": speed_mps,
                "diktum_speed": diktum_speed,
            }
        except Exception as e:
            log.error(f"Test failed: {e}", exc_info=True)
            await self.stop_sequence_async(reason="exception")
            return {"ok": False, "error": str(e)}
        finally:
            await self._disconnect_nats()

    async def _wait_for_sequence_completion(self, sequence_id: str, timeout: float = 60.0) -> bool:
        """Wait for sequence to complete by polling KV store."""
        start_time = time.time()
        while (time.time() - start_time) < timeout:
            state = await self.kv_store.load_state()
            current_seq = state.get("current_sequence")
            seq_state = state.get("sequence_state")
            
            if current_seq != sequence_id:
                # Sequence changed or cleared
                if seq_state == "COMPLETED":
                    return True
                return False

            if seq_state == "COMPLETED":
                return True
            elif seq_state == "ERROR":
                return False

            await asyncio.sleep(0.1)  # Poll every 100ms
        
        log.warning(f"Sequence '{sequence_id}' did not complete within {timeout}s")
        return False

    # Backward compatibility methods - delegate to SequenceConfig
    def _get_test_speed_mps(self) -> float:
        """Get test speed in m/s from config (backward compatibility)."""
        return self.config_helper.get_test_speed_mps()
    
    def _get_diktum_speed(self) -> int:
        """Get fixed Diktum speed value from config (backward compatibility)."""
        return self.config_helper.get_diktum_speed()
    
    def _convert_mps_to_diktum_forward(self, speed_mps: float) -> int:
        """Convert forward speed from m/s to Diktum forward units (backward compatibility)."""
        return self.config_helper.convert_mps_to_diktum_forward(speed_mps)
    
    def _convert_mps_to_diktum_turn(self, speed_mps: float) -> int:
        """Convert turn speed from m/s to Diktum turn units (backward compatibility)."""
        return self.config_helper.convert_mps_to_diktum_turn(speed_mps)
    
    def _convert_mps_to_diktum_units(self, speed_mps: float) -> int:
        """Convert speed from m/s to Diktum units (backward compatibility - uses forward conversion)."""
        return self.config_helper.convert_mps_to_diktum_forward(speed_mps)
