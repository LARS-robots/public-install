#!/usr/bin/env python3
"""
Base class for Diktum NATS test scripts.
Provides shared functionality for config loading, NATS communication, and startup sequence.
"""
import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

import nats
from nats.aio.client import Client as NATS
from config_loader import get_config

log = logging.getLogger(__name__)


class DiktumNatsTestBase:
    """Base class for Diktum NATS test scripts."""
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self.config = {}
        self.nats_url = os.getenv("NATS_URL", "nats://nats:4222")
        self._stop_flag = False
    
    def _load_config(self):
        """Load configuration from config.toml."""
        try:
            app_config = get_config()
            self.config = app_config.raw_data
            log.info(f"Loaded config from: {app_config.config_path}")
        except Exception as e:
            log.warning(f"Failed to load config: {e}, using defaults")
            self.config = {}
    
    def _get_test_speed_mps(self) -> float:
        """Get test speed in m/s from config."""
        diktum_test = self.config.get("diktum_test", {})
        return float(diktum_test.get("diktum_test_speed_mps", 1.0))
    
    def _get_conversion_constant(self) -> float:
        """Get conversion constant from config."""
        diktum_test = self.config.get("diktum_test", {})
        return float(diktum_test.get("diktum_test_conversion_constant", 1000.0))
    
    def _convert_mps_to_diktum_units(self, speed_mps: float) -> int:
        """Convert speed from m/s to Diktum speed units."""
        constant = self._get_conversion_constant()
        diktum_speed = int(speed_mps * constant)
        diktum_speed = max(0, min(2000, diktum_speed))
        if diktum_speed <= 280:
            diktum_speed = 0
        return diktum_speed
    
    async def _connect_nats(self) -> bool:
        """Connect to NATS server."""
        try:
            log.info(f"Connecting to NATS at {self.nats_url}")
            self.nc = await nats.connect(self.nats_url)
            log.info("Connected to NATS")
            return True
        except Exception as e:
            log.error(f"Failed to connect to NATS: {e}")
            return False
    
    async def _disconnect_nats(self):
        """Disconnect from NATS."""
        if self.nc:
            await self.nc.close()
            log.info("Disconnected from NATS")
    
    async def _send_relay_command(self, relay_name: str, relay_on: bool) -> bool:
        """Send relay command via NATS."""
        if not self.nc:
            return False
        try:
            message = {
                "cmd": "relay",
                "args": {"relay_name": relay_name, "relay_on": relay_on},
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            }
            await self.nc.publish("motors.relay", json.dumps(message, separators=(',', ':')).encode())
            log.info(f"Sent relay: {relay_name}={relay_on}")
            return True
        except Exception as e:
            log.error(f"Failed to send relay command: {e}")
            return False
    
    async def _send_move_command(self, speed: int, forward: int, turn: int) -> bool:
        """Send move command via NATS."""
        if not self.nc:
            return False
        try:
            message = {
                "cmd": "move",
                "args": {"speed": speed, "forward": forward, "turn": turn},
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            }
            await self.nc.publish("motors.move", json.dumps(message, separators=(',', ':')).encode())
            return True
        except Exception as e:
            log.error(f"Failed to send move command: {e}")
            return False
    
    async def _send_commands_loop(self, duration: float, speed: int, forward: int, turn: int, description: str):
        """Send commands in a loop for specified duration (72ms intervals)."""
        start_time = time.time()
        frame_count = 0
        while not self._stop_flag and (time.time() - start_time) < duration:
            await self._send_move_command(speed, forward, turn)
            frame_count += 1
            if frame_count % 10 == 0:
                log.info(f"{description} (frame {frame_count})")
            await asyncio.sleep(0.072)  # 72ms interval
    
    async def _startup_sequence(self) -> bool:
        """
        Execute startup sequence matching diktum_test_service.py exactly.
        
        Sequence:
        1. Enable permission relay
        2. Send idle commands (0,0,0) for 2 seconds in loop
        3. Enable starter relay
        4. Send idle commands (0,0,0) for 3.5 seconds in loop
        5. Disable starter relay
        6. Send idle commands (0,0,0) for 2 seconds in loop
        7. Return True when ready
        """
        # Step 1: Enable permission
        log.info("Step 1: Enabling permission relay...")
        if not await self._send_relay_command("permission", True):
            return False
        
        # Step 1.5: Send idle commands for 2 seconds (loop)
        log.info("Step 1.5: Waiting 2 seconds (sending idle commands)...")
        await self._send_commands_loop(2.0, 0, 0, 0, "Idle (permission ON)")
        
        # Step 2: Enable starter
        log.info("Step 2: Enabling starter relay...")
        if not await self._send_relay_command("starter", True):
            return False
        
        # Step 3: Send idle commands for 3.5 seconds (loop)
        log.info("Step 3: Engine warm-up 3.5 seconds (sending idle commands)...")
        await self._send_commands_loop(3.5, 0, 0, 0, "Idle (starter ON)")
        
        # Step 4: Disable starter (keep permission ON)
        log.info("Step 4: Disabling starter relay...")
        if not await self._send_relay_command("starter", False):
            return False
        
        # Step 4.5: Send idle commands for 2 seconds (loop)
        log.info("Step 4.5: Waiting 2 seconds (sending idle commands)...")
        await self._send_commands_loop(2.0, 0, 0, 0, "Idle (after starter)")
        
        log.info("Startup sequence completed")
        return True

