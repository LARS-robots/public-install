# services/config.py
"""
DEPRECATED: This module is deprecated. Use config_loader instead.
Kept for backward compatibility.
"""
from __future__ import annotations

# Import from centralized config loader
from .config_loader import (
    AppConfig,
    AspectCfg,
    LayoutCfg,
    LayoutStereoCfg,
    LayoutQuadCfg,
    VideoCfg,
    RecordingCfg,
    LoggingCfg,
    DiktumCfg,
    MotionCfg,
    MapCfg,
    StartPoseCfg,
    get_config,
    get_config_loader,
    get_config_section,
)

# Re-export for backward compatibility
__all__ = [
    "AppConfig",
    "AspectCfg",
    "LayoutCfg",
    "LayoutStereoCfg",
    "LayoutQuadCfg",
    "VideoCfg",
    "RecordingCfg",
    "LoggingCfg",
    "DiktumCfg",
    "MotionCfg",
    "MapCfg",
    "StartPoseCfg",
    "get_config",
    "get_config_loader",
    "get_config_section",
]
