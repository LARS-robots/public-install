from __future__ import annotations
import asyncio
import os
import time
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# --- existing routers & services ---
from .routers.system import admin, telemetry_router, logs, localization_debug, svc_state_router
from .routers.streaming import camera, webrtc
from .routers.motor import motion
from .routers.navigation import route_routers
from .routers.network import wifi_api, wifi_ws
from .routers.test import motor_diktum_test
from .routers.test import nats_pub_test

from .services.network.wifi_manager import WifiManager
from .services.motor.robot_service import get_robot_service
from .logging_setup import setup_logging, start_observers
from .telemetry import logbus
from .services.system.svc_state import SvcStateClient
# from .services.logging.nats_log_bridge import start_nats_log_bridge, stop_nats_log_bridge
try:
    from .services.logging.nats_log_bridge import start_nats_log_bridge, stop_nats_log_bridge
except ImportError:
    # Fallback if nats_log_bridge doesn't exist
    async def start_nats_log_bridge():
        pass
    async def stop_nats_log_bridge():
        pass

# --- new unified video system with centralized config ---
from .services.system.config_loader import get_config
from .services.streaming.camera_manager import CameraManager
from .services.streaming.webrtc_service import WebRTCService


logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    print("[START] API server starting...", flush=True)
    logger.info("🚀 Starting application lifespan...")
    # ---- load centralized config ----
    app_config = get_config()
    app.state.app_config = app_config
    logger.info("✅ Config loaded")
    
    # ---- init camera manager ----
    camera_manager = CameraManager(app_config)
    app.state.camera_manager = camera_manager
    
    # ---- init WebRTC service ----
    webrtc_service = WebRTCService(app_config)
    webrtc_service.set_camera_manager(camera_manager)
    camera_manager.set_webrtc_service(webrtc_service)
    app.state.webrtc_service = webrtc_service

    # ---- start telemetry log bus ----
    logbus.bind_loop(asyncio.get_running_loop())
    interval_s = 10
    logging.getLogger("startup").info(f"Starting observers with interval {interval_s}s")
    start_observers(asyncio.get_running_loop(), interval_s=interval_s)
    
    # ---- publish initial svc_state for API ----
    svc_state_client = None
    svc_state_nc = None
    try:
        from .routers.system.localization_debug import _connect_nats

        svc_state_nc = await _connect_nats()
        svc_state_client = SvcStateClient(svc_state_nc)
        await svc_state_client.initialize()
        # starting
        await svc_state_client.set_status(
            "api",
            "starting",
            details={"phase": "init"},
        )
        app.state.svc_state_client = svc_state_client
        logger.info("✅ svc_state client initialized for api")
    except Exception as e:
        logger.warning("Failed to initialize svc_state client for api: %s", e)
    
    # ---- start NATS log bridge (для отображения логов из других сервисов на веб-странице) ----
    # Запускаем в фоне, чтобы не блокировать старт приложения
    async def start_bridge_background():
        try:
            # Небольшая задержка, чтобы убедиться, что логирование полностью настроено
            await asyncio.sleep(0.5)
            logger.info("Starting NATS log bridge background task...")
            await start_nats_log_bridge()
            logger.info("✅ NATS log bridge background task completed")
        except Exception as e:
            error_msg = f"Failed to start NATS log bridge: {e}, continuing without it"
            print(f"[ERROR] {error_msg}", flush=True)
            logger.warning(error_msg, exc_info=True)
    
    # Запустить в фоне, не ждать завершения
    bridge_task = asyncio.create_task(start_bridge_background())
    logger.info(f"NATS log bridge task created: {bridge_task}")

    # ---- navigation tick task ----
    async def navigation_tick_loop():
        """Background autonomous navigation tick (~12 Hz)."""
        while True:
            try:
                robot = get_robot_service(app.state)
                robot.tick_navigation()
            except Exception as e:
                logger.error(f"❌ Navigation tick error: {e}", exc_info=True)
            await asyncio.sleep(0.08)

    tick_task = asyncio.create_task(navigation_tick_loop())
    logger.info("✅ Navigation tick loop started")

    # API fully ready
    if svc_state_client:
        try:
            await svc_state_client.set_status(
                "api",
                "ready",
                details={"phase": "running"},
            )
        except Exception as e:
            logger.warning("Failed to publish ready status to svc_state: %s", e)

    yield  # ---------------- app runs here ----------------

    # ---- graceful shutdown ----
    logger.info("🛑 Shutting down navigation tick loop")
    tick_task.cancel()
    try:
        await tick_task
    except asyncio.CancelledError:
        pass

    # ---- cleanup WebRTC state ----
    try:
        logger.info("🧹 Cleaning up WebRTC state")
        await webrtc.cleanup_app_state(app.state)
    except Exception as exc:
        logger.warning("WebRTC cleanup during shutdown failed: %s", exc)
    
    # ---- stop NATS log bridge ----
    await stop_nats_log_bridge()

    # ---- update svc_state on shutdown ----
    if getattr(app.state, "svc_state_client", None):
        try:
            await app.state.svc_state_client.set_status(
                "api",
                "stopped",
                details={"phase": "shutdown"},
            )
        except Exception as e:
            logger.warning("Failed to publish stopped status to svc_state: %s", e)
    if svc_state_nc:
        try:
            await svc_state_nc.drain()
        except Exception:
            await svc_state_nc.close()
    
    print("[STOP] API server stopped", flush=True)

def create_app() -> FastAPI:
    # ---- load config for logging setup ----
    app_config = get_config()
    log_cfg = app_config.logging
    
    # ---- load NATS configuration (включен по умолчанию) ----
    nats_enable = True  # По умолчанию ВКЛЮЧЕН
    nats_url = None
    nats_service_name = None
    
    try:
        # Попытка загрузить из config.toml (через raw_data)
        nats_config = app_config.raw_data.get("nats", {})
        nats_logging = nats_config.get("logging", {})
        # По умолчанию True, но можно отключить через config
        nats_enable = nats_logging.get("enable", True)  # ← По умолчанию True
        # Приоритет: env переменная > config.toml
        nats_url = os.getenv("NATS_URL") or nats_config.get("url")
        nats_service_name = nats_logging.get("service_name") or os.getenv("SERVICE_NAME")
    except Exception:
        # Если конфигурация недоступна - используем env variables
        # По умолчанию включен, можно отключить через NATS_LOGGING_ENABLE=0
        nats_enable_env = os.getenv("NATS_LOGGING_ENABLE", "1")  # ← По умолчанию "1"
        nats_enable = nats_enable_env.lower() in ("1", "true", "yes")
        nats_url = os.getenv("NATS_URL")
        nats_service_name = os.getenv("SERVICE_NAME")
    
    # ---- structured logging setup (старая система + NATS по умолчанию) ----
    setup_logging(
        level=logging.INFO,
        live_dir        = log_cfg.live_dir,
        archive_dir     = log_cfg.archive_dir,
        segment_size_mb = log_cfg.segment_size_mb,
        segment_max_sec = log_cfg.segment_max_sec,
        zstd_level      = log_cfg.zstd_level,
        max_total_bytes = log_cfg.max_total_bytes,
        max_age_days    = log_cfg.max_age_days,
        # НОВОЕ: NATS параметры (включен по умолчанию)
        enable_nats     = nats_enable,  # По умолчанию True
        nats_url        = nats_url,
        nats_service_name = nats_service_name,
    )

    tags_metadata = [
        {"name": "Admin", "description": "Управление подключением"},
        {"name": "Camera", "description": "Операции с камерой"},
        {"name": "Motion", "description": "Движение робота"},
        {"name": "Telemetry", "description": "Телеметрия и навигация робота"},
        {"name": "Route", "description": "Планирование и следование маршрутам"},
        {"name": "WebRTC", "description": "Обработка и трансляция видео"},
        {"name": "WiFi", "description": "Настройка WiFi через API и WebSocket"},
        {"name": "Logs", "description": "Работа с логами"},
        {"name": "Test", "description": "Тестирование Двигателей, NATS"},
    ]

    app = FastAPI(
        title="LARS Robot Server",
        version="1.0.0",
        description="Управление камерой, движением и навигацией робота ЛАРС",
        lifespan=lifespan,
        openapi_tags=tags_metadata
    )

    # ---- CORS ----
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- shared app state ----
    app.state.wifi_manager = WifiManager()
    app.state.sim_pose = None
    app.state.motion_cfg = None
    app.state.route_state = None
    app.state.manual_override_until = 0.0

    # ---- Access logging middleware ----
    @app.middleware("http")
    async def access_log_mw(request: Request, call_next):
        t0 = time.perf_counter()
        resp = await call_next(request)
        dt_ms = int((time.perf_counter() - t0) * 1000)
        logging.getLogger("http").info(
            "request",
            extra={"event": {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
                "src": "http",
                "evt": "request",
                "method": request.method,
                "path": request.url.path,
                "status": resp.status_code,
                "ms": dt_ms
            }},
        )
        return resp

    # ---- Routers ----
    app.include_router(admin.router)
    app.include_router(camera.router)
    app.include_router(motion.router)
    app.include_router(telemetry_router.router)
    app.include_router(localization_debug.router)
    app.include_router(svc_state_router.router)
    app.include_router(webrtc.router)
    app.include_router(wifi_api.router)
    app.include_router(wifi_ws.router)
    app.include_router(logs.router)
    app.include_router(route_routers.router)
    app.include_router(motor_diktum_test.router)
    app.include_router(nats_pub_test.router)

    # ---- UI (React SPA) ----
    ui_dist = Path(__file__).parent / "ui_dist"
    ui_index = ui_dist / "index.html"
    ui_assets = ui_dist / "assets"

    @app.get("/", include_in_schema=False)
    def root_redirect():
        return RedirectResponse(url="/ui/", status_code=307)

    @app.get("/ui", include_in_schema=False)
    def ui_no_slash_redirect():
        return RedirectResponse(url="/ui/", status_code=307)

    # /ui/assets/* -> ассеты сборки Vite
    if ui_assets.exists():
        app.mount("/ui/assets", StaticFiles(directory=str(ui_assets)), name="ui-assets")
        logger.info(f"✅ UI assets mounted: {ui_assets}")
    else:
        logger.warning(f"⚠️ UI assets directory not found: {ui_assets}")

    # SPA fallback: /ui/* -> index.html
    @app.get("/ui/{full_path:path}", include_in_schema=False)
    def ui_spa(full_path: str):
        if not ui_index.exists():
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail="UI build not found (ui_dist/index.html)")

        # If a real file exists in ui_dist (e.g. /ui/vite.svg, /ui/RobotMapIcon.png), serve it.
        # Otherwise fall back to index.html (SPA routing).
        try:
            requested_path = (ui_dist / full_path).resolve()
            requested_path.relative_to(ui_dist.resolve())
        except Exception:
            return FileResponse(ui_index)

        if requested_path.is_file():
            return FileResponse(requested_path)

        return FileResponse(ui_index)

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
