from __future__ import annotations
import asyncio
import time
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# --- existing routers & services ---
from .routers.system import admin, telemetry_router, logs
from .routers.streaming import camera, webrtc
from .routers.motor import motion
from .routers.navigation import route_routers
from .routers.network import wifi_api, wifi_ws

from .services.network.wifi_manager import WifiManager
from .services.motor.robot_service import get_robot_service
from .logging_setup import setup_logging, start_observers
from .telemetry import logbus

# --- new unified video system with centralized config ---
from .services.system.config_loader import get_config
from .services.streaming.camera_manager import CameraManager
from .services.streaming.webrtc_service import WebRTCService

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    # ---- load centralized config ----
    app_config = get_config()
    app.state.app_config = app_config
    
    # ---- init camera manager ----
    camera_manager = CameraManager(app_config)
    app.state.camera_manager = camera_manager
    
    # ---- init WebRTC service ----
    webrtc_service = WebRTCService(app_config)
    webrtc_service.set_camera_manager(camera_manager)
    camera_manager.set_webrtc_service(webrtc_service)
    app.state.webrtc_service = webrtc_service

    # ---- start telemetry log bus ----
    logbus.bind_loop(asyncio.get_running_loop())
    interval_s = 10
    logging.getLogger("startup").info(f"Starting observers with interval {interval_s}s")
    start_observers(asyncio.get_running_loop(), interval_s=interval_s)

    # ---- navigation tick task ----
    async def navigation_tick_loop():
        """Background autonomous navigation tick (~12 Hz)."""
        while True:
            try:
                robot = get_robot_service(app.state)
                robot.tick_navigation()
            except Exception as e:
                logger.error(f"❌ Navigation tick error: {e}", exc_info=True)
            await asyncio.sleep(0.08)

    tick_task = asyncio.create_task(navigation_tick_loop())
    logger.info("✅ Navigation tick loop started")

    yield  # ---------------- app runs here ----------------

    # ---- graceful shutdown ----
    logger.info("🛑 Shutting down navigation tick loop")
    tick_task.cancel()
    try:
        await tick_task
    except asyncio.CancelledError:
        pass

    # ---- cleanup WebRTC state ----
    try:
        logger.info("🧹 Cleaning up WebRTC state")
        await webrtc.cleanup_app_state(app.state)
    except Exception as exc:
        logger.warning("WebRTC cleanup during shutdown failed: %s", exc)

def create_app() -> FastAPI:
    # ---- load config for logging setup ----
    app_config = get_config()
    log_cfg = app_config.logging
    
    # ---- structured logging setup ----
    setup_logging(
        level=logging.INFO,
        live_dir        = log_cfg.live_dir,
        archive_dir     = log_cfg.archive_dir,
        segment_size_mb = log_cfg.segment_size_mb,
        segment_max_sec = log_cfg.segment_max_sec,
        zstd_level      = log_cfg.zstd_level,
        max_total_bytes = log_cfg.max_total_bytes,
        max_age_days    = log_cfg.max_age_days,
    )

    tags_metadata = [
        {"name": "Admin", "description": "Управление подключением"},
        {"name": "Camera", "description": "Операции с камерой"},
        {"name": "motion", "description": "Движение робота"},
        {"name": "telemetry", "description": "Телеметрия и навигация робота"},
        {"name": "route", "description": "Планирование и следование маршрутам"},
        {"name": "WebRTC", "description":
            ("Обработка и трансляция видео. "
             "Для тестирования видео откройте [HTML-клиент ↗](/static/webrtc_client.html).")
        },
        {"name": "WiFi", "description": "Настройка WiFi через API и WebSocket"},
        {"name": "Logs", "description":
            ("Для просмотра логов откройте [HTML-клиент ↗](/admin/logs).")
        },
    ]

    app = FastAPI(
        title="LARS Robot Server",
        version="1.0.0",
        description="Управление камерой, движением и навигацией робота ЛАРС",
        lifespan=lifespan,
        openapi_tags=tags_metadata
    )

    # ---- CORS ----
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- shared app state ----
    app.state.wifi_manager = WifiManager()
    app.state.sim_pose = None
    app.state.motion_cfg = None
    app.state.route_state = None
    app.state.manual_override_until = 0.0

    # ---- Access logging middleware ----
    @app.middleware("http")
    async def access_log_mw(request: Request, call_next):
        t0 = time.perf_counter()
        resp = await call_next(request)
        dt_ms = int((time.perf_counter() - t0) * 1000)
        logging.getLogger("http").info(
            "request",
            extra={"event": {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
                "src": "http",
                "evt": "request",
                "method": request.method,
                "path": request.url.path,
                "status": resp.status_code,
                "ms": dt_ms
            }},
        )
        return resp

    # ---- Routers ----
    app.include_router(admin.router)
    app.include_router(camera.router)
    app.include_router(motion.router)
    app.include_router(telemetry_router.router)
    app.include_router(webrtc.router)
    app.include_router(wifi_api.router)
    app.include_router(wifi_ws.router)
    app.include_router(logs.router)
    app.include_router(route_routers.router)

    # ---- Static files ----
    static_path = Path(__file__).parent / "static"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
        logger.info(f"✅ Static files mounted: {static_path}")
    else:
        logger.warning(f"⚠️ Static directory not found: {static_path}")

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
