# app/logging_setup.py
from __future__ import annotations

import logging
import sys
import time
import os
import asyncio
import subprocess
import threading
from pathlib import Path
from typing import Optional, Dict

# Требуются зависимости:
#   pip install msgpack zstandard
import msgpack
try:
    import zstandard as zstd
except Exception:
    zstd = None  # позволим работать без компрессии (dev-окружение)

# НОВЫЙ импорт: NATS logger (опционально, с fallback)
import sys
# Добавляем путь к nats_logger если он смонтирован
if "/nats_logger" not in sys.path:
    sys.path.insert(0, "/nats_logger")

try:
    from nats_logger import NATSHandler, detect_service_name
    NATS_LOGGER_AVAILABLE = True
except ImportError:
    NATS_LOGGER_AVAILABLE = False
    NATSHandler = None  # type: ignore
    detect_service_name = None  # type: ignore


def record_to_event(record: logging.LogRecord) -> dict:
    """
    Преобразуем LogRecord в структурное событие.
    Если лог вызывали как log.info(..., extra={"event": {...}}), берём этот dict за основу.
    """
    ev = getattr(record, "event", None)
    if isinstance(ev, dict):
        out = ev.copy()
    else:
        out = {"msg": record.getMessage()}
    out.setdefault("logger", record.name)
    out.setdefault("level", record.levelname)
    out.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)))
    return out


class MsgpackZstdSegmentHandler(logging.Handler):
    """
    DEPRECATED: Основное хранилище логов: бинарный поток MessagePack с ротацией.
    
    ⚠️ Этот handler помечен как DEPRECATED и будет удален в будущем.
    Используйте logger-daemon для централизованного хранения логов из NATS в JSONL формат.
    
    Текущий сегмент хранится нежатым (для live-вьюера), закрытые сегменты — сжимаются в .zst.
    После каждой компрессии запускается "reaper" (лимиты по объёму/возрасту).
    """
    def __init__(
        self,
        live_dir: str = "/var/log/lars/live",
        archive_dir: str = "/var/log/lars/archive",
        segment_size_mb: int = 64,
        segment_max_sec: int = 1800,
        zstd_level: int = 9,
        max_total_bytes: int | str = 8_589_934_592,  # 8 GiB
        max_age_days: int = 14,
    ) -> None:
        super().__init__()
        self.live_dir = Path(live_dir); self.live_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir = Path(archive_dir); self.archive_dir.mkdir(parents=True, exist_ok=True)
        self.seg_bytes = int(segment_size_mb) * 1024 * 1024
        self.seg_secs  = int(segment_max_sec)
        self.zstd_level = int(zstd_level)
        self.max_total_bytes = self._parse_size(max_total_bytes)
        self.max_age_days = int(max_age_days)

        self.cur_path = self.live_dir / "robot-current.msgp"
        self._f = open(self.cur_path, "ab", buffering=0)
        self._opened_at = time.time()
        self._bytes = self._f.tell()
        self._lock = threading.Lock()

    @staticmethod
    def _parse_size(v):
        if isinstance(v, int):
            return v
        s = str(v).strip().lower().replace(" ", "")
        mul = 1
        if s.endswith(("k", "kb")): mul, s = 1024, s.rstrip("kb").rstrip("k")
        elif s.endswith(("m", "mb")): mul, s = 1024**2, s.rstrip("mb").rstrip("m")
        elif s.endswith(("g", "gb")): mul, s = 1024**3, s.rstrip("gb").rstrip("g")
        elif s.endswith(("t", "tb")): mul, s = 1024**4, s.rstrip("tb").rstrip("t")
        elif s.endswith("kib"): mul, s = 1024, s[:-3]
        elif s.endswith("mib"): mul, s = 1024**2, s[:-3]
        elif s.endswith("gib"): mul, s = 1024**3, s[:-3]
        elif s.endswith("tib"): mul, s = 1024**4, s[:-3]
        try:
            return int(float(s) * mul)
        except Exception:
            return 8_589_934_592  # дефолт 8 GiB

    def emit(self, record: logging.LogRecord) -> None:
        try:
            event = record_to_event(record)
            data = msgpack.packb(event, use_bin_type=True)
            with self._lock:
                self._f.write(data)
                self._bytes += len(data)
                if self._need_rotate():
                    self._rotate_async()
        except Exception as e:
            try:
                sys.stderr.write(f"[logging_setup] emit error: {e}\n")
            except Exception:
                pass  # не роняем приложение из-за логгера

    def _need_rotate(self) -> bool:
        return (self._bytes >= self.seg_bytes) or ((time.time() - self._opened_at) >= self.seg_secs)

    def _rotate_async(self) -> None:
        # закрыть текущий
        try:
            self._f.flush()
            self._f.close()
        except Exception:
            pass

        ts = time.strftime("%Y%m%d-%H%M%S", time.localtime(self._opened_at))
        final = self.live_dir / f"robot-{ts}.msgp"
        os.replace(self.cur_path, final)

        # открыть новый
        self._f = open(self.cur_path, "ab", buffering=0)
        self._opened_at = time.time()
        self._bytes = 0

        # компрессия в фоне (если есть zstd)
        if zstd is not None:
            t = threading.Thread(target=self._compress_then_delete, args=(final,), daemon=True)
            t.start()

    def _compress_then_delete(self, src: Path) -> None:
        try:
            dst = self.archive_dir / (src.name + ".zst")
            c = zstd.ZstdCompressor(level=self.zstd_level) if zstd else None
            if c is not None:
                with open(src, "rb") as fi, open(dst, "wb") as fo:
                    c.copy_stream(fi, fo)
        except Exception as e:
            try:
                sys.stderr.write(f"[logging_setup] compress error: {e}\n")
            except Exception:
                pass
            return
        # удаляем исходный сегмент после успешной компрессии
        try:
            src.unlink()
        except Exception:
            pass
        # применяем ретеншн-правила
        try:
            self._reap()
        except Exception:
            pass

    def _reap(self) -> None:
        """
        Лимиты по возрасту (max_age_days) и общему объёму (max_total_bytes) в archive_dir.
        Удаляем самые старые сегменты.
        """
        import time as _t
        files = list(self.archive_dir.glob("robot-*.msgp.zst")) + list(self.archive_dir.glob("robot-*.msgp"))
        files.sort(key=lambda p: p.stat().st_mtime)

        # по возрасту
        cutoff = _t.time() - self.max_age_days * 86400
        for f in files:
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink(missing_ok=True)
            except FileNotFoundError:
                pass

        # по общему размеру
        files = list(self.archive_dir.glob("robot-*.msgp.zst")) + list(self.archive_dir.glob("robot-*.msgp"))
        files.sort(key=lambda p: p.stat().st_mtime)
        total = 0
        sized = []
        for f in files:
            try:
                sz = f.stat().st_size
            except FileNotFoundError:
                continue
            total += sz
            sized.append((f, sz))
        i = 0
        while total > self.max_total_bytes and i < len(sized):
            f, sz = sized[i]
            try:
                f.unlink(missing_ok=True)
                total -= sz
            except FileNotFoundError:
                pass
            i += 1


def setup_logging(
    level: int = logging.INFO,
    live_dir: str | None = None,  
    archive_dir: str | None = None,
    segment_size_mb: int = 64,
    segment_max_sec: int = 1800,
    zstd_level: int = 9,
    max_total_bytes: int | str = 8_589_934_592,
    max_age_days: int = 14,
    # НОВЫЕ параметры: NATS логирование (включено по умолчанию)
    enable_nats: bool = True,  # ← По умолчанию ВКЛЮЧЕНО
    nats_url: Optional[str] = None,
    nats_service_name: Optional[str] = None,
    # Опциональное отключение локального хранения файлов (legacy - DEPRECATED)
    enable_file_storage: bool = False,  # По умолчанию False - используйте logger-daemon для хранения логов
) -> None:
    """
    Unified logging pipeline:
      1) StreamHandler(stdout) — ERROR+ только (триггерные события: ERROR, CRITICAL, старт/стоп)
      2) MsgpackZstdSegmentHandler — DEPRECATED, опционально (по умолчанию отключен, используйте logger-daemon)
      3) NATSHandler — centralized logging via NATS (ENABLED BY DEFAULT)
    
    Архитектура логирования:
    - Все события (INFO, WARNING, ERROR, CRITICAL) отправляются в NATS через NATSHandler
    - NATS log bridge (nats_log_bridge.py) подписывается на NATS и пересылает события в logbus
    - WebSocket /admin/logs/ws использует logbus для отображения логов в веб-интерфейсе
    - stdout содержит только триггерные события (ERROR, CRITICAL, старт/стоп)
    - Старт/стоп события выводятся через print() для гарантированного отображения
    - NATS включен по умолчанию, можно отключить через enable_nats=False
    - Если NATS недоступен, остальные handlers продолжают работать нормально
    
    Хранение логов:
    - Рекомендуется использовать logger-daemon для централизованного хранения (JSONL формат)
    - MsgpackZstdSegmentHandler (локальное хранение) опционально, можно отключить через enable_file_storage=False
    - API endpoints /admin/logs/tail и /admin/logs/before поддерживают оба формата:
      * MessagePack (legacy): robot-*.msgp, robot-*.msgp.zst
      * JSONL (logger-daemon): robot-*.json, robot-*.json.zst
      * Приоритет отдается JSONL файлам, если они существуют
    
    ПРИМЕЧАНИЕ: PublishToBusHandler удален (Этап 2 оптимизации).
    Теперь все события идут через единую систему: NATS → nats_log_bridge → logbus → WebSocket.
    
    Args:
        level: Уровень логирования для root logger
        live_dir: Директория для текущих сегментов (по умолчанию определяется автоматически)
        archive_dir: Директория для архивных сегментов (по умолчанию определяется автоматически)
        segment_size_mb: Максимальный размер сегмента в МБ (только для MsgpackZstdSegmentHandler)
        segment_max_sec: Максимальное время жизни сегмента в секундах (только для MsgpackZstdSegmentHandler)
        zstd_level: Уровень сжатия zstd (только для MsgpackZstdSegmentHandler)
        max_total_bytes: Максимальный общий размер архивов (только для MsgpackZstdSegmentHandler)
        max_age_days: Максимальный возраст архивов в днях (только для MsgpackZstdSegmentHandler)
        enable_nats: Включить NATS логирование (по умолчанию True)
        nats_url: URL NATS сервера (если не указан, берется из переменной окружения NATS_URL)
        nats_service_name: Имя сервиса для NATS (если не указано, определяется автоматически)
        enable_file_storage: Включить локальное хранение через MsgpackZstdSegmentHandler (DEPRECATED, по умолчанию False).
                            ⚠️ Используйте logger-daemon для хранения логов - этот параметр будет удален в будущем
    """
    
    # Auto-detect appropriate log directory
    if live_dir is None or archive_dir is None:
        # Try to determine if running as system service or development
        if os.path.exists("/var/log/lars") and os.access("/var/log/lars", os.W_OK):
            # Production: systemd service with proper permissions
            live_dir = live_dir or "/var/log/lars/live"
            archive_dir = archive_dir or "/var/log/lars/archive"
        else:
            # Development: use project-local log directory
            project_root = Path(__file__).parent.parent.parent
            log_base = project_root / "log" / "lars"
            live_dir = live_dir or str(log_base / "live")
            archive_dir = archive_dir or str(log_base / "archive")
            
            # Create directories if they don't exist
            Path(live_dir).mkdir(parents=True, exist_ok=True)
            Path(archive_dir).mkdir(parents=True, exist_ok=True)
    
    # Использовать унифицированную настройку логирования из nats_logger
    # Это обеспечивает единообразную конфигурацию для всех сервисов
    try:
        from nats_logger import setup_unified_logging
        setup_unified_logging(
            service_name=nats_service_name or "api",
            level=level,
            nats_url=nats_url,
            enable_nats=enable_nats,
            stdout_format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )
    except ImportError:
        # Fallback если nats_logger не доступен
        root = logging.getLogger()
        for h in list(root.handlers):
            root.removeHandler(h)
        root.setLevel(level)
        sh = logging.StreamHandler(sys.stdout)
        sh.setLevel(logging.ERROR)
        sh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        root.addHandler(sh)
        logging.getLogger(__name__).warning("nats_logger not available, using standard logging only")
    
    # Получить root logger для добавления дополнительных handlers
    root = logging.getLogger()
    
    # События старт/стоп логируются через print() для гарантированного вывода в stdout

    # 2) бинарные сегменты (и архив) - DEPRECATED, будет удален в будущем
    # ⚠️ ВНИМАНИЕ: MsgpackZstdSegmentHandler помечен как DEPRECATED.
    # Используйте logger-daemon для централизованного хранения логов из NATS в JSONL формат.
    # API endpoints /admin/logs/tail и /admin/logs/before поддерживают оба формата:
    # - MessagePack (legacy, DEPRECATED): robot-*.msgp, robot-*.msgp.zst
    # - JSONL (рекомендуется, от logger-daemon): robot-*.json, robot-*.json.zst
    # Приоритет отдается JSONL файлам, если они существуют
    if enable_file_storage:
        import warnings
        warnings.warn(
            "MsgpackZstdSegmentHandler is DEPRECATED and will be removed in the future. "
            "Please use logger-daemon for centralized log storage from NATS.",
            DeprecationWarning,
            stacklevel=2
        )
        root.addHandler(MsgpackZstdSegmentHandler(
            live_dir=live_dir,
            archive_dir=archive_dir,
            segment_size_mb=segment_size_mb,
            segment_max_sec=segment_max_sec,
            zstd_level=zstd_level,
            max_total_bytes=max_total_bytes,
            max_age_days=max_age_days,
        ))
    else:
        # Локальное хранение отключено - используем только logger-daemon для хранения
        logging.getLogger(__name__).info(
            "Local file storage (MsgpackZstdSegmentHandler) disabled. "
            "Using logger-daemon for centralized log storage."
        )

    # NATSHandler уже настроен через setup_unified_logging() выше
    # Дополнительная настройка NATSHandler не требуется

    # uvicorn → прокидываем наверх, чтобы не было дублей
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        lg = logging.getLogger(name)
        lg.handlers[:] = []
        lg.propagate = True

    # предупреждения stdlib в logging
    try:
        import warnings
        logging.captureWarnings(True)
        warnings.filterwarnings("default")
    except Exception:
        pass

    # Финальное логирование статуса (только через logger, не в stdout)
    nats_status = "enabled" if (enable_nats and NATS_LOGGER_AVAILABLE and (nats_url or os.getenv("NATS_URL"))) else "disabled"
    logging.getLogger(__name__).info(
        f"Unified logging enabled: live_dir={live_dir}, archive_dir={archive_dir}, NATS: {nats_status}"
    )


# --- power/thermal/event-loop observers ---
_observer_tasks: list[asyncio.Task] = []
_stop_flag = False

# Optional helper: decode vcgencmd bitmask (also exported for reuse)
def decode_throttled(bitmask: int) -> Dict[str, bool]:
    # https://www.raspberrypi.com/documentation/computers/config_txt.html#get_throttled
    # Bits (current <<0.., since_boot <<16..)
    flags = {
        "under_voltage":      bool(bitmask & (1 << 0)),
        "freq_capped":        bool(bitmask & (1 << 1)),
        "throttled":          bool(bitmask & (1 << 2)),
        "soft_temp_limit":    bool(bitmask & (1 << 3)),
        "uv_occurred":        bool(bitmask & (1 << 16)),
        "fc_occurred":        bool(bitmask & (1 << 17)),
        "throttled_occurred": bool(bitmask & (1 << 18)),
        "stl_occurred":       bool(bitmask & (1 << 19)),
    }
    return flags

def _read_first(path: str) -> Optional[str]:
    try:
        with open(path, "r") as f:
            return f.read().strip()
    except Exception:
        return None

def _cpu_temp_c() -> Optional[float]:
    raw = _read_first("/sys/class/thermal/thermal_zone0/temp")
    try:
        return int(raw) / 1000.0 if raw else None
    except Exception:
        return None

def _cpu_freq_mhz() -> Optional[float]:
    raw = _read_first("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    try:
        return int(raw) / 1000.0 if raw else None
    except Exception:
        return None

def _vcgencmd_get_throttled() -> Optional[int]:
    try:
        p = subprocess.run(["vcgencmd", "get_throttled"], text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1.5)
        if p.returncode == 0 and "0x" in p.stdout:
            return int(p.stdout.strip().split("0x", 1)[1], 16)
    except Exception:
        pass
    return None

async def _observer_power(interval_s: int):
    log = logging.getLogger("power")
    while not _stop_flag:
        ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        raw = _vcgencmd_get_throttled()
        if raw is not None:
            flags = decode_throttled(raw)
            lvl = logging.WARNING if (flags["under_voltage"] or flags["throttled"] or flags["freq_capped"]) else logging.INFO
            log.log(lvl, "throttled", extra={"event": {"ts": ts, "src": "power", "evt": "throttled", "raw": hex(raw), **flags}})
        temp_c = _cpu_temp_c()
        freq_mhz = _cpu_freq_mhz()
        if (temp_c is not None) or (freq_mhz is not None):
            log.info("cpu_state", extra={"event": {"ts": ts, "src": "power", "evt": "cpu_state",
                                                   "temp_c": temp_c, "freq_mhz": freq_mhz}})
        await asyncio.sleep(interval_s)

async def _observer_event_loop(interval_s: int):
    # Small runtime signal: event-loop lag
    log = logging.getLogger("runtime")
    target = asyncio.get_running_loop().time()
    while not _stop_flag:
        await asyncio.sleep(interval_s)
        now = asyncio.get_running_loop().time()
        lag_ms = max(0.0, (now - target - interval_s) * 1000.0)
        log.info("event_loop_lag", extra={"event": {"ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
                                                    "src": "runtime", "evt": "event_loop_lag", "lag_ms": round(lag_ms, 2)}})
        target = now

def start_observers(loop: asyncio.AbstractEventLoop, interval_s: int = 10) -> None:
    """
    Start lightweight observers. Safe to call once at app startup.
    """
    global _observer_tasks, _stop_flag
    if _observer_tasks:
        return
    _stop_flag = False
    _observer_tasks = [
        loop.create_task(_observer_power(interval_s)),
        # Отключено: runtime observer (event loop lag) - генерировал пустые события
        # loop.create_task(_observer_event_loop(interval_s)),
    ]

async def stop_observers():
    global _observer_tasks, _stop_flag
    _stop_flag = True
    for t in list(_observer_tasks):
        try:
            t.cancel()
        except Exception:
            pass
    _observer_tasks.clear()
