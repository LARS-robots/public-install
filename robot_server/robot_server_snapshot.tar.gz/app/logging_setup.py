"""
Lightweight logging setup for the robot API.

Goals:
- Provide a stable `setup_logging(...)` API that `main.py` expects.
- Prefer unified NATS-based logging via `nats_logger.setup_unified_logging`.
- Keep behaviour sane even if `nats_logger` volume is not mounted.

This is an interim implementation compatible with the long‑term plan:
Python logging → setup_unified_logging() → NATS → logger-daemon(JSONL) → /admin/logs.
"""

from __future__ import annotations

import logging
import os
from typing import Optional


def _basic_stdout_logging(level: int = logging.INFO) -> None:
    """
    Fallback: simple stdout logging with a concise format.
    """
    root = logging.getLogger()
    # Clear existing handlers to avoid duplicate logs when reloaded by uvicorn
    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler()
    handler.setLevel(level)
    handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    )

    root.setLevel(level)
    root.addHandler(handler)


def setup_logging(
    *,
    level: int = logging.INFO,
    live_dir: Optional[str] = None,
    archive_dir: Optional[str] = None,
    segment_size_mb: Optional[int] = None,
    segment_max_sec: Optional[int] = None,
    zstd_level: Optional[int] = None,
    max_total_bytes: Optional[int] = None,
    max_age_days: Optional[int] = None,
    enable_nats: bool = True,
    nats_url: Optional[str] = None,
    nats_service_name: Optional[str] = None,
) -> None:
    """
    Unified logging entrypoint used by `main.py`.

    For now we:
    - always configure basic stdout logging;
    - optionally add NATS logging via `nats_logger.setup_unified_logging`
      if the package is available.

    File/segment parameters are accepted for compatibility but ignored here:
    the long‑term plan is that logger-daemon is the only component writing JSONL.
    """
    # 1) Always ensure we have sane stdout logging
    _basic_stdout_logging(level=level)

    # 2) Try to enable NATS logging if requested and available
    if not enable_nats:
        logging.getLogger(__name__).info("NATS logging disabled via config/env")
        return

    # Lazily import nats_logger if mounted into the container
    try:
        from nats_logger import setup_unified_logging  # type: ignore
    except Exception as e:  # pragma: no cover - optional dependency
        logging.getLogger(__name__).warning(
            "nats_logger not available, continuing with stdout only: %s", e
        )
        return

    # Derive service name if not explicitly provided
    service_name = (
        nats_service_name
        or os.getenv("SERVICE_NAME")
        or "api"
    )

    # Derive NATS URL if not provided (use env for consistency with other services)
    url = nats_url or os.getenv("NATS_URL")
    if url:
        url = url.strip().rstrip(":")

    setup_unified_logging(
        service_name=service_name,
        nats_url=url,
    )


def start_observers(loop, interval_s: float = 10.0) -> None:
    """
    Compatibility stub for legacy observer system.

    Historically this function started various periodic observers for metrics.
    At the moment API uses `logbus` + logger-daemon for diagnostics, so we
    keep this as a cheap no-op to avoid breaking imports.

    If needed later, we can attach background tasks to `loop` here.
    """
    logger = logging.getLogger(__name__)
    logger.info(
        "start_observers called (interval_s=%s) - no observers configured yet",
        interval_s,
    )


