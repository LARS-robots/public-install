# services/system/config_loader.py
"""
Centralized configuration loader for the robot API.

This module provides a single source of truth for loading configuration
from TOML files, eliminating duplicate config loading logic across the codebase.

Key features:
- Environment-aware config path resolution (Docker, development, production)
- Singleton pattern to avoid reloading configs
- Thread-safe access
- Backward compatibility with existing config structures
"""
from __future__ import annotations
import os
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from threading import Lock

# TOML loader (Py3.11+/older)
try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore

logger = logging.getLogger(__name__)

# ============================================================================
# PATH RESOLUTION
# ============================================================================

def _get_config_search_paths() -> list[Path]:
    """
    Returns prioritized list of paths to search for config.toml.
    
    Order of precedence:
    1. /app/src/config/config.toml (Docker container)
    2. Relative to current working directory
    3. Relative to this file's location
    4. Legacy paths for backward compatibility
    """
    paths = [
        # Docker container path (highest priority)
        Path("/app/src/config/config.toml"),
        # Shared bind mount for multi-service access
        Path("/config/config.toml"),
        # Legacy camera-daemon mount
        Path("/api/src/config/config.toml"),
        
        # Current working directory
        Path.cwd() / "config.toml",
        Path.cwd() / "src/config/config.toml",
        
        # Relative to this module
        Path(__file__).resolve().parent.parent.parent / "config" / "config.toml",
        
        # Legacy paths
        Path("~/LARS/robot_server/config.toml").expanduser(),
        Path(__file__).resolve().parents[2] / "config.toml",
    ]
    
    return paths


def find_config_file() -> Optional[Path]:
    """
    Locate the config.toml file using the search path hierarchy.
    
    Returns:
        Path to config.toml if found, None otherwise
    """
    for path in _get_config_search_paths():
        if path.exists() and path.is_file():
            logger.info(f"✅ Found config at: {path}")
            return path
    
    logger.warning(f"❌ No config file found! Searched paths:")
    for path in _get_config_search_paths():
        logger.warning(f"  - {path}")
    return None


# ============================================================================
# DATA CLASSES
# ============================================================================

def _parse_ratio(text: Optional[str]) -> Tuple[int, int]:
    """Parse aspect ratio string like '16:9' or '1920x1080' to (H, W)."""
    if not text:
        return (0, 0)
    try:
        # Support both ':' and 'x' separators
        text = text.replace("x", ":").replace("X", ":")
        parts = text.split(":")
        if len(parts) != 2:
            return (0, 0)
        w, h = map(int, parts)
        # Return (H, W) to match I420 helpers that expect height first
        return (h, w)
    except (ValueError, AttributeError):
        return (0, 0)


@dataclass(frozen=True)
class AspectCfg:
    """Aspect ratio configuration for video streams."""
    enabled: bool
    mode: str                    # "letterbox" | "crop" | "center_crop"
    mono: tuple[int, int]        # (H, W)
    stereo_left: tuple[int, int] # (H, W)
    quad: tuple[int, int]        # (H, W)


@dataclass(frozen=True)
class LayoutStereoCfg:
    """Stereo camera layout configuration."""
    width: int
    height: int
    camera_index: Optional[int] = None


@dataclass(frozen=True)
class LayoutQuadCfg:
    """Quad camera layout configuration."""
    width: int
    height: int


@dataclass(frozen=True)
class LayoutCfg:
    """Layout configuration for camera arrangements."""
    stereo: Optional[LayoutStereoCfg]
    quad: Optional[LayoutQuadCfg]


@dataclass(frozen=True)
class VideoCfg:
    """Video capture configuration."""
    platform: str   # "gstreamer" | "v4l2" | "opencv" | "rpi"
    fps: int
    width: int
    height: int
    resolution: str  # e.g., "1920x1080"
    codec: str       # e.g., "h264"


@dataclass(frozen=True)
class RecordingCfg:
    """Recording configuration."""
    out_dir: Path
    segment_sec: Optional[int]
    fps: int
    timestamp_source: str


@dataclass(frozen=True)
class LoggingCfg:
    """Logging configuration."""
    live_dir: str
    archive_dir: str
    segment_size_mb: int
    segment_max_sec: int
    zstd_level: int
    max_total_bytes: str
    max_age_days: int


@dataclass(frozen=True)
class DiktumCfg:
    """Diktum robot hardware configuration."""
    serial_device: str
    baudrate: int
    base_command: str
    control_byte_index: int
    control_keep_mask: str
    relay_bits: Dict[str, int]
    command_bytes: Dict[str, str]


@dataclass(frozen=True)
class MotionCfg:
    """Motion control configuration."""
    speed_mps: float
    orient_then_move: bool
    dead_zone: float
    turn_speed_dps: float


@dataclass(frozen=True)
class MapCfg:
    """Map configuration."""
    resolution_m: float
    path_to_geojson: str
    bounds: Dict[str, float]


@dataclass(frozen=True)
class StartPoseCfg:
    """Initial robot pose configuration."""
    lat: float
    lon: float
    yaw: float


@dataclass(frozen=True)
class AppConfig:
    """Main application configuration container."""
    # Core configs
    robot_type: str
    aspect: AspectCfg
    layout: LayoutCfg
    video: VideoCfg
    recording: RecordingCfg
    logging: LoggingCfg
    
    # Robot-specific configs
    diktum: Optional[DiktumCfg]
    motion: MotionCfg
    map: MapCfg
    start_pose: StartPoseCfg
    
    # Raw data for custom access
    raw_data: Dict[str, Any]
    config_path: Optional[Path]

    @staticmethod
    def load(path: Optional[str | Path] = None) -> "AppConfig":
        """
        Load application configuration from TOML file.
        
        Args:
            path: Optional explicit path to config file. If None, uses search paths.
            
        Returns:
            AppConfig instance
            
        Raises:
            FileNotFoundError: If no config file found
        """
        # Determine config path
        if path:
            config_path = Path(path)
            if not config_path.exists():
                raise FileNotFoundError(f"Config not found: {config_path}")
        else:
            config_path = find_config_file()
            if not config_path:
                raise FileNotFoundError("No config.toml found in search paths")
        
        # Load TOML data
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
        
        logger.info(f"✅ Loaded config from: {config_path}")
        
        # Parse robot type
        default_section = data.get("default", {}) or {}
        robot_type = str(default_section.get("robot_type", "simulator"))
        
        # Parse aspect config
        a = data.get("aspect", {}) or {}
        aspect = AspectCfg(
            enabled=bool(a.get("enabled", False)),
            mode=str(a.get("mode", "center_crop")),
            mono=_parse_ratio(a.get("mono")),
            stereo_left=_parse_ratio(a.get("stereo_left")),
            quad=_parse_ratio(a.get("quad")),
        )

        # Parse layout config
        lay = data.get("layout", {}) or {}
        stereo_dict = lay.get("stereo")
        quad_dict = lay.get("quad")
        
        stereo_cfg = None
        if isinstance(stereo_dict, dict):
            stereo_cfg = LayoutStereoCfg(
                width=int(stereo_dict.get("width", 640)),
                height=int(stereo_dict.get("height", 480)),
                camera_index=stereo_dict.get("camera_index"),
            )
        
        quad_cfg = None
        if isinstance(quad_dict, dict):
            quad_cfg = LayoutQuadCfg(
                width=int(quad_dict.get("width", 640)),
                height=int(quad_dict.get("height", 640)),
            )
        
        layout = LayoutCfg(stereo=stereo_cfg, quad=quad_cfg)

        # Parse video config
        v = data.get("video", {}) or {}
        video = VideoCfg(
            platform=str(v.get("platform", "gstreamer")).lower(),
            fps=int(v.get("fps", 30)),
            width=int(v.get("width", 640)),
            height=int(v.get("height", 480)),
            resolution=str(v.get("resolution", "640x480")),
            codec=str(v.get("codec", "h264")),
        )

        # Parse recording config
        r = data.get("recording", {}) or {}
        recording = RecordingCfg(
            out_dir=Path(r.get("out_dir", "recordings")),
            segment_sec=(int(r["segment_sec"]) if "segment_sec" in r and r["segment_sec"] is not None else None),
            fps=int(r.get("fps", 60)),
            timestamp_source=str(r.get("timestamp_source", "monotonic")),
        )

        # Parse logging config
        log = data.get("logging", {}) or {}
        logging_cfg = LoggingCfg(
            live_dir=str(log.get("live_dir", "/var/log/lars/live")),
            archive_dir=str(log.get("archive_dir", "/var/log/lars/archive")),
            segment_size_mb=int(log.get("segment_size_mb", 64)),
            segment_max_sec=int(log.get("segment_max_sec", 1800)),
            zstd_level=int(log.get("zstd_level", 9)),
            max_total_bytes=str(log.get("max_total_bytes", "20GiB")),
            max_age_days=int(log.get("max_age_days", 14)),
        )

        # Parse diktum config (optional)
        diktum_dict = data.get("diktum")
        diktum_cfg = None
        if isinstance(diktum_dict, dict):
            diktum_cfg = DiktumCfg(
                serial_device=str(diktum_dict.get("serial_device", "/dev/ttyAMA0")),
                baudrate=int(diktum_dict.get("baudrate", 115200)),
                base_command=str(diktum_dict.get("base_command", "")),
                control_byte_index=int(diktum_dict.get("control_byte_index", 8)),
                control_keep_mask=str(diktum_dict.get("control_keep_mask", "0x3C")),
                relay_bits=dict(diktum_dict.get("relay_bits", {})),
                command_bytes=dict(diktum_dict.get("command_bytes", {})),
            )

        # Parse motion config
        m = data.get("motion", {}) or {}
        motion = MotionCfg(
            speed_mps=float(m.get("speed_mps", 5.0)),
            orient_then_move=bool(m.get("orient_then_move", True)),
            dead_zone=float(m.get("dead_zone", 0.12)),
            turn_speed_dps=float(m.get("turn_speed_dps", 1.0)),
        )

        # Parse map config
        map_dict = data.get("map", {}) or {}
        map_cfg = MapCfg(
            resolution_m=float(map_dict.get("resolution_m", 2.0)),
            path_to_geojson=str(map_dict.get("path_to_geojson", "app/static/cache/chelybinsk2.geojson")),
            bounds=dict(map_dict.get("bounds", {})),
        )

        # Parse start pose
        sp = data.get("start_pose", {}) or {}
        start_pose = StartPoseCfg(
            lat=float(sp.get("lat", 55.164441)),
            lon=float(sp.get("lon", 61.436843)),
            yaw=float(sp.get("yaw", 0.0)),
        )

        return AppConfig(
            robot_type=robot_type,
            aspect=aspect,
            layout=layout,
            video=video,
            recording=recording,
            logging=logging_cfg,
            diktum=diktum_cfg,
            motion=motion,
            map=map_cfg,
            start_pose=start_pose,
            raw_data=data,
            config_path=config_path,
        )


# ============================================================================
# SINGLETON INSTANCE
# ============================================================================

class ConfigLoader:
    """
    Thread-safe singleton config loader.
    
    Usage:
        config = get_config()
        # or
        loader = get_config_loader()
        config = loader.get_config()
    """
    _instance: Optional["ConfigLoader"] = None
    _lock = Lock()
    
    def __init__(self):
        self._config: Optional[AppConfig] = None
        self._load_lock = Lock()
    
    @classmethod
    def get_instance(cls) -> "ConfigLoader":
        """Get singleton instance (thread-safe)."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = ConfigLoader()
        return cls._instance
    
    def get_config(self, reload: bool = False) -> AppConfig:
        """
        Get cached config or load if not yet loaded.
        
        Args:
            reload: Force reload from disk
            
        Returns:
            AppConfig instance
        """
        if self._config is None or reload:
            with self._load_lock:
                if self._config is None or reload:
                    self._config = AppConfig.load()
        return self._config
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get a specific section from the config.
        
        Args:
            section: Section name (e.g., "video", "motion", "logging")
            
        Returns:
            Dictionary of section data
        """
        config = self.get_config()
        return config.raw_data.get(section, {}) or {}


# ============================================================================
# PUBLIC API
# ============================================================================

def get_config_loader() -> ConfigLoader:
    """Get the singleton ConfigLoader instance."""
    return ConfigLoader.get_instance()


def get_config(reload: bool = False) -> AppConfig:
    """
    Get the application configuration.
    
    This is the primary function that should be used throughout the codebase
    to access configuration.
    
    Args:
        reload: Force reload from disk
        
    Returns:
        AppConfig instance
        
    Example:
        from app.services.system.config_loader import get_config
        
        config = get_config()
        print(f"Robot type: {config.robot_type}")
        print(f"Video FPS: {config.video.fps}")
    """
    return get_config_loader().get_config(reload=reload)


def get_config_section(section: str) -> Dict[str, Any]:
    """
    Get a specific section from the config.
    
    Args:
        section: Section name (e.g., "video", "motion", "logging")
        
    Returns:
        Dictionary of section data
        
    Example:
        from app.services.system.config_loader import get_config_section
        
        video_cfg = get_config_section("video")
        print(f"FPS: {video_cfg['fps']}")
    """
    return get_config_loader().get_section(section)


# Backward compatibility exports
__all__ = [
    "AppConfig",
    "AspectCfg",
    "LayoutCfg",
    "LayoutStereoCfg",
    "LayoutQuadCfg",
    "VideoCfg",
    "RecordingCfg",
    "LoggingCfg",
    "DiktumCfg",
    "MotionCfg",
    "MapCfg",
    "StartPoseCfg",
    "get_config",
    "get_config_loader",
    "get_config_section",
    "find_config_file",
]
