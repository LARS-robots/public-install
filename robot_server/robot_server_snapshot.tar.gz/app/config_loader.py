from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Tuple, Optional

# TOML loader (Py3.11+/older)
try:
    import tomllib  # Python 3.11+
except Exception:
    import tomli as tomllib


@dataclass
class AspectConfig:
    enabled: bool
    mode: Literal["center_crop", "letterbox"]
    mono: Optional[str] = None
    stereo_left: Optional[str] = None
    quad: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "AspectConfig":
        return AspectConfig(
            enabled=bool(d.get("enabled", False)),
            mode=d.get("mode", "center_crop"),
            mono=d.get("mono"),
            stereo_left=d.get("stereo_left"),
            quad=d.get("quad"),
        )


@dataclass
class VideoConfig:
    fps: int
    resolution: str
    codec: str


@dataclass
class AppConfig:
    video: VideoConfig
    aspect: AspectConfig

    @staticmethod
    def load(path: str = "config.toml") -> "AppConfig":
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Config not found: {path}")
        with open(p, "rb") as f:
            data = tomllib.load(f)
        v = data.get("video", {})
        a = data.get("aspect", {})
        return AppConfig(
            video=VideoConfig(
                fps=int(v.get("fps", 30)),
                resolution=v.get("resolution", "640x480"),
                codec=v.get("codec", "h264"),
            ),
            aspect=AspectConfig.from_dict(a),
        )

    def parse_resolution(self) -> Tuple[int, int]:
        try:
            w, h = map(int, self.video.resolution.lower().split("x"))
            return w, h
        except Exception:
            return 640, 480
