from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, Optional

from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError


log = logging.getLogger(__name__)


class SvcStateClient:
    """
    Lightweight helper to publish service status into NATS KV `svc_state`.

    Key format:
      - bucket: svc_state
      - key: <service_name>

    Value format (JSON):
      - service: str
      - status: str (starting|ready|degraded|error|stopped|unknown)
      - ts: float (epoch seconds)
      - details: dict (optional, arbitrary diagnostic payload)
    """

    def __init__(self, nc: NATS, bucket: str = "svc_state") -> None:
        self._nc = nc
        self._bucket = bucket
        self._js = None
        self._kv = None

    async def initialize(self) -> None:
        """
        Initialize JetStream + KV bucket.

        Idempotent: safe to call multiple times.
        """
        if not self._nc:
            log.warning("[SVC_STATE] NATS connection not available")
            return

        try:
            if self._js is None:
                self._js = self._nc.jetstream()

            # Try to create, then fall back to existing
            try:
                self._kv = await self._js.create_key_value(bucket=self._bucket)
                log.info("[SVC_STATE] KV bucket '%s' created", self._bucket)
            except Exception as e:
                try:
                    self._kv = await self._js.key_value(bucket=self._bucket)
                    log.info("[SVC_STATE] KV bucket '%s' opened (exists)", self._bucket)
                except Exception:
                    log.error(
                        "[SVC_STATE] Failed to create or open KV bucket '%s': %s",
                        self._bucket,
                        e,
                    )
                    self._kv = None
        except Exception as e:  # pragma: no cover - defensive
            log.error("[SVC_STATE] initialize() failed: %s", e, exc_info=True)
            self._kv = None

    async def set_status(
        self,
        service: str,
        status: str,
        *,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Publish one service status entry into KV.

        Non‑fatal on errors: logs warning and continues.
        """
        if not self._kv:
            # Try lazy init once
            await self.initialize()
            if not self._kv:
                return

        payload = {
            "service": service,
            "status": status,
            "ts": time.time(),
            "details": details or {},
        }

        try:
            data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
            await self._kv.put(service, data)
        except Exception as e:  # pragma: no cover - defensive
            log.warning(
                "[SVC_STATE] Failed to put status for %s (%s): %s",
                service,
                status,
                e,
            )


async def read_all_states(nc: NATS, bucket: str = "svc_state") -> Dict[str, Any]:
    """
    Helper for API endpoint: read all svc_state entries from KV.

    Returns dict:
      { service_name: {service, status, ts, age_sec, details} }
    """
    now = time.time()
    out: Dict[str, Any] = {}

    js = nc.jetstream()
    try:
        kv = await js.key_value(bucket=bucket)
    except NotFoundError:
        # No bucket yet – return empty dict
        return {}
    except Exception as e:
        log.warning("[SVC_STATE] Failed to open KV bucket '%s': %s", bucket, e)
        return {}

    try:
        # Scan all keys via history (simple approach, low cardinality expected)
        keys = await kv.keys()
    except Exception as e:
        log.warning("[SVC_STATE] Failed to list keys in '%s': %s", bucket, e)
        return {}

    for key in keys:
        try:
            entry = await kv.get(key)
        except NotFoundError:
            continue
        except Exception:
            continue

        try:
            data = json.loads(entry.value.decode("utf-8"))
        except Exception:
            continue

        ts = data.get("ts")
        if isinstance(ts, (int, float)):
            age_sec = now - float(ts)
        else:
            age_sec = None

        service = data.get("service") or key
        status = data.get("status") or "unknown"

        out[service] = {
            "service": service,
            "status": status,
            "ts": ts,
            "age_sec": age_sec,
            "details": data.get("details") or {},
        }

    return out


