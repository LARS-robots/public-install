# services/devices.py
"""
DeviceRegistry - Unified camera discovery across platforms.
Reconciles Raspberry Pi (libcamera), Linux (V4L2), and OpenCV backends.
"""
from __future__ import annotations
import logging
import platform as _py_platform
import shutil
import subprocess
import re
import glob
from dataclasses import dataclass
from typing import List, Optional

import cv2

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class CameraInfo:
    """Metadata about a discovered camera device."""
    index: int
    width: Optional[int] = None
    height: Optional[int] = None
    backend: str = "unknown"   # "rpi" | "v4l2" | "opencv"


class DeviceRegistry:
    """
    Reconciles camera enumeration across platforms with optional open() probe.
    Caches results briefly (in-memory) and can re-validate on demand.
    
    Platform support:
    - Raspberry Pi: Uses rpicam-hello --list-cameras
    - Linux: Scans /dev/video* nodes
    - Windows/macOS: Falls back to OpenCV enumeration
    """

    def __init__(self):
        self._last_list: list[CameraInfo] = []

    def list_cameras(self, probe_open: bool = False, max_probe: int = 8) -> list[int]:
        """
        Enumerate available cameras.
        
        Args:
            probe_open: If True, attempts to open each camera to verify availability
            max_probe: Maximum number of camera indices to check
            
        Returns:
            List of camera indices (0-based)
        """
        indices = self._list_indices_raw(max_probe=max_probe)
        
        if not probe_open:
            self._last_list = [CameraInfo(i) for i in indices]
            return indices

        # Probe by attempting to open each camera
        backend = (
            cv2.CAP_DSHOW
            if _py_platform.system() == "Windows"
            else cv2.CAP_AVFOUNDATION
            if _py_platform.system() == "Darwin"
            else 0
        )
        
        confirmed: list[int] = []
        for i in indices:
            try:
                cap = cv2.VideoCapture(i, backend)
                if cap and cap.isOpened():
                    confirmed.append(i)
                    cap.release()
            except Exception as e:
                log.debug("Camera %d probe failed: %s", i, e)
                
        self._last_list = [CameraInfo(i, backend=self._detect_backend()) for i in confirmed]
        return confirmed

    def _list_indices_raw(self, max_probe: int) -> list[int]:
        """
        Platform-specific camera discovery without opening devices.
        
        Returns:
            List of potential camera indices
        """
        # Raspberry Pi (libcamera)
        if shutil.which("rpicam-hello"):
            try:
                p = subprocess.run(
                    ["rpicam-hello", "--list-cameras"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=5,
                )
                cams = []
                if p.returncode == 0:
                    for line in p.stdout.splitlines():
                        # Match lines like "0 : imx219 [3280x2464]"
                        if re.match(r"^\s*\d+\s*:", line):
                            cams.append(int(line.split(":")[0].strip()))
                if cams:
                    log.info("Discovered %d cameras via rpicam-hello", len(cams))
                    return sorted(set(cams))
            except Exception as e:
                log.warning("rpicam-hello failed: %s", e)

        # V4L2 nodes (Linux)
        try:
            dev_nodes = sorted(
                {
                    int(p.split("/dev/video")[1])
                    for p in glob.glob("/dev/video*")
                    if p.replace("/dev/video", "").isdigit()
                }
            )
            if dev_nodes:
                log.info("Discovered %d V4L2 devices", len(dev_nodes))
                return dev_nodes
        except Exception as e:
            log.debug("V4L2 enumeration failed: %s", e)

        # Fallback: probe indices 0..max_probe-1
        log.debug("Using fallback enumeration: 0..%d", max_probe - 1)
        return list(range(max_probe))

    def _detect_backend(self) -> str:
        """Detect which camera backend is being used."""
        if shutil.which("rpicam-hello"):
            return "rpi"
        if glob.glob("/dev/video*"):
            return "v4l2"
        return "opencv"

    def has_any(self) -> bool:
        """Check if any cameras are available."""
        if not self._last_list:
            _ = self.list_cameras(probe_open=False)
        return bool(self._last_list)

    def snapshot(self) -> list[CameraInfo]:
        """Get cached camera info from last enumeration."""
        if not self._last_list:
            self.list_cameras(probe_open=False)
        return list(self._last_list)
