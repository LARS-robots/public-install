# services/errors.py
"""
Domain-specific errors for video/recording services.
These translate to appropriate HTTP status codes at the router layer.
"""


class DeviceUnavailableError(RuntimeError):
    """Requested camera is not present or cannot be opened."""


class ConflictError(RuntimeError):
    """Operation conflicts with current state (e.g., already recording)."""


class PreconditionFailedError(RuntimeError):
    """Required precondition not met (e.g., no cameras detected)."""
