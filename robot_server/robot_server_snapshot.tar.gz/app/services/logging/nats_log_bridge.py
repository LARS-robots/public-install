"""
NATS Log Bridge - получает логи из NATS и публикует их в logbus для веб-интерфейса.

Этот модуль подключается к NATS, подписывается на логи (log.*) и пересылает их
в logbus для отображения на веб-странице /admin/logs.

Архитектура:
- Все сервисы (включая API) отправляют логи в NATS через NATSHandler
- NATS log bridge подписывается на log.> и получает все логи
- Bridge пересылает все события в logbus (внутрипроцессная шина)
- WebSocket /admin/logs/ws использует logbus для отображения логов

Преимущества:
- Единая система логирования для всех сервисов
- Кольцевой буфер logbus для snapshot новых подключений
- Легковесная внутрипроцессная очередь (быстрее чем подписка на NATS для каждого WebSocket)
- Один NATS consumer (bridge) вместо множества (по одному на WebSocket)
- Меньше нагрузка на NATS сервер
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from typing import Optional

# Добавляем путь к nats_logger
sys.path.insert(0, "/nats_logger")

try:
    import nats
    from nats.aio.client import Client as NATSClient
    NATS_AVAILABLE = True
except ImportError:
    NATS_AVAILABLE = False
    NATSClient = None

from ...telemetry import logbus

logger = logging.getLogger(__name__)

_nc: Optional[NATSClient] = None
_subscription = None
_task: Optional[asyncio.Task] = None
_running = False


async def start_nats_log_bridge() -> None:
    """
    Запустить мост для получения логов из NATS и публикации в logbus.
    """
    global _nc, _subscription, _task, _running
    
    logger.info("🚀 Starting NATS log bridge initialization...")
    
    if not NATS_AVAILABLE:
        error_msg = "NATS client not available, nats_log_bridge disabled"
        print(f"[ERROR] {error_msg}", flush=True)
        logger.warning(error_msg)
        return
    
    if _running:
        logger.info("NATS log bridge already running")
        return
    
    try:
        # Получить NATS URL из окружения или конфига
        nats_url = os.getenv("NATS_URL", "nats://dev:devpass@nats:4222")
        
        # Нормализация URL: убираем лишние двоеточия и пробелы в конце
        # Это важно, так как некоторые конфиги могут содержать лишние символы
        nats_url = nats_url.strip().rstrip(':').rstrip()
        
        # В Docker контейнере используем имя сервиса "nats" вместо 127.0.0.1
        # Проверяем, запущены ли мы в Docker (если есть /app/src, значит в контейнере)
        if os.path.exists("/app/src") and "127.0.0.1" in nats_url:
            # В Docker Compose используем имя сервиса
            nats_url = nats_url.replace("127.0.0.1", "nats")
            # Повторно нормализуем после замены (на случай если было двоеточие)
            nats_url = nats_url.strip().rstrip(':').rstrip()
            logger.info(f"Replaced 127.0.0.1 with 'nats' in NATS URL: {nats_url}")
        
        logger.info(f"Connecting to NATS at {nats_url} for log bridge...")
        
        # Проверить, что logbus привязан к loop
        if logbus.loop is None:
            loop = asyncio.get_running_loop()
            logbus.bind_loop(loop)
            logger.info("Bound logbus to event loop")
        
        # Подключиться к NATS
        _nc = NATSClient()
        try:
            await _nc.connect(nats_url, connect_timeout=10)
            logger.info("✅ Connected to NATS for log bridge")
        except Exception as e:
            error_msg = f"Failed to connect to NATS: {e}"
            logger.error(error_msg, exc_info=True)
            print(f"[ERROR] {error_msg}", flush=True)
            raise
        
        # Подписаться на все логи
        subject = "log.>"  # Все логи всех сервисов
        
        # Счетчик для отслеживания первого сообщения
        _message_count = 0
        
        async def message_handler(msg):
            """Обработчик сообщений из NATS."""
            nonlocal _message_count
            _message_count += 1
            
            try:
                # ФИЛЬТРАЦИЯ: Пропускаем дополнительные subjects для избежания дубликатов
                # NATSHandler может отправлять в log.{service}.{level}, log.{service} и log.all
                # Мы подписаны на log.>, поэтому получаем все. Но нам нужны только log.{service}.{level}
                # Subjects вида "log.localization-daemon" или "log.all" содержат батчи и создают дубликаты
                subject_parts = msg.subject.split(".")
                if len(subject_parts) == 2:  # log.{service} или log.all - это дубликаты батчей
                    return  # Пропускаем эти subjects
                
                # Парсим JSON сообщение
                data = msg.data.decode("utf-8")
                event = json.loads(data)
                
                # ПРИМЕЧАНИЕ (Этап 2 оптимизации):
                # Фильтрация API событий удалена. Теперь все события (включая события от API сервиса)
                # идут через единую систему: NATS → nats_log_bridge → logbus → WebSocket.
                # PublishToBusHandler удален, поэтому дубликатов больше нет.
                
                # NATSHandler может отправлять батчи (списки) или отдельные события
                events_to_publish = event if isinstance(event, list) else [event]
                
                # Публикуем в logbus для веб-интерфейса
                # ВАЖНО: Публикуем ВСЕ события, включая события от API сервиса
                published_count = 0
                for evt in events_to_publish:
                    # Дополнительная проверка для списков
                    if isinstance(evt, dict):
                        evt_service = evt.get('service')
                        
                        # Публикуем только валидные события (содержат хотя бы service или msg)
                        # Все события публикуются без фильтрации (включая события от API)
                        if evt_service or evt.get('msg') or evt.get('logger'):
                            await logbus.publish(evt)
                            published_count += 1
                            
            except Exception as e:
                # Используем print для ошибок, чтобы не создавать циклы
                print(f"[ERROR] Error processing NATS log message: {e}", flush=True)
        
        # Подписаться на логи
        _subscription = await _nc.subscribe(subject, cb=message_handler)
        logger.info(f"✅ Subscribed to {subject} for log bridge")
        
        _running = True
        
        # Запустить фоновую задачу для поддержания соединения
        async def keep_alive():
            """Поддерживать соединение и обрабатывать сообщения."""
            while _running:
                try:
                    await asyncio.sleep(1)
                    if _nc and not _nc.is_connected:
                        logger.warning("NATS connection lost, attempting reconnect...")
                        print("[ERROR] NATS connection lost, attempting reconnect...", flush=True)
                        await _nc.connect(nats_url)
                        logger.info("✅ Reconnected to NATS")
                except Exception as e:
                    logger.warning(f"NATS keep-alive error: {e}")
                    await asyncio.sleep(5)
        
        _task = asyncio.create_task(keep_alive())
        
        logger.info("✅ NATS log bridge started successfully and is running")
        
    except Exception as e:
        error_msg = f"Failed to start NATS log bridge: {e}"
        logger.error(error_msg, exc_info=True)
        print(f"[ERROR] {error_msg}", flush=True)
        _running = False
        if _nc:
            try:
                await _nc.close()
            except Exception:
                pass
            _nc = None


async def stop_nats_log_bridge() -> None:
    """
    Остановить мост NATS.
    """
    global _nc, _subscription, _task, _running
    
    _running = False
    
    if _task:
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        _task = None
    
    if _subscription:
        try:
            await _subscription.unsubscribe()
        except Exception:
            pass
        _subscription = None
    
    if _nc:
        try:
            await _nc.close()
        except Exception:
            pass
        _nc = None
    
    logger.info("NATS log bridge stopped")

