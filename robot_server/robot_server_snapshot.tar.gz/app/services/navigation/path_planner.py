from __future__ import annotations
from typing import List, Tuple, Dict, Any, Optional
from pydantic import BaseModel
import math, heapq, json
import os
import logging

logger = logging.getLogger(__name__)

class LatLon(BaseModel):
    lat: float
    lon: float

class PlannerConfig(BaseModel):
    # Bounding box of the navigable map (degrees)
    min_lat: float
    min_lon: float
    max_lat: float
    max_lon: float
    # Grid resolution (meters per cell)
    resolution_m: float = 2.0
    # Optional polygons (each polygon = list of {lat,lon})
    obstacles: List[List[LatLon]] = []
    # Corner detection thresholds
    turn_thresh_deg: float = 12.0  # Minimum angle change to keep as corner
    min_segment_m: float = 5.0     # Minimum segment length to consider

class RoadNetworkPathPlanner:
    """
    Road-based A* planner that follows actual streets and paths.
    Use this when you have a proper road network in GeoJSON.
    """
    
    def __init__(self, geojson_path: str):
        """Load GeoJSON and build road graph"""
        if not os.path.exists(geojson_path):
            raise FileNotFoundError(f"GeoJSON file not found: {geojson_path}")
            
        with open(geojson_path, 'r') as f:
            data = json.load(f)
        
        self.obstacles = []  # Polygon obstacles
        self.roads = []      # Road segments
        self.graph = {}      # Node adjacency graph
        self.has_roads = False  # Track if we actually have road data
        
        for feature in data['features']:
            props = feature.get('properties', {})
            geom = feature.get('geometry', {})
            
            if props.get('is_road'):
                self.has_roads = True
                # Store road segment
                self.roads.append({
                    'coords': geom['coordinates'],
                    'type': props.get('highway_type', 'unknown')
                })
                
                # Build graph nodes from road endpoints
                self._add_road_to_graph(geom['coordinates'])
            
            elif props.get('blocked'):
                # Store obstacle polygon
                if geom.get('type') == 'Polygon' and geom.get('coordinates'):
                    self.obstacles.append(geom['coordinates'][0])
    
    def _add_road_to_graph(self, coords: List[List[float]]):
        """Add road segment to graph"""
        for i in range(len(coords) - 1):
            p1 = tuple(coords[i])
            p2 = tuple(coords[i + 1])
            
            # Calculate distance
            dist = self._haversine_distance(p1[1], p1[0], p2[1], p2[0])
            
            # Add bidirectional edges
            if p1 not in self.graph:
                self.graph[p1] = []
            if p2 not in self.graph:
                self.graph[p2] = []
            
            self.graph[p1].append((p2, dist))
            self.graph[p2].append((p1, dist))
    
    def _haversine_distance(self, lat1: float, lon1: float, 
                           lat2: float, lon2: float) -> float:
        """Calculate distance between two GPS points in meters"""
        R = 6371000  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        
        a = math.sin(dphi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        return R * c
    
    def _find_nearest_road_node(self, lat: float, lon: float) -> Optional[Tuple[float, float]]:
        """Find nearest node in road graph"""
        if not self.graph:
            return None
            
        min_dist = float('inf')
        nearest = None
        
        for node in self.graph.keys():
            dist = self._haversine_distance(lat, lon, node[1], node[0])
            if dist < min_dist:
                min_dist = dist
                nearest = node
        
        return nearest
    
    def plan_path(self, start_lat: float, start_lon: float,
                  goal_lat: float, goal_lon: float) -> Optional[List[Dict[str, float]]]:
        """
        A* pathfinding on road network
        Returns list of waypoints following roads, or None if no path found
        """
        if not self.has_roads or not self.graph:
            return None
            
        # Snap start/goal to nearest road nodes
        start_node = self._find_nearest_road_node(start_lat, start_lon)
        goal_node = self._find_nearest_road_node(goal_lat, goal_lon)
        
        if not start_node or not goal_node:
            return None
        
        # A* algorithm
        open_set = [(0, start_node)]
        came_from = {}
        g_score = {start_node: 0}
        f_score = {start_node: self._haversine_distance(
            start_node[1], start_node[0], goal_node[1], goal_node[0]
        )}
        
        visited = set()
        
        while open_set:
            _, current = heapq.heappop(open_set)
            
            if current in visited:
                continue
            visited.add(current)
            
            if current == goal_node:
                # Reconstruct path
                path = []
                while current in came_from:
                    path.append({"lat": current[1], "lon": current[0]})
                    current = came_from[current]
                path.append({"lat": start_node[1], "lon": start_node[0]})
                path.reverse()
                return path
            
            for neighbor, dist in self.graph.get(current, []):
                tentative_g = g_score[current] + dist
                
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    h = self._haversine_distance(
                        neighbor[1], neighbor[0], goal_node[1], goal_node[0]
                    )
                    f_score[neighbor] = tentative_g + h
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        return None  # No path found

class GridPathPlanner:
    """
    A* planner on a 2D grid with obstacle polygons.
    Falls back when no road network available.
    """
    
    def __init__(self, cfg: PlannerConfig):
        self.cfg = cfg
        
        # Validate bounds
        if not all(isinstance(x, (int, float)) and not math.isnan(x) and not math.isinf(x) 
                   for x in [cfg.min_lat, cfg.max_lat, cfg.min_lon, cfg.max_lon]):
            raise ValueError(f"Invalid bounding box: contains NaN or Inf values")
        
        if cfg.min_lat >= cfg.max_lat or cfg.min_lon >= cfg.max_lon:
            raise ValueError(f"Invalid bounding box: min >= max")
        
        # Calculate grid dimensions
        lat_span = cfg.max_lat - cfg.min_lat
        lon_span = cfg.max_lon - cfg.min_lon
        
        # Haversine distance approximation
        R = 6378137.0
        lat_mid = (cfg.min_lat + cfg.max_lat) / 2
        
        height_m = lat_span * (math.pi / 180) * R
        width_m = lon_span * (math.pi / 180) * R * math.cos(math.radians(lat_mid))
        
        # ✅ FIXED: Adaptive resolution based on area size
        # For large areas (>10km), use coarser resolution to keep grid manageable
        area_km2 = (height_m / 1000) * (width_m / 1000)
        
        if area_km2 > 100:  # Very large area (>10km x 10km)
            resolution = max(cfg.resolution_m, 5.0)
            logger.warning(f"⚠️  Large area ({area_km2:.1f} km²), using coarser resolution: {resolution}m")
        elif area_km2 > 25:  # Medium area
            resolution = max(cfg.resolution_m, 3.0)
        else:
            resolution = cfg.resolution_m
        
        self.h = max(1, int(height_m / resolution))
        self.w = max(1, int(width_m / resolution))
        
        # ✅ Safety check: limit grid size to prevent memory issues
        MAX_CELLS = 10_000_000  # 10 million cells = ~10MB
        total_cells = self.w * self.h
        
        if total_cells > MAX_CELLS:
            # Scale down resolution
            scale_factor = math.sqrt(total_cells / MAX_CELLS)
            resolution *= scale_factor
            self.h = max(1, int(height_m / resolution))
            self.w = max(1, int(width_m / resolution))
            total_cells = self.w * self.h
            logger.warning(f"⚠️  Grid too large, scaled to {self.w}x{self.h} cells ({resolution:.1f}m resolution)")
        
        # Store actual resolution used
        self.cfg.resolution_m = resolution
        
        # Calculate meters per degree for transforms
        self._m_per_deg_lat = height_m / lat_span
        self._m_per_deg_lon = width_m / lon_span
        
        # Initialize occupation grid
        self.occ = bytearray(self.w * self.h)
        
        # Build obstacle grid
        self._rasterize_obstacles(cfg.obstacles)
        
        logger.info(f"✅ Grid planner initialized: {self.w}x{self.h} cells "
                   f"({width_m/1000:.1f}km x {height_m/1000:.1f}km at {resolution:.1f}m resolution), "
                   f"{len(cfg.obstacles)} obstacle polygons, "
                   f"memory: {len(self.occ)/(1024*1024):.1f}MB")
    
    # ---------- geo transforms ----------
    def _latlon_to_xy(self, lat: float, lon: float) -> Tuple[int,int]:
        dx_m = (lon - self.cfg.min_lon) * self._m_per_deg_lon
        dy_m = (lat - self.cfg.min_lat) * self._m_per_deg_lat
        x = int(dx_m / self.cfg.resolution_m)
        y = int(dy_m / self.cfg.resolution_m)
        return (max(0,min(self.w-1,x)), max(0,min(self.h-1,y)))

    def _xy_to_latlon(self, x: int, y: int) -> Tuple[float,float]:
        lon = self.cfg.min_lon + (x + 0.5) * self.cfg.resolution_m / self._m_per_deg_lon
        lat = self.cfg.min_lat + (y + 0.5) * self.cfg.resolution_m / self._m_per_deg_lat
        return (lat, lon)

    # ---------- rasterize ----------
    def _rasterize_obstacles(self, polygons: List[List[LatLon]]) -> None:
        for poly in polygons or []:
            pts = [self._latlon_to_xy(p.lat, p.lon) for p in poly]
            self._fill_polygon(pts)

    def _fill_polygon(self, pts: List[Tuple[int,int]]) -> None:
        if len(pts) < 3: return
        miny = max(0, min(y for _,y in pts)); maxy = min(self.h-1, max(y for _,y in pts))
        for y in range(miny, maxy+1):
            # find intersections with scanline
            xs = []
            for i in range(len(pts)):
                x1,y1 = pts[i]; x2,y2 = pts[(i+1)%len(pts)]
                if (y1<=y<y2) or (y2<=y<y1):
                    t = (y - y1) / (y2 - y1 + 1e-9)
                    xs.append(int(round(x1 + t*(x2-x1))))
            xs.sort()
            for i in range(0, len(xs), 2):
                xL = max(0, xs[i]); xR = min(self.w-1, xs[i+1] if i+1 < len(xs) else xs[i])
                for x in range(xL, xR+1):
                    self.occ[y*self.w + x] = 255  # occupied

    # ---------- A* ----------
    def _heur(self, a: Tuple[int,int], b: Tuple[int,int]) -> float:
        dx = a[0]-b[0]; dy = a[1]-b[1]
        return math.hypot(dx,dy)

    def _neighbors(self, x:int, y:int):
        for dx,dy,c in ((1,0,1),(0,1,1),(-1,0,1),(0,-1,1),(1,1,1.414),(1,-1,1.414),(-1,1,1.414),(-1,-1,1.414)):
            nx,ny = x+dx, y+dy
            if 0 <= nx < self.w and 0 <= ny < self.h and self.occ[ny*self.w + nx] == 0:
                yield nx,ny,c

    # ---------- Path smoothing and corner detection ----------
    
    def _los_free(self, a: Tuple[int,int], b: Tuple[int,int]) -> bool:
        """Bresenham-ish raycast: return True if straight line a->b does not cross occupied cells."""
        x0, y0 = a
        x1, y1 = b
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        x, y = x0, y0
        
        while True:
            # Check bounds
            if x < 0 or x >= self.w or y < 0 or y >= self.h:
                return False
            # Check occupation
            if self.occ[y * self.w + x] != 0:
                return False
            # Check if we reached the target
            if x == x1 and y == y1:
                return True
                
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy

    def _string_pull(self, pts: List[Tuple[int,int]]) -> List[Tuple[int,int]]:
        """
        Greedy shortcutting: keep [i], then jump to the farthest j with line-of-sight free.
        This finds natural corners at obstacle boundaries.
        """
        if len(pts) <= 2:
            return pts
            
        out = [pts[0]]
        i = 0
        n = len(pts)
        
        while i < n - 1:
            # Try to leap as far as possible
            j = i + 1
            last_ok = j
            
            while j < n and self._los_free(pts[i], pts[j]):
                last_ok = j
                j += 1
                
            out.append(pts[last_ok])
            i = last_ok
            
        return out

    def _angle_deg(self, a: Tuple[int,int], b: Tuple[int,int], c: Tuple[int,int]) -> float:
        """Calculate angle ABC in degrees (0-180)."""
        ux, uy = b[0] - a[0], b[1] - a[1]
        vx, vy = c[0] - b[0], c[1] - b[1]
        
        du = math.hypot(ux, uy) or 1e-9
        dv = math.hypot(vx, vy) or 1e-9
        
        cosang = (ux * vx + uy * vy) / (du * dv)
        cosang = max(-1.0, min(1.0, cosang))  # Clamp to avoid numerical errors
        
        return math.degrees(math.acos(cosang))

    def _keep_corners(self, pts: List[Tuple[int,int]], turn_thresh_deg: float = 12.0) -> List[Tuple[int,int]]:
        """
        Keep only points where the path turns significantly.
        This creates clean polylines with corners at natural turning points.
        """
        if len(pts) <= 2:
            return pts
            
        out = [pts[0]]  # Always keep start
        
        for i in range(1, len(pts) - 1):
            ang = self._angle_deg(pts[i-1], pts[i], pts[i+1])
            if ang >= turn_thresh_deg:
                out.append(pts[i])
                
        out.append(pts[-1])  # Always keep end
        return out

    def _filter_short_segments(self, pts: List[Tuple[int,int]], min_cells: int = 3) -> List[Tuple[int,int]]:
        """Remove points that create very short segments, except start/end."""
        if len(pts) <= 2:
            return pts
            
        out = [pts[0]]
        
        for i in range(1, len(pts) - 1):
            prev_dist = math.hypot(pts[i][0] - out[-1][0], pts[i][1] - out[-1][1])
            if prev_dist >= min_cells:
                out.append(pts[i])
                
        out.append(pts[-1])
        return out

    # ---------- Main planning ----------

    def plan(self, start: LatLon, goal: LatLon) -> Dict[str,Any]:
        sx,sy = self._latlon_to_xy(start.lat, start.lon)
        gx,gy = self._latlon_to_xy(goal.lat, goal.lon)
        
        if self.occ[sy*self.w + sx] or self.occ[gy*self.w + gx]:
            return {"ok": False, "reason": "start_or_goal_in_obstacle"}

        openq = [(0.0,(sx,sy))]
        g = { (sx,sy): 0.0 }
        parent: Dict[Tuple[int,int],Tuple[int,int]] = {}
        visited = set()
        
        while openq:
            _, (x,y) = heapq.heappop(openq)
            if (x,y) in visited: continue
            visited.add((x,y))
            if x==gx and y==gy: break
            
            for nx,ny,cost in self._neighbors(x,y):
                ng = g[(x,y)] + cost
                if ng < g.get((nx,ny), 1e18):
                    g[(nx,ny)] = ng
                    parent[(nx,ny)] = (x,y)
                    f = ng + self._heur((nx,ny), (gx,gy))
                    heapq.heappush(openq, (f,(nx,ny)))

        if (gx,gy) not in parent and (gx,gy)!=(sx,sy):
            return {"ok": False, "reason": "no_path"}

        # Reconstruct raw path
        path_xy = []
        cur = (gx,gy)
        path_xy.append(cur)
        while cur != (sx,sy):
            cur = parent.get(cur, (sx,sy))
            if path_xy and cur == path_xy[-1]: break
            path_xy.append(cur)
        path_xy.reverse()

        # Apply path smoothing for clean road-like corners
        try:
            # Step 1: String-pulling to find natural corners at obstacle boundaries
            pulled = self._string_pull(path_xy)
            
            # Step 2: Keep only significant turns
            min_cells = max(1, int(self.cfg.min_segment_m / self.cfg.resolution_m))
            cornered = self._keep_corners(pulled, self.cfg.turn_thresh_deg)
            
            # Step 3: Filter out very short segments
            simplified = self._filter_short_segments(cornered, min_cells)
            
        except Exception as e:
            # Fallback to simple decimation if smoothing fails
            simplified = self._decimate(path_xy, keep_every=3)

        # Convert to lat/lon
        path_latlon = [{"lat": self._xy_to_latlon(x,y)[0], "lon": self._xy_to_latlon(x,y)[1]} for x,y in simplified]
        
        return {
            "ok": True, 
            "path": path_latlon, 
            "cost": g.get((gx,gy), 0.0),
            "debug": {
                "raw_points": len(path_xy),
                "after_string_pull": len(pulled) if 'pulled' in locals() else 0,
                "final_points": len(simplified)
            }
        }

    def _decimate(self, pts: List[Tuple[int,int]], keep_every:int=3) -> List[Tuple[int,int]]:
        """Fallback decimation method."""
        if len(pts)<=2: return pts
        out = []
        for i,p in enumerate(pts):
            if i==0 or i==len(pts)-1 or (i % keep_every)==0:
                out.append(p)
        return out


class HybridPathPlanner:
    """
    Hybrid planner that tries road-based planning first, falls back to grid-based.
    """
    
    def __init__(self, geojson_path: str, planner_config: Optional[PlannerConfig] = None):
        """Initialize both planners."""
        self.geojson_path = geojson_path
        
        # Try to initialize road planner
        try:
            self.road_planner = RoadNetworkPathPlanner(geojson_path)
            if self.road_planner.has_roads:
                logger.info(f"✅ Road planner initialized: {len(self.road_planner.graph)} nodes, "
                           f"{len(self.road_planner.roads)} roads")
            else:
                logger.warning("⚠️  No roads found in GeoJSON (missing 'is_road' property)")
                self.road_planner = None
        except Exception as e:
            logger.error(f"❌ Road planner initialization failed: {e}", exc_info=True)
            self.road_planner = None
        
        # Initialize grid planner
        if planner_config:
            try:
                self.grid_planner = GridPathPlanner(planner_config)
            except Exception as e:
                logger.error(f"❌ Grid planner initialization failed: {e}", exc_info=True)
                self.grid_planner = None
        else:
            # Auto-generate config from GeoJSON bounds
            self.grid_planner = None
            self._init_grid_planner_from_geojson()
    
    def _init_grid_planner_from_geojson(self):
        """Extract obstacles from GeoJSON and create grid planner"""
        try:
            with open(self.geojson_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            obstacles = []
            all_coords = []  # ✅ Collect all coordinates for bounds
            
            for feature in data.get('features', []):
                props = feature.get('properties', {})
                geom = feature.get('geometry', {})
                
                # ✅ Extract obstacles
                if props.get('blocked') and geom.get('type') == 'Polygon':
                    coords = geom['coordinates'][0]
                    poly = [LatLon(lat=c[1], lon=c[0]) for c in coords]
                    obstacles.append(poly)
                    all_coords.extend(coords)
                
                # ✅ Also collect road coordinates for bounds
                elif geom.get('type') == 'LineString':
                    all_coords.extend(geom.get('coordinates', []))
            
            # ✅ Calculate bounds from all features
            if not all_coords:
                logger.warning("⚠️  No coordinates found in GeoJSON, using default Chelyabinsk bounds")
                min_lat, min_lon = 55.10, 61.30
                max_lat, max_lon = 55.25, 61.50
            else:
                lons = [c[0] for c in all_coords]
                lats = [c[1] for c in all_coords]
                min_lon, max_lon = min(lons), max(lons)
                min_lat, max_lat = min(lats), max(lats)
            
            # Add padding (1% of span)
            lat_padding = (max_lat - min_lat) * 0.01
            lon_padding = (max_lon - min_lon) * 0.01
            
            config = PlannerConfig(
                min_lat=min_lat - lat_padding,
                max_lat=max_lat + lat_padding,
                min_lon=min_lon - lon_padding,
                max_lon=max_lon + lon_padding,
                obstacles=obstacles,
                resolution_m=2.0
            )
            
            logger.info(f"📍 Auto-detected bounds: "
                       f"lat=[{config.min_lat:.4f}, {config.max_lat:.4f}], "
                       f"lon=[{config.min_lon:.4f}, {config.max_lon:.4f}]")
            
            self.grid_planner = GridPathPlanner(config)
            logger.info(f"✅ Grid planner initialized: {len(obstacles)} obstacles")
            
        except Exception as e:
            logger.error(f"❌ Grid planner initialization failed: {e}", exc_info=True)
            self.grid_planner = None
    
    def plan_path(self, start_lat: float, start_lon: float,
                  goal_lat: float, goal_lon: float) -> Dict[str, Any]:
        """
        Plan path using hybrid approach:
        1. Try road-based planning first (follows streets)
        2. Fall back to grid-based planning (obstacle avoidance)
        3. Fall back to direct line if both fail
        
        Returns:
            Dict with:
                - ok: bool
                - path: List[Dict] of waypoints
                - planner_used: str ("road", "grid", or "direct")
                - reason: str (if failed)
        """
        
        # Try road planner first
        if self.road_planner and self.road_planner.has_roads:
            try:
                road_path = self.road_planner.plan_path(start_lat, start_lon, goal_lat, goal_lon)
                if road_path:
                    return {
                        "ok": True,
                        "path": road_path,
                        "planner_used": "road",
                        "fallback": False
                    }
            except Exception as e:
                logger.warning(f"Road planner failed: {e}")
        
        # Fall back to grid planner
        if self.grid_planner:
            try:
                start = LatLon(lat=start_lat, lon=start_lon)
                goal = LatLon(lat=goal_lat, lon=goal_lon)
                result = self.grid_planner.plan(start, goal)
                
                if result.get("ok"):
                    return {
                        "ok": True,
                        "path": result["path"],
                        "planner_used": "grid",
                        "fallback": True,
                        "debug": result.get("debug", {})
                    }
            except Exception as e:
                logger.warning(f"Grid planner failed: {e}")
        
        # Last resort: direct line
        return {
            "ok": True,
            "path": [
                {"lat": start_lat, "lon": start_lon},
                {"lat": goal_lat, "lon": goal_lon}
            ],
            "planner_used": "direct",
            "fallback": True,
            "reason": "all_planners_failed"
        }


# Factory function to create planner
def create_planner(geojson_path: str = None, 
                   config: Optional[PlannerConfig] = None) -> HybridPathPlanner:
    """
    Create a new planner instance.
    Use this in your route_routers.py dependency injection.
    """
    return HybridPathPlanner(geojson_path, config)