"""
Route service - manages autonomous navigation and waypoint following.
Integrates with HybridPathPlanner for intelligent pathfinding.
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import math, time
import logging
import json
from .path_planner import create_planner, HybridPathPlanner, LatLon
from pathlib import Path

logger = logging.getLogger(__name__)

class Waypoint(BaseModel):
    lat: float
    lon: float

class RouteState(BaseModel):
    """State of active route navigation"""
    path: List[Waypoint] = Field(default_factory=list)
    path_idx: int = 0
    arrive_eps_m: float = 10.0
    last_tick_s: float = 0.0

class RouteService:
    """
    Manages route navigation and waypoint following.
    NO GLOBAL STATE - all state stored in app_state.
    """
    
    def __init__(self):
        """Initialize route service (stateless)"""
        pass
    
    # ========== STATE MANAGEMENT ==========
    
    def get_state(self, app_state) -> Optional[RouteState]:
        """Get current route state from app_state, or None if no active route."""
        return getattr(app_state, "route_state", None)

    def set_state(self, app_state, state: Optional[RouteState]) -> None:
        """Set current route state in app_state."""
        app_state.route_state = state
    
    # ========== HELPER FUNCTIONS ==========
    
    def _dist_m(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Haversine distance in meters between two lat/lon points."""
        R = 6378137.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat/2)**2 + 
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
             math.sin(dlon/2)**2)
        return 2 * R * math.asin(math.sqrt(a))

    def _bearing_rad(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Bearing in radians from point 1 to point 2."""
        dlon = math.radians(lon2 - lon1)
        y = math.sin(dlon) * math.cos(math.radians(lat2))
        x = (math.cos(math.radians(lat1)) * math.sin(math.radians(lat2))
             - math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(dlon))
        return math.atan2(y, x)
    
    # ========== PLANNER INTEGRATION ==========
    
    def _get_geojson_path(self) -> Path:
        """
        Get GeoJSON file path from config or use default.
        Searches in multiple locations for robustness.
        """
        try:
            # Try to load from centralized config
            from ..system.config_loader import get_config
            cfg = get_config()
            
            config_path = cfg.map.path_to_geojson
            
            # Handle relative paths (relative to robot_server/)
            if not Path(config_path).is_absolute():
                robot_server_root = Path(__file__).parent.parent.parent
                full_path = robot_server_root / config_path
            else:
                full_path = Path(config_path)
            
            if full_path.exists():
                logger.info(f"📍 Using GeoJSON from config: {full_path}")
                return full_path
            else:
                logger.warning(f"⚠️  Config path not found: {full_path}")
        except Exception as e:
            logger.warning(f"⚠️  Could not load config: {e}")
        
        # Fallback search paths (in order of priority)
        search_paths = [
            # 1. Cache directory (uploaded maps)
            Path(__file__).parent.parent / "static" / "cache" / "chelybinsk.geojson",
            # 2. Data directory (bundled maps)
            Path(__file__).parent.parent.parent / "data" / "chelybinsk.geojson",
            # 3. Project root data
            Path(__file__).parent.parent.parent.parent / "data" / "chelybinsk.geojson",
        ]
        
        for path in search_paths:
            if path.exists():
                logger.info(f"📍 Found GeoJSON at: {path}")
                return path
        
        # If nothing found, return cache path (will be created on upload)
        default_path = Path(__file__).parent.parent / "static" / "cache" / "chelybinsk.geojson"
        logger.warning(f"⚠️  No GeoJSON found, will use: {default_path}")
        return default_path
    
    def _get_or_create_planner(self, app_state) -> Optional[HybridPathPlanner]:
        """
        Get cached planner or create new one.
        Caches in app_state to avoid reloading GeoJSON every request.
        """
        
        # Check if planner already cached
        if hasattr(app_state, '_route_planner'):
            return app_state._route_planner
        
        # Create new planner
        try:
            geojson_path = self._get_geojson_path()
            
            if not geojson_path.exists():
                logger.warning(f"⚠️  GeoJSON file not found: {geojson_path}")
                logger.info("💡 Upload a map via /route/map/upload to enable navigation")
                return None
            
            logger.info(f"🗺️  Loading planner from: {geojson_path.absolute()}")
            
            planner = create_planner(str(geojson_path))
            
            # Cache for reuse
            app_state._route_planner = planner
            logger.info("✅ Planner created and cached")
            
            return planner
            
        except Exception as e:
            logger.error(f"❌ Failed to create planner: {e}", exc_info=True)
            return None
    
    def _invalidate_planner_cache(self, app_state) -> None:
        """
        Invalidate cached planner (call after map upload).
        Forces reload on next plan request.
        """
        if hasattr(app_state, '_route_planner'):
            delattr(app_state, '_route_planner')
            logger.info("🔄 Planner cache invalidated")
    
    # ========== PUBLIC API ==========
    
    def plan_polyline(
        self, 
        app_state, 
        start: Waypoint, 
        goal: Waypoint, 
        motor: Any = None  # Changed from MotorService to Any
    ) -> Dict[str, Any]:
        """
        Plan a path from start to goal using HybridPathPlanner.
        Falls back to straight line if planner unavailable.
        
        Returns:
            {
                "ok": bool,
                "path": List[Waypoint],
                "planner_used": str,  # "road", "grid", or "direct"
                "fallback": bool
            }
        """
        planner = self._get_or_create_planner(app_state)
        
        if not planner:
            logger.warning("⚠️  No planner available, using straight line")
            return {
                "ok": True, 
                "path": [start.model_dump(), goal.model_dump()], 
                "planner_used": "direct",
                "fallback": True,
                "reason": "planner_unavailable"
            }
        
        try:
            # Use HybridPathPlanner
            result = planner.plan_path(start.lat, start.lon, goal.lat, goal.lon)
            
            if not result.get("ok"):
                logger.warning(f"⚠️  Planning failed: {result.get('reason')}")
                # Still return straight line as fallback
                return {
                    "ok": True,
                    "path": [start.model_dump(), goal.model_dump()],
                    "planner_used": "direct",
                    "fallback": True,
                    "reason": result.get("reason", "planning_failed")
                }
            
            logger.info(f"✅ Path planned: {len(result['path'])} waypoints, "
                       f"planner={result.get('planner_used', 'unknown')}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Planning error: {e}", exc_info=True)
            return {
                "ok": True,
                "path": [start.model_dump(), goal.model_dump()],
                "planner_used": "direct",
                "fallback": True,
                "reason": f"error: {str(e)}"
            }

    def start(self, app_state, path_or_waypoints: List[Waypoint]) -> RouteState:
        """
        Start a new route with given path or waypoints.
        
        Args:
            app_state: Application state
            path_or_waypoints: List of waypoints to follow
            
        Returns:
            RouteState: Active route state
        """
        if len(path_or_waypoints) < 1:
            st = RouteState(path=[])
            logger.warning("⚠️  Route started with empty path")
        else:
            st = RouteState(path=path_or_waypoints, path_idx=0)
            logger.info(f"✅ Route started: {len(st.path)} waypoints")
        
        self.set_state(app_state, st)
        return st

    def cancel(self, app_state) -> bool:
        """
        Cancel the current route.
        
        Returns:
            bool: True if there was an active route to cancel
        """
        had = self.get_state(app_state) is not None
        self.set_state(app_state, None)
        
        if had:
            logger.info("🛑 Route canceled")
        
        return had

    def tick(self, app_state, motor: Any = None) -> None:
        """
        Periodic update to move robot towards next waypoint.
        Note: Disabled until NATS integration for pose and commands is complete.
        """
        # TODO: Implement via NATS - subscribe to motors.telemetry.pose, publish to motors.cmd.move
        return
    
    # ========== MAP UPLOAD SUPPORT ==========
    
    def handle_map_upload(self, app_state, geojson_data: dict) -> Dict[str, Any]:
        """
        Handle uploaded GeoJSON map data.
        Saves to cache and invalidates planner.
        
        Args:
            app_state: Application state
            geojson_data: GeoJSON dict from upload
            
        Returns:
            {"ok": bool, "message": str}
        """
        try:
            cache_dir = Path(__file__).parent.parent / "static" / "cache"
            cache_dir.mkdir(parents=True, exist_ok=True)
            
            # Save as chelybinsk.geojson (consistent with config)
            cache_file = cache_dir / "chelybinsk.geojson"
            
            # Save uploaded map
            with cache_file.open("w", encoding="utf-8") as f:
                json.dump(geojson_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"💾 Map saved: {cache_file.absolute()} "
                       f"({cache_file.stat().st_size} bytes)")
            
            # Invalidate planner cache to force reload
            self._invalidate_planner_cache(app_state)
            
            # Try to preload planner to validate map
            planner = self._get_or_create_planner(app_state)
            if not planner:
                return {
                    "ok": False, 
                    "message": "Map saved but failed to load planner"
                }
            
            return {
                "ok": True, 
                "message": f"Map uploaded successfully, planner ready"
            }
            
        except Exception as e:
            logger.error(f"❌ Map upload failed: {e}", exc_info=True)
            return {"ok": False, "message": f"Upload failed: {str(e)}"}
    
    def get_map_status(self, app_state) -> Dict[str, Any]:
        """
        Get status of current map and planner.
        
        Returns:
            {
                "has_map": bool,
                "planner_ready": bool,
                "map_file": str,
                "features": int (if available)
            }
        """
        cache_file = Path(__file__).parent.parent / "static" / "cache" / "site.geojson"
        
        has_map = cache_file.exists()
        planner = self._get_or_create_planner(app_state) if has_map else None
        
        status = {
            "has_map": has_map,
            "planner_ready": planner is not None,
            "map_file": str(cache_file.absolute()) if has_map else None
        }
        
        # Add planner info if available
        if planner and hasattr(planner, 'road_planner'):
            if planner.road_planner:
                status["road_nodes"] = len(planner.road_planner.graph)
                status["roads"] = len(planner.road_planner.roads)
            if planner.grid_planner:
                status["grid_size"] = f"{planner.grid_planner.w}x{planner.grid_planner.h}"
                status["obstacles"] = len(planner.grid_planner.cfg.obstacles)
        
        return status