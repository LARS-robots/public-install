# services/recording_service.py
"""
Recording Service - Orchestration layer for video recording.
"""
from __future__ import annotations
import asyncio
import logging
from typing import Optional, Tuple, List
from pathlib import Path

from ..system.camera_discovery import DeviceRegistry
from ..system.errors import DeviceUnavailableError, ConflictError, PreconditionFailedError
from .camera_manager import CameraManager

log = logging.getLogger(__name__)


class RecordingService:
    """
    Thin orchestration layer that:
      * Validates devices before starting
      * Provides idempotent stop semantics
      * Delegates actual recording to CameraManager
    """

    def __init__(
        self,
        device_registry: Optional[DeviceRegistry] = None,
        manager: Optional[CameraManager] = None
    ):
        self.devices = device_registry or DeviceRegistry()
        self.manager = manager or CameraManager()
        self._lock = asyncio.Lock()

        # Diagnostic counters
        self.conflicts_total = 0
        self.device_unavailable_total = 0
        self.recordings_started = 0
        self.recordings_stopped = 0

    async def get_cameras(self) -> list[int]:
        """Get list of available cameras."""
        return self.devices.list_cameras(probe_open=False)

    async def start_recording(
        self,
        session_id: Optional[str] = None,
        output_dir: Optional[Path] = None,
        segment_sec: Optional[int] = None,
    ) -> Tuple[str, List[Path], List[int]]:
        """Start recording from all available cameras."""
        async with self._lock:
            # Check if already recording
            if self.manager.is_recording():
                self.conflicts_total += 1
                log.info("recording.conflict_detected: already recording")
                raise ConflictError("Recording already active")

            # Precondition: at least one device must exist
            cams = self.devices.list_cameras(probe_open=False)
            if not cams:
                self.device_unavailable_total += 1
                log.warning("recording.no_devices: enumeration returned empty")
                raise PreconditionFailedError("No cameras detected")

            log.info("recording.start_requested: cameras=%s", cams)

            try:
                sid, files, started = await self.manager.start_recording(
                    session_id=session_id,
                    output_dir=output_dir,
                    segment_sec=segment_sec,
                )
                
                if not started:
                    raise DeviceUnavailableError("No cameras could be started")
                
                self.recordings_started += 1
                log.info(
                    "recording.started: session=%s, cameras=%s, files=%d",
                    sid, started, len(files)
                )
                
                return sid, files, started
                
            except Exception as e:
                log.error("recording.start_failed: %s", e, exc_info=True)
                raise

    async def stop_recording(self) -> Tuple[str, List[Path]]:
        """Stop active recording."""
        async with self._lock:
            # Clean up any dead recorders first
            await self.manager.cleanup_dead_recorders()
            
            # Check if there's actually something to stop
            if not self.manager.is_recording():
                self.conflicts_total += 1
                log.warning("recording.stop_noop: no active recording")
                raise ConflictError("No active recording")
            
            try:
                # Delegate to manager
                session_id, files = await self.manager.stop_recording()
                
                self.recordings_stopped += 1
                log.info(
                    "recording.stopped: session=%s, files=%d",
                    session_id, len(files)
                )
                
                return session_id, files
                
            except Exception as e:
                log.error("recording.stop_failed: %s", e, exc_info=True)
                raise

    def get_status(self) -> dict:
        """Get current recording status and diagnostics."""
        manager_status = self.manager.get_status()
        return {
            "is_recording": self.manager.is_recording(),
            "available_cameras": len(self.devices.snapshot()),
            "manager_status": manager_status,
            "statistics": {
                "conflicts_total": self.conflicts_total,
                "device_unavailable_total": self.device_unavailable_total,
                "recordings_started": self.recordings_started,
                "recordings_stopped": self.recordings_stopped,
            }
        }

    def get_zip_path(self, session_id: str) -> Optional[Path]:
        """Get ZIP path for a session."""
        return self.manager.get_zip_path(session_id)
