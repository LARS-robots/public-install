# services/eis_rt.py
"""
Real-time, config-driven EIS adapters for streaming.

Key properties
--------------
* No globals. Instances are owned by a single track (producer thread).
* Stabilization is applied ONLY to the STREAMING branch.
* I420 (YUV420p) path avoids BGR conversions on RPi hot path.
* Optional BGR path for the OpenCV fallback track.
* Stereo wrapper: per-eye stabilization for side-by-side stereo frames.

Config keys (from [eis] in config.toml)
---------------------------------------
  enabled: bool
  layout: "stereo_h" | "mono"   # никаких auto/detect
  cpu_budget_ms, queue_guard_depth, ...
  [eis.algorithm], [eis.virtual_gimbal]
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict
import logging
import time
import cv2
import numpy as np
from .gimbal_stabilizer import VirtualGimbal, VGParams

logger = logging.getLogger("eis_rt")

# --------------------------- Core single-view EIS --------------------------- #
@dataclass
class _Params:
    downscale_width: int = 640
    gftt_max_corners: int = 800
    lk_win: int = 21
    ransac_thresh: float = 3.0
    ema_alpha_pos: float = 0.20
    ema_alpha_rot: float = 0.20
    safety_crop_percent: int = 8
    cpu_budget_ms: int = 6
    queue_guard_depth: int = 6
    estimate_every_n: int = 2   # 1 = estimate every frame

class EISRT:
    """Stateful real-time EIS for a single image (mono)."""
    def __init__(self, width: int, height: int, cfg: Dict):
        self.W = int(width)
        self.H = int(height)
        eis_cfg = dict(cfg or {})
        algo = dict(eis_cfg.get("algorithm", {}))
        vg_cfg = dict(eis_cfg.get("virtual_gimbal", {}))

        estn = int(eis_cfg.get("estimate_every_n", eis_cfg.get("every_n", 1)))
        p = _Params(
            downscale_width=int(algo.get("downscale_width", 640)),
            gftt_max_corners=int(algo.get("gftt_max_corners", 800)),
            lk_win=int(algo.get("lk_win", 21)),
            ransac_thresh=float(algo.get("ransac_thresh", 3.0)),
            ema_alpha_pos=float(algo.get("ema_alpha_pos", 0.20)),
            ema_alpha_rot=float(algo.get("ema_alpha_rot", 0.20)),
            safety_crop_percent=int(algo.get("safety_crop_percent", eis_cfg.get("safety_crop_percent", 8))),
            cpu_budget_ms=int(eis_cfg.get("cpu_budget_ms", 6)),
            queue_guard_depth=int(eis_cfg.get("queue_guard_depth", 6)),
            estimate_every_n=max(1, estn),
        )
        p.safety_crop_percent = int(max(0, min(20, p.safety_crop_percent)))
        p.downscale_width = int(max(320, min(1280, p.downscale_width)))
        p.cpu_budget_ms = int(max(1, min(12, p.cpu_budget_ms)))
        p.queue_guard_depth = int(max(1, min(24, p.queue_guard_depth)))
        self.p = p

        # Optional virtual gimbal smoothing
        self.vg = None
        if vg_cfg and bool(vg_cfg.get("enabled", False)) and VirtualGimbal is not None:
            try:
                hfov_deg = float(algo.get("hfov_deg", eis_cfg.get("hfov_deg", 84.0)))
                use_percent = bool(vg_cfg.get("use_percent_hfov", True))
                def _deg2rad(d: float) -> float: return d * 3.1415926535 / 180.0
                if use_percent:
                    enter_xy = float(vg_cfg.get("enter_xy_percent", 0.12)) * 0.01 * self.W
                    exit_xy  = float(vg_cfg.get("exit_xy_percent", 0.08))  * 0.01 * self.W
                    enter_th = _deg2rad(float(vg_cfg.get("enter_theta_percent", 0.12)) * 0.01 * hfov_deg)
                    exit_th  = _deg2rad(float(vg_cfg.get("exit_theta_percent", 0.08))  * 0.01 * hfov_deg)
                else:
                    enter_xy = float(vg_cfg.get("enter_xy", 2.0))
                    exit_xy  = float(vg_cfg.get("exit_xy", 1.0))
                    enter_th = _deg2rad(float(vg_cfg.get("enter_theta_deg", 0.3)))
                    exit_th  = _deg2rad(float(vg_cfg.get("exit_theta_deg", 0.2)))
                p_xy = VGParams(
                    omega=float(vg_cfg.get("omega_xy", 6.0)),
                    zeta=1.0,
                    vmax=0.0,
                    amax=0.0,
                    enter=enter_xy,
                    exit=exit_xy,
                    lock_hold_frames=int(vg_cfg.get("lock_hold_frames", 3))
                )
                p_th = VGParams(
                    omega=float(vg_cfg.get("omega_theta", 4.0)),
                    zeta=1.0,
                    vmax=0.0,
                    amax=0.0,
                    enter=enter_th,
                    exit=exit_th,
                    lock_hold_frames=int(vg_cfg.get("lock_hold_frames", 3))
                )
                self.vg = VirtualGimbal(p_xy, p_th)
            except Exception as e:
                print(f"VirtualGimbal init failed: {e}")
                self.vg = None

        # State
        self._prev_gray: Optional[np.ndarray] = None
        self._ema_dx = self._ema_dy = self._ema_dth = 0.0
        self._last_ts = 0.0
        self._proc_ms_smoothed = 0.0
        self._frame_idx = 0
        self._last_M = None  # last affine (2x3)
        self._last_dx = self._last_dy = self._last_dth = 0.0

    # ---- internals ----
    def _downscale_gray_from_Y(self, Y: np.ndarray) -> tuple[np.ndarray, float]:
        h, w = Y.shape[:2]
        if w <= self.p.downscale_width:
            return Y, 1.0
        scale = self.p.downscale_width / float(w)
        gray = cv2.resize(Y, (self.p.downscale_width, int(round(h * scale))), interpolation=cv2.INTER_AREA)
        return gray, scale

    @staticmethod
    def _estimate_affine(prev_gray: np.ndarray, gray: np.ndarray,
                         max_corners: int, lk_win: int, ransac_thresh: float) -> tuple[float, float, float, int, int]:
        pts0 = cv2.goodFeaturesToTrack(prev_gray, maxCorners=max_corners, qualityLevel=0.01,
                                       minDistance=7, blockSize=7)
        if pts0 is None or len(pts0) < 6:
            return 0.0, 0.0, 0.0, 0, 0
        pts1, st, _ = cv2.calcOpticalFlowPyrLK(prev_gray, gray, pts0, None,
                                               winSize=(lk_win, lk_win), maxLevel=3,
                                               criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
        if pts1 is None:
            return 0.0, 0.0, 0.0, len(pts0), 0
        g0 = pts0[st.flatten() == 1]
        g1 = pts1[st.flatten() == 1]
        if g0 is None or g1 is None or len(g0) < 6 or len(g1) < 6:
            return 0.0, 0.0, 0.0, len(pts0), 0
        M, inliers = cv2.estimateAffinePartial2D(g0, g1, method=cv2.RANSAC,
                                                 ransacReprojThreshold=ransac_thresh)
        if M is None:
            return 0.0, 0.0, 0.0, len(g0), 0
        dx = float(M[0, 2]); dy = float(M[1, 2])
        dth = float(np.arctan2(M[1, 0], M[0, 0]))
        nin = int(inliers.sum()) if inliers is not None else 0
        return dx, dy, dth, len(g0), nin

    def _smooth(self, dx: float, dy: float, dth: float, dt: float) -> tuple[float, float, float]:
        """ Smooth the motion deltas using virtual gimbal or EMA fallback. """
        if getattr(self, "vg", None) is not None:
            cx, cy, cth = self.vg.update(dx, dy, dth, max(1e-4, dt))
            return dx + cx, dy + cy, dth + cth
        # EMA fallback
        a_pos, a_rot = self.p.ema_alpha_pos, self.p.ema_alpha_rot
        self._ema_dx = a_pos * dx + (1 - a_pos) * self._ema_dx
        self._ema_dy = a_pos * dy + (1 - a_pos) * self._ema_dy
        self._ema_dth = a_rot * dth + (1 - a_rot) * self._ema_dth
        return self._ema_dx, self._ema_dy, self._ema_dth

    @staticmethod
    def _affine_center(dx: float, dy: float, dth: float, W: int, H: int) -> np.ndarray:
        """
        Rotation around the center of the frame + translation.
        This reduces edge distortion (including “skew” at the bottom).
        """
        cx, cy = 0.5 * W, 0.5 * H
        ct, st = float(np.cos(dth)), float(np.sin(dth))
        M = np.array([[ct, -st, 0.0],
                      [st,  ct, 0.0]], dtype=np.float32)
        # the same as T(c) * R * T(-c) + translation(dx,dy)
        M[0, 2] = dx + (1 - ct) * cx + st * cy
        M[1, 2] = dy + (1 - ct) * cy - st * cx
        return M

    @staticmethod
    def _affine_for_uv(dx: float, dy: float, dth: float, W_uv: int, H_uv: int) -> np.ndarray:
        """ Affine matrix for UV plane (half resolution and half shifts). """
        return EISRT._affine_center(dx * 0.5, dy * 0.5, dth, W_uv, H_uv)

    # ---- public API ----
    def process_i420(self, buf_2d: np.ndarray, *, queue_len: int = 0) -> np.ndarray:
        """Stabilize an I420 buffer (H*3/2, W) → returns NEW ndarray."""
        t_start = time.perf_counter()
        if queue_len >= self.p.queue_guard_depth:
            return buf_2d
        H, W = self.H, self.W
        ysz = W * H
        uvw, uvh = W // 2, H // 2
        uvsz = uvw * uvh
        flat = buf_2d.ravel()
        if flat.size != ysz + 2 * uvsz:
            return buf_2d
        Y = flat[0:ysz].reshape(H, W)
        U = flat[ysz:ysz + uvsz].reshape(uvh, uvw)
        V = flat[ysz + uvsz:ysz + 2 * uvsz].reshape(uvh, uvw)

        # Downscale gray
        gray, scale = self._downscale_gray_from_Y(Y)
        if self._prev_gray is None:
            self._prev_gray = gray.copy()
            return buf_2d

        self._frame_idx += 1
        if (self._frame_idx % self.p.estimate_every_n) == 0 or self._last_M is None:
            dxs, dys, dth, _, _ = self._estimate_affine(
                self._prev_gray, gray,
                self.p.gftt_max_corners, self.p.lk_win, self.p.ransac_thresh
            )
            dx = dxs / max(1e-6, scale)
            dy = dys / max(1e-6, scale)
            self._last_dx, self._last_dy, self._last_dth = dx, dy, dth
        else:
            dx, dy, dth = self._last_dx, self._last_dy, self._last_dth

        now = time.time()
        dt = max(1e-3, now - (self._last_ts or now))
        self._last_ts = now
        sdx, sdy, sdth = self._smooth(dx, dy, dth, dt)

        # IMPORTANT: rotation around the center
        M   = self._affine_center(sdx, sdy, sdth, W,   H)
        Muv = self._affine_for_uv(sdx, sdy, sdth, uvw, uvh)
        self._last_M = M

        crop = int(round(self.p.safety_crop_percent * 0.01 * W))
        x0 = crop; y0 = crop; x1 = W - crop; y1 = H - crop
        if x1 <= x0 or y1 <= y0:
            x0 = y0 = 0; x1 = W; y1 = H

        Yw = cv2.warpAffine(Y, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        Yc = Yw[y0:y1, x0:x1]
        if (x0 or y0):
            Yc = cv2.resize(Yc, (W, H), interpolation=cv2.INTER_LINEAR)

        Uw = cv2.warpAffine(U, Muv, (uvw, uvh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        Vw = cv2.warpAffine(V, Muv, (uvw, uvh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        ux0, uy0, ux1, uy1 = x0 // 2, y0 // 2, x1 // 2, y1 // 2
        Uc = Uw[uy0:uy1, ux0:ux1]; Vc = Vw[uy0:uy1, ux0:ux1]
        if (x0 or y0):
            Uc = cv2.resize(Uc, (uvw, uvh), interpolation=cv2.INTER_LINEAR)
            Vc = cv2.resize(Vc, (uvw, uvh), interpolation=cv2.INTER_LINEAR)

        out = np.empty_like(flat)
        out[0:ysz] = Yc.reshape(-1)
        out[ysz:ysz + uvsz] = Uc.reshape(-1)
        out[ysz + uvsz:ysz + 2 * uvsz] = Vc.reshape(-1)
        proc_ms = (time.perf_counter() - t_start) * 1000.0
        self._prev_gray = gray
        if self._proc_ms_smoothed == 0.0:
            self._proc_ms_smoothed = proc_ms
        else:
            self._proc_ms_smoothed = 0.8 * self._proc_ms_smoothed + 0.2 * proc_ms
        if (self._frame_idx % 50) == 0:
            logger.info(
                "eis_rt.avg_proc_ms",
                extra={
                    "event": {
                        "stage": "eis",
                        "action": "avg_proc_ms",
                        "value": round(self._proc_ms_smoothed, 2),
                        "frame": self._frame_idx,
                    }
                },
            )
        return out.reshape(H * 3 // 2, W)

    def process_bgr(self, frame_bgr: np.ndarray, *, queue_len: int = 0) -> np.ndarray:
        """Stabilize a BGR frame (desktop/OpenCV path)."""
        if queue_len >= self.p.queue_guard_depth:
            return frame_bgr
        H, W = frame_bgr.shape[:2]
        small_w = min(self.p.downscale_width, W)
        scale = small_w / float(W)
        small = cv2.resize(frame_bgr, (small_w, int(round(H * scale))), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if self._prev_gray is None:
            self._prev_gray = gray.copy()
            return frame_bgr

        self._frame_idx += 1
        if (self._frame_idx % self.p.estimate_every_n) == 0 or self._last_M is None:
            dxs, dys, dth, _, _ = self._estimate_affine(
                self._prev_gray, gray,
                self.p.gftt_max_corners, self.p.lk_win, self.p.ransac_thresh
            )
            dx = dxs / max(1e-6, scale)
            dy = dys / max(1e-6, scale)
            self._last_dx, self._last_dy, self._last_dth = dx, dy, dth
        else:
            dx, dy, dth = self._last_dx, self._last_dy, self._last_dth

        now = time.time()
        dt = max(1e-3, now - (self._last_ts or now))
        self._last_ts = now
        sdx, sdy, sdth = self._smooth(dx, dy, dth, dt)

        # Rotation around the center of the frame for BGR
        M = self._affine_center(sdx, sdy, sdth, W, H)
        self._last_M = M

        crop = int(round(self.p.safety_crop_percent * 0.01 * W))
        x0 = crop; y0 = crop; x1 = W - crop; y1 = H - crop
        if x1 <= x0 or y1 <= y0:
            x0 = y0 = 0; x1 = W; y1 = H
        warped = cv2.warpAffine(frame_bgr, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        out = warped[y0:y1, x0:x1]
        if (x0 or y0):
            out = cv2.resize(out, (W, H), interpolation=cv2.INTER_LINEAR)
        self._prev_gray = gray
        return out

# --------------------------- Stereo side-by-side wrapper ------------------- #
class StereoEISRT:
    """SBS split → two EISRT → stitch back."""
    def __init__(self, width: int, height: int, cfg: Dict):
        assert width % 2 == 0, "StereoEISRT expects even width"
        self.W = int(width)
        self.H = int(height)
        self.w_half = self.W // 2
        self.left = EISRT(self.w_half, self.H, cfg)
        self.right = EISRT(self.w_half, self.H, cfg)

    def _split_i420_sbs(self, buf_2d: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """ Split side-by-side I420 into two I420 buffers. """
        H, W = self.H, self.W
        wh = self.w_half
        ysz = W * H
        uvw, uvh = W // 2, H // 2
        uvsz = uvw * uvh
        flat = buf_2d.ravel()
        Y = flat[0:ysz].reshape(H, W)
        U = flat[ysz:ysz + uvsz].reshape(uvh, uvw)
        V = flat[ysz + uvsz:ysz + 2 * uvsz].reshape(uvh, uvw)
        YL, YR = Y[:, :wh], Y[:, wh:]
        UL, UR = U[:, :wh // 2], U[:, wh // 2:]
        VL, VR = V[:, :wh // 2], V[:, wh // 2:]

        def _pack(Yp, Up, Vp):
            flat_out = np.empty(Yp.size + Up.size + Vp.size, dtype=np.uint8)
            flat_out[:Yp.size] = Yp.reshape(-1)
            flat_out[Yp.size:Yp.size + Up.size] = Up.reshape(-1)
            flat_out[Yp.size + Up.size:] = Vp.reshape(-1)
            return flat_out.reshape(H * 3 // 2, wh)

        left = _pack(YL, UL, VL)
        right = _pack(YR, UR, VR)
        return left, right

    def _stitch_i420_sbs(self, left_2d: np.ndarray, right_2d: np.ndarray) -> np.ndarray:
        """ Stitch two I420 buffers into side-by-side I420. """
        H, W = self.H, self.W
        wh = self.w_half
        ysz = wh * H
        uvw, uvh = wh // 2, H // 2
        uvsz = uvw * uvh
        L = left_2d.ravel(); R = right_2d.ravel()
        YL = L[0:ysz].reshape(H, wh)
        UL = L[ysz:ysz + uvsz].reshape(uvh, uvw)
        VL = L[ysz + uvsz:ysz + 2 * uvsz].reshape(uvh, uvw)
        YR = R[0:ysz].reshape(H, wh)
        UR = R[ysz:ysz + uvsz].reshape(uvh, uvw)
        VR = R[ysz + uvsz:ysz + 2 * uvsz].reshape(uvh, uvw)
        Y = np.concatenate([YL, YR], axis=1)
        U = np.concatenate([UL, UR], axis=1)
        V = np.concatenate([VL, VR], axis=1)
        out = np.empty(W * H + (W // 2) * (H // 2) * 2, dtype=np.uint8)
        off = 0
        out[off:off + W * H] = Y.reshape(-1); off += W * H
        out[off:off + (W // 2) * (H // 2)] = U.reshape(-1); off += (W // 2) * (H // 2)
        out[off:off + (W // 2) * (H // 2)] = V.reshape(-1)
        return out.reshape(H * 3 // 2, W)

    def process_i420(self, buf_2d: np.ndarray, *, queue_len: int = 0) -> np.ndarray:
        """ Stabilize a side-by-side I420 buffer. """
        L, R = self._split_i420_sbs(buf_2d)
        Ls = self.left.process_i420(L, queue_len=queue_len)
        Rs = self.right.process_i420(R, queue_len=queue_len)
        return self._stitch_i420_sbs(Ls, Rs)

    def process_bgr(self, frame_bgr: np.ndarray, *, queue_len: int = 0) -> np.ndarray:
        """ Stabilize a side-by-side BGR frame. """
        H, W = frame_bgr.shape[:2]
        wh = W // 2
        L = frame_bgr[:, :wh, :]
        R = frame_bgr[:, wh:, :]
        Ls = self.left.process_bgr(L, queue_len=queue_len)
        Rs = self.right.process_bgr(R, queue_len=queue_len)
        return np.concatenate([Ls, Rs], axis=1)

# --------------------------- Factory / layout logic ------------------------ #
def build_eis_adapter(width: int, height: int, eis_cfg: Dict):
    """
    Build adapter strictly by explicit layout from config:
      - "stereo_h" -> StereoEISRT (side-by-side)
      - "mono"     -> EISRT
    """
    if not eis_cfg or not bool(eis_cfg.get("enabled", False)):
        return None
    layout = str(eis_cfg.get("layout", "mono")).lower()
    if layout == "stereo_h":
        assert width % 2 == 0, "stereo_h requires even width"
        return StereoEISRT(width, height, eis_cfg)
    # quad stabilizes as mono for now 
    return EISRT(width, height, eis_cfg)
