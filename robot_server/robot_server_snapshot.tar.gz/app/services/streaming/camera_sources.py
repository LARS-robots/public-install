# services/sources.py
from __future__ import annotations
import asyncio, platform as _py_platform, shutil, subprocess, time
from pathlib import Path
from threading import Event, Lock, Thread
from typing import Optional
from collections import deque
import logging

import cv2
import numpy as np

from .camera_ipc import CameraDaemonClient, FrameReader, IPCConfig
from ..system.config import AppConfig

log = logging.getLogger(__name__)

class CameraSource:
    """
    Single-producer source:
      - rpi: rpicam-vid → raw I420
      - v4l2: ffmpeg -f v4l2 → raw I420
      - opencv: cv2 VideoCapture → BGR → I420 (only if you explicitly set platform=opencv)
    """
    def __init__(self, camera_index: int, width: int, height: int, fps: int, platform: str, queue_size: int = 4):
        self.camera_index = int(camera_index)
        self.width, self.height, self.fps = int(width), int(height), int(fps)
        self.platform = platform  # "rpi"|"v4l2"|"opencv"
        self.frame_size = self.width * self.height * 3 // 2
        self._proc = None; self._stdout_thread = None; self._stderr_thread = None
        self._cv_cap = None; self._cv_thread = None
        self._stop_evt = Event()
        self._frames = deque(maxlen=queue_size); self._frames_lock = Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _build_cmd(self) -> list[str]:
        if self.platform == "rpi":
            return [
                "rpicam-vid","--camera",str(self.camera_index),
                "--width",str(self.width),"--height",str(self.height),
                "--codec","yuv420","--nopreview","--timeout","0","--flush","-o","-"
            ]
        # v4l2
        return [
            "ffmpeg","-hide_banner","-loglevel","warning",
            "-f","v4l2","-video_size",f"{self.width}x{self.height}",
            "-framerate",str(self.fps),
            "-i", f"/dev/video{self.camera_index}",
            "-f","rawvideo","-pix_fmt","yuv420p","-"
        ]

    async def start(self) -> None:
        if self._proc or self._cv_thread: return
        self._loop = asyncio.get_running_loop(); self._stop_evt.clear()

        if self.platform == "opencv":
            be = cv2.CAP_DSHOW if _py_platform.system()=="Windows" else (cv2.CAP_AVFOUNDATION if _py_platform.system()=="Darwin" else 0)
            cap = cv2.VideoCapture(self.camera_index, be)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            cap.set(cv2.CAP_PROP_FPS, self.fps)
            if not cap or not cap.isOpened():
                log.error("capture.open_error", extra={"event":{"stage":"capture","action":"open_error","camera_id":self.camera_index,"platform":"opencv"}})
                return
            self._cv_cap = cap
            log.info("capture.start", extra={"event":{"stage":"capture","action":"start","camera_id":self.camera_index,"width":self.width,"height":self.height,"fps":self.fps,"platform":"opencv"}})
            self._cv_thread = Thread(target=self._cv_reader, name="CameraSource-cv2", daemon=True); self._cv_thread.start()
            return

        cmd = self._build_cmd()
        log.info("capture.start", extra={"event":{"stage":"capture","action":"start","camera_id":self.camera_index,"width":self.width,"height":self.height,"fps":self.fps,"platform":self.platform,"cmd":" ".join(cmd)}})
        self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self._stdout_thread = Thread(target=self._stdout_reader, name="CameraSource-stdout", daemon=True); self._stdout_thread.start()
        self._stderr_thread = Thread(target=self._stderr_reader, name="CameraSource-stderr", daemon=True); self._stderr_thread.start()

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    async def stop(self, timeout: float = 3.0) -> None:
        if self._cv_thread:
            self._stop_evt.set()
            try: self._cv_thread.join(timeout=timeout)
            except: pass
            self._cv_thread=None
            if self._cv_cap:
                try: self._cv_cap.release()
                except: pass
            with self._frames_lock: self._frames.clear()
            return

        if not self._proc:
            return
        self._stop_evt.set()
        try: self._proc.terminate()
        except: pass
        loop = asyncio.get_running_loop()
        try: await loop.run_in_executor(None, lambda: self._proc.wait(timeout))
        except: pass
        finally:
            for t in (self._stdout_thread, self._stderr_thread):
                if t and t.is_alive():
                    try: t.join(timeout=1.0)
                    except: pass
            self._stdout_thread=self._stderr_thread=None; self._proc=None
            with self._frames_lock: self._frames.clear()

    # ---- internal readers ----
    def _read_exact(self, n: int) -> Optional[bytes]:
        assert self._proc and self._proc.stdout
        buf = bytearray()
        while len(buf) < n:
            b = self._proc.stdout.read(n - len(buf))
            if not b:
                return None
            buf.extend(b)
        return bytes(buf)

    def _stdout_reader(self) -> None:
        assert self._proc and self._proc.stdout
        frame_size = self.frame_size
        while not self._stop_evt.is_set():
            data = self._read_exact(frame_size)
            if not data:
                break
            arr = np.frombuffer(data, dtype=np.uint8)
            if arr.size != frame_size:
                continue
            with self._frames_lock:
                self._frames.append(arr)

    def _stderr_reader(self) -> None:
        assert self._proc and self._proc.stderr
        for line in self._proc.stderr:
            try:
                log.debug("ffmpeg: %s", line.decode(errors="ignore").strip())
            except Exception:
                pass

    def _cv_reader(self) -> None:
        import cv2
        while not self._stop_evt.is_set():
            ok, bgr = self._cv_cap.read()
            if not ok:
                time.sleep(0.01); continue
            h, w = bgr.shape[:2]
            # Convert BGR to I420 (slow path, used only if platform=opencv)
            yuv = cv2.cvtColor(bgr, cv2.COLOR_BGR2YUV_I420)
            with self._frames_lock:
                self._frames.append(yuv.reshape(-1).copy())

class CameraSourceDaemon:
    """Pulls I420 frames from a GStreamer camera daemon via TCP."""
    def __init__(self, camera_index: int, width: int, height: int, fps: int, queue_size: int = 4):
        self.camera_index=int(camera_index); self.width=int(width); self.height=int(height); self.fps=int(fps)
        self.frame_size=self.width*self.height*3//2
        self._frames=deque(maxlen=queue_size); self._frames_lock=Lock()
        self._loop=None; self._reader_task=None; self._frame_reader=None; self._daemon_client=None
        self._ipc_config: Optional[IPCConfig]=None
        self._stop_evt = Event()

    async def start(self) -> None:
        if self._reader_task: return
        self._loop=asyncio.get_running_loop()
        self._ipc_config = IPCConfig()
        self._daemon_client = CameraDaemonClient(self._ipc_config)
        res = await self._daemon_client.start_camera(self.camera_index, self.width, self.height, self.fps)
        if res.get("status") not in ("started","already_running"):
            raise RuntimeError(f"Failed to start camera {self.camera_index} via daemon: {res}")
        self._frame_reader = FrameReader(self.camera_index, self._ipc_config)
        self._reader_task = asyncio.create_task(self._read_frames())

    async def _read_frames(self) -> None:
        try:
            await self._frame_reader.connect()
            async for w,h,pts_us,fmt,payload in self._frame_reader.read_frames():
                if (w,h)!=(self.width,self.height):
                    # accept size renegotiation from daemon
                    self.width,self.height=w,h; self.frame_size=w*h*3//2
                arr = np.frombuffer(payload, dtype=np.uint8)
                if arr.size != self.frame_size:
                    continue
                with self._frames_lock:
                    self._frames.append(arr.copy())
        finally:
            try: await self._frame_reader.disconnect()
            except: pass

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    async def stop(self, timeout: float = 3.0, *, keep_daemon: bool = False) -> None:
        """Stop camera source. If keep_daemon=True, only disconnect reader."""
        
        # 1) Cancel reader task
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await asyncio.wait_for(self._reader_task, timeout=timeout)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            self._reader_task = None

        # 2) Disconnect frame reader (TCP connection)
        if self._frame_reader:
            await self._frame_reader.disconnect()
            self._frame_reader = None

        # 3) Only stop daemon if keep_daemon=False
        if not keep_daemon and self._daemon_client:
            log.info(
                "source.stop_daemon",
                extra={"event": {
                    "stage": "capture",
                    "action": "stop_daemon_command",
                    "camera_id": self.camera_index
                }}
            )
            await self._daemon_client.stop_camera(self.camera_index)
        elif keep_daemon:
            log.info(
                "source.detach_only",
                extra={"event": {
                    "stage": "capture",
                    "action": "detach_tcp_reader",
                    "camera_id": self.camera_index,
                    "daemon": "kept_alive"
                }}
            )
        
        # 4) Clear references
        self._daemon_client = None
        self._ipc_config = None

        with self._frames_lock:
            self._frames.clear()

def create_camera_source(cfg: AppConfig, camera_index: int, width: int, height: int, fps: int) -> CameraSource | CameraSourceDaemon:
    plat = cfg.video.platform
    if plat in ("gstreamer", "gst", "daemon"):
        return CameraSourceDaemon(camera_index, width, height, fps)
    elif plat in ("rpi", "v4l2", "opencv"):
        return CameraSource(camera_index, width, height, fps, platform=plat)
    # default to gstreamer if unknown
    return CameraSourceDaemon(camera_index, width, height, fps)
