# services/sources.py
from __future__ import annotations
import asyncio, platform as _py_platform, shutil, subprocess, time
from pathlib import Path
from threading import Event, Lock, Thread
from typing import Optional
from collections import deque
import logging

import cv2
import numpy as np

from .camera_ipc import CameraDaemonClient, FrameReader, IPCConfig
from ..system.config import AppConfig

log = logging.getLogger(__name__)

class CameraSource:
    """
    Single-producer source:
      - rpi: rpicam-vid → raw I420
      - v4l2: ffmpeg -f v4l2 → raw I420
      - opencv: cv2 VideoCapture → BGR → I420 (only if you explicitly set platform=opencv)
    """
    def __init__(self, camera_index: int, width: int, height: int, fps: int, platform: str, queue_size: int = 4):
        self.camera_index = int(camera_index)
        self.width, self.height, self.fps = int(width), int(height), int(fps)
        self.platform = platform  # "rpi"|"v4l2"|"opencv"
        self.frame_size = self.width * self.height * 3 // 2
        self._proc = None; self._stdout_thread = None; self._stderr_thread = None
        self._cv_cap = None; self._cv_thread = None
        self._stop_evt = Event()
        self._frames = deque(maxlen=queue_size); self._frames_lock = Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _build_cmd(self) -> list[str]:
        if self.platform == "rpi":
            return [
                "rpicam-vid","--camera",str(self.camera_index),
                "--width",str(self.width),"--height",str(self.height),
                "--codec","yuv420","--nopreview","--timeout","0","--flush","-o","-"
            ]
        # v4l2
        return [
            "ffmpeg","-hide_banner","-loglevel","warning",
            "-f","v4l2","-video_size",f"{self.width}x{self.height}",
            "-framerate",str(self.fps),
            "-i", f"/dev/video{self.camera_index}",
            "-f","rawvideo","-pix_fmt","yuv420p","-"
        ]

    async def start(self) -> None:
        if self._proc or self._cv_thread: return
        self._loop = asyncio.get_running_loop(); self._stop_evt.clear()

        if self.platform == "opencv":
            be = cv2.CAP_DSHOW if _py_platform.system()=="Windows" else (cv2.CAP_AVFOUNDATION if _py_platform.system()=="Darwin" else 0)
            cap = cv2.VideoCapture(self.camera_index, be)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            cap.set(cv2.CAP_PROP_FPS, self.fps)
            if not cap or not cap.isOpened():
                log.error("capture.open_error", extra={"event":{"stage":"capture","action":"open_error","camera_id":self.camera_index,"platform":"opencv"}})
                return
            self._cv_cap = cap
            log.info("capture.start", extra={"event":{"stage":"capture","action":"start","camera_id":self.camera_index,"width":self.width,"height":self.height,"fps":self.fps,"platform":"opencv"}})
            self._cv_thread = Thread(target=self._cv_reader, name="CameraSource-cv2", daemon=True); self._cv_thread.start()
            return

        cmd = self._build_cmd()
        log.info("capture.start", extra={"event":{"stage":"capture","action":"start","camera_id":self.camera_index,"width":self.width,"height":self.height,"fps":self.fps,"platform":self.platform,"cmd":" ".join(cmd)}})
        self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self._stdout_thread = Thread(target=self._stdout_reader, name="CameraSource-stdout", daemon=True); self._stdout_thread.start()
        self._stderr_thread = Thread(target=self._stderr_reader, name="CameraSource-stderr", daemon=True); self._stderr_thread.start()

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    async def stop(self, timeout: float = 3.0) -> None:
        if self._cv_thread:
            self._stop_evt.set()
            try: self._cv_thread.join(timeout=timeout)
            except: pass
            self._cv_thread=None
            if self._cv_cap:
                try: self._cv_cap.release()
                except: pass
            with self._frames_lock: self._frames.clear()
            log.info(f"Stopped OpenCV camera source for camera {self.camera_index}")
            return

        if not self._proc:
            return
        
        log.info(f"Stopping camera process (platform: {self.platform}) for camera {self.camera_index}")
        self._stop_evt.set()
        
        # Try graceful termination first
        try: 
            self._proc.terminate()
            log.debug(f"Sent terminate signal to camera process for camera {self.camera_index}")
        except Exception as e:
            log.warning(f"Failed to terminate camera process: {e}")
        
        # Wait for process to finish
        loop = asyncio.get_running_loop()
        try: 
            await loop.run_in_executor(None, lambda: self._proc.wait(timeout))
            log.info(f"Camera process terminated gracefully for camera {self.camera_index}")
        except Exception as e:
            log.warning(f"Process did not terminate within timeout: {e}")
            # Force kill if still running
            if self._proc.poll() is None:
                try:
                    self._proc.kill()
                    log.warning(f"Force killed camera process for camera {self.camera_index}")
                    await loop.run_in_executor(None, lambda: self._proc.wait(timeout=1.0))
                except Exception as e2:
                    log.error(f"Failed to kill camera process: {e2}")
        finally:
            for t in (self._stdout_thread, self._stderr_thread):
                if t and t.is_alive():
                    try: t.join(timeout=1.0)
                    except: pass
            self._stdout_thread=self._stderr_thread=None
            self._proc=None
            with self._frames_lock: self._frames.clear()
            log.info(f"✅ Camera source stopped for camera {self.camera_index}")

    # ---- internal readers ----
    def _read_exact(self, n: int) -> Optional[bytes]:
        assert self._proc and self._proc.stdout
        buf = bytearray()
        while len(buf) < n:
            b = self._proc.stdout.read(n - len(buf))
            if not b:
                return None
            buf.extend(b)
        return bytes(buf)

    def _stdout_reader(self) -> None:
        assert self._proc and self._proc.stdout
        frame_size = self.frame_size
        while not self._stop_evt.is_set():
            data = self._read_exact(frame_size)
            if not data:
                break
            arr = np.frombuffer(data, dtype=np.uint8)
            if arr.size != frame_size:
                continue
            with self._frames_lock:
                self._frames.append(arr)

    def _stderr_reader(self) -> None:
        assert self._proc and self._proc.stderr
        for line in self._proc.stderr:
            try:
                log.debug("ffmpeg: %s", line.decode(errors="ignore").strip())
            except Exception:
                pass

    def _cv_reader(self) -> None:
        import cv2
        while not self._stop_evt.is_set():
            ok, bgr = self._cv_cap.read()
            if not ok:
                time.sleep(0.01); continue
            h, w = bgr.shape[:2]
            # Convert BGR to I420 (slow path, used only if platform=opencv)
            yuv = cv2.cvtColor(bgr, cv2.COLOR_BGR2YUV_I420)
            with self._frames_lock:
                self._frames.append(yuv.reshape(-1).copy())


class VirtualCameraSource:
    """
    Виртуальная камера с программной генерацией тестовых кадров или чтением видео-файла.
    Использует OpenCV и NumPy для создания кадров или чтения видео-файла.
    """
    def __init__(self, camera_index: int, width: int, height: int, fps: int, video_file: Optional[str] = None, queue_size: int = 4):
        self.camera_index = int(camera_index)
        self.width, self.height, self.fps = int(width), int(height), int(fps)
        self.video_file = video_file
        self.frame_size = self.width * self.height * 3 // 2
        self._frames = deque(maxlen=queue_size)
        self._frames_lock = Lock()
        self._generator_thread: Optional[Thread] = None
        self._video_cap: Optional[cv2.VideoCapture] = None
        self._stop_evt = Event()
        self._frame_counter = 0
    
    def _generate_frame(self) -> np.ndarray:
        """Генерирует кадр: из видео-файла или программно"""
        if self.video_file and self._video_cap:
            ret, frame_bgr = self._video_cap.read()
            if not ret:
                self._video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret, frame_bgr = self._video_cap.read()
                if not ret:
                    raise RuntimeError(f"Failed to read from video file: {self.video_file}")
            # НЕ делаем resize - используем реальный размер из видео
            # Размеры обновлены в start() из CAP_PROP_FRAME_WIDTH/HEIGHT
        else:
            frame_bgr = np.zeros((self.height, self.width, 3), dtype=np.uint8)
            tile_size = 32
            for y in range(self.height):
                for x in range(self.width):
                    tile_x = (x + self._frame_counter) // tile_size
                    tile_y = y // tile_size
                    if (tile_x + tile_y) % 2 == 0:
                        frame_bgr[y, x] = [180, 180, 180]
                    else:
                        frame_bgr[y, x] = [80, 80, 80]
            center_x = int(self.width // 2 + 50 * np.sin(self._frame_counter * 0.1))
            center_y = int(self.height // 2 + 30 * np.cos(self._frame_counter * 0.1))
            cv2.circle(frame_bgr, (center_x, center_y), 40, (255, 255, 255), -1)
            cv2.putText(frame_bgr, f"Frame {self._frame_counter}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        frame_i420 = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2YUV_I420)
        self._frame_counter += 1
        return frame_i420.reshape(-1)
    
    def _generator_loop(self):
        """Генератор кадров в отдельном потоке"""
        frame_time = 1.0 / self.fps
        while not self._stop_evt.is_set():
            start = time.time()
            frame = self._generate_frame()
            with self._frames_lock:
                self._frames.append(frame)
            elapsed = time.time() - start
            time.sleep(max(0, frame_time - elapsed))
    
    async def start(self) -> None:
        if self._generator_thread:
            return
        if self.video_file:
            self._video_cap = cv2.VideoCapture(self.video_file)
            if not self._video_cap.isOpened():
                raise RuntimeError(f"Cannot open video file: {self.video_file}")
            # Автоматически определяем размеры из видео-файла
            video_width = int(self._video_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            video_height = int(self._video_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            if video_width > 0 and video_height > 0:
                self.width = video_width
                self.height = video_height
                self.frame_size = self.width * self.height * 3 // 2
                log.info(f"Virtual camera auto-detected resolution: {self.width}x{self.height} from video file")
        self._stop_evt.clear()
        self._generator_thread = Thread(target=self._generator_loop, name=f"VirtualCamera-{self.camera_index}", daemon=True)
        self._generator_thread.start()
        mode = f"video file: {self.video_file}" if self.video_file else "generated frames"
        log.info(f"Virtual camera started: cam{self.camera_index} {self.width}x{self.height}@{self.fps}fps ({mode})")
    
    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]
    
    async def stop(self, timeout: float = 3.0) -> None:
        if self._generator_thread:
            self._stop_evt.set()
            try:
                self._generator_thread.join(timeout=timeout)
            except Exception:
                pass
            self._generator_thread = None
        if self._video_cap:
            self._video_cap.release()
            self._video_cap = None
        with self._frames_lock:
            self._frames.clear()


class CameraSourceDaemon:
    """Pulls I420 frames from a GStreamer camera daemon via TCP."""
    def __init__(self, camera_index: int, width: int, height: int, fps: int, queue_size: int = 4, video_file: Optional[str] = None):
        self.camera_index=int(camera_index); self.width=int(width); self.height=int(height); self.fps=int(fps)
        self.video_file = video_file  # Путь к видео-файлу для виртуальной камеры
        self.frame_size=self.width*self.height*3//2
        self._frames=deque(maxlen=queue_size); self._frames_lock=Lock()
        self._loop=None; self._reader_task=None; self._frame_reader=None; self._daemon_client=None
        self._ipc_config: Optional[IPCConfig]=None
        self._stop_evt = Event()

    async def start(self) -> None:
        if self._reader_task: return
        self._loop=asyncio.get_running_loop()
        self._ipc_config = IPCConfig.from_env()
        self._daemon_client = CameraDaemonClient(self._ipc_config)
        res = await self._daemon_client.start_camera(self.camera_index, self.width, self.height, self.fps, video_file=self.video_file)
        if res.get("status") not in ("started","already_running"):
            raise RuntimeError(f"Failed to start camera {self.camera_index} via daemon: {res}")
        self._frame_reader = FrameReader(self.camera_index, self._ipc_config)
        self._reader_task = asyncio.create_task(self._read_frames())

    async def _read_frames(self) -> None:
        try:
            await self._frame_reader.connect()
            async for w,h,pts_us,fmt,payload in self._frame_reader.read_frames():
                if (w,h)!=(self.width,self.height):
                    # accept size renegotiation from daemon
                    self.width,self.height=w,h; self.frame_size=w*h*3//2
                arr = np.frombuffer(payload, dtype=np.uint8)
                expected_size = w * h * 3 // 2
                if arr.size != expected_size:
                    log.warning("Frame size mismatch: received %d bytes, expected %d (w=%d h=%d)", arr.size, expected_size, w, h)
                    continue
                # Check if frame is all zeros (black frame detection)
                if arr.size > 0 and np.all(arr[:min(1000, arr.size)] == 0):
                    log.warning("Received black frame (all zeros) from camera %d", self.camera_index)
                with self._frames_lock:
                    self._frames.append(arr.copy())
        finally:
            try: await self._frame_reader.disconnect()
            except: pass

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    async def stop(self, timeout: float = 3.0, *, keep_daemon: bool = False) -> None:
        """Stop camera source. If keep_daemon=True, only disconnect reader."""
        
        log.info(f"Stopping CameraSourceDaemon for camera {self.camera_index} (keep_daemon={keep_daemon})")
        
        # 1) Cancel reader task
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await asyncio.wait_for(self._reader_task, timeout=timeout)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            self._reader_task = None

        # 2) Disconnect frame reader (TCP connection)
        if self._frame_reader:
            await self._frame_reader.disconnect()
            self._frame_reader = None

        # 3) Only stop daemon if keep_daemon=False
        if not keep_daemon and self._daemon_client:
            log.info(
                "source.stop_daemon",
                extra={"event": {
                    "stage": "capture",
                    "action": "stop_daemon_command",
                    "camera_id": self.camera_index
                }}
            )
            try:
                result = await self._daemon_client.stop_camera(self.camera_index)
                if result.get("error"):
                    log.warning(f"Failed to stop daemon for camera {self.camera_index}: {result}")
                else:
                    log.info(f"✅ Daemon stopped for camera {self.camera_index}: {result}")
            except Exception as e:
                log.error(f"❌ Exception stopping daemon for camera {self.camera_index}: {e}", exc_info=True)
        elif keep_daemon:
            log.info(
                "source.detach_only",
                extra={"event": {
                    "stage": "capture",
                    "action": "detach_tcp_reader",
                    "camera_id": self.camera_index,
                    "daemon": "kept_alive"
                }}
            )
        
        # 4) Clear references
        self._daemon_client = None
        self._ipc_config = None

        with self._frames_lock:
            self._frames.clear()
        
        log.info(f"CameraSourceDaemon stopped for camera {self.camera_index}")

async def create_camera_source(cfg: AppConfig, camera_index: int, width: int, height: int, fps: int) -> CameraSource | CameraSourceDaemon | VirtualCameraSource:
    """
    Create camera source with automatic fallback.
    Supports physical cameras, virtual cameras (video file), and virtual cameras (generated frames).
    """
    # ВИРТУАЛЬНАЯ КАМЕРА
    if cfg.video.source_type == "virtual":
        if cfg.video.virtual and cfg.video.virtual.video_file:
            # Попробовать сначала VirtualCameraSource с OpenCV (проще, не требует daemon)
            log.info(f"🎬 Attempting virtual camera with video file via OpenCV: {cfg.video.virtual.video_file}")
            try:
                virtual_source = VirtualCameraSource(camera_index, width, height, fps, video_file=cfg.video.virtual.video_file)
                await virtual_source.start()
                log.info(f"✅ Virtual camera with video file started successfully via OpenCV")
                return virtual_source
            except Exception as e:
                log.warning(
                    f"⚠️  VirtualCameraSource failed for video file, falling back to daemon: {e}",
                    extra={"event": {
                        "stage": "capture",
                        "action": "virtual_cv_fallback",
                        "video_file": cfg.video.virtual.video_file,
                        "error": str(e)
                    }}
                )
                # Fallback на daemon с GStreamer (лучшая поддержка форматов)
                try:
                    daemon_source = CameraSourceDaemon(camera_index, width, height, fps, video_file=cfg.video.virtual.video_file)
                    await daemon_source.start()
                    log.info(f"✅ Virtual camera daemon started successfully for camera {camera_index}")
                    return daemon_source
                except Exception as e2:
                    log.error(f"❌ Failed to start virtual camera daemon: {e2}")
                    raise RuntimeError(f"Failed to start virtual camera: OpenCV failed ({e}), daemon failed ({e2})")
        else:
            # Виртуальная камера с программной генерацией кадров
            log.info(f"🎨 Using virtual camera with generated frames for camera {camera_index}")
            virtual_source = VirtualCameraSource(camera_index, width, height, fps)
            await virtual_source.start()
            return virtual_source
    
    # ФИЗИЧЕСКИЕ КАМЕРЫ (существующая логика)
    plat = cfg.video.platform
    
    # If explicitly set to direct modes, use them
    if plat in ("rpi", "v4l2", "opencv"):
        log.info(f"📹 Using direct camera source: platform={plat}")
        source = CameraSource(camera_index, width, height, fps, platform=plat)
        await source.start()
        return source
    
    # Try daemon first (gstreamer, gst, daemon, or default)
    try:
        log.info(f"🎥 Attempting to use camera daemon for camera {camera_index}")
        daemon_source = CameraSourceDaemon(camera_index, width, height, fps)
        await daemon_source.start()
        log.info(f"✅ Camera daemon started successfully for camera {camera_index}")
        return daemon_source
    except Exception as e:
        log.warning(
            f"⚠️  Camera daemon failed for camera {camera_index}, falling back to direct capture: {e}",
            extra={"event": {
                "stage": "capture",
                "action": "daemon_fallback",
                "camera_id": camera_index,
                "error": str(e)
            }}
        )
        
        # Determine best fallback platform
        import platform as sys_platform
        system = sys_platform.system()
        
        if system == "Linux":
            # Try rpicam-vid first (Raspberry Pi), then v4l2
            if shutil.which("rpicam-vid"):
                fallback_platform = "rpi"
            else:
                fallback_platform = "v4l2"
        elif system == "Windows":
            fallback_platform = "opencv"
        elif system == "Darwin":  # macOS
            fallback_platform = "opencv"
        else:
            fallback_platform = "v4l2"
        
        log.info(f"Using fallback platform: {fallback_platform}")
        fallback_source = CameraSource(camera_index, width, height, fps, platform=fallback_platform)
        await fallback_source.start()
        return fallback_source
