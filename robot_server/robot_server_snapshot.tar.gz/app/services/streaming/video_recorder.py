# services/recorder.py
from __future__ import annotations
import subprocess, time, logging
from pathlib import Path
from threading import Event, Thread
from typing import Optional, List
import numpy as np
from .frame_aspect_utils import ensure_aspect_i420

log = logging.getLogger(__name__)

class CameraRecorder:
    """Records I420 frames from a CameraSource to MP4 via FFmpeg. Rolls segment on size change."""
    def __init__(self, source, path: Path, width: int, height: int, fps: int, segment_sec: Optional[int] = None):
        self._source=source; self._output_path=Path(path); self._width=width; self._height=height; self._fps=fps; self._segment_sec=segment_sec
        self._proc=None; self._worker_thread=None; self._stop_evt=Event(); self._recording=False
        self._current_segment=0; self._segment_start_time=0.0; self._output_files: List[Path]=[]
        self._output_path.parent.mkdir(parents=True, exist_ok=True)

    def _build_ffmpeg_cmd(self, output_file: Path, width: int, height: int) -> list[str]:
        gop = max(10, min(2*self._fps, 240))
        return [
            "ffmpeg","-hide_banner","-loglevel","warning",
            "-f","rawvideo","-pix_fmt","yuv420p","-s",f"{width}x{height}",
            "-r",str(self._fps),"-i","-",
            "-c:v","libx264","-preset","veryfast","-tune","zerolatency",
            "-g",str(gop),"-bf","0","-pix_fmt","yuv420p","-y",str(output_file)
        ]

    def _get_segment_path(self, seg:int)->Path:
        if self._segment_sec is None: return self._output_path
        p=self._output_path; return p.parent / f"{p.stem}_seg{seg:03d}{p.suffix}"

    async def start(self)->None:
        if self._recording: return
        self._recording=True; self._stop_evt.clear(); self._current_segment=0; self._segment_start_time=time.time(); self._output_files=[]
        self._worker_thread=Thread(target=self._recording_worker, name="CameraRecorder", daemon=True); self._worker_thread.start()

    def _recording_worker(self)->None:
        frames_written = 0
        no_frame_count = 0
        max_no_frames = self._fps * 2  # Максимум 2 секунды без кадров
        
        try:
            while self._recording and not self._stop_evt.is_set():
                out = self._get_segment_path(self._current_segment)
                first = self._source.get_frame_nowait()
                if first is None: 
                    no_frame_count += 1
                    if no_frame_count > max_no_frames:
                        log.warning(f"Recording stopped: no frames received for {max_no_frames} attempts (source may be dead)")
                        break
                    time.sleep(0.05); 
                    continue
                
                no_frame_count = 0  # Reset on success
                src_w,src_h = self._source.width, self._source.height
                buf, rec_w, rec_h = ensure_aspect_i420(first, src_w, src_h, *self._target_ratio(), self._aspect_mode())
                proc = subprocess.Popen(self._build_ffmpeg_cmd(out, rec_w, rec_h), stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
                log.info(f"Started recording segment {self._current_segment} to {out}")

                target_dt = 1.0/max(1,self._fps); next_t = time.time()
                segment_frames = 0
                
                while self._recording and not self._stop_evt.is_set():
                    # Check if ffmpeg process died
                    if proc.poll() is not None:
                        return_code = proc.returncode
                        stderr_output = ""
                        try:
                            if proc.stderr:
                                stderr_output = proc.stderr.read(1000).decode(errors="ignore")
                        except:
                            pass
                        log.error(f"FFmpeg process died with code {return_code}. stderr: {stderr_output[:200]}")
                        break
                    
                    if self._segment_sec and time.time() >= (self._segment_start_time + self._segment_sec): 
                        log.info(f"Segment {self._segment_sec}s timeout reached")
                        break
                    
                    now=time.time()
                    if now < next_t: time.sleep(min(0.002, next_t-now)); continue
                    
                    fr = self._source.get_frame_nowait()
                    if fr is None: 
                        no_frame_count += 1
                        if no_frame_count > max_no_frames:
                            log.warning(f"Recording stopped: no frames received for {max_no_frames} attempts in segment")
                            break
                        next_t += target_dt; 
                        continue
                    
                    no_frame_count = 0  # Reset on success
                    src_w,src_h = self._source.width, self._source.height
                    corr, cw, ch = ensure_aspect_i420(fr, src_w, src_h, *self._target_ratio(), self._aspect_mode())
                    if (cw,ch)!=(rec_w,rec_h):  # size changed → roll segment safely
                        log.info(f"Frame size changed, rolling segment")
                        break
                    try:
                        proc.stdin.write(corr.tobytes())
                        proc.stdin.flush()
                        frames_written += 1
                        segment_frames += 1
                    except (BrokenPipeError,OSError) as e:
                        log.error(f"Error writing to ffmpeg: {e}")
                        break
                    next_t += target_dt

                try:
                    if proc.stdin: proc.stdin.close()
                    proc.wait(timeout=5.0)
                    if proc.returncode==0: 
                        self._output_files.append(out)
                        log.info(f"Segment {self._current_segment} completed: {segment_frames} frames")
                    else:
                        log.warning(f"Segment {self._current_segment} failed with code {proc.returncode}")
                except Exception as e:
                    log.error(f"Error finalizing segment: {e}")
                    try: proc.kill()
                    except: pass

                # Continue to next segment if segment_sec is set, otherwise stop
                if self._segment_sec and self._recording and not self._stop_evt.is_set():
                    self._current_segment += 1; self._segment_start_time=time.time()
                else:
                    # No segment_sec means single file recording - stop after first segment
                    if not self._segment_sec:
                        log.info(f"Single file recording completed: {frames_written} frames")
                    break
        except Exception as e:
            log.error(f"Recording worker error: {e}", exc_info=True)
        finally:
            self._recording=False
            log.info(f"Recording worker stopped. Total frames: {frames_written}")

    async def stop(self, timeout: float = 10.0)->list[Path]:
        if not self._recording: return self._output_files
        # Finalize only our ffmpeg branch; never signal EOS to shared producers
        self._recording=False; self._stop_evt.set()
        if self._worker_thread and self._worker_thread.is_alive():
            import asyncio; loop=asyncio.get_running_loop()
            try: await loop.run_in_executor(None, self._worker_thread.join, timeout)
            except: pass
        self._worker_thread=None
        return self._output_files.copy()

    def is_recording(self)->bool:
        return self._recording and self._worker_thread is not None and self._worker_thread.is_alive()

    # injected by manager (no globals)
    def _aspect_mode(self)->str:
        return getattr(self, "_aspect_mode_val", "center_crop")
    def _target_ratio(self)->tuple[int,int]:
        return getattr(self, "_target_ratio_val", (0,0))
