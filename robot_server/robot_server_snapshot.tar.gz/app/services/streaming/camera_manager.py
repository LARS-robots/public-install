# services/video_manager.py
from __future__ import annotations
import asyncio, logging, time
from pathlib import Path
from typing import Optional, List
from zipfile import ZipFile, ZIP_STORED

import numpy as np

from ..system.config import AppConfig
from ..system.camera_discovery import DeviceRegistry
from .camera_sources import create_camera_source, CameraSource, CameraSourceDaemon
from .video_recorder import CameraRecorder
from .webrtc_service import WebRTCService

log = logging.getLogger(__name__)

class CameraManager:
    """
    Coordinates camera sources, recorders, and WebRTC tracks.
    
    KEY ARCHITECTURE CHANGE:
    - ONE shared source per camera (not separate for WebRTC/Recording)
    - WebRTC and Recording both read from the same source
    - Source lifecycle managed centrally here
    """

    def __init__(self, cfg: AppConfig, webrtc_service: Optional[WebRTCService] = None):
        self._cfg = cfg
        self._registry = DeviceRegistry()
        self._webrtc_service = webrtc_service
        
        # Single shared source (not a list)
        self._source: Optional[CameraSource | CameraSourceDaemon] = None
        self._source_camera_id: Optional[int] = None
        self._source_width: int = 0
        self._source_height: int = 0
        self._source_fps: int = 0
        
        self._recorders: List[CameraRecorder] = []
        self._current_session_id: Optional[str] = None
        self._last_files: List[Path] = []
        self._last_zip: Optional[Path] = None
        self._lock = asyncio.Lock()

    def set_webrtc_service(self, webrtc_service: WebRTCService) -> None:
        """Inject WebRTCService after initialization to avoid circular deps."""
        self._webrtc_service = webrtc_service

    # -------- Cameras --------
    def enumerate_cameras(self) -> List[int]:
        return self._registry.list_cameras(probe_open=False)

    # -------- Shared Source Management --------
    async def ensure_source(self, camera_id: int) -> CameraSource | CameraSourceDaemon:
        """
        Ensure camera source is running for the given camera.
        SHARED between WebRTC and Recording.
        """
        async with self._lock:
            # Determine resolution from config
            width, height = self._cfg.video.width, self._cfg.video.height
            if self._cfg.layout.stereo and camera_id in (0, 1):
                width = self._cfg.layout.stereo.width
                height = self._cfg.layout.stereo.height
            if self._cfg.layout.quad and camera_id in (0, 1, 2, 3):
                width = self._cfg.layout.quad.width
                height = self._cfg.layout.quad.height
            
            fps = self._cfg.video.fps
            
            # Reuse existing source if params match
            if (self._source 
                and self._source_camera_id == camera_id
                and self._source_width == width
                and self._source_height == height
                and self._source_fps == fps):
                log.info(f"✅ Reusing source: cam{camera_id} {width}x{height}@{fps}fps")
                return self._source
            
            # Stop old source if params changed
            if self._source:
                log.info(f"🔄 Restarting source due to param change")
                await self._source.stop()
                self._source = None
            
            # Create and start new source (with automatic daemon → direct fallback)
            log.info(f"🎥 Starting new source: cam{camera_id} {width}x{height}@{fps}fps")
            src = await create_camera_source(self._cfg, camera_id, width, height, fps)
            
            self._source = src
            self._source_camera_id = camera_id
            self._source_width = width
            self._source_height = height
            self._source_fps = fps
            
            return src

    async def release_source_if_idle(self) -> bool:
        """
        Stop source ONLY if no recorders AND no WebRTC tracks are using it.
        """
        async with self._lock:
            if not self._source:
                return False
            
            # Check if anyone is using the source
            has_recorders = len(self._recorders) > 0
            has_webrtc = (self._webrtc_service 
                         and self._webrtc_service.has_active_tracks_for_camera(self._source_camera_id))
            
            if has_recorders or has_webrtc:
                log.info(f"⏸️  Source still in use (recorders={has_recorders}, webrtc={has_webrtc})")
                return False
            
            # Safe to stop
            log.info(f"🛑 Stopping idle source: cam{self._source_camera_id}")
            await self._source.stop()
            self._source = None
            self._source_camera_id = None
            self._source_width = 0
            self._source_height = 0
            self._source_fps = 0
            return True

    # -------- Recording --------
    def is_recording(self) -> bool:
        return any(rec.is_recording() for rec in self._recorders)

    async def start_recording(
        self,
        session_id: Optional[str] = None,
        output_dir: Optional[Path] = None,
        segment_sec: Optional[int] = None,
    ) -> tuple[str, List[Path], List[int]]:
        """
        Start recording from ALL cameras.
        ✅ SHARES sources with WebRTC (doesn't create new ones).
        """
        if self.is_recording():
            raise RuntimeError("Recording already in progress")

        cams = self.enumerate_cameras()
        if not cams:
            raise RuntimeError("No cameras detected")

        self._recorders.clear()

        out_dir = Path(output_dir or self._cfg.recording.out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        sid = session_id or time.strftime("%Y%m%d_%H%M%S")
        started: List[int] = []
        out_files: List[Path] = []

        for cam_id in cams:
            # Get or create SHARED source
            src = await self.ensure_source(cam_id)
            
            output_path = out_dir / f"camera{cam_id}_{sid}.mp4"
            rec = CameraRecorder(
                src, 
                output_path, 
                src.width,  # Use actual source dimensions
                src.height, 
                src.fps, 
                segment_sec or self._cfg.recording.segment_sec
            )

            # Inject aspect preferences
            h, w, mode = self._resolve_aspect_for_layout(cam_id)
            setattr(rec, "_target_ratio_val", (h, w))
            setattr(rec, "_aspect_mode_val", mode)

            await rec.start()
            self._recorders.append(rec)
            started.append(cam_id)
            out_files.append(output_path)

        self._current_session_id = sid
        self._last_files = out_files
        
        log.info(
            "recording.start",
            extra={"event": {
                "stage": "recording",
                "action": "start_all_cameras",
                "cameras": started,
                "session_id": sid
            }}
        )
        
        return sid, out_files, started

    async def stop_recording(self) -> tuple[str, List[Path]]:
        """
        Stop all recorders.
        DOES NOT touch sources (WebRTC may still be using them).
        """
        if not self.is_recording():
            raise RuntimeError("No active recording")

        # 1) Stop recorders only
        stop_tasks = [rec.stop() for rec in self._recorders]
        results = await asyncio.gather(*stop_tasks, return_exceptions=True)
        files: List[Path] = []
        for r in results:
            if isinstance(r, list):
                files.extend(r)

        # 2) NEVER stop sources here - they're shared with WebRTC!
        self._recorders.clear()

        sid = self._current_session_id or "n/a"
        self._current_session_id = None
        self._last_files = files
        self._last_zip = None
        
        log.info(
            "recording.stop",
            extra={"event": {
                "stage": "recording",
                "action": "stop_complete",
                "session_id": sid,
                "files_count": len(files),
                "note": "sources kept alive for webrtc"
            }}
        )
        
        # 3) Try to cleanup idle sources (will check WebRTC status)
        await self.release_source_if_idle()
        
        return sid, files

    async def cleanup_dead_recorders(self) -> None:
        self._recorders = [r for r in self._recorders if r.is_recording()]

    # -------- Status --------
    def get_status(self) -> dict:
        return {
            "recording": self.is_recording(),
            "current_session_id": self._current_session_id,
            "last_files": [str(f) for f in self._last_files],
            "source_active": self._source is not None,
            "source_camera_id": self._source_camera_id,
            "active_recorders": len(self._recorders),
            "last_zip": str(self._last_zip) if self._last_zip else None,
        }

    # -------- Aspect helpers --------
    def _resolve_aspect_for_layout(self, cam_id: int) -> tuple[int, int, str]:
        a = self._cfg.aspect
        if self._cfg.layout.quad and cam_id in (0, 1, 2, 3):
            h, w = a.quad
        elif self._cfg.layout.stereo and cam_id in (0, 1):
            h, w = a.stereo_left
        else:
            h, w = a.mono
        return h, w, a.mode

    # -------- ZIP helpers --------
    def _recordings_root(self) -> Path:
        root = Path(self._cfg.recording.out_dir)
        root.mkdir(parents=True, exist_ok=True)
        return root

    def _zip_path(self, session_id: str) -> Path:
        return self._recordings_root() / f"record_{session_id}.zip"

    def build_zip(self, session_id: str, files: List[Path]) -> Path:
        zip_path = self._zip_path(session_id)
        ordered = sorted({Path(f) for f in files if Path(f).exists()}, key=lambda p: p.name)
        if not ordered:
            raise RuntimeError("No files to archive")

        with ZipFile(zip_path, "w", compression=ZIP_STORED) as zf:
            for file_path in ordered:
                zf.write(file_path, arcname=file_path.name)

        self._last_zip = zip_path
        return zip_path

    def get_zip_path(self, session_id: str) -> Optional[Path]:
        path = self._zip_path(session_id)
        if path.exists():
            return path
        return self._last_zip if self._last_zip and self._last_zip.exists() else None
