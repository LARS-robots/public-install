import logging
from typing import Literal, Tuple

import numpy as np

log = logging.getLogger(__name__)


def _jlog(tag: str, **kw):
    log.info(tag, extra={"event": {"tag": tag, **kw}})


def ensure_aspect_i420(
    buf: np.ndarray,
    src_w: int,
    src_h: int,
    target_h: int,
    target_w: int,
    mode: Literal["center_crop", "letterbox"] = "center_crop",
) -> Tuple[np.ndarray, int, int]:
    """
    Enforces a target aspect ratio on an I420 (YUV420p) buffer.

    Args:
        buf: Flat numpy array containing the I420 frame data.
        src_w: Source width.
        src_h: Source height.
        target_h: Target aspect ratio height component.
        target_w: Target aspect ratio width component.
        mode: 'center_crop' or 'letterbox'.

    Returns:
        A tuple of (new_buffer, new_width, new_height).
        The new buffer may be a view or a copy of the original.
    """
    if not (target_h > 0 and target_w > 0):
        return buf, src_w, src_h

    # Ensure source dimensions are even
    if src_w % 2 != 0 or src_h % 2 != 0:
        log.warning("aspect.skip_odd_dims", extra={"event": {"tag": "ASPECT_SKIP", "reason": "odd_dims", "w": src_w, "h": src_h}})
        return buf, src_w, src_h

    src_aspect = src_h / src_w
    target_aspect = target_h / target_w

    # Skip if aspect is already close enough
    if abs(src_aspect - target_aspect) / target_aspect < 0.01:
        return buf, src_w, src_h

    y_size = src_w * src_h
    uv_size = y_size // 4
    y = buf[:y_size].reshape(src_h, src_w)
    u = buf[y_size : y_size + uv_size].reshape(src_h // 2, src_w // 2)
    v = buf[y_size + uv_size :].reshape(src_h // 2, src_w // 2)

    dst_w, dst_h = src_w, src_h
    op_mode = "noop"
    px_change = 0

    if src_aspect > target_aspect:  # Source is taller/thinner than target -> crop/pad height
        if mode == "center_crop":
            op_mode = "crop_h"
            dst_h = int(src_w * target_aspect)
            dst_h -= dst_h % 2  # Ensure even
            if dst_h >= src_h: # Should not happen with this logic branch
                return buf, src_w, src_h
            
            crop_total = src_h - dst_h
            crop_top = crop_total // 2
            crop_top -= crop_top % 2 # Ensure even for UV plane
            
            y = y[crop_top : crop_top + dst_h, :]
            u = u[crop_top // 2 : crop_top // 2 + dst_h // 2, :]
            v = v[crop_top // 2 : crop_top // 2 + dst_h // 2, :]
            px_change = crop_total

        else:  # letterbox (pad width)
            op_mode = "pad_w"
            dst_w = int(src_h / target_aspect)
            dst_w -= dst_w % 2
            if dst_w <= src_w:
                return buf, src_w, src_h

            pad_total = dst_w - src_w
            pad_left = pad_total // 2
            pad_left -= pad_left % 2

            y_new = np.zeros((src_h, dst_w), dtype=np.uint8)
            u_new = np.full((src_h // 2, dst_w // 2), 128, dtype=np.uint8)
            v_new = np.full((src_h // 2, dst_w // 2), 128, dtype=np.uint8)

            y_new[:, pad_left : pad_left + src_w] = y
            u_new[:, pad_left // 2 : pad_left // 2 + src_w // 2] = u
            v_new[:, pad_left // 2 : pad_left // 2 + src_w // 2] = v
            y, u, v = y_new, u_new, v_new
            px_change = pad_total

    else:  # Source is wider/shorter than target -> crop/pad width
        if mode == "center_crop":
            op_mode = "crop_w"
            dst_w = int(src_h / target_aspect)
            dst_w -= dst_w % 2
            if dst_w >= src_w:
                return buf, src_w, src_h

            crop_total = src_w - dst_w
            crop_left = crop_total // 2
            crop_left -= crop_left % 2

            y = y[:, crop_left : crop_left + dst_w]
            u = u[:, crop_left // 2 : crop_left // 2 + dst_w // 2]
            v = v[:, crop_left // 2 : crop_left // 2 + dst_w // 2]
            px_change = crop_total

        else:  # letterbox (pad height)
            op_mode = "pad_h"
            dst_h = int(src_w * target_aspect)
            dst_h -= dst_h % 2
            if dst_h <= src_h:
                return buf, src_w, src_h

            pad_total = dst_h - src_h
            pad_top = pad_total // 2
            pad_top -= pad_top % 2

            y_new = np.zeros((dst_h, src_w), dtype=np.uint8)
            u_new = np.full((dst_h // 2, src_w // 2), 128, dtype=np.uint8)
            v_new = np.full((dst_h // 2, src_w // 2), 128, dtype=np.uint8)

            y_new[pad_top : pad_top + src_h, :] = y
            u_new[pad_top // 2 : pad_top // 2 + src_h // 2, :] = u
            v_new[pad_top // 2 : pad_top // 2 + src_h // 2, :] = v
            y, u, v = y_new, u_new, v_new
            px_change = pad_total

    _jlog("ASPECT", src_w=src_w, src_h=src_h, dst_w=dst_w, dst_h=dst_h, mode=op_mode, px=px_change)

    # Flatten planes into a single contiguous buffer
    return np.concatenate([y.ravel(), u.ravel(), v.ravel()]), dst_w, dst_h