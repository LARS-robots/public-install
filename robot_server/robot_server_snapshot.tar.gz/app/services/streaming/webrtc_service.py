import asyncio
import ipaddress
import logging
import shlex
import socket
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration
from aiortc.mediastreams import VideoStreamTrack
from av import VideoFrame

from .frame_aspect_utils import ensure_aspect_i420
from ..system.config import AppConfig
from .camera_sources import CameraSource, CameraSourceDaemon

log = logging.getLogger(__name__)


# -------- Network Utilities --------
class NetworkMode(Enum):
    LAN_ONLY = "lan_only"
    INTERNET_FALLBACK = "internet_fallback"


@dataclass
class NetworkInfo:
    mode: NetworkMode
    client_ip: str
    local_interface_ip: str
    allowed_ips: Set[str]
    ice_servers: List[Dict[str, Any]]



def _is_private_ip(ip_str: str) -> bool:
    _PRIVATE_RANGES = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
]
    try:
        ip_obj = ipaddress.ip_address(ip_str)
        return any(ip_obj in net for net in _PRIVATE_RANGES)
    except ValueError:
        return False


def _determine_network_mode(client_ip: str) -> NetworkMode:
    return NetworkMode.LAN_ONLY if _is_private_ip(client_ip) else NetworkMode.INTERNET_FALLBACK


def _local_ip_for_peer(peer_ip: str) -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect((peer_ip, 9))
            local_ip = sock.getsockname()[0]
            if local_ip.startswith(("172.17.", "172.18.")):
                return peer_ip
            ipaddress.ip_address(local_ip)
            return local_ip
    except Exception:
        return peer_ip


def _get_network_info(client_ip: str) -> NetworkInfo:
    mode = _determine_network_mode(client_ip)
    if client_ip in {"127.0.0.1", "::1", "::ffff:127.0.0.1", "localhost"}:
        return NetworkInfo(
            mode=mode,
            client_ip=client_ip,
            local_interface_ip="127.0.0.1",
            allowed_ips={"127.0.0.1"},
            ice_servers=[],
        )
    local_if = _local_ip_for_peer(client_ip)
    allowed = {local_if}
    if _is_private_ip(client_ip):
        allowed.add(client_ip)
    return NetworkInfo(
        mode=mode, client_ip=client_ip, local_interface_ip=local_if, allowed_ips=allowed, ice_servers=[]
    )


async def resolve_mdns_to_ipv4(hostname: str, timeout: float = 1.0, retries: int = 2) -> Optional[str]:
    """Resolve .local mDNS hostname to IPv4 address."""
    if not hostname.endswith(".local"):
        try:
            loop = asyncio.get_running_loop()
            infos = await loop.run_in_executor(
                None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM)
            )
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET:
                    return sa[0]
        except Exception:
            return None
        return None

    async def _try_getaddrinfo() -> Optional[str]:
        try:
            loop = asyncio.get_running_loop()
            infos = await asyncio.wait_for(
                loop.run_in_executor(
                    None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM)
                ),
                timeout=timeout,
            )
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET and _is_private_ip(sa[0]):
                    return sa[0]
        except Exception:
            return None
        return None

    async def _try_avahi() -> Optional[str]:
        cmd = f"avahi-resolve -n {shlex.quote(hostname)}"
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if proc.returncode == 0 and out:
                text = out.decode("utf-8", "ignore").strip()
                parts = text.split("\t")
                if len(parts) >= 2 and _is_private_ip(parts[-1].strip()):
                    return parts[-1].strip()
        except Exception:
            return None
        return None

    for _ in range(max(1, retries)):
        ip_val = await _try_getaddrinfo()
        if ip_val:
            return ip_val
        ip_val = await _try_avahi()
        if ip_val:
            return ip_val
        await asyncio.sleep(0.1)
    return None


async def _filter_sdp_for_lan_only(
    sdp: str, client_ip: str, server_ip: str, *, is_offer: bool = True
) -> Tuple[str, int]:
    """Filter SDP to keep only LAN candidates."""
    lines: List[str] = []
    kept = 0
    docker_prefixes = ("172.17.", "172.18.")

    for line in sdp.splitlines():
        if line.startswith("a=candidate:") and "typ host" in line:
            parts = line.split()
            if len(parts) < 5:
                continue
            cand_ip = parts[4]
            if any(cand_ip.startswith(pref) for pref in docker_prefixes):
                continue
            if cand_ip.endswith(".local"):
                resolved = await resolve_mdns_to_ipv4(cand_ip, timeout=1.0, retries=2)
                if resolved:
                    line = line.replace(cand_ip, resolved, 1)
                    cand_ip = resolved
                elif _is_private_ip(client_ip):
                    line = line.replace(cand_ip, client_ip, 1)
                    cand_ip = client_ip
                else:
                    continue
            if cand_ip in (server_ip, client_ip, "127.0.0.1") or _is_private_ip(cand_ip):
                lines.append(line)
                kept += 1
        elif line.startswith("c=IN "):
            lines.append(f"c=IN IP4 {server_ip}")
        else:
            lines.append(line)

    if not any(l.startswith("a=end-of-candidates") for l in lines):
        lines.append("a=end-of-candidates")

    return "\r\n".join(lines) + "\r\n", kept


# -------- Connection Monitoring --------
class ConnectionMonitor:
    """Tracks WebRTC peer connection lifecycle."""

    def __init__(self) -> None:
        self._info: Dict[RTCPeerConnection, Dict[str, Any]] = {}

    def add(self, pc: RTCPeerConnection, net: NetworkInfo) -> None:
        self._info[pc] = {
            "created_at": time.time(),
            "mode": net.mode.value,
            "client_ip": net.client_ip,
            "last": "new",
            "changes": [],
        }

    def update(self, pc: RTCPeerConnection, state: str) -> None:
        if pc not in self._info:
            return
        rec = self._info[pc]
        rec["changes"].append({"ts": time.time(), "to": state})
        rec["last"] = state

    def remove(self, pc: RTCPeerConnection) -> None:
        self._info.pop(pc, None)

    def stats(self) -> Dict[str, Any]:
        return {
            "active": len(self._info),
            "connections": [
                {
                    "mode": rec["mode"],
                    "client_ip": rec["client_ip"],
                    "state": rec["last"],
                    "age": time.time() - rec["created_at"],
                }
                for rec in self._info.values()
            ],
        }


# -------- Video Track --------
def _fps_from_samples(samples: List[float]) -> Optional[float]:
    if len(samples) < 5:
        return None
    recent = samples[-20:]
    if len(recent) < 3:
        return None
    median_dt = float(np.median(recent))
    mean_dt = float(np.mean(recent))
    dt = median_dt if abs(median_dt - mean_dt) / max(1e-6, mean_dt) < 0.2 else mean_dt
    if dt <= 0:
        return None
    return 1.0 / dt


class _SourceVideoTrack(VideoStreamTrack):
    """WebRTC video track that reads from camera source."""

    def __init__(
        self,
        source: CameraSource | CameraSourceDaemon,
        fps: int,
        aspect_ratio: Tuple[int, int],
        aspect_mode: str,
        overlay: bool = True,
    ) -> None:
        super().__init__()
        self._source = source
        self._fps = max(1, int(fps))
        self._frame_delay = 1.0 / float(self._fps)
        self._aspect_ratio = aspect_ratio
        self._aspect_mode = aspect_mode
        self._stopped = False
        self._black_cache: Optional[np.ndarray] = None
        self._overlay_enabled = overlay
        self._fps_samples: List[float] = []
        self._last_frame_time: float = 0.0

    async def recv(self) -> VideoFrame:
        pts, time_base = await self.next_timestamp()

        buffer = self._source.get_frame_nowait()
        width = self._source.width
        height = self._source.height

        if buffer is None:
            if self._black_cache is None or self._black_cache.shape != (height * 3 // 2, width):
                y = np.zeros(width * height, dtype=np.uint8)
                uv = np.full(width * height // 4, 128, dtype=np.uint8)
                self._black_cache = np.concatenate([y, uv, uv]).reshape(height * 3 // 2, width)
            buf_flat = self._black_cache.reshape(-1)
        else:
            buf = buffer
            if self._aspect_ratio[0] > 0 and self._aspect_ratio[1] > 0:
                buf, width, height = ensure_aspect_i420(
                    buf,
                    self._source.width,
                    self._source.height,
                    self._aspect_ratio[0],
                    self._aspect_ratio[1],
                    self._aspect_mode,
                )
            buf_flat = buf.reshape(-1)

        buf_with_overlay = self._draw_overlay_on_i420(buf_flat, width, height)
        frame_2d = buf_with_overlay.reshape(height * 3 // 2, width)

        await asyncio.sleep(self._frame_delay)

        frame = VideoFrame.from_ndarray(frame_2d, format="yuv420p")
        frame.pts, frame.time_base = pts, time_base
        return frame

    def stop(self) -> None:
        if not self._stopped:
            self._stopped = True
            super().stop()

    def set_overlay(self, enabled: bool) -> None:
        self._overlay_enabled = enabled

    def _draw_overlay_on_i420(self, frame_buf: np.ndarray, width: int, height: int) -> np.ndarray:
        if not self._overlay_enabled:
            return frame_buf
        try:
            from datetime import datetime
            import cv2

            w, h = width, height
            y_size = w * h
            frame_copy = frame_buf.copy()
            y_plane = frame_copy[:y_size].reshape(h, w)

            now = time.time()
            if self._last_frame_time > 0:
                self._fps_samples.append(now - self._last_frame_time)
                if len(self._fps_samples) > 50:
                    self._fps_samples.pop(0)
            self._last_frame_time = now

            fps = _fps_from_samples(self._fps_samples)
            fps_str = f"{fps:.1f}" if fps else "?"
            text = f"{datetime.now():%H:%M:%S} | cam{self._source.camera_index} | {fps_str} fps | {w}x{h}"

            mask = np.zeros((h, w), dtype=np.uint8)
            cv2.putText(mask, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2, cv2.LINE_AA)
            alpha = 0.6
            sel = mask > 0
            if np.any(sel):
                y_plane[sel] = np.clip((1 - alpha) * y_plane[sel] + alpha * 235, 0, 255).astype(np.uint8)
            return frame_copy
        except Exception as exc:
            log.warning("webrtc.overlay_error", extra={"event": {"error_message": str(exc)}})
            return frame_buf


# -------- WebRTC Service --------
class WebRTCService:
    """
    Service that manages WebRTC peer connections and video tracks.
    
    Responsibilities:
    - Peer connection lifecycle
    - Track management
    - SDP filtering for LAN-only
    - Connection monitoring
    - Coordinates with CameraManager for shared sources
    """

    def __init__(self, cfg: AppConfig, camera_manager: Optional["CameraManager"] = None) -> None:
        self._cfg = cfg
        self._camera_manager = camera_manager
        self._lock = asyncio.Lock()
        
        # Streaming state
        self._streaming_enabled: bool = False
        self._current_camera: Optional[int] = None
        self._stream_info: Dict[str, Any] = {}
        
        # Peer connections
        self._peer_connections: Set[RTCPeerConnection] = set()
        self._tracks: Dict[RTCPeerConnection, _SourceVideoTrack] = {}
        self._connection_monitor = ConnectionMonitor()

    def set_camera_manager(self, manager: "CameraManager") -> None:
        """Inject CameraManager after initialization to avoid circular deps."""
        self._camera_manager = manager

    # -------- Streaming Control --------
    async def start_stream(self, camera_id: Optional[int] = None) -> Dict[str, Any]:
        """Start streaming from camera."""
        async with self._lock:
            if self._streaming_enabled:
                return {"status": "already_started", **self._stream_info}
            
            if not self._camera_manager:
                raise RuntimeError("CameraManager not injected")
            
            target_cam = self._select_camera_id() if camera_id is None else int(camera_id)
            source = await self._camera_manager.ensure_source(target_cam)
            
            self._streaming_enabled = True
            self._current_camera = target_cam
            self._stream_info = {
                "camera_id": target_cam,
                "width": source.width,
                "height": source.height,
                "fps": source.fps,
                "source_active": True,
            }
            
            log.info(
                "webrtc.start",
                extra={"event": {"camera_id": target_cam, "width": source.width, "height": source.height, "fps": source.fps}},
            )
            
            return {"status": "started", **self._stream_info}

    async def stop_stream(self) -> Dict[str, Any]:
        """Stop streaming and close all peer connections."""
        async with self._lock:
            if not self._streaming_enabled:
                return {"status": "not_started"}
            
            # Close all peer connections
            for pc in list(self._peer_connections):
                await self._drop_peer(pc)
            
            self._streaming_enabled = False
            self._current_camera = None
            self._stream_info = {}
            
            log.info("webrtc.stop")
        
        # Auto-cleanup after stopping (outside lock to avoid deadlock)
        await self.cleanup()
        
        return {"status": "stopped"}

    async def switch_camera(self, camera_id: int) -> Dict[str, Any]:
        """Switch to different camera."""
        async with self._lock:
            if not self._streaming_enabled:
                raise RuntimeError("No active stream")
            
            if self._peer_connections:
                raise RuntimeError("Disconnect viewers before switching cameras")
            
            if not self._camera_manager:
                raise RuntimeError("CameraManager not injected")
            
            source = await self._camera_manager.ensure_source(camera_id)
            
            self._current_camera = camera_id
            self._stream_info = {
                "camera_id": camera_id,
                "width": source.width,
                "height": source.height,
                "fps": source.fps,
                "source_active": True,
            }
            
            log.info("webrtc.switch", extra={"event": {"camera_id": camera_id}})
            return {"status": "switched", **self._stream_info}

    # -------- Peer Connection Management --------
    async def create_peer_connection(self, client_ip: str, offer_sdp: str, offer_type: str) -> Dict[str, Any]:
        """
        Create WebRTC peer connection for client.
        
        Returns answer SDP and connection metadata.
        """
        if not self._streaming_enabled:
            raise RuntimeError("Stream not started")
        
        if not self._camera_manager:
            raise RuntimeError("CameraManager not injected")
        
        # Network setup
        server_ip = _local_ip_for_peer(client_ip)
        net = _get_network_info(client_ip)
        
        # Cleanup dead connections
        await self._cleanup_dead_peers()
        
        # Ensure source is ready
        await self._camera_manager.ensure_source(self._current_camera)
        
        # Filter offer SDP for LAN
        filtered_offer, kept_offer = await _filter_sdp_for_lan_only(offer_sdp, client_ip, server_ip, is_offer=True)
        
        # Create peer connection
        pc = RTCPeerConnection(configuration=RTCConfiguration(iceServers=net.ice_servers))
        self._peer_connections.add(pc)
        self._connection_monitor.add(pc, net)
        
        try:
            # Create video track
            track = await self._create_track()
            self._tracks[pc] = track
            
            # Setup event handlers
            @pc.on("connectionstatechange")
            async def _on_connection_state_change() -> None:
                st = pc.connectionState
                self._connection_monitor.update(pc, st)
                if st in {"failed", "closed"}:
                    await self._drop_peer(pc)

            @pc.on("iceconnectionstatechange")
            async def _on_ice_state_change() -> None:
                ice_state = pc.iceConnectionState
                if ice_state in {"failed", "closed", "disconnected"}:
                    self._connection_monitor.update(pc, f"ice:{ice_state}")
                    await self._drop_peer(pc)
            
            # Set remote description
            remote = RTCSessionDescription(sdp=filtered_offer, type=offer_type)
            await pc.setRemoteDescription(remote)
            pc.addTrack(track)
            
            # Create answer
            answer = await pc.createAnswer()
            filtered_answer, kept_answer = await _filter_sdp_for_lan_only(
                answer.sdp, client_ip, server_ip, is_offer=False
            )
            await pc.setLocalDescription(RTCSessionDescription(filtered_answer, answer.type))
            
            log.info(
                "webrtc.offer",
                extra={"event": {
                    "mode": net.mode.value,
                    "client_ip": client_ip,
                    "server_ip": server_ip,
                    "kept_offer": kept_offer,
                    "kept_answer": kept_answer,
                }},
            )
            
            local = pc.localDescription
            return {
                "type": local.type,
                "sdp": local.sdp,
                "mode": net.mode.value,
                "candidates": {"offer": kept_offer, "answer": kept_answer},
            }
            
        except Exception as exc:
            # Cleanup on error
            self._peer_connections.discard(pc)
            self._connection_monitor.remove(pc)
            await pc.close()
            raise

    async def _create_track(self) -> _SourceVideoTrack:
        """Create video track from current source."""
        if not self._camera_manager or not self._camera_manager._source:
            raise RuntimeError("No camera source active")
        
        source = self._camera_manager._source
        aspect_ratio, aspect_mode = self._resolve_aspect(source.camera_index)
        
        track = _SourceVideoTrack(
            source=source,
            fps=source.fps,
            aspect_ratio=aspect_ratio,
            aspect_mode=aspect_mode,
            overlay=True,
        )
        return track

    async def _drop_peer(self, pc: RTCPeerConnection) -> None:
        """Remove peer connection and cleanup resources."""
        track = self._tracks.pop(pc, None)
        if track is not None:
            track.stop()
        
        self._peer_connections.discard(pc)
        self._connection_monitor.remove(pc)
        
        try:
            await pc.close()
        except Exception:
            pass

    async def _cleanup_dead_peers(self) -> int:
        """Remove failed/closed connections."""
        removed = 0
        for pc in list(self._peer_connections):
            conn_state = getattr(pc, "connectionState", None)
            ice_state = getattr(pc, "iceConnectionState", None)
            if conn_state in {"failed", "closed"} or ice_state in {"failed", "closed", "disconnected"}:
                await self._drop_peer(pc)
                removed += 1
        return removed

    async def cleanup(self) -> Dict[str, Any]:
        """Cleanup dead connections and release idle sources."""
        removed = await self._cleanup_dead_peers()
        
        recording_active = False
        if self._camera_manager:
            recording_active = self._camera_manager.is_recording()
        
        released = False
        if not recording_active and self._camera_manager:
            released = await self._camera_manager.release_source_if_idle()
            if released:
                self._streaming_enabled = False
                self._current_camera = None
                self._stream_info = {}
        
        log.info(
            "webrtc.cleanup",
            extra={"event": {
                "removed": removed,
                "streaming": self._streaming_enabled,
                "released": released,
                "recording": recording_active,
            }},
        )
        
        return {
            "removed_connections": removed,
            "streaming_enabled": self._streaming_enabled,
            "source_released": released,
            "recording": recording_active,
        }

    # -------- Status --------
    def get_status(self) -> Dict[str, Any]:
        """Get current service status."""
        return {
            "streaming_enabled": self._streaming_enabled,
            "current_camera": self._current_camera,
            "active_connections": len(self._peer_connections),
            "connection_stats": self._connection_monitor.stats(),
            "stream_info": self._stream_info,
        }

    def is_streaming(self) -> bool:
        """Check if streaming is active."""
        return self._streaming_enabled

    def has_active_tracks(self) -> bool:
        """Check if there are any active tracks."""
        return bool(self._tracks)

    def has_active_tracks_for_camera(self, camera_id: int) -> bool:
        """Check if there are active tracks for specific camera."""
        if not self._camera_manager or not self._camera_manager._source:
            return False
        return self._camera_manager._source.camera_index == camera_id and bool(self._tracks)

    # -------- Network Info --------
    def get_network_info(self, client_ip: str) -> Dict[str, Any]:
        """Get network configuration for client."""
        net = _get_network_info(client_ip)
        return {
            "client_ip": net.client_ip,
            "mode": net.mode.value,
            "local_interface": net.local_interface_ip,
            "allowed_ips": list(net.allowed_ips),
            "ice_servers": net.ice_servers,
        }

    # -------- Config Helpers --------
    def _select_camera_id(self) -> int:
        stereo = self._cfg.layout.stereo
        if stereo and stereo.camera_index is not None:
            return int(stereo.camera_index)
        return 0

    def _resolve_aspect(self, cam_id: int) -> Tuple[Tuple[int, int], str]:
        a = self._cfg.aspect
        if self._cfg.layout.quad and cam_id in (0, 1, 2, 3):
            return a.quad, a.mode
        stereo = self._cfg.layout.stereo
        if stereo and stereo.camera_index == cam_id:
            return a.stereo_left, a.mode
        return a.mono, a.mode

    # -------- Shutdown --------
    async def shutdown(self) -> None:
        """Shutdown service and cleanup all resources."""
        for pc in list(self._peer_connections):
            await self._drop_peer(pc)
        log.info("webrtc.shutdown")