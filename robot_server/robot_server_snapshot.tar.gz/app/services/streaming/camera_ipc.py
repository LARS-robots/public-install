"""
Camera Daemon IPC Client
Communicates with the camera_daemon process via TCP sockets.
"""
import asyncio
import os
import json
import logging
import struct
from dataclasses import dataclass
from typing import AsyncGenerator, Optional, Tuple

log = logging.getLogger(__name__)

@dataclass(frozen=True)
class IPCConfig:
    """Configuration shared by control client and frame readers."""

    control_host: str = "camera-daemon"  # Имя сервиса в Docker сети
    control_port: int = 8765
    frame_base_port: int = 8800
    frame_header_fmt: str = ">IHHQB"
    fmt_i420: int = 1
    
    @classmethod
    def from_env(cls) -> "IPCConfig":
        """Create IPCConfig from environment variables with defaults."""
        return cls(
            control_host=os.getenv("CAMERA_DAEMON_HOST", "camera-daemon"),
            control_port=int(os.getenv("CONTROL_PORT", "8765")),
            frame_base_port=int(os.getenv("FRAME_BASE_PORT", "8800")),
            frame_header_fmt=os.getenv("FRAME_HEADER_FMT", ">IHHQB"),
            fmt_i420=int(os.getenv("FMT_I420", "1")),
        )

    @property
    def frame_header_size(self) -> int:
        return struct.calcsize(self.frame_header_fmt)

    def port_for_camera(self, cam_id: int) -> int:
        return self.frame_base_port + cam_id


class CameraDaemonClient:
    """Client for communicating with camera daemon control socket."""
    
    def __init__(self, config: Optional[IPCConfig] = None):
        self._config = config or IPCConfig.from_env()

    @property
    def config(self) -> IPCConfig:
        return self._config
    
    async def send_command(self, cmd: str, **params) -> dict:
        """Send a command to the daemon and return response."""
        try:
            reader, writer = await asyncio.open_connection(
                self._config.control_host, self._config.control_port
            )
            
            request = {"cmd": cmd, **params}
            request_line = json.dumps(request) + "\n"
            
            writer.write(request_line.encode())
            await writer.drain()
            
            response_line = await reader.readline()
            writer.close()
            await writer.wait_closed()
            
            if not response_line:
                return {"error": "no_response"}
            
            return json.loads(response_line.decode().strip())
        except Exception as e:
            log.error("Failed to send command to daemon: %s", e)
            return {"error": "connection_failed", "details": str(e)}
    
    async def start_camera(self, cam_id: int, width: int, height: int, fps: int, video_file: Optional[str] = None) -> dict:
        """Request daemon to start a camera (physical or virtual) with retry logic."""
        params = {"id": cam_id, "w": width, "h": height, "fps": fps}
        if video_file:
            params["video_file"] = video_file
        
        # Retry logic for daemon startup (handles cases when daemon is not ready yet)
        max_retries = 3
        retry_delay = 0.5
        
        for attempt in range(max_retries):
            result = await self.send_command("start", **params)
            if result.get("status") in ("started", "already_running"):
                return result
            if attempt < max_retries - 1:
                log.warning(
                    "Camera start attempt %d/%d failed for camera %d: %s, retrying...",
                    attempt + 1,
                    max_retries,
                    cam_id,
                    result,
                )
                await asyncio.sleep(retry_delay)
                retry_delay *= 2  # Exponential backoff
            else:
                log.error(
                    "Failed to start camera %d after %d attempts: %s",
                    cam_id,
                    max_retries,
                    result,
                )
        
        return result
    
    async def stop_camera(self, cam_id: int) -> dict:
        """Request daemon to stop a camera."""
        return await self.send_command("stop", id=cam_id)
    
    async def get_status(self) -> dict:
        """Get daemon status."""
        return await self.send_command("status")


class FrameReader:
    """Reads frames from camera daemon frame socket."""
    
    def __init__(self, cam_id: int, config: Optional[IPCConfig] = None):
        self.cam_id = cam_id
        self._config = config or IPCConfig.from_env()
        self.host = self._config.control_host
        self.port = self._config.port_for_camera(cam_id)
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
    
    async def connect(self) -> None:
        """Connect to the frame socket."""
        if self.reader is not None:
            return
        
        # Retry connection with exponential backoff
        max_retries = 5
        retry_delay = 0.1
        
        for attempt in range(max_retries):
            try:
                self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
                log.info("Connected to frame socket for camera %d on port %d", self.cam_id, self.port)
                return
            except Exception as e:
                if attempt < max_retries - 1:
                    log.debug("Connection attempt %d/%d failed for camera %d: %s, retrying...", 
                             attempt + 1, max_retries, self.cam_id, e)
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    log.error("Failed to connect to frame socket for camera %d after %d attempts: %s", 
                             self.cam_id, max_retries, e)
                    raise
    
    async def disconnect(self) -> None:
        """Disconnect from frame socket."""
        if self.writer:
            self.writer.close()
            await self.writer.wait_closed()
        self.reader = None
        self.writer = None
        log.info("Disconnected from frame socket for camera %d", self.cam_id)
    
    async def read_frames(self) -> AsyncGenerator[Tuple[int, int, int, int, bytes], None]:
        """
        Read frames from the socket.
        
        Yields:
            (width, height, pts_us, format, payload)
        """
        if self.reader is None:
            await self.connect()
        
        try:
            while True:
                # Read frame header
                header_bytes = await self.reader.readexactly(self._config.frame_header_size)
                length, width, height, pts_us, fmt = struct.unpack(
                    self._config.frame_header_fmt, header_bytes
                )
                
                # Read frame payload
                payload = await self.reader.readexactly(length)
                
                yield width, height, pts_us, fmt, payload
        except asyncio.IncompleteReadError:
            log.warning("Frame socket for camera %d closed", self.cam_id)
        except Exception as e:
            log.error("Error reading frames from camera %d: %s", self.cam_id, e)
        finally:
            await self.disconnect()


__all__ = ["IPCConfig", "CameraDaemonClient", "FrameReader"]
