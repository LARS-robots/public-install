"""
Unified robot service - single source of truth for robot state and operations.
Encapsulates motors, navigation, telemetry without global variables.
"""
from __future__ import annotations
from typing import Optional, Dict, Any, List
from pydantic import BaseModel

from ..system.config_loader import get_config
from ..navigation.route_service import RouteService, Waypoint


# Define SimulatorPose locally
class SimulatorPose(BaseModel):
    lat: float
    lon: float
    yaw: float
    timestamp: float


class RobotService:
    """
    Facade for all robot operations.
    Uses dependency injection - NO GLOBALS.
    """
    
    def __init__(self, app_state):
        """
        Initialize robot service with app state reference.
        
        Args:
            app_state: FastAPI app.state object (dependency injected)
        """
        self.app_state = app_state
        self.route_service = RouteService()
    
    def get_robot_type(self) -> str:
        """Get robot type from config"""
        try:
            config = get_config()
            return config.robot_type
        except Exception:
            return "simulator"  # Default fallback
    
    def init_simulator(self) -> bool:
        """Initialize simulator if needed"""
        # Simulator initialization now handled in motor_daemon
        return self.get_robot_type() == "simulator"
    
    def get_pose(self) -> Optional[SimulatorPose]:
        """
        Get current robot pose.
        Note: Pose data now comes from motor_daemon via NATS.
        Returns None until NATS subscription is implemented.
        """
        # TODO: Subscribe to NATS topic motors.telemetry.pose to get pose updates
        return None
    
    # ========== NAVIGATION API (route_service.py delegation) ==========
    
    def plan_route(self, start: Waypoint, goal: Waypoint) -> Dict[str, Any]:
        """
        Plan route with A* pathfinding.
        PRESERVES: /route/plan endpoint behavior
        """
        return self.route_service.plan_polyline(
            self.app_state, start, goal, None
        )
    
    def start_route(self, waypoints: List[Waypoint]) -> Dict[str, Any]:
        """
        Start following route.
        PRESERVES: /route POST endpoint behavior
        """
        state = self.route_service.start(self.app_state, waypoints)
        return {
            "ok": True,
            "count": len(state.path),
            "active": True
        }
    
    def get_route_status(self) -> Dict[str, Any]:
        """
        Get active route status.
        PRESERVES: /route GET endpoint behavior
        """
        state = self.route_service.get_state(self.app_state)
        if not state:
            return {"ok": True, "active": False, "path": [], "index": 0}
        
        return {
            "ok": True,
            "active": True,
            "index": state.path_idx,
            "path": [w.model_dump() for w in state.path]
        }
    
    def cancel_route(self) -> Dict[str, Any]:
        """
        Cancel active route.
        PRESERVES: /route/cancel endpoint behavior
        """
        canceled = self.route_service.cancel(self.app_state)
        return {"ok": True, "canceled": canceled}
    
    def tick_navigation(self) -> None:
        """
        Periodic navigation update (called by background task).
        Note: Navigation tick needs pose and command execution via NATS.
        Disabled until NATS integration is complete.
        """
        # TODO: Implement via NATS - subscribe to pose, publish commands
        # For now, disable navigation tick
        pass


# ========== DEPENDENCY INJECTION ==========

def get_robot_service(app_state) -> RobotService:
    """
    Factory function for dependency injection.
    Creates RobotService with app_state reference.
    
    Usage in routers:
        robot: RobotService = Depends(lambda req: get_robot_service(req.app.state))
    """
    # Check if already initialized (reuse singleton per app lifecycle)
    if not hasattr(app_state, '_robot_service'):
        app_state._robot_service = RobotService(app_state)
    return app_state._robot_service