"""
Unified robot service - single source of truth for robot state and operations.
Encapsulates motors, navigation, telemetry without global variables.
"""
from __future__ import annotations
from typing import Optional, Dict, Any, List
from pydantic import BaseModel

from .motor_service import MotorService, SimulatorPose
from ..navigation.route_service import RouteService, Waypoint


class RobotCommand(BaseModel):
    """Unified command structure"""
    throttle: Optional[float] = None
    steer: Optional[float] = None
    vx: Optional[float] = None
    wz: Optional[float] = None


class RobotService:
    """
    Facade for all robot operations.
    Uses dependency injection - NO GLOBALS.
    """
    
    def __init__(self, app_state):
        """
        Initialize robot service with app state reference.
        
        Args:
            app_state: FastAPI app.state object (dependency injected)
        """
        self.app_state = app_state
        self.motor_service = MotorService()
        self.route_service = RouteService()
        
        # Route service will auto-detect geojson path from config
    
    # ========== MOTION API (motors.py delegation) ==========
    
    def send_command(self, command: RobotCommand) -> Dict[str, Any]:
        """
        Execute motion command.
        PRESERVES: existing motion.py behavior
        """
        return self.motor_service.execute_joystick_command(
            app_state=self.app_state,
            throttle=command.throttle,
            steer=command.steer,
            vx=command.vx,
            wz=command.wz
        )
    
    def get_robot_type(self) -> str:
        """Get robot type (simulator/real)"""
        return self.motor_service.get_robot_type()
    
    def init_simulator(self) -> bool:
        """Initialize simulator if needed"""
        return self.motor_service.init_simulator_pose(self.app_state)
    
    def get_pose(self) -> Optional[SimulatorPose]:
        """
        Get current robot pose.
        PRESERVES: telemetry_router.py behavior
        """
        return self.motor_service.get_current_pose(self.app_state)
    
    # ========== NAVIGATION API (route_service.py delegation) ==========
    
    def plan_route(self, start: Waypoint, goal: Waypoint) -> Dict[str, Any]:
        """
        Plan route with A* pathfinding.
        PRESERVES: /route/plan endpoint behavior
        """
        return self.route_service.plan_polyline(
            self.app_state, start, goal, self.motor_service
        )
    
    def start_route(self, waypoints: List[Waypoint]) -> Dict[str, Any]:
        """
        Start following route.
        PRESERVES: /route POST endpoint behavior
        """
        state = self.route_service.start(self.app_state, waypoints)
        return {
            "ok": True,
            "count": len(state.path),
            "active": True
        }
    
    def get_route_status(self) -> Dict[str, Any]:
        """
        Get active route status.
        PRESERVES: /route GET endpoint behavior
        """
        state = self.route_service.get_state(self.app_state)
        if not state:
            return {"ok": True, "active": False, "path": [], "index": 0}
        
        return {
            "ok": True,
            "active": True,
            "index": state.path_idx,
            "path": [w.model_dump() for w in state.path]
        }
    
    def cancel_route(self) -> Dict[str, Any]:
        """
        Cancel active route.
        PRESERVES: /route/cancel endpoint behavior
        """
        canceled = self.route_service.cancel(self.app_state)
        return {"ok": True, "canceled": canceled}
    
    def tick_navigation(self) -> None:
        """
        Periodic navigation update (called by background task).
        PRESERVES: route_service.tick() behavior
        """
        self.route_service.tick(self.app_state, self.motor_service)


# ========== DEPENDENCY INJECTION ==========

def get_robot_service(app_state) -> RobotService:
    """
    Factory function for dependency injection.
    Creates RobotService with app_state reference.
    
    Usage in routers:
        robot: RobotService = Depends(lambda req: get_robot_service(req.app.state))
    """
    # Check if already initialized (reuse singleton per app lifecycle)
    if not hasattr(app_state, '_robot_service'):
        app_state._robot_service = RobotService(app_state)
    return app_state._robot_service