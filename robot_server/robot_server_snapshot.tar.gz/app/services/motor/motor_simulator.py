import logging
import time
import math
from typing import Dict, Any, Optional, Tuple
from .motor_iface import MotorIface

logger = logging.getLogger(__name__)

class SimulatorMotor(MotorIface):
    """
    Simulator motor driver with full physics integration.
    Maintains virtual pose (lat, lon, yaw) and integrates velocity commands.
    """
    name = "simulator"

    def __init__(self):
        self._connected = False
        self._pose: Optional[Dict[str, float]] = None
        self._motion_cfg: Optional[Dict[str, Any]] = None

    def connect(self, app_state) -> None:
        """Initialize simulator pose from config"""
        # Load config to get start_pose
        cfg = self._load_config_from_app_state(app_state)
        start_pose = cfg.get("start_pose", {})
        
        try:
            lat0 = float(start_pose.get("lat", 55.164441))
            lon0 = float(start_pose.get("lon", 61.436843))
            yaw0 = float(start_pose.get("yaw", 0.0))
        except (ValueError, TypeError):
            lat0, lon0, yaw0 = 55.164441, 61.436843, 0.0

        self._pose = {
            "lat": lat0,
            "lon": lon0,
            "yaw": yaw0,
            "t": time.time()
        }
        
        # Store motion config
        motion_section = cfg.get("motion", {})
        speed_mps = float(motion_section.get("speed_mps", 0.6))
        turn_speed_dps = float(motion_section.get("turn_speed_dps", 90.0))
        turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
        max_yaw_rate = turn_speed_dps * math.pi / 180.0
        orient_then_move = bool(motion_section.get("orient_then_move", True))
        dead_zone = float(motion_section.get("dead_zone", 0.12))
        dead_zone = max(0.0, min(0.4, dead_zone))
        
        self._motion_cfg = {
            "speed_mps": speed_mps,
            "max_yaw_rate": max_yaw_rate,
            "orient_then_move": orient_then_move,
            "dead_zone": dead_zone
        }
        
        self._connected = True
        
        logger.info("simulator.init", extra={"event": {
            "stage": "motion",
            "action": "simulator_init",
            "lat": lat0,
            "lon": lon0,
            "yaw": yaw0,
            "config": self._motion_cfg
        }})

    def _load_config_from_app_state(self, app_state) -> Dict[str, Any]:
        """Helper to load config using centralized config loader."""
        try:
            from ..system.config_loader import get_config
            app_config = get_config()
            return app_config.raw_data
        except Exception as e:
            logger.warning(f"Failed to load config: {e}")
            return {}

    def set_throttle(self, value: float) -> None:
        """Not used in simulator - uses command_velocity instead"""
        pass

    def set_steer(self, value: float) -> None:
        """Not used in simulator - uses command_velocity instead"""
        pass

    def command_velocity(self, vx: float, wz: float) -> None:
        """
        Integrate velocity command into simulated pose.
        
        Args:
            vx: Linear velocity in m/s
            wz: Angular velocity in rad/s
        """
        if not self._connected or self._pose is None:
            logger.warning("Simulator not initialized")
            return

        now = time.time()
        last_t = float(self._pose["t"])
        dt = max(0.0, min(0.2, now - last_t)) * 10  # clamp & scale

        # Update yaw
        current_yaw = float(self._pose["yaw"])
        new_yaw = self._normalize_angle(current_yaw + wz * dt)

        # Compute displacement in meters
        dx = vx * math.sin(new_yaw) * dt
        dy = vx * math.cos(new_yaw) * dt

        # Convert to lat/lon delta
        current_lat = float(self._pose["lat"])
        current_lon = float(self._pose["lon"])
        dlat, dlon = self._meters_to_latlon(current_lat, dx, dy)

        # Update pose
        new_lat = current_lat + dlat
        new_lon = current_lon + dlon

        self._pose["lat"] = new_lat
        self._pose["lon"] = new_lon
        self._pose["yaw"] = new_yaw
        self._pose["t"] = now

        logger.info("motion.command", extra={"event": {
            "stage": "motion",
            "action": "command",
            "effective": {"vx": float(vx), "wz": float(wz)},
            "physics": {"dt": dt, "dx": dx, "dy": dy},
            "pose": {"lat": new_lat, "lon": new_lon, "yaw": new_yaw}
        }})

    def get_pose(self) -> Optional[Dict[str, float]]:
        """Get current simulated pose"""
        return self._pose.copy() if self._pose else None

    def get_motion_config(self) -> Optional[Dict[str, Any]]:
        """Get motion configuration"""
        return self._motion_cfg.copy() if self._motion_cfg else None

    def stop(self) -> None:
        """Stop simulation (no-op, just log)"""
        logger.info("motor.stop", extra={"event": {
            "stage": "motion",
            "action": "stop",
            "driver": self.name
        }})

    def shutdown(self) -> None:
        """Shutdown simulator"""
        self._connected = False
        self._pose = None
        self._motion_cfg = None
        logger.info("motor.shutdown", extra={"event": {
            "stage": "motion",
            "action": "shutdown",
            "driver": self.name
        }})

    # Helper methods
    def _normalize_angle(self, angle: float) -> float:
        """Normalize angle to [-π, π]"""
        if angle > math.pi or angle < -math.pi:
            angle = (angle + math.pi) % (2.0 * math.pi) - math.pi
        return angle

    def _meters_to_latlon(self, lat_deg: float, dx_m: float, dy_m: float) -> Tuple[float, float]:
        """Convert meter displacement to lat/lon delta"""
        R = 6378137.0  # WGS84 Earth radius
        dlat = (dy_m / R) * (180.0 / math.pi)
        dlon = (dx_m / (R * math.cos(lat_deg * math.pi / 180.0))) * (180.0 / math.pi)
        return dlat, dlon