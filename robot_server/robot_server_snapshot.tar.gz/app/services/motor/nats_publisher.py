"""
NATS Publisher Service for Motor Commands.

Publishes motor commands to NATS subjects using NATS core.
Uses JSONL format (compact JSON, single line).
"""
import asyncio
import json
import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime

import nats
from nats.aio.client import Client as NATS

log = logging.getLogger(__name__)


class NATSPublisher:
    """Singleton NATS publisher for motor commands."""
    
    _instance: Optional['NATSPublisher'] = None
    _lock = asyncio.Lock()
    
    def __init__(self):
        self.nc: Optional[NATS] = None
        self._connected = False
        self._connection_lock = asyncio.Lock()
    
    @classmethod
    async def get_instance(cls) -> 'NATSPublisher':
        """Get singleton instance of NATS publisher."""
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    await cls._instance._connect()
        return cls._instance
    
    async def _connect(self):
        """Connect to NATS server."""
        if self._connected and self.nc and self.nc.is_connected:
            return
        
        async with self._connection_lock:
            # Double-check after acquiring lock
            if self._connected and self.nc and self.nc.is_connected:
                return
            
            nats_url = os.getenv("NATS_URL", "nats://nats:4222")
            
            # Normalize URL: replace 127.0.0.1/localhost with 'nats' in Docker
            nats_url = nats_url.strip().rstrip(':').rstrip()
            if os.path.exists("/app/src"):  # Check if running in Docker
                if "127.0.0.1" in nats_url:
                    nats_url = nats_url.replace("127.0.0.1", "nats")
                elif "localhost" in nats_url:
                    nats_url = nats_url.replace("localhost", "nats")
                nats_url = nats_url.strip().rstrip(':').rstrip()
            
            log.info(f"Connecting NATS publisher to {nats_url}")
            
            try:
                # Close existing connection if any
                if self.nc:
                    try:
                        await self.nc.close()
                    except Exception:
                        pass
                
                self.nc = await nats.connect(
                    nats_url,
                    reconnect_time_wait=2,
                    max_reconnect_attempts=-1,  # Infinite reconnects
                    connect_timeout=5,
                )
                self._connected = True
                log.info("NATS publisher connected")
            except Exception as e:
                self._connected = False
                log.error(f"Failed to connect NATS publisher: {e}")
                raise

    async def _publish(self, subject: str, cmd: str, args: Dict[str, Any]) -> None:
        """Core publish method - handles all common logic."""
        # Check connection health and reconnect if needed
        if not self._connected or not self.nc or not self.nc.is_connected:
            await self._connect()
        
        message = {
            "cmd": cmd,
            "args": args,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
        
        try:
            jsonl_data = json.dumps(message, separators=(',', ':'), ensure_ascii=False)
            await self.nc.publish(subject, jsonl_data.encode())
            log.debug(f"Published {cmd} to {subject}")
        except Exception as e:
            # Connection might be lost, reset flag and try to reconnect
            self._connected = False
            log.warning(f"Publish failed, attempting reconnect: {e}")
            try:
                await self._connect()
                # Retry publish after reconnection
                jsonl_data = json.dumps(message, separators=(',', ':'), ensure_ascii=False)
                await self.nc.publish(subject, jsonl_data.encode())
                log.debug(f"Published {cmd} to {subject} after reconnect")
            except Exception as retry_error:
                log.error(f"Failed to publish {cmd} to {subject} after reconnect: {retry_error}")
                raise
    
    async def publish_move(
        self,
        speed: Optional[int] = None,
        forward: Optional[int] = None,
        turn: Optional[int] = None
    ) -> None:
        """Publish move command to motors.move."""
        await self._publish(
            "motors.move",
            "move",
            {"speed": speed, "forward": forward, "turn": turn}
        )
    
    async def publish_stop(self) -> None:
        """Publish stop command to motors.stop."""
        await self._publish("motors.stop", "stop", {})
    
    async def publish_relay(self, relay_name: str, relay_on: bool = True) -> None:
        """Publish relay command to motors.relay."""
        await self._publish(
            "motors.relay",
            "relay",
            {"relay_name": relay_name, "relay_on": relay_on}
        )
    
    async def close(self):
        """Close NATS connection."""
        if self.nc:
            await self.nc.close()
            self._connected = False
            log.info("NATS publisher disconnected")


async def get_nats_publisher() -> NATSPublisher:
    """Get NATS publisher instance (for FastAPI dependency injection)."""
    return await NATSPublisher.get_instance()

