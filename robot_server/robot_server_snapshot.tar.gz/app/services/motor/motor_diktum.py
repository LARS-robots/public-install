# robot_server/app/services/motor_diktum.py
import logging
import struct
import time
from typing import Dict, Any, Optional
from pathlib import Path

from .motor_iface import MotorIface

log = logging.getLogger(__name__)

try:
    import tomllib as toml_reader   # py311+
except Exception:  # pragma: no cover
    import tomli as toml_reader     # py310 / backport

try:
    import serial  # pyserial
except Exception:  # pragma: no cover
    serial = None


class DiktumMotor(MotorIface):
    """
    Diktum motor driver with UART-based control.
    - No globals: serial handle & counters live in app.state or instance fields.
    - Reads parameters from config.toml ([diktum] & [motion]).
    """
    name = "diktum"

    def __init__(self):
        self._connected = False
        self._cfg: Dict[str, Any] = {}
        self._last_packet: Optional[bytes] = None
        self._seq: int = 0  # per-instance counter (NOT global)
        self._app_state = None # To hold app_state reference

    # ---------- config ----------
    def _load_config(self) -> Dict[str, Any]:
        """Load config using centralized config loader."""
        if self._cfg:
            return self._cfg
        try:
            from ..system.config_loader import get_config
            app_config = get_config()
            self._cfg = app_config.raw_data
            return self._cfg
        except Exception as e:
            log.warning(f"[diktum] failed to load config: {e}")
            self._cfg = {}
            return self._cfg

    def _cfg_diktum(self) -> Dict[str, Any]:
        return (self._load_config().get("diktum") or {})

    def _cfg_motion(self) -> Dict[str, Any]:
        return (self._load_config().get("motion") or {})

    def _control_index(self) -> int:
        dcfg = self._cfg_diktum()
        try:
            idx = int(dcfg.get("control_byte_index", 8))
        except Exception:
            idx = 8
        return max(0, min(25, idx))

    def _keep_mask(self) -> int:
        dcfg = self._cfg_diktum()
        m = dcfg.get("control_keep_mask", "0x3C")
        try:
            mask = int(m, 0) if isinstance(m, str) else int(m)
        except Exception:
            mask = 0x3C
        return mask & 0xFF

    def _relay_bits_cfg(self) -> Dict[str, int]:
        dcfg = self._cfg_diktum()
        default = {"permission": 5, "starter": 4, "speed2": 3, "sound": 2}
        rb = dcfg.get("relay_bits")
        if isinstance(rb, dict):
            try:
                return {str(k): int(v) for k, v in rb.items()}
            except Exception:
                return default
        return default

    # ---------- serial ----------
    def _ensure_serial(self, app_state):
        """
        Open and cache serial connection in app.state to avoid globals.
        """
        self._app_state = app_state # Keep a reference
        if getattr(app_state, "diktum_serial", None):
            return app_state.diktum_serial
        if serial is None:
            raise RuntimeError("pyserial is not installed. Install with: uv pip install pyserial")
        dcfg = self._cfg_diktum()
        device = dcfg.get("serial_device") or "/dev/ttyAMA0"
        baud = int(dcfg.get("baudrate", 115200))
        ser = serial.Serial(device, baud)
        app_state.diktum_serial = ser
        log.info("motor.connect", extra={"event": {
            "stage": "motion", "action": "serial_open",
            "driver": self.name, "device": device, "baud": baud
        }})
        return ser

    # ---------- helpers ----------
    @staticmethod
    def _hex_to_bytes(hex_str: str) -> bytearray:
        cleaned = "".join(hex_str.split())
        return bytearray.fromhex(cleaned)

    def _base_frame(self) -> bytearray:
        base_hex = (self._cfg_diktum().get("base_command") or "").strip()
        if not base_hex:
            raise ValueError("[diktum] base_command is missing in config.toml")
        pkt = self._hex_to_bytes(base_hex)
        if len(pkt) != 26 or pkt[-2:] != b"\x0D\x0A":
            raise ValueError("[diktum] base_command must be 26 bytes and end with 0D 0A")
        return pkt

    def _get_current_control(self, app_state) -> int:
        val = getattr(app_state, "diktum_control", None)
        if val is None:
            try:
                base = self._base_frame()
                idx = self._control_index()
                val = int(base[idx])
            except Exception:
                val = 0
            val &= self._keep_mask()
            setattr(app_state, "diktum_control", int(val))
        return int(val)

    def _set_current_control(self, app_state, control: int) -> None:
        setattr(app_state, "diktum_control", int(control & self._keep_mask()))

    def _pack_i16_le(self, value: int) -> bytes:
        return struct.pack("<h", int(value))

    def _clamp(self, x: float, lo: float, hi: float) -> float:
        return max(lo, min(x, hi))

    def _build_velocity_frame(self, app_state, vx_mps: float, wz_rad: float, speed_factor: float) -> bytearray:
        """
        Build the 26-byte Diktum frame.
        """
        pkt = self._base_frame()

        micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
        pkt[0:4] = struct.pack("<I", micros)

        self._seq = (self._seq + 1) & 0xFFFFFFFF
        pkt[4:8] = struct.pack("<I", self._seq)

        pkt[self._control_index()] = self._get_current_control(app_state) & 0xFF
        pkt[9] = 0x00

        mcfg = self._cfg_motion()
        max_vx = float(mcfg.get("speed_mps", 0.6))
        max_wz_dps = float(mcfg.get("turn_speed_dps", 90.0))
        max_wz_rad = max(10.0, min(360.0, max_wz_dps)) * 3.1415926535 / 180.0

        nx = 0.0 if max_vx <= 1e-6 else self._clamp(vx_mps / max_vx, -1.0, 1.0)
        nz = 0.0 if max_wz_rad <= 1e-6 else self._clamp(wz_rad / max_wz_rad, -1.0, 1.0)

        def to_joy(v: float) -> int:
            return int(round(self._clamp(v, -1.0, 1.0) * 2000))

        joy0 = to_joy(nx)
        joy1 = to_joy(nz)

        raw_speed = int(round(self._clamp(float(speed_factor), 0.0, 1.0) * 2000))
        if raw_speed <= 280:
            raw_speed = 0
        pkt[10:12] = self._pack_i16_le(raw_speed)

        pkt[12:14] = self._pack_i16_le(joy0)
        pkt[14:16] = self._pack_i16_le(joy1)
        for i in range(4):
            pkt[16 + i*2 : 18 + i*2] = b"\x00\x00"

        return pkt

    # ---------- MotorIface ----------
    def connect(self, app_state) -> None:
        self._load_config()
        self._ensure_serial(app_state)
        self._connected = True
        log.info("motor.connect", extra={"event": {"stage": "motion", "action": "connect", "driver": self.name}})

    def set_throttle(self, value: float) -> None:
        log.info("motor.throttle", extra={"event": {"stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)}})

    def set_steer(self, value: float) -> None:
        log.info("motor.steer", extra={"event": {"stage": "motion", "action": "steer", "driver": self.name, "value": float(value)}})

    def command_velocity(self, vx: float, wz: float) -> None:
        if not self._app_state:
            log.warning("Diktum driver not connected, cannot send velocity command.")
            return

        mcfg = self._cfg_motion()
        max_vx = float(mcfg.get("speed_mps", 0.6))
        speed_factor = 0.0 if max_vx <= 1e-6 else self._clamp(abs(vx) / max_vx, 0.0, 1.0)

        pkt = self._build_velocity_frame(app_state=self._app_state,
                                         vx_mps=vx, wz_rad=wz, speed_factor=speed_factor)

        n = self.write_packet(self._app_state, pkt)

        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity",
            "driver": self.name,
            "effective": {"vx": float(vx), "wz": float(wz)},
            "bytes": int(n),
            "frame": " ".join(f"{b:02X}" for b in pkt)
        }})

    def stop(self) -> None:
        log.info("motor.stop", extra={"event": {"stage": "motion", "action": "stop", "driver": self.name}})

    def shutdown(self) -> None:
        log.info("motor.shutdown", extra={"event": {"stage": "motion", "action": "shutdown", "driver": self.name}})

    # ---------- Relay control ----------
    def _base_control_from_config(self) -> int:
        try:
            pkt = self._base_frame()
            return int(pkt[self._control_index()])
        except Exception:
            return 0

    def set_relay(self, app_state, name: str, on: bool) -> Dict[str, Any]:
        if name == "stop":
            pkt = self._build_command_with_control("00")
            n = self.write_packet(app_state, pkt)
            self._set_current_control(app_state, 0)
            log.info("diktum.relay.stop", extra={"event": {
                "stage": "motion", "action": "relay_stop", "driver": self.name, "bytes": int(n)
            }})
            return {"ok": True, "driver": self.name, "relay": "stop", "on": False, "bytes_written": int(n)}

        rb = self._relay_bits_cfg()
        if name not in rb:
            raise ValueError(f"[diktum] unknown relay: {name}")
        bit = int(rb[name])

        current = self._get_current_control(app_state)
        new_val = (current | (1 << bit)) if on else (current & ~(1 << bit))
        new_val &= self._keep_mask()

        pkt = self._build_command_with_control(f"{new_val:02X}")
        n = self.write_packet(app_state, pkt)
        self._set_current_control(app_state, new_val)

        log.info("diktum.relay", extra={"event": {
            "stage": "motion", "action": "relay_write", "driver": self.name,
            "relay": name, "on": bool(on), "control_hex": f"{new_val:02X}", "bytes": int(n)
        }})
        return {"ok": True, "driver": self.name, "relay": name, "on": bool(on), "bytes_written": int(n)}

    # ---------- low-level write & cache ----------
    def _build_command_with_control(self, control_hex: str) -> bytearray:
        pkt = self._base_frame()
        idx = self._control_index()
        try:
            pkt[idx] = int(control_hex, 16) & 0xFF
        except Exception:
            raise ValueError(f"[diktum] invalid control hex: {control_hex}")
        return pkt

    def write_packet(self, app_state, packet: bytes | bytearray) -> int:
        ser = self._ensure_serial(app_state)
        data = bytes(packet)
        n = ser.write(data)
        self._last_packet = data
        return int(n)

    def get_last_packet(self) -> Optional[bytes]:
        return self._last_packet

    # ---------- public helpers for MotorService ----------
    def send_permission(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "permission")

    def send_starter(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "starter")

    def send_stop(self, app_state) -> Dict[str, Any]:
        return self._send_named_control(app_state, "stop")

    def _send_named_control(self, app_state, name: str) -> Dict[str, Any]:
        mapping: Dict[str, str] = (self._cfg_diktum().get("command_bytes") or {})
        if name not in mapping:
            raise ValueError(f"[diktum] command_bytes.{name} is missing in config.toml")
        control_hex = mapping[name]
        pkt = self._build_command_with_control(control_hex)
        n = self.write_packet(app_state, pkt)
        self._set_current_control(app_state, int(control_hex, 16))
        log.info("diktum.control", extra={"event": {
            "stage": "motion", "action": "uart_write", "driver": self.name,
            "command": name, "control_hex": control_hex, "bytes": int(n)
        }})
        return {"ok": True, "driver": self.name, "command": name, "bytes_written": int(n)}
