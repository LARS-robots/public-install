from __future__ import annotations
from typing import Protocol, Optional, runtime_checkable

@runtime_checkable
class MotorIface(Protocol):
    """
    Minimal interface all motor drivers must implement.
    Values:
      - throttle, steer in [-1.0, 1.0]
      - vx (m/s), wz (rad/s)
    """

    name: str

    def connect(self, app_state) -> None: ...
    def set_throttle(self, value: float) -> None: ...
    def set_steer(self, value: float) -> None: ...
    def command_velocity(self, vx: float, wz: float) -> None: ...
    def stop(self) -> None: ...
    def shutdown(self) -> None: ...
