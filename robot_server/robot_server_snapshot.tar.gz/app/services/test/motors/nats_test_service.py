# robot/services/api/src/app/services/test/motors/nats_test_service.py
"""
NATS-based test service for Diktum robot movement tests.
Sends commands via NATS instead of direct serial access.
"""
import logging
from typing import Dict, Any, Optional

from ...motor.nats_publisher import NATSPublisher, get_nats_publisher

log = logging.getLogger(__name__)


class DiktumNatsTestService:
    """
    Service for testing Diktum motor controls via NATS commands.
    Handles sequence start and stop commands.
    No global variables - all state stored in instance attributes.
    """
    
    def __init__(self):
        """Initialize test service."""
        self._publisher: Optional[NATSPublisher] = None
    
    async def _get_publisher(self) -> NATSPublisher:
        """Get NATS publisher instance."""
        if self._publisher is None:
            self._publisher = await get_nats_publisher()
        return self._publisher
    
    async def _publish(self, subject: str, cmd: str, args: Dict[str, Any]) -> None:
        """Publish NATS message using NATSPublisher."""
        publisher = await self._get_publisher()
        await publisher._publish(subject, cmd, args)
    
    async def publish_start_sequence(self, sequence_id: str) -> Dict[str, Any]:
        """
        Publish start sequence command to motors.start_sequence.
        
        Args:
            sequence_id: Sequence identifier (e.g., "forward_backward", "turn_180")
            
        Returns:
            Result dictionary with status
        """
        try:
            await self._publish(
                "motors.start_sequence",
                "start_sequence",
                {"sequence_id": sequence_id}
            )
            log.info(f"Published start_sequence command: {sequence_id}")
            return {
                "ok": True,
                "message": f"Start sequence '{sequence_id}' command published via NATS",
                "sequence_id": sequence_id
            }
        except Exception as e:
            log.error(f"Failed to publish start_sequence: {e}", exc_info=True)
            return {
                "ok": False,
                "error": str(e)
            }
    
    async def publish_stop(self) -> Dict[str, Any]:
        """
        Publish stop command to motors.stop.
        
        Returns:
            Result dictionary with status
        """
        try:
            await self._publish("motors.stop", "stop", {})
            log.info("Published stop command")
            return {
                "ok": True,
                "message": "Stop command published via NATS"
            }
        except Exception as e:
            log.error(f"Failed to publish stop: {e}", exc_info=True)
            return {
                "ok": False,
                "error": str(e)
            }
    
    async def publish_start_sequence_forward(self) -> Dict[str, Any]:
        """Publish start sequence forward command to motors.start_sequence."""
        return await self.publish_start_sequence("forward_backward")
    
    async def publish_start_sequence_turn_180(self) -> Dict[str, Any]:
        """Publish start sequence turn 180 command to motors.start_sequence."""
        return await self.publish_start_sequence("turn_180")
    
    async def test_forward(self) -> Dict[str, Any]:
        """
        Test forward movement.
        
        Returns:
            Result dictionary with status
        """
        return await self.publish_start_sequence_forward()
    
    async def test_turn_180(self) -> Dict[str, Any]:
        """
        Test 180° clockwise turn.
        
        Returns:
            Result dictionary with status
        """
        return await self.publish_start_sequence_turn_180()


async def get_diktum_nats_test_service() -> DiktumNatsTestService:
    """
    Factory function for getting DiktumNatsTestService instance.
    
    Returns:
        DiktumNatsTestService instance
    """
    return DiktumNatsTestService()

