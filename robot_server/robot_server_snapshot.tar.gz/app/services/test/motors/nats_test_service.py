# robot/services/api/src/app/services/test/motors/nats_test_service.py
"""
NATS-based test service for Diktum robot movement tests.
Sends commands via NATS instead of direct serial access.
"""
import asyncio
import logging
from typing import Dict, Any, Optional

from ...motor.nats_publisher import NATSPublisher, get_nats_publisher
from ....config_loader import get_config

log = logging.getLogger(__name__)


class DiktumNatsTestService:
    """
    Service for testing Diktum motor controls via NATS commands.
    Handles automatic engine startup and movement commands.
    No global variables - all state stored in instance attributes.
    """
    
    def __init__(self):
        """Initialize test service."""
        self._publisher: Optional[NATSPublisher] = None
        self._config: Optional[Dict[str, Any]] = None
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from config.toml."""
        if self._config is not None:
            return self._config
        
        try:
            app_config = get_config()
            self._config = app_config.raw_data
            return self._config
        except Exception as e:
            log.warning(f"Failed to load config: {e}, using defaults")
            self._config = {}
            return self._config
    
    def _get_test_speed_mps(self) -> float:
        """Get test speed in m/s from config."""
        diktum_test = self._load_config().get("diktum_test", {})
        return float(diktum_test.get("diktum_test_speed_mps", 1.0))
    
    def _get_conversion_constant(self) -> float:
        """Get conversion constant from config."""
        diktum_test = self._load_config().get("diktum_test", {})
        return float(diktum_test.get("diktum_test_conversion_constant", 1000.0))
    
    def _convert_mps_to_diktum_units(self, speed_mps: float) -> int:
        """
        Convert speed from m/s to Diktum speed units.
        
        Args:
            speed_mps: Speed in meters per second
            
        Returns:
            Diktum speed units (0-2000), with dead zone applied
        """
        constant = self._get_conversion_constant()
        diktum_speed = int(speed_mps * constant)
        
        # Clamp to valid range
        diktum_speed = max(0, min(2000, diktum_speed))
        
        # Apply dead zone: values 0-280 are forced to 0
        if diktum_speed <= 280:
            diktum_speed = 0
        
        return diktum_speed
    
    async def _get_publisher(self) -> NATSPublisher:
        """Get NATS publisher instance."""
        if self._publisher is None:
            self._publisher = await get_nats_publisher()
        return self._publisher
    
    async def ensure_permission_enabled(self) -> bool:
        """
        Ensure permission relay is enabled.
        This is idempotent - safe to call multiple times.
        
        Returns:
            True if permission is enabled (or was enabled), False on error
        """
        try:
            publisher = await self._get_publisher()
            await publisher.publish_relay("permission", True)
            log.info("Published permission relay ON command")
            return True
        except Exception as e:
            log.error(f"Failed to enable permission relay: {e}")
            return False
    
    async def start_engine_sequence(self) -> Dict[str, Any]:
        """
        Start engine sequence: permission → wait → starter → warm-up → starter off → wait.
        
        Returns:
            Result dictionary with status
        """
        try:
            publisher = await self._get_publisher()
            
            # Step 1: Enable permission
            log.info("Step 1: Enabling permission relay...")
            await publisher.publish_relay("permission", True)
            await asyncio.sleep(0.5)  # Brief pause for command processing
            
            # Step 2: Wait 2 seconds (startup requirement)
            log.info("Step 2: Waiting 2 seconds (startup requirement)...")
            await asyncio.sleep(2.0)
            
            # Step 3: Enable starter
            log.info("Step 3: Enabling starter relay...")
            await publisher.publish_relay("starter", True)
            await asyncio.sleep(0.5)
            
            # Step 4: Wait 3.5 seconds (engine warm-up)
            log.info("Step 4: Engine warm-up (3.5 seconds)...")
            await asyncio.sleep(3.5)
            
            # Step 5: Disable starter (keep permission on)
            log.info("Step 5: Disabling starter relay (keeping permission ON)...")
            await publisher.publish_relay("starter", False)
            await asyncio.sleep(0.5)
            
            # Step 6: Wait 2 seconds (stabilization)
            log.info("Step 6: Stabilization (2 seconds)...")
            await asyncio.sleep(2.0)
            
            log.info("Engine startup sequence completed")
            return {
                "ok": True,
                "message": "Engine startup sequence completed"
            }
            
        except Exception as e:
            log.error(f"Engine startup sequence failed: {e}", exc_info=True)
            return {
                "ok": False,
                "error": str(e)
            }
    
    async def ensure_engine_ready(self) -> Dict[str, Any]:
        """
        Ensure engine is ready (permission enabled, engine started if needed).
        This automatically starts the engine sequence if permission is not enabled.
        
        Returns:
            Result dictionary with status
        """
        # Try to enable permission (idempotent)
        permission_ok = await self.ensure_permission_enabled()
        if not permission_ok:
            return {
                "ok": False,
                "error": "Failed to enable permission relay"
            }
        
        # Start full engine sequence (idempotent - safe to call multiple times)
        # The sequence will handle the timing and relay control
        startup_result = await self.start_engine_sequence()
        return startup_result
    
    async def send_move_command(
        self,
        speed_mps: Optional[float] = None,
        forward_mps: Optional[float] = None,
        turn_mps: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Send move command via NATS.
        
        Args:
            speed_mps: Speed in m/s (if None, uses config default)
            forward_mps: Forward/backward speed in m/s (if None, uses config default)
            turn_mps: Turn speed in m/s (if None, uses config default, negative = clockwise)
            
        Returns:
            Result dictionary with status and converted values
        """
        try:
            # Get speeds from config if not provided
            if speed_mps is None:
                speed_mps = self._get_test_speed_mps()
            if forward_mps is None:
                forward_mps = self._get_test_speed_mps()
            if turn_mps is None:
                turn_mps = 0.0
            
            # Convert to Diktum units
            diktum_speed = self._convert_mps_to_diktum_units(speed_mps)
            diktum_forward = self._convert_mps_to_diktum_units(abs(forward_mps))
            if forward_mps < 0:
                diktum_forward = -diktum_forward
            
            diktum_turn = self._convert_mps_to_diktum_units(abs(turn_mps))
            if turn_mps < 0:
                diktum_turn = -diktum_turn
            
            # Send command via NATS
            publisher = await self._get_publisher()
            await publisher.publish_move(
                speed=diktum_speed,
                forward=diktum_forward,
                turn=diktum_turn
            )
            
            log.info(f"Published move command: speed={diktum_speed} (from {speed_mps} m/s), "
                    f"forward={diktum_forward} (from {forward_mps} m/s), "
                    f"turn={diktum_turn} (from {turn_mps} m/s)")
            
            return {
                "ok": True,
                "message": "Move command sent via NATS",
                "speed_mps": speed_mps,
                "forward_mps": forward_mps,
                "turn_mps": turn_mps,
                "diktum_speed": diktum_speed,
                "diktum_forward": diktum_forward,
                "diktum_turn": diktum_turn
            }
            
        except Exception as e:
            log.error(f"Failed to send move command: {e}", exc_info=True)
            return {
                "ok": False,
                "error": str(e)
            }
    
    async def test_forward(self) -> Dict[str, Any]:
        """
        Test forward movement.
        Automatically starts engine if needed, then sends forward command.
        
        Returns:
            Result dictionary with status
        """
        # Ensure engine is ready
        engine_result = await self.ensure_engine_ready()
        if not engine_result.get("ok"):
            return engine_result
        
        # Get speed from config
        speed_mps = self._get_test_speed_mps()
        
        # Send forward command
        return await self.send_move_command(
            speed_mps=speed_mps,
            forward_mps=speed_mps,
            turn_mps=0.0
        )
    
    async def test_turn_180(self) -> Dict[str, Any]:
        """
        Test 180° clockwise turn.
        Automatically starts engine if needed, then sends turn command.
        
        Returns:
            Result dictionary with status
        """
        # Ensure engine is ready
        engine_result = await self.ensure_engine_ready()
        if not engine_result.get("ok"):
            return engine_result
        
        # Get speed from config
        speed_mps = self._get_test_speed_mps()
        
        # Send turn command (negative = clockwise/right)
        return await self.send_move_command(
            speed_mps=speed_mps,
            forward_mps=0.0,
            turn_mps=-speed_mps  # Negative = clockwise
        )


async def get_diktum_nats_test_service() -> DiktumNatsTestService:
    """
    Factory function for getting DiktumNatsTestService instance.
    
    Returns:
        DiktumNatsTestService instance
    """
    return DiktumNatsTestService()

