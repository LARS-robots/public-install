# Test motor services
from .nats_test_service import (
    DiktumNatsTestService,
    get_diktum_nats_test_service
)

