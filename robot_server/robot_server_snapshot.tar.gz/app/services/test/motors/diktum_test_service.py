# robot/services/api/src/app/services/test/motors/diktum_test_service.py
"""
Diktum motor test service for manual testing of speed and joystick controls.
Manages timed command loops without global variables.
"""
import logging
import threading
import time
from typing import Optional, Dict, Any

from .diktum_packets import (
    build_frame,
    build_control_frame,
    write_frame_to_uart,
    open_serial_connection,
    _get_relay_bits,
    _get_keep_mask,
    _get_control_index,
    _get_base_frame
)

log = logging.getLogger(__name__)


class DiktumTestService:
    """
    Service for testing Diktum motor controls with timed command loops.
    No global variables - all state stored in instance attributes.
    """
    
    def __init__(self):
        """Initialize test service with no active operations."""
        self._lock = threading.Lock()
        self._active_thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._serial: Optional[Any] = None  # pyserial.Serial object
        self._last_frame: Optional[bytes] = None
        self._current_control: Optional[int] = None  # Track current control byte state
    
    def _ensure_serial(self):
        """Open serial connection if not already open."""
        with self._lock:
            if self._serial is None or not self._serial.is_open:
                self._serial = open_serial_connection()
            return self._serial
    
    def _close_serial(self):
        """Close serial connection."""
        with self._lock:
            if self._serial is not None:
                try:
                    if self._serial.is_open:
                        self._serial.close()
                except Exception as e:
                    log.warning(f"Error closing serial: {e}")
                finally:
                    self._serial = None
    
    def _stop_active_operation(self):
        """Stop any currently running test operation."""
        with self._lock:
            if self._active_thread is not None and self._active_thread.is_alive():
                self._stop_flag.set()
                self._active_thread.join(timeout=2.0)
                self._active_thread = None
            self._stop_flag.clear()
    
    def _get_current_control(self) -> int:
        """Get current control byte value."""
        if self._current_control is None:
            try:
                base = _get_base_frame()
                idx = _get_control_index()
                keep_mask = _get_keep_mask()
                val = int(base[idx]) & keep_mask
                self._current_control = val
            except Exception:
                self._current_control = 0
        return int(self._current_control)
    
    def _set_current_control(self, control: int) -> None:
        """Set current control byte value."""
        keep_mask = _get_keep_mask()
        self._current_control = int(control & keep_mask)
    
    def _validate_movement_params(self, speed: int, forward: int, turn: int) -> Optional[Dict[str, Any]]:
        """Validate movement parameters. Returns error dict if invalid, None if valid."""
        if speed < 0 or speed > 2000:
            return {"ok": False, "error": f"Speed value must be between 0 and 2000, got {speed}"}
        if forward < -2000 or forward > 2000:
            return {"ok": False, "error": f"Forward value must be between -2000 and 2000, got {forward}"}
        if turn < -2000 or turn > 2000:
            return {"ok": False, "error": f"Turn value must be between -2000 and 2000, got {turn}"}
        return None
    
    def _set_relay_bit(self, relay_name: str, on: bool) -> Dict[str, Any]:
        """Set a single relay bit and send frame. Returns result dict."""
        ser = self._ensure_serial()
        relay_bits = _get_relay_bits()
        if relay_name not in relay_bits:
            return {"ok": False, "error": f"Unknown relay: {relay_name}"}
        
        bit = int(relay_bits[relay_name])
        current = self._get_current_control()
        new_val = (current | (1 << bit)) if on else (current & ~(1 << bit))
        new_val &= _get_keep_mask()
        
        frame = build_control_frame(new_val)
        n = write_frame_to_uart(ser, frame)
        self._set_current_control(new_val)
        
        with self._lock:
            self._last_frame = bytes(frame)
        
        # Log relay frame
        log.info("diktum_test.relay_frame", extra={"event": {
            "stage": "test",
            "action": "relay_frame_written",
            "relay": relay_name,
            "on": on,
            "control_hex": f"{new_val:02X}",
            "frame_hex": " ".join(f"{b:02X}" for b in frame),
            "bytes": int(n)
        }})
        
        return {"ok": True, "control_hex": f"{new_val:02X}", "bytes": int(n)}
    
    def set_relay(self, name: str, on: bool) -> Dict[str, Any]:
        """
        Set relay on or off by name. Simple on/off control for manual testing.
        
        Args:
            name: Relay name ("permission", "starter", "speed2", "sound", or "stop")
            on: True to turn on, False to turn off (ignored for "stop")
        
        Returns:
            Result dictionary with status and details
        """
        # Handle "stop" - turns off all relays
        if name == "stop":
            try:
                ser = self._ensure_serial()
                frame = build_control_frame(0x00)
                n = write_frame_to_uart(ser, frame)
                self._set_current_control(0)
                with self._lock:
                    self._last_frame = bytes(frame)
                return {"ok": True, "relay": "stop", "on": False, "bytes_written": int(n)}
            except Exception as e:
                return {"ok": False, "error": f"Failed to stop: {e}"}
        
        # Regular relay control (error handling in _set_relay_bit)
        result = self._set_relay_bit(name, on)
        if not result.get("ok"):
            return result
        
        return {
            "ok": True,
            "relay": name,
            "on": bool(on),
            "control_hex": result.get("control_hex"),
            "bytes_written": result.get("bytes", 0)
        }
    
    def send_command(self, speed: int, forward: int, turn: int) -> Dict[str, Any]:
        """
        Execute complete test sequence with permission and starter control in movement loop.
        
        Sequence:
        - Permission ON → starter ON + movement (2s) → starter OFF + movement (3s) → everything OFF
        
        Args:
            speed: Speed value from 0 to 2000
            forward: Forward/backward value from -2000 to 2000 (+ = forward)
            turn: Turn value from -2000 to 2000 (+ = left)
        
        Returns:
            Result dictionary with status and details
        """
        # Stop any active operation
        self._stop_active_operation()
        
        # Validate inputs
        validation_error = self._validate_movement_params(speed, forward, turn)
        if validation_error:
            return validation_error
        
        # Start new operation
        self._stop_flag.clear()
        
        def _full_sequence():
            """Execute complete sequence: permission ON → starter ON (2s) + movement → starter OFF + movement (3s) → stop."""
            try:
                ser = self._ensure_serial()
                
                # Step 1: Enable permission
                self._set_relay_bit("permission", True)
                log.info("diktum_test.permission_on")
                
                # Step 1.5: Send idle frames for 2 seconds after permission
                delay_start = time.time()
                frame_count = 0
                while not self._stop_flag.is_set() and (time.time() - delay_start) < 2.0:
                    frame = build_frame(0, 0, speed_value=0, control_byte=self._get_current_control())
                    write_frame_to_uart(ser, frame)
                    if frame_count % 10 == 0:
                        log.info("Idle frame (permission ON, waiting): %s", " ".join(f"{b:02X}" for b in frame))
                    with self._lock:
                        self._last_frame = bytes(frame)
                    frame_count += 1
                    time.sleep(0.072)
                log.info("diktum_test.delay_after_permission")
                
                # Step 2: Enable starter
                self._set_relay_bit("starter", True)
                log.info("diktum_test.starter_on")
                
                # Step 3: Wait 3.5 seconds with starter ON (engine warming up, no movement)
                start_time = time.time()
                control_with_starter = self._get_current_control()  # Permission + Starter ON
                while not self._stop_flag.is_set() and (time.time() - start_time) < 3.5:
                    # Send idle frame (zero movement) while starter is ON
                    frame = build_frame(0, 0, speed_value=0, control_byte=control_with_starter)
                    write_frame_to_uart(ser, frame)
                    
                    # Log first frame and every 10th frame to avoid spam
                    if frame_count == 0 or frame_count % 10 == 0:
                        log.info("Idle frame (starter ON, warming up): %s", " ".join(f"{b:02X}" for b in frame))
                    
                    with self._lock:
                        self._last_frame = bytes(frame)
                    frame_count += 1
                    time.sleep(0.072)
                
                # Step 4: Turn starter OFF (keep permission ON)
                self._set_relay_bit("starter", False)
                log.info("diktum_test.starter_off")
                
                # Step 4.5: Send idle frames for 2 seconds after starter OFF
                delay_start = time.time()
                while not self._stop_flag.is_set() and (time.time() - delay_start) < 2.0:
                    frame = build_frame(0, 0, speed_value=0, control_byte=self._get_current_control())
                    write_frame_to_uart(ser, frame)
                    if frame_count % 10 == 0:
                        log.info("Idle frame (after starter, waiting): %s", " ".join(f"{b:02X}" for b in frame))
                    with self._lock:
                        self._last_frame = bytes(frame)
                    frame_count += 1
                    time.sleep(0.072)
                log.info("diktum_test.delay_after_starter")
                
                # Step 5: Send actual movement commands for 5 seconds with only permission ON
                control_no_starter = self._get_current_control()  # Permission ON, Starter OFF
                movement_start = time.time()
                while not self._stop_flag.is_set() and (time.time() - movement_start) < 5.0:
                    # Now send actual movement with speed, forward, turn
                    frame = build_frame(forward, turn, speed_value=speed, control_byte=control_no_starter)
                    write_frame_to_uart(ser, frame)
                    
                    # Log every 10th frame
                    if frame_count % 10 == 0:
                        log.info("Movement frame (actual movement): %s", " ".join(f"{b:02X}" for b in frame))
                    
                    with self._lock:
                        self._last_frame = bytes(frame)
                    frame_count += 1
                    time.sleep(0.072)
                
                # Step 6: Send stop frame and turn off permission

                stop_frame = build_frame(0, 0, speed_value=0, control_byte=control_no_starter)
                stop_start = time.time()
                while not self._stop_flag.is_set() and (time.time() - stop_start) < 2.0:
                    write_frame_to_uart(ser, stop_frame)
                    if frame_count % 10 == 0:
                        log.info("Stop frame written: %s", " ".join(f"{b:02X}" for b in stop_frame))
                    with self._lock:
                        self._last_frame = bytes(stop_frame)
                    frame_count += 1
                    time.sleep(0.072)
                    
                self._set_relay_bit("permission", False)
                write_frame_to_uart(ser, build_frame(0, 0, speed_value=0, control_byte=0x00))
                
                log.info("diktum_test.sequence_complete", extra={"event": {
                    "stage": "test", "action": "sequence_complete",
                    "speed": speed, "forward": forward, "turn": turn, 
                    "frames_sent": frame_count,
                    "last_frame_hex": " ".join(f"{b:02X}" for b in self._last_frame) if self._last_frame else None
                }})
            except Exception as e:
                log.error("diktum_test.sequence_error", extra={"event": {
                    "stage": "test", "action": "sequence_error", "error": str(e)
                }}, exc_info=True)
            finally:
                with self._lock:
                    self._active_thread = None
        
        with self._lock:
            self._active_thread = threading.Thread(target=_full_sequence, daemon=True)
            self._active_thread.start()
        
        return {
            "ok": True,
            "message": "Started sequence: permission ON → wait 5s → starter ON (3.5s) → starter OFF → wait 4s → movement (5s) → everything OFF",
            "speed": speed,
            "forward": forward,
            "turn": turn
        }
    
    def stop(self) -> Dict[str, Any]:
        """
        Stop any currently running test operation.
        
        Returns:
            Result dictionary with status
        """
        self._stop_active_operation()
        
        # Send stop frame if serial is open
        try:
            ser = self._ensure_serial()
            stop_frame = build_frame(0, 0, speed_value=0, control_byte=0x00)
            write_frame_to_uart(ser, stop_frame)
            with self._lock:
                self._last_frame = bytes(stop_frame)
        except Exception as e:
            log.warning(f"Error sending stop frame: {e}")
        
        return {
            "ok": True,
            "message": "Test operation stopped"
        }
    
    def get_last_frame(self) -> Optional[str]:
        """
        Get hex representation of last sent frame.
        
        Returns:
            Hex string of last frame, or None if no frame sent yet
        """
        with self._lock:
            if self._last_frame is None:
                return None
            return " ".join(f"{b:02X}" for b in self._last_frame)
    
    def cleanup(self):
        """Cleanup resources (close serial connection)."""
        self._stop_active_operation()
        self._close_serial()


def get_diktum_test_service(app_state) -> DiktumTestService:
    """
    Factory function for getting singleton DiktumTestService instance.
    
    Args:
        app_state: FastAPI app.state object
    
    Returns:
        DiktumTestService instance
    """
    if not hasattr(app_state, "_diktum_test_service"):
        app_state._diktum_test_service = DiktumTestService()
    return app_state._diktum_test_service

