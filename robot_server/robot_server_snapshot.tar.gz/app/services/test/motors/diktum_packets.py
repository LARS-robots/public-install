# robot/services/api/src/app/services/test/motors/diktum_packets.py
"""
Standalone packet building utilities for Diktum motor testing.
Independent of production DiktumMotor driver.
"""
import logging
import struct
import time
from typing import Optional

from ...system.config_loader import get_config

log = logging.getLogger(__name__)

try:
    import serial  # pyserial
except Exception:  # pragma: no cover
    serial = None


def _hex_to_bytes(hex_str: str) -> bytearray:
    """Convert hex string to bytearray."""
    cleaned = "".join(hex_str.split())
    return bytearray.fromhex(cleaned)


def _get_diktum_config() -> dict:
    """Load diktum config section from centralized config."""
    try:
        app_config = get_config()
        return app_config.raw_data.get("diktum", {})
    except Exception as e:
        log.warning(f"[diktum_test] failed to load config: {e}")
        return {}


def _get_base_frame() -> bytearray:
    """Build base 26-byte frame from config."""
    dcfg = _get_diktum_config()
    base_hex = (dcfg.get("base_command") or "").strip()
    if not base_hex:
        raise ValueError("[diktum_test] base_command is missing in config.toml")
    pkt = _hex_to_bytes(base_hex)
    if len(pkt) != 26 or pkt[-2:] != b"\x0D\x0A":
        raise ValueError("[diktum_test] base_command must be 26 bytes and end with 0D 0A")
    return pkt


def _get_control_index() -> int:
    """Get control byte index from config."""
    dcfg = _get_diktum_config()
    try:
        idx = int(dcfg.get("control_byte_index", 8))
    except Exception:
        idx = 8
    return max(0, min(25, idx))


def _get_keep_mask() -> int:
    """Get control keep mask from config."""
    dcfg = _get_diktum_config()
    m = dcfg.get("control_keep_mask", "0x3C")
    try:
        mask = int(m, 0) if isinstance(m, str) else int(m)
    except Exception:
        mask = 0x3C
    return mask & 0xFF


def _pack_i16_le(value: int) -> bytes:
    """Pack signed 16-bit integer as little-endian."""
    return struct.pack("<h", int(value))


def _clamp_int(value: int, lo: int, hi: int) -> int:
    """Clamp integer value between lo and hi."""
    return max(lo, min(value, hi))


def _get_relay_bits() -> dict:
    """Get relay bits configuration from config."""
    dcfg = _get_diktum_config()
    default = {"permission": 5, "starter": 4, "speed2": 3, "sound": 2}
    rb = dcfg.get("relay_bits")
    if isinstance(rb, dict):
        try:
            return {str(k): int(v) for k, v in rb.items()}
        except Exception:
            return default
    return default


def _update_frame_header(pkt: bytearray) -> None:
    """Update timestamp and sequence number in frame header."""
    micros = (time.monotonic_ns() // 1000) & 0xFFFFFFFF
    pkt[0:4] = struct.pack("<I", micros)
    seq = int(time.time() * 1000) & 0xFFFFFFFF
    pkt[4:8] = struct.pack("<I", seq)


def build_frame(
    forward_value: int,
    turn_value: int,
    speed_value: Optional[int] = None,
    control_byte: Optional[int] = None
) -> bytearray:
    """
    Build a 26-byte Diktum frame with speed and joystick values.
    
    Args:
        forward_value: Forward/backward value from -2000 to 2000 (+ = forward)
        turn_value: Turn value from -2000 to 2000 (+ = left, will be negated for Diktum)
        speed_value: Optional speed value from -2000 to 2000 (defaults to 0)
        control_byte: Optional control byte (defaults to base frame control byte)
    
    Returns:
        26-byte frame ready for UART transmission
    """
    pkt = _get_base_frame()
    _update_frame_header(pkt)
    
    # Control byte
    idx = _get_control_index()
    if control_byte is None:
        control_byte = int(pkt[idx]) & _get_keep_mask()
    pkt[idx] = control_byte & 0xFF
    pkt[9] = 0x00
    
    # Speed (bytes 10-12)
    if speed_value is not None:
        clamped_speed = _clamp_int(speed_value, 0, 2000)
        if clamped_speed <= 280:
            clamped_speed = 0
        pkt[10:12] = _pack_i16_le(clamped_speed)
    else:
        pkt[10:12] = b"\x00\x00"
        
    # joy1: turn (bytes 12-14)
    # Diktum spec: ch[1] positive = clockwise (right turn), negative = counter-clockwise (left turn)
    # Backend convention: positive = left turn, negative = right turn
    # So we negate turn_value to match Diktum's convention
    clamped_turn = _clamp_int(turn_value, -2000, 2000)
    pkt[12:14] = _pack_i16_le(clamped_turn)
    
    # Joystick channels
    # joy0: forward/backward (bytes 14-16)
    clamped_forward = _clamp_int(forward_value, -2000, 2000)
    pkt[14:16] = _pack_i16_le(clamped_forward)
    
    
    
    # Zero out remaining channels (bytes 16-24)
    for i in range(4):
        pkt[16 + i*2 : 18 + i*2] = b"\x00\x00"
    
    return pkt


def build_control_frame(control_byte: int) -> bytearray:
    """
    Build a 26-byte Diktum frame with a specific control byte value.
    Used for relay control commands.
    
    Args:
        control_byte: Control byte value (0-255), will be masked with keep_mask
    
    Returns:
        26-byte frame ready for UART transmission
    """
    pkt = _get_base_frame()
    _update_frame_header(pkt)
    
    # Set control byte (apply keep_mask to preserve important bits)
    idx = _get_control_index()
    keep_mask = _get_keep_mask()
    pkt[idx] = (control_byte & keep_mask) & 0xFF
    pkt[9] = 0x00
    
    return pkt


def write_frame_to_uart(ser, frame: bytes | bytearray) -> int:
    """
    Write frame to UART serial port.
    
    Args:
        ser: pyserial Serial object
        frame: Frame bytes to write
    
    Returns:
        Number of bytes written
    """
    if serial is None:
        raise RuntimeError("pyserial is not installed. Install with: uv pip install pyserial")
    if ser is None or not ser.is_open:
        raise RuntimeError("Serial port is not open")
    
    data = bytes(frame)
    n = ser.write(data)
    return int(n)


def open_serial_connection() -> "serial.Serial":
    """
    Open serial connection to Diktum device using config.
    
    Returns:
        Opened pyserial Serial object
    """
    if serial is None:
        raise RuntimeError("pyserial is not installed. Install with: uv pip install pyserial")
    
    dcfg = _get_diktum_config()
    device = dcfg.get("serial_device") or "/dev/ttyAMA0"
    baud = int(dcfg.get("baudrate", 115200))
    
    ser = serial.Serial(device, baud)
    log.info("diktum_test.serial_open", extra={"event": {
        "stage": "test", "action": "serial_open",
        "device": device, "baud": baud
    }})
    return ser

