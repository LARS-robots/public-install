import os
import asyncio
from nats.aio.client import Client as NATS

async def main():
    nc = NATS()
    nats_url = os.getenv("NATS_URL", "nats://localhost:4222")
    await nc.connect(nats_url)
    async def message_handler(msg):
        print(f"Received message: {msg.data.decode()}")
    await nc.subscribe("test.topic", cb=message_handler)
    print('-' * 100)
    await asyncio.Future()
    
if __name__ == "__main__":
    asyncio.run(main())