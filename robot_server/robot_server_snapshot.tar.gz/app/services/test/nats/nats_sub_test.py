"""
NATS Subscriber Test - Listen to motor commands.

Usage via Docker:
    docker exec -it robot-api-1 python -m app.services.test.nats.nats_sub_test
"""
import os
import asyncio
import json
import nats
from nats.aio.client import Client as NATS

async def test():
    nc = NATS()
    nats_url = os.getenv("NATS_URL", "nats://localhost:4222")
    await nc.connect(nats_url)
    async def message_handler(msg):
        print(f"Received message: {msg.data.decode()}")
    await nc.subscribe("test.topic", cb=message_handler)
    print('-' * 100)
    await asyncio.Future()
    
async def main():
    nc = await nats.connect(os.getenv("NATS_URL", "nats://localhost:4222"))
    async def handler(msg):
        data = json.loads(msg.data.decode())
        print(f"{data['cmd']}: {data.get('args', {})}")
    await nc.subscribe("motors.*", cb=handler)
    await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())