from fastapi import APIRouter, Request, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import List, Annotated, Dict, Any, Optional
import logging
import json
from datetime import datetime, timezone

from ...services.motor.robot_service import get_robot_service, RobotService
from ...services.motor.nats_publisher import get_nats_publisher
from ...services.navigation.route_service import Waypoint
from ...services.system.map_download_service import MapDownloadService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/route", tags=["Route"])

# Dependency injection
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

# Map download request model
class MapDownloadRequest(BaseModel):
    south: float = Field(..., ge=-90, le=90)
    west: float = Field(..., ge=-180, le=180)
    north: float = Field(..., ge=-90, le=90)
    east: float = Field(..., ge=-180, le=180)

class FollowReq(BaseModel):
    path: Annotated[List[Waypoint], Field(min_length=1, max_length=2048)]
    origin: Optional[Dict[str, float]] = None  # Опционально: {"lat": float, "lon": float, "yaw": float}

class RouteCreate(BaseModel):
    waypoints: Annotated[List[Waypoint], Field(min_length=1, max_length=100)]
    mode: str | None = "simulator"

class PlanReq(BaseModel):
    start: Waypoint
    goal: Waypoint

class MapUpload(BaseModel):
    """GeoJSON map upload request"""
    geojson: Dict[str, Any]
    version: str | None = None

class CancelReq(BaseModel):
    """Optional cancel payload (used for UI debugging / attribution)."""
    reason: str | None = None

@router.post("")
def post_route(
    req: Request,
    body: RouteCreate,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Start route following waypoints."""
    if robot.get_robot_type() != "simulator":
        # На реальном роботе безопасная езда по маршруту пока не реализована
        raise HTTPException(
            status_code=400,
            detail="Езда по маршруту доступна только в режиме 'simulator'. Переключите робота в режим симуляции.",
        )
    
    route_state = robot.route_service.get_state(req.app.state)
    if route_state:
        raise HTTPException(
            status_code=409,
            detail="Маршрут уже активен. Сначала отмените текущий маршрут.",
        )
    
    if not robot.init_simulator():
        raise HTTPException(
            status_code=400,
            detail="Симулятор не инициализирован. Проверьте конфигурацию ROBOT_TYPE и перезапустите motor_daemon/api.",
        )
    
    return robot.start_route(body.waypoints)

@router.get("")
async def get_route(
    req: Request,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Get active route status from KV store."""
    try:
        publisher = await get_nats_publisher()
        js = publisher.nc.jetstream()
        kv = await js.key_value("motors_navigation")
        
        try:
            entry = await kv.get("route")
            if entry:
                route_data = json.loads(entry.value.decode())
                path_idx = route_data.get("path_idx", 0)
                return {
                    "ok": True,
                    "active": route_data.get("status") == "RUNNING",
                    # Prefer `path_idx` as canonical name (matches motor_daemon route state).
                    # Keep `index` for backward compatibility with older UIs.
                    "path_idx": path_idx,
                    "index": path_idx,
                    "path": route_data.get("path", []),
                    "status": route_data.get("status"),
                    "error": route_data.get("error")
                }
        except Exception:
            pass  # No route in KV store
        
        # Fallback to route_service for backward compatibility
        return robot.get_route_status()
    except Exception as e:
        logger.warning(f"Failed to read route from KV store: {e}, falling back to route_service")
    return robot.get_route_status()

@router.post("/cancel")
async def cancel_route(
    req: Request,
    body: CancelReq | None = None,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Cancel active route."""
    # Publish cancel command to NATS
    try:
        publisher = await get_nats_publisher()
        nav_msg = {
            "cmd": "cancel",
            "args": {},
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        }
        await publisher.nc.publish(
            "motors.navigation.cancel",
            json.dumps(nav_msg, separators=(',', ':')).encode()
        )
        logger.info("[ROUTE] Published navigation cancel command to NATS (reason=%s)", getattr(body, "reason", None))
    except Exception as e:
        logger.error(f"Failed to publish cancel command: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Failed to publish cancel command: {e}")
    
    # Delete route from KV store
    try:
        publisher = await get_nats_publisher()
        js = publisher.nc.jetstream()
        kv = await js.key_value("motors_navigation")
        try:
            await kv.delete("route")
            logger.info("[ROUTE] Deleted route from KV store")
        except Exception:
            pass  # Route might not exist
    except Exception as e:
        logger.warning(f"Failed to delete route from KV store: {e}")
    
    # Also cancel via route_service for backward compatibility
    return robot.cancel_route()

@router.post("/plan")
def plan_route(
    req: Request,
    body: PlanReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Plan route with A* pathfinding.
    Returns planned path but DOESN'T start navigation.
    """
    logger.info(f"Planning route: start=({body.start.lat:.6f}, {body.start.lon:.6f}), goal=({body.goal.lat:.6f}, {body.goal.lon:.6f})")
    
    if robot.get_robot_type() != "simulator":
        raise HTTPException(
            status_code=400,
            detail="Езда по маршруту доступна только в режиме 'simulator'. Переключите робота в режим симуляции.",
        )
    
    if not robot.init_simulator():
        raise HTTPException(
            status_code=400,
            detail="Симулятор не инициализирован. Проверьте конфигурацию ROBOT_TYPE и перезапустите motor_daemon/api.",
        )
    
    result = robot.plan_route(body.start, body.goal)
    
    if not result.get("ok"):
        logger.warning(f"Route planning failed: reason={result.get('reason')}")
        return {"ok": False, "reason": result.get("reason")}
    
    logger.info(f"Route planned successfully: {len(result['path'])} waypoints, planner={result.get('planner_used', 'unknown')}")
    return result

@router.post("/follow")
async def follow_path(
    req: Request, 
    body: FollowReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Start following a pre-planned path.
    This is called by the frontend after /route/plan succeeds.
    """
    logger.info(f"Starting route following: {len(body.path)} waypoints")
    
    if robot.get_robot_type() != "simulator":
        raise HTTPException(status_code=400, detail="not_simulator")
    
    # Check if route already active (read from KV store)
    try:
        publisher = await get_nats_publisher()
        if not publisher:
            logger.error("NATS publisher is None")
            raise HTTPException(status_code=503, detail="NATS publisher not available")
        
        if not publisher.nc:
            logger.error("NATS connection is None")
            raise HTTPException(status_code=503, detail="NATS connection not available")
        
        if not publisher.nc.is_connected:
            logger.error("NATS connection is not connected")
            raise HTTPException(status_code=503, detail="NATS connection not connected")
        
        js = publisher.nc.jetstream()
        if not js:
            logger.error("JetStream context is None")
            raise HTTPException(status_code=503, detail="JetStream context not available")
        
        kv = await js.key_value("motors_navigation")
        try:
            entry = await kv.get("route")
            if entry:
                route_data = json.loads(entry.value.decode())
                route_status = route_data.get("status")
                
                if route_status == "RUNNING":
                    # Check if route is stale (not updated for more than 10 seconds)
                    last_update_str = route_data.get("last_update")
                    if last_update_str:
                        try:
                            last_update = datetime.fromisoformat(last_update_str.replace("Z", "+00:00"))
                            now = datetime.now(timezone.utc)
                            age_seconds = (now - last_update.replace(tzinfo=timezone.utc)).total_seconds()
                            
                            if age_seconds > 10.0:
                                # Route is stale - cancel it automatically
                                logger.info(f"Stale route detected (age={age_seconds:.1f}s), auto-cancelling")
                                await kv.delete("route")
                                # Also publish cancel command
                                nav_msg = {
                                    "cmd": "cancel",
                                    "args": {},
                                    "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                                }
                                await publisher.nc.publish(
                                    "motors.navigation.cancel",
                                    json.dumps(nav_msg, separators=(',', ':')).encode()
                                )
                            else:
                                # Route is active and fresh
                                logger.warning(f"Route already active: status={route_status}, path_idx={route_data.get('path_idx')}, age={age_seconds:.1f}s")
                                raise HTTPException(status_code=409, detail="route_active")
                        except (ValueError, TypeError) as e:
                            # Invalid timestamp - treat as stale and cancel
                            logger.warning(f"Invalid route timestamp format, auto-cancelling: {e}")
                            await kv.delete("route")
                    else:
                        # No timestamp - treat as stale and cancel
                        logger.warning("Route missing timestamp, auto-cancelling")
                        await kv.delete("route")
        except HTTPException:
            raise
        except Exception as e:
            logger.debug(f"No active route found in KV store: {type(e).__name__}")
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"Failed to check route status from KV store: {type(e).__name__}: {e}")
    
    if not robot.init_simulator():
        logger.error("Simulator initialization failed")
        raise HTTPException(status_code=400, detail="simulator_not_initialized")
    
    # Prepare route state for KV store
    waypoints_list = [{"lat": w.lat, "lon": w.lon} for w in body.path]
    route_state = {
        "path": waypoints_list,
        "path_idx": 0,
        "status": "RUNNING",
        "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "last_update": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "error": None
    }
    
    # Add origin if provided
    if body.origin:
        route_state["origin"] = {
            "lat": float(body.origin.get("lat")),
            "lon": float(body.origin.get("lon")),
            "yaw": float(body.origin.get("yaw", 0.0))
        }
    
    # Save route to KV store
    try:
        publisher = await get_nats_publisher()
        if not publisher or not publisher.nc:
            logger.error("NATS publisher unavailable for KV save")
            raise HTTPException(status_code=503, detail="NATS publisher not available")
        
        js = publisher.nc.jetstream()
        if not js:
            logger.error("JetStream unavailable for KV save")
            raise HTTPException(status_code=503, detail="JetStream not available")
        
        kv = await js.key_value("motors_navigation")
        route_json = json.dumps(route_state, separators=(',', ':'))
        await kv.put("route", route_json.encode())
        logger.info(f"Route saved to KV store: {len(waypoints_list)} waypoints, size={len(route_json)} bytes")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to save route to KV store: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Failed to save route to KV store: {type(e).__name__}: {e}")
    
    # Publish start command to NATS
    try:
        publisher = await get_nats_publisher()
        if not publisher or not publisher.nc:
            logger.error("NATS publisher unavailable for command publish")
            raise HTTPException(status_code=503, detail="NATS publisher not available")
        
        if not publisher.nc.is_connected:
            logger.error("NATS connection not connected for command publish")
            raise HTTPException(status_code=503, detail="NATS connection not connected")
        
        nav_msg = {
            "cmd": "start",
            "args": {
                "path": waypoints_list,
                "origin": route_state.get("origin")  # Добавить origin если есть
            },
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        }
        nav_msg_json = json.dumps(nav_msg, separators=(',', ':'))
        await publisher.nc.publish(
            "motors.navigation.start",
            nav_msg_json.encode()
        )
        logger.info(f"Navigation start command published to NATS: subject=motors.navigation.start, size={len(nav_msg_json)} bytes")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to publish navigation command: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Failed to publish navigation command: {type(e).__name__}: {e}")
    
    # Also update route_service for backward compatibility
    try:
        st = robot.route_service.start(req.app.state, body.path)
        logger.info(f"Route following started: {len(st.path)} waypoints")
        return {"ok": True, "active": True, "count": len(st.path)}
    except Exception as e:
        logger.warning(f"Failed to update route_service (non-critical): {type(e).__name__}: {e}")
        # Return success anyway since KV store and NATS publish succeeded
        return {"ok": True, "active": True, "count": len(waypoints_list)}

@router.post("/map/download")
def download_map(
    body: MapDownloadRequest,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Download map from OpenStreetMap and build GeoJSON.
    Runs build_site_geojson.py script in background.
    
    This will:
    1. Fetch OSM data from Overpass API
    2. Build GeoJSON with roads (is_road=true) and obstacles (blocked=true)
    3. Save to robot_server/app/static/cache/chelybinsk.geojson
    4. Auto-reload planner
    """
    logger.info(f"Map download requested: bounds=({body.south},{body.west}) to ({body.north},{body.east})")
    
    # Use service to download
    download_service = MapDownloadService()
    result = download_service.download_map(
        south=body.south,
        west=body.west,
        north=body.north,
        east=body.east
    )
    
    if result["ok"]:
        # Invalidate planner cache to force reload
        robot.route_service._invalidate_planner_cache(robot.app_state)
        logger.info("Map downloaded successfully, planner cache invalidated")
    
    return result

@router.post("/map/upload")
def upload_map(
    body: MapUpload,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Upload GeoJSON map for navigation."""
    logger.info(f"Receiving map upload: version={body.version}")
    
    # Delegate to route service
    result = robot.route_service.handle_map_upload(robot.app_state, body.geojson)
    
    if result.get("ok"):
        logger.info(f"Map uploaded successfully: {result.get('message', '')}")
    else:
        logger.error(f"Map upload failed: {result.get('message', 'Upload failed')}")
    
    return {
        **result,
        "version": body.version
    }

@router.get("/map/status")
def map_status(
    robot: RobotService = Depends(get_robot_from_request)
):
    """Check if uploaded map exists and get planner status."""
    return robot.route_service.get_map_status(robot.app_state)

@router.get("/debug/status")
async def get_navigation_debug_status(
    req: Request
):
    """
    Get detailed navigation status for debugging.
    
    Returns:
    - Current robot pose
    - Active route information
    - Current waypoint and distance to target
    - Navigation phase (TURNING/MOVING)
    - Recent command history
    """
    try:
        publisher = await get_nats_publisher()
        if not publisher or not publisher.nc:
            raise HTTPException(status_code=503, detail="NATS publisher not available")
        
        js = publisher.nc.jetstream()
        kv_nav = await js.key_value("motors_navigation")
        kv_loc = await js.key_value("loc_state")
        
        result = {
            "ok": True,
            "navigation": None,
            "pose": None,
            "status": "no_route"
        }
        
        # Get route status
        try:
            entry = await kv_nav.get("route")
            if entry:
                route_data = json.loads(entry.value.decode())
                result["navigation"] = {
                    "route_status": route_data.get("status"),
                    "path_idx": route_data.get("path_idx", 0),
                    "total_waypoints": len(route_data.get("path", [])),
                    "path": route_data.get("path", []),
                    "last_update": route_data.get("last_update"),
                    "started_at": route_data.get("started_at"),
                    "error": route_data.get("error")
                }
                
                # Get current pose
                try:
                    pose_entry = await kv_loc.get("current")
                    if pose_entry:
                        pose_data = json.loads(pose_entry.value.decode())
                        result["pose"] = {
                            "lat": pose_data.get("lat"),
                            "lon": pose_data.get("lon"),
                            "yaw": pose_data.get("yaw"),
                            "x": pose_data.get("x"),
                            "y": pose_data.get("y"),
                            "ts": pose_data.get("ts")
                        }
                        
                        # Calculate distance to current waypoint
                        if route_data.get("path") and result["pose"]:
                            path = route_data["path"]
                            path_idx = route_data.get("path_idx", 0)
                            if path_idx < len(path):
                                target = path[path_idx]
                                # Simple Haversine distance calculation
                                import math
                                R = 6378137.0
                                lat1 = math.radians(result["pose"]["lat"])
                                lon1 = math.radians(result["pose"]["lon"])
                                lat2 = math.radians(target["lat"])
                                lon2 = math.radians(target["lon"])
                                dlat = lat2 - lat1
                                dlon = lon2 - lon1
                                a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
                                a = min(1.0, max(0.0, a))
                                distance = 2 * R * math.asin(math.sqrt(a))
                                
                                result["navigation"]["current_target"] = target
                                result["navigation"]["distance_to_target_m"] = distance
                                result["status"] = route_data.get("status", "unknown").lower()
                except NotFoundError:
                    pass
        except NotFoundError:
            pass
        
        # Get pose even if no route
        if not result["pose"]:
            try:
                pose_entry = await kv_loc.get("current")
                if pose_entry:
                    pose_data = json.loads(pose_entry.value.decode())
                    result["pose"] = {
                        "lat": pose_data.get("lat"),
                        "lon": pose_data.get("lon"),
                        "yaw": pose_data.get("yaw"),
                        "x": pose_data.get("x"),
                        "y": pose_data.get("y"),
                        "ts": pose_data.get("ts")
                    }
            except NotFoundError:
                pass
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get navigation debug status: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get navigation status: {str(e)}")