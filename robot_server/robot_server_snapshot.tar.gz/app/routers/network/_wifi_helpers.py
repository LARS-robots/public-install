"""Shared WiFi validation and connection helpers"""
from typing import Optional
from fastapi import HTTPException
import logging
import time
import shlex
from ...services.network.wifi_manager import WifiManager, WifiError

log = logging.getLogger(__name__)

def ensure_visible_and_validate(wm: WifiManager, ssid: str, password: Optional[str]) -> bool:
    """
    Check network visibility, security requirements, and validate credentials.
    Returns True if validation passed, raises HTTPException on errors.
    """
    # 1. Check network visibility
    log.info(f"Checking network visibility: {ssid}")
    try:
        nets = wm.scan()
    except WifiError as e:
        raise HTTPException(status_code=500, detail=f"Scan failed: {e}")
    
    found_network = None
    for net in nets:
        if net.ssid == ssid:
            found_network = net
            break
    
    if not found_network:
        available_ssids = [net.ssid for net in nets[:5]]
        raise HTTPException(
            status_code=400, 
            detail=f"Network '{ssid}' not found. Available: {available_ssids}"
        )
    
    # 2. Check security requirements
    requires_password = found_network.security and found_network.security.strip() not in ["", "--"]
    if requires_password and not password:
        raise HTTPException(
            status_code=400,
            detail=f"Network '{ssid}' requires a password (security: {found_network.security})"
        )
    
    # 3. Validate credentials (move validation logic here)
    log.info(f"Validating credentials for: {ssid}")
    
    # Use existing validation logic from wifi_api.py
    return _validate_credentials_internal(wm, ssid, password)

def _validate_credentials_internal(wm: WifiManager, ssid: str, password: Optional[str]) -> bool:
    """Быстрая проверка правильности логина/пароля"""
    try:
        log.info(f"Validating credentials for {ssid}")
        
        # Устанавливаем guard для защиты от автоподъема AP во время валидации
        wm._write_guard(60)
        wm._suppress_ap_autoconnect(60)
        
        # Создаем временное тестовое подключение
        test_connection_name = f"test-{int(time.time())}"
        
        # Пытаемся создать подключение с заданными учетными данными
        cmd = f'sudo nmcli connection add type wifi con-name "{test_connection_name}" ssid {shlex.quote(ssid)}'
        if password:
            cmd += f' wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)}'
        
        try:
            wm._run(cmd, timeout=10)
            
            # Пытаемся активировать подключение на короткое время
            activate_cmd = f'sudo nmcli connection up "{test_connection_name}" ifname wlan0'
            wm._run(activate_cmd, timeout=15)
            
            # Проверяем, что подключились к правильной сети
            time.sleep(2)
            current_status = wm.status()
            success = current_status.get("ssid") == ssid
            
            log.info(f"Credential validation result: {success}")
            return success
            
        finally:
            # Удаляем тестовое подключение
            try:
                wm._run(f'sudo nmcli connection delete "{test_connection_name}"', timeout=5)
            except Exception:
                pass
                
    except WifiError as e:
        error_msg = str(e).lower()
        
        # Проверяем специфичные ошибки аутентификации
        if any(keyword in error_msg for keyword in [
            "password", "authentication", "key", "psk", 
            "secrets were required", "invalid key"
        ]):
            log.error(f"Authentication failed: {e}")
            return False
        
        # Проверяем ошибки сети
        if any(keyword in error_msg for keyword in [
            "not found", "no network", "ssid"
        ]):
            log.error(f"Network not found: {e}")
            return False
            
        # Другие ошибки также считаем неудачными
        log.error(f"Connection validation failed: {e}")
        return False
        
    except Exception as e:
        log.exception(f"Unexpected error during validation: {e}")
        return False
    
    finally:
        # Очищаем guard после валидации
        wm._clear_guard()