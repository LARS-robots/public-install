from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from ...services.network.wifi_manager import WifiManager
import asyncio
import logging

router = APIRouter(prefix="/wifi", tags=["WiFi"])
# BEGIN FIX: thread-safe WebSocket client management
clients: set[WebSocket] = set()
log = logging.getLogger(__name__)  # module logger instead of basicConfig
# END FIX

@router.websocket("/ws/wifi")
async def wifi_ws(ws: WebSocket):
    await ws.accept()
    clients.add(ws)  # set.add instead of list.append
    try:
        wm: WifiManager = ws.app.state.wifi_manager
        while True:
            await asyncio.sleep(5)
            try:
                ip_info = wm.status()
                data = {"ssid": ip_info.get("ssid"), "ip": ip_info.get("ip4")}
                await ws.send_json(data)
            except Exception as e:
                log.warning(f"Failed to send periodic status: {e}")
                break
    except WebSocketDisconnect:
        pass
    finally:
        clients.discard(ws)  # set.discard instead of list.remove

async def notify_event(event: str, ssid: str = None, reason: str = None, ip: str = None):
    """Thread-safe broadcasting to WebSocket clients"""
    payload = {"event": event}
    
    if ssid is not None:
        payload["ssid"] = ssid
    if ip is not None:
        payload["ip"] = ip
    if reason is not None:
        payload["reason"] = reason
    
    log.info(f"Broadcasting WiFi event: {payload}")
    
    # BEGIN FIX: thread-safe broadcasting
    # Create snapshot to avoid concurrent modification
    client_snapshot = list(clients)
    disconnected_clients = []
    
    for ws in client_snapshot:
        try:
            await ws.send_json(payload)
        except Exception as e:
            log.warning(f"Failed to send event to WebSocket client: {e}")
            disconnected_clients.append(ws)
    
    # Clean up disconnected clients safely
    for ws in disconnected_clients:
        clients.discard(ws)
    # END FIX

async def notify_new_ip(wm: WifiManager):
    """
    Совместимость со старым API: отправляем ip_acquired событие + текущее состояние
    """
    try:
        ip_info = wm.status()
        await notify_event(
            event="ip_acquired",
            ssid=ip_info.get("ssid"),
            ip=ip_info.get("ip4")
        )
    except Exception as e:
        logging.error(f"Failed to notify new IP: {e}")