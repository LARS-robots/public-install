# robot_server/app/routers/motion.py
from fastapi import APIRouter, Request, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import logging

from ...services.motor.nats_publisher import get_nats_publisher, NATSPublisher

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/motion", tags=["Motion"])

class CommandReq(BaseModel):
    # Normalized joystick values (-1.0 to 1.0) - conversion happens in motor-daemon drivers
    speed: Optional[float] = Field(None, ge=0.0, le=1.0, description="Speed value from 0.0 to 1.0")
    forward: Optional[float] = Field(None, ge=-1.0, le=1.0, description="Forward/backward value from -1.0 to 1.0 (+ = forward)")
    turn: Optional[float] = Field(None, ge=-1.0, le=1.0, description="Turn value from -1.0 to 1.0 (+ = left)")

@router.post("/command")
async def post_command(
    body: CommandReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """
    Send joystick command to robot via NATS.
    Uses normalized values (-1.0 to 1.0) - conversion to robot-specific ranges happens in motor-daemon drivers.
    Command is published to NATS and processed asynchronously by motor-daemon.
    """
    try:
        await publisher.publish_move(
            speed=body.speed,
            forward=body.forward,
            turn=body.turn
        )
        logger.info("motion.command.published", extra={"event": {
            "stage": "motion",
            "action": "command_published",
            "command": body.dict()
        }})
        return {"status": "sent"}
    except Exception as e:
        # Для UI важно получить понятную причину, почему движение недоступно.
        logger.error(f"Failed to publish motion command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось отправить команду движения в NATS (motors.move): {e}",
        )


# ---------- per-relay endpoints ----------
class RelayReq(BaseModel):
    on: bool = True

@router.post("/relay/permission")
async def relay_permission(
    body: RelayReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """Control permission relay via NATS."""
    try:
        await publisher.publish_relay("permission", body.on)
        logger.info("motion.relay.permission", extra={"event": {
            "stage": "motion", "action": "relay_permission", "on": body.on
        }})
        return {"status": "sent"}
    except Exception as e:
        logger.error(f"Failed to publish relay command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось переключить реле разрешения через NATS: {e}",
        )

@router.post("/relay/starter")
async def relay_starter(
    body: RelayReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """Control starter relay via NATS."""
    try:
        await publisher.publish_relay("starter", body.on)
        logger.info("motion.relay.starter", extra={"event": {
            "stage": "motion", "action": "relay_starter", "on": body.on
        }})
        return {"status": "sent"}
    except Exception as e:
        logger.error(f"Failed to publish relay command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось переключить реле стартера через NATS: {e}",
        )

@router.post("/relay/speed2")
async def relay_speed2(
    body: RelayReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """Control speed2 relay via NATS."""
    try:
        await publisher.publish_relay("speed2", body.on)
        logger.info("motion.relay.speed2", extra={"event": {
            "stage": "motion", "action": "relay_speed2", "on": body.on
        }})
        return {"status": "sent"}
    except Exception as e:
        logger.error(f"Failed to publish relay command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось переключить реле speed2 через NATS: {e}",
        )

@router.post("/relay/sound")
async def relay_sound(
    body: RelayReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """Control sound relay via NATS."""
    try:
        await publisher.publish_relay("sound", body.on)
        logger.info("motion.relay.sound", extra={"event": {
            "stage": "motion", "action": "relay_sound", "on": body.on
        }})
        return {"status": "sent"}
    except Exception as e:
        logger.error(f"Failed to publish relay command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось переключить звуковое реле через NATS: {e}",
        )

@router.post("/relay/stop")
async def relay_stop(
    body: RelayReq,
    publisher: NATSPublisher = Depends(get_nats_publisher)
):
    """Emergency stop relay via NATS."""
    try:
        await publisher.publish_relay("stop", body.on)
        logger.info("motion.relay.stop", extra={"event": {
            "stage": "motion", "action": "relay_stop", "on": body.on
        }})
        return {"status": "sent"}
    except Exception as e:
        logger.error(f"Failed to publish relay command: {e}", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось активировать аварийный стоп через NATS: {e}",
        )
