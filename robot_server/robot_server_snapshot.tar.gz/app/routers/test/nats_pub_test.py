# routers/test/nats_pub_test.py
from fastapi import APIRouter, Query
import asyncio
import os
import logging
import time
from nats.aio.client import Client as NATS

router = APIRouter(prefix="/test/nats", tags=["test"])

# Logger для тестового логирования
test_logger = logging.getLogger("test.nats_logging")

@router.post("/send")
async def send_message(msg: str = "Hello from API"):
    nc = NATS()
    # Use NATS_URL from environment, fallback to nats service name (for Docker)
    nats_url = os.getenv("NATS_URL", "nats://nats:4222")

    await nc.connect(nats_url)
    await nc.publish("test.topic", msg.encode())
    await nc.drain()
    return {"status": "sent", "message": msg}


@router.post("/test-logging")
async def test_logging(
    level: str = Query("INFO", description="Log level: DEBUG, INFO, WARNING, ERROR, CRITICAL"),
    message: str = Query("Test log message from API", description="Log message"),
    service: str = Query("api", description="Service name"),
):
    """
    Тестовый endpoint для проверки логирования через NATS.
    
    Отправляет тестовое сообщение через Python logging framework,
    которое должно пройти через NATSHandler → NATS → мост → logbus → веб-интерфейс.
    
    Проверьте веб-интерфейс http://localhost:8000/admin/logs после вызова этого endpoint.
    """
    level_map = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }
    
    log_level = level_map.get(level.upper(), logging.INFO)
    
    # Простое логирование
    test_logger.log(log_level, message)
    
    # Структурированное логирование с extra event
    test_logger.info(
        "test_nats_logging",
        extra={
            "event": {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
                "src": "test",
                "evt": "test_logging",
                "level": level,
                "message": message,
                "service": service,
                "test_id": f"test_{int(time.time())}",
            }
        }
    )
    
    # Логи разных уровней для проверки
    if log_level >= logging.INFO:
        test_logger.info(f"✅ Test INFO log: {message}")
    if log_level >= logging.WARNING:
        test_logger.warning(f"⚠️ Test WARNING log: {message}")
    if log_level >= logging.ERROR:
        test_logger.error(f"❌ Test ERROR log: {message}")
    
    return {
        "status": "sent",
        "level": level,
        "message": message,
        "service": service,
        "note": "Check logs at http://localhost:8000/admin/logs",
        "expected_flow": "logging → NATSHandler → NATS → bridge → logbus → web UI"
    }