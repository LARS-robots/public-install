# routers/test/nats_pub_test.py
from fastapi import APIRouter
import asyncio
import os
from nats.aio.client import Client as NATS

router = APIRouter(prefix="/test/nats", tags=["test"])

@router.post("/send")
async def send_message(msg: str = "Hello from API"):
    nc = NATS()
    # Use NATS_URL from environment, fallback to nats service name (for Docker)
    nats_url = os.getenv("NATS_URL", "nats://nats:4222")

    await nc.connect(nats_url)
    await nc.publish("test.topic", msg.encode())
    await nc.drain()
    return {"status": "sent", "message": msg}