# robot/services/api/src/app/routers/test/motor_diktum_test.py
"""
FastAPI router for Diktum motor testing endpoints.
"""
from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
import logging
import json

from ...services.test.motors.diktum_test_service import (
    DiktumTestService,
    get_diktum_test_service
)
from ...services.test.motors.nats_test_service import (
    DiktumNatsTestService,
    get_diktum_nats_test_service
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/test/diktum", tags=["test"])


def get_test_service_from_request(req: Request) -> DiktumTestService:
    """Dependency function to get test service from request."""
    return get_diktum_test_service(req.app.state)


async def get_nats_test_service_from_request(req: Request) -> DiktumNatsTestService:
    """Dependency function to get NATS test service from request."""
    return await get_diktum_nats_test_service()


class CommandRequest(BaseModel):
    """Request model for combined command test."""
    speed: int = Field(..., ge=0, le=2000, description="Speed value from 0 to 2000")
    forward: int = Field(..., ge=-2000, le=2000, description="Forward/backward value from -2000 to 2000 (+ = forward)")
    turn: int = Field(..., ge=-2000, le=2000, description="Turn value from -2000 to 2000 (+ = left)")


class RelayRequest(BaseModel):
    """Request model for relay control."""
    on: bool = Field(True, description="True to turn relay on, False to turn off")
    speed: Optional[int] = Field(None, ge=0, le=2000, description="Optional speed value (0-2000) for automatic sequence")
    forward: Optional[int] = Field(None, ge=-2000, le=2000, description="Optional forward/backward value (-2000 to 2000) for automatic sequence")
    turn: Optional[int] = Field(None, ge=-2000, le=2000, description="Optional turn value (-2000 to 2000) for automatic sequence")


@router.post("/command")
def test_command(
    req: Request,
    body: CommandRequest,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Execute complete automated test sequence for Diktum motor.
    
    **Sequence (total 5 seconds):**
    1. Enable permission relay
    2. Enable starter relay + send movement commands (2 seconds)
    3. Disable starter relay + continue movement (3 seconds)
    4. Turn everything OFF (including permission)
    
    Permission stays ON during entire movement loop. Starter is ON only for first 2 seconds.
    
    - **speed**: Speed value from 0 to 2000
    - **forward**: Forward/backward value from -2000 to 2000 (+ = forward)
    - **turn**: Turn value from -2000 to 2000 (+ = left)
    """
    result = service.send_command(body.speed, body.forward, body.turn)
    logger.info("diktum_test.command_request", extra={"event": {
        "stage": "test",
        "action": "command_request",
        "speed": body.speed,
        "forward": body.forward,
        "turn": body.turn,
        "result": result
    }})
    return result

@router.post("/start_engine")
async def test_start_engine(
    req: Request,
    nats_service: DiktumNatsTestService = Depends(get_nats_test_service_from_request)
):
    """
    Start the engine.
    
    Publishes start engine command via NATS to motors.start_engine.
    The motor daemon will execute the startup sequence if engine is not already started.
    """
    result = await nats_service.publish_start_engine()
    logger.info("diktum_test.start_engine", extra={"event": {
        "stage": "test",
        "action": "start_engine",
        "result": result
    }})
    return result

@router.post("/stop")
async def test_stop(
    req: Request,
    nats_service: DiktumNatsTestService = Depends(get_nats_test_service_from_request)
):
    """
    Stop any currently running test sequence.
    
    Sends a stop command via NATS to interrupt the current sequence.
    This works with sequences managed by test_base.py state machine.
    """
    result = await nats_service.publish_start_sequence("stop")
    logger.info("diktum_test.stop_request", extra={"event": {
        "stage": "test",
        "action": "stop_request",
        "result": result
    }})
    return result


@router.get("/last_frame")
def get_last_frame(
    req: Request,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Get hex representation of the last sent frame.
    
    Useful for debugging and verification of packet structure.
    """
    frame_hex = service.get_last_frame()
    if frame_hex is None:
        return {
            "ok": True,
            "frame": None,
            "message": "No frame sent yet"
        }
    return {
        "ok": True,
        "frame": frame_hex,
        "message": "Last sent frame"
    }


# ---------- Relay control endpoints ----------

@router.post("/relay/permission")
def relay_permission(
    req: Request,
    body: RelayRequest,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Set permission relay on/off.
    
    **Required first step**: Permission relay must be ON before movement commands will work.
    
    - **on**: True to enable permission, False to disable
    """
    result = service.set_relay("permission", body.on)
    logger.info("diktum_test.relay.permission", extra={"event": {
        "stage": "test",
        "action": "relay_permission",
        "on": body.on,
        "result": result
    }})
    return result


@router.post("/relay/starter")
def relay_starter(
    req: Request,
    body: RelayRequest,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Set starter relay on/off, or trigger full sequence if movement params provided.
    
    **Manual mode** (no movement params): Simple on/off control
    **Auto mode** (with movement params): Executes complete sequence:
      - permission ON → starter ON + movement (2s) → starter OFF + movement (3s) → everything OFF
    
    - **on**: True to start, False to stop (ignored if movement params provided)
    - **speed**: Optional speed value (0-2000) for automatic sequence
    - **forward**: Optional forward/backward value (-2000 to 2000) for automatic sequence
    - **turn**: Optional turn value (-2000 to 2000) for automatic sequence
    """
    # If movement parameters provided, trigger full sequence
    if body.speed is not None and body.forward is not None and body.turn is not None:
        result = service.send_command(body.speed, body.forward, body.turn)
    else:
        # Manual relay control
        result = service.set_relay("starter", body.on)
    
    logger.info("diktum_test.relay.starter", extra={"event": {
        "stage": "test",
        "action": "relay_starter",
        "on": body.on,
        "speed": body.speed,
        "forward": body.forward,
        "turn": body.turn,
        "result": result
    }})
    return result


@router.post("/relay/speed2")
def relay_speed2(
    req: Request,
    body: RelayRequest,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Set speed2 relay on/off.
    
    Optional relay for speed control.
    
    - **on**: True to enable speed2, False to disable
    """
    result = service.set_relay("speed2", body.on)
    logger.info("diktum_test.relay.speed2", extra={"event": {
        "stage": "test",
        "action": "relay_speed2",
        "on": body.on,
        "result": result
    }})
    return result


@router.post("/relay/sound")
def relay_sound(
    req: Request,
    body: RelayRequest,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Set sound relay on/off.
    
    Optional relay for sound control.
    
    - **on**: True to enable sound, False to disable
    """
    result = service.set_relay("sound", body.on)
    logger.info("diktum_test.relay.sound", extra={"event": {
        "stage": "test",
        "action": "relay_sound",
        "on": body.on,
        "result": result
    }})
    return result


@router.post("/relay/stop")
def relay_stop(
    req: Request,
    service: DiktumTestService = Depends(get_test_service_from_request)
):
    """
    Send stop command - turns off all relays.
    
    Sets control byte to 0x00, disabling all relays including permission and starter.
    This is equivalent to an emergency stop.
    """
    result = service.set_relay("stop", False)
    logger.info("diktum_test.relay.stop", extra={"event": {
        "stage": "test",
        "action": "relay_stop",
        "result": result
    }})
    return result


# ---------- NATS-based test endpoints ----------

@router.post("/forward")
async def test_forward(
    req: Request,
    service: DiktumNatsTestService = Depends(get_nats_test_service_from_request)
):
    """
    Test forward movement via NATS.
    
    Send forward movement command
    
    Speed is read from config (`diktum_test_speed_mps`) and converted to Diktum units.
    Command is sent via NATS to `motors.move` subject.
    Motor daemon handles continuous frame sending at 72ms intervals.
    
    Returns:
        Result dictionary with speed in m/s and Diktum units
    """
    result = await service.test_forward()
    logger.info("diktum_test.forward", extra={"event": {
        "stage": "test",
        "action": "forward",
        "result": result
    }})
    return result


@router.post("/turn_180")
async def test_turn_180(
    req: Request,
    service: DiktumNatsTestService = Depends(get_nats_test_service_from_request)
):
    """
    Test 180° clockwise turn via NATS.
    
    Send clockwise turn command (negative turn value)
    
    Speed is read from config (`diktum_test_speed_mps`) and converted to Diktum units.
    Command is sent via NATS to `motors.move` subject.
    Motor daemon handles continuous frame sending at 72ms intervals.
    
    Returns:
        Result dictionary with speed in m/s and Diktum units
    """
    result = await service.test_turn_180()
    logger.info("diktum_test.turn_180", extra={"event": {
        "stage": "test",
        "action": "turn_180",
        "result": result
    }})
    return result


@router.get("/motor_state")
async def get_motor_state(
    req: Request,
    nats_service: DiktumNatsTestService = Depends(get_nats_test_service_from_request)
):
    """
    Get current motor engine state.
    
    Returns:
        Dictionary with motor state:
        - engine_state: Current engine state (ENGINE_OFF, ENGINE_READY, ENGINE_STARTING, ENGINE_RUNNING)
        - permission_active: Whether permission relay is active
        - starter_active: Whether starter relay is active
        - current_sequence: Current sequence ID if any
        - sequence_state: Sequence execution state (IDLE, RUNNING, COMPLETED, STOPPED, ERROR)
    """
    result = await nats_service.get_motor_state()
    logger.info("diktum_test.get_state", extra={"event": {
        "stage": "test",
        "action": "get_motor_state",
        "result": result
    }})
    return result

