import serial
import time

ser = serial.Serial('/dev/ttyAMA0', 115200)

hex_msg = "80 82 48 0E 53 0B 00 00 20 00 D0 07 00 00 00 00 00 00 00 00 00 00 00 00 0D 0A"

for _ in range(20):
    ser.write(bytes.fromhex(hex_msg))
    time.sleep(0.072)
 
time.sleep(2)
# Читаем одну строку (до \n, включая \r\n если есть)
# Читаем всё, что доступно в буфере
buffer = ser.read(ser.in_waiting or 1)  # or 1 — чтобы не читать 0 байт

if buffer:
    # Декодируем и разбиваем на строки по \r\n или \n
    text = buffer.decode('utf-8', errors='replace')
    lines = text.splitlines()
    for line in lines:
        if line.strip():  # пропускаем пустые строки, если нужно
            print("→", line)


