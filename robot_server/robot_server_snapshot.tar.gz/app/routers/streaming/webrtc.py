# routers/webrtc.py
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ...services.system.config import AppConfig
from ...services.streaming.camera_manager import CameraManager
from ...services.streaming.webrtc_service import WebRTCService

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])
logger = logging.getLogger(__name__)


# -------- Dependencies --------
def get_config(request: Request) -> AppConfig:
    return request.app.state.app_config


def get_manager(request: Request) -> CameraManager:
    return request.app.state.camera_manager


def get_webrtc_service(request: Request) -> WebRTCService:
    """Get or create WebRTCService instance."""
    svc = getattr(request.app.state, "webrtc_service", None)
    if svc is None:
        cfg = get_config(request)
        manager = get_manager(request)
        svc = WebRTCService(cfg, manager)
        manager.set_webrtc_service(svc)
        request.app.state.webrtc_service = svc
    return svc


# -------- Request Models --------
class OfferPayload(BaseModel):
    type: str = Field(..., description="SDP type")
    sdp: str = Field(..., min_length=1, description="Session Description")


# -------- Camera Endpoints --------
@router.get("/cameras")
async def list_cameras(mgr: CameraManager = Depends(get_manager)):
    """List available cameras."""
    return {"cameras": mgr.enumerate_cameras()}


# -------- Streaming Endpoints --------
@router.post("/start_stream")
async def start_stream(
    camera_id: int | None = None,
    svc: WebRTCService = Depends(get_webrtc_service),
):
    """Start video streaming."""
    try:
        info = await svc.start_stream(camera_id)
        return info
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Failed to start stream: %s", exc)
        raise HTTPException(status_code=500, detail=f"Stream start failed: {exc}")


@router.post("/switch_camera")
async def switch_camera(
    camera_id: int,
    svc: WebRTCService = Depends(get_webrtc_service),
):
    """Switch to different camera."""
    try:
        info = await svc.switch_camera(camera_id)
        return info
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        logger.exception("Failed to switch camera: %s", exc)
        raise HTTPException(status_code=500, detail=f"Camera switch failed: {exc}")


@router.post("/stop_stream")
async def stop_stream(svc: WebRTCService = Depends(get_webrtc_service)):
    """Stop video streaming."""
    try:
        result = await svc.stop_stream()
        return result
    except Exception as exc:
        logger.exception("Failed to stop stream: %s", exc)
        raise HTTPException(status_code=500, detail=f"Stream stop failed: {exc}")


# -------- WebRTC Signaling --------
@router.post("/offer")
async def offer(
    payload: OfferPayload,
    request: Request,
    svc: WebRTCService = Depends(get_webrtc_service),
):
    """Handle WebRTC offer from client."""
    client_ip = request.client.host if request.client else "127.0.0.1"
    
    try:
        answer = await svc.create_peer_connection(client_ip, payload.sdp, payload.type)
        return answer
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Failed to process offer: %s", exc)
        raise HTTPException(status_code=500, detail=f"Offer processing failed: {exc}")


# -------- Cleanup --------
@router.post("/cleanup")
async def cleanup_client(svc: WebRTCService = Depends(get_webrtc_service)):
    """Cleanup dead connections and idle sources."""
    result = await svc.cleanup()
    return result


# -------- Status --------
@router.get("/status")
async def get_status(svc: WebRTCService = Depends(get_webrtc_service)):
    """Get WebRTC service status."""
    return svc.get_status()


@router.get("/network_info")
async def network_info(request: Request, svc: WebRTCService = Depends(get_webrtc_service)):
    """Get network configuration for client."""
    client_ip = request.client.host if request.client else "127.0.0.1"
    return svc.get_network_info(client_ip)


# -------- Recording Endpoints --------
@router.post("/record/start")
async def start_recording(mgr: CameraManager = Depends(get_manager)):
    """Start recording from all cameras."""
    try:
        sid, files, cams = await mgr.start_recording()
        # Don't return download_zip_url at start - ZIP doesn't exist yet!
        return {
            "session_id": sid,
            "started_cameras": cams,
            "files_expected": [str(p) for p in files],
            "download_zip_url": f"/webrtc/record_{sid}.zip",
        }
    except RuntimeError as exc:
        if "already" in str(exc).lower():
            raise HTTPException(status_code=409, detail=str(exc))
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/record/stop")
async def stop_recording(mgr: CameraManager = Depends(get_manager)):
    """Stop recording and generate ZIP."""
    try:
        sid, files = await mgr.stop_recording()
        zip_url = ""
        if files:
            try:
                zip_path = mgr.build_zip(sid, files)
                zip_url = f"/webrtc/record_{sid}.zip"
            except Exception as exc:
                logger.warning("Failed to build ZIP: %s", exc)
        
        # Ensure zip_url is always returned (even if empty)
        return {
            "session_id": sid,
            "files": [str(p) for p in files],
            "zip_url": zip_url,
        }
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.get("/record_{session_id}.zip")
async def download_zip(session_id: str, mgr: CameraManager = Depends(get_manager)):
    """Download recording ZIP file."""
    zip_path = mgr.get_zip_path(session_id)
    if not zip_path or not zip_path.exists():
        raise HTTPException(status_code=404, detail="ZIP not found")
    return FileResponse(zip_path, media_type="application/zip", filename=zip_path.name)
