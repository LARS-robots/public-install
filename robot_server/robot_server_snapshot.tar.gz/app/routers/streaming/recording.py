"""
Recording API Router - Lightweight HTTP layer for recording control.
All business logic is in RecordingService.
"""
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, List

from ...services.streaming.recording_service import RecordingService

router = APIRouter(prefix="/record", tags=["Recording"])


# Pydantic models for request/response validation
class RecordStartRequest(BaseModel):
    """Request model for starting recording."""
    segment_sec: Optional[int] = None


class RecordStartResponse(BaseModel):
    """Response model for successful recording start."""
    session_id: str
    started_cameras: List[int]
    files_expected: List[str]
    download_zip_url: str


class RecordStopResponse(BaseModel):
    """Response model for successful recording stop."""
    session_id: str
    files: List[str]
    zip_url: str


# Dependency injection - service instance
def get_recording_service(request: Request) -> RecordingService:
    """Get or create RecordingService instance."""
    if not hasattr(request.app.state, "_recording_service"):
        request.app.state._recording_service = RecordingService()
    return request.app.state._recording_service


@router.post("/start", response_model=RecordStartResponse)
async def start_recording(request: Request, body: RecordStartRequest):
    """
    Start recording from all available cameras.
    
    Returns:
        RecordStartResponse: Session ID, camera list, and download URL
        
    Raises:
        409: Recording already active
        500: Failed to start cameras
    """
    service = get_recording_service(request)
    return await service.start_recording(segment_sec=body.segment_sec)


@router.post("/stop", response_model=RecordStopResponse)
async def stop_recording(request: Request):
    """
    Stop active recording and build ZIP archive.
    
    Returns:
        RecordStopResponse: Session ID, file list, and ZIP URL
        
    Raises:
        409: No active recording
        500: Failed to stop recording
    """
    service = get_recording_service(request)
    return await service.stop_recording()


@router.get("/status")
async def get_status(request: Request):
    """Get current recording status."""
    service = get_recording_service(request)
    return service.get_status()


@router.get("/{session_id}.zip")
async def download_zip(request: Request, session_id: str):
    """
    Download recording ZIP archive.
    
    Args:
        session_id: Recording session identifier
        
    Returns:
        FileResponse: ZIP file download
        
    Raises:
        404: ZIP file not found
    """
    service = get_recording_service(request)
    zip_path = service.get_zip_path(session_id)
    
    if not zip_path or not zip_path.exists():
        raise HTTPException(status_code=404, detail="ZIP not found")
    
    return FileResponse(
        path=zip_path,
        media_type="application/zip",
        filename=zip_path.name
    )