from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, HTTPException

from ...routers.system.localization_debug import _connect_nats
from ...services.system.svc_state import read_all_states


router = APIRouter(prefix="/system", tags=["System"])


@router.get("/svc_state")
async def get_svc_state() -> Dict[str, Any]:
    """
    Aggregate service status from NATS KV `svc_state`.

    Returns a mapping:
      {service_name: {service, status, ts, age_sec, details}}
    """
    try:
        nc = await _connect_nats()
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Failed to connect to NATS for svc_state: {e}",
        )

    try:
        data = await read_all_states(nc)
    finally:
        try:
            await nc.drain()
        except Exception:
            await nc.close()

    return data


