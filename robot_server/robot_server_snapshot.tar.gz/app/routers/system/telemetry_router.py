from fastapi import APIRouter, Request, Depends, HTTPException
from ...services.motor.robot_service import get_robot_service, RobotService

import asyncio
import json
import time
from typing import Optional
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError
from nats import errors as nats_errors
from .localization_debug import _connect_nats

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])

# Proper dependency function
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

@router.get("/pose")
async def get_pose(
    robot: RobotService = Depends(get_robot_from_request),
):
    """
    Get current robot pose for map visualization.
    
    Читает последнее состояние локализации из KV `loc_state/current`
    (тот же источник, что и /debug/localization/current) и пробрасывает x,y,yaw в UI.
    
    Если запись отсутствует или устарела, отдаёт 503 с понятным описанием причины.
    """
    nc: Optional[NATS] = None
    try:
        # Подключаемся к NATS и KV так же, как /debug/localization/current
        try:
            nc = await _connect_nats()
        except (ConnectionError, OSError) as connect_error:
            # Ошибки подключения к NATS обрабатываем отдельно
            error_msg = str(connect_error)
            error_type = type(connect_error).__name__
            # Если сообщение уже содержит понятное описание (из _connect_nats), используем его
            if "Таймаут подключения к NATS" in error_msg or "недоступен" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail=error_msg,  # Используем сообщение из _connect_nats
                )
            elif "Connection refused" in error_msg or "No address associated with hostname" in error_msg or "gaierror" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail="Не удалось подключиться к NATS серверу. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "timeout" in error_msg.lower() or "Timeout" in error_type:
                raise HTTPException(
                    status_code=503,
                    detail="Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "connection" in error_msg.lower() or "connect" in error_msg.lower() or "Connection" in error_type:
                raise HTTPException(
                    status_code=503,
                    detail=f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
            else:
                raise HTTPException(
                    status_code=503,
                    detail=f"Не удалось подключиться к NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
        except Exception as connect_error:
            # Другие ошибки подключения (например, asyncio.TimeoutError)
            error_msg = str(connect_error)
            error_type = type(connect_error).__name__
            if "timeout" in error_msg.lower() or "Timeout" in error_type or isinstance(connect_error, (asyncio.TimeoutError, TimeoutError)):
                raise HTTPException(
                    status_code=503,
                    detail="Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "connection" in error_msg.lower() or "connect" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail=f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
            else:
                raise HTTPException(
                    status_code=503,
                    detail=f"Не удалось подключиться к NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
        js = nc.jetstream()
        kv = await js.key_value("loc_state")
        
        # Try to read from motor_odom first (has lat/lon for all robots)
        data = None
        ts = None
        source = "motor_odom"
        
        try:
            entry = await kv.get("motor_odom")
            if entry:
                data = json.loads(entry.value.decode("utf-8"))
                ts = data.get("ts")
                if isinstance(ts, (int, float)):
                    age = time.time() - float(ts)
                    if age <= 2.0:  # Fresh data
                        source = "motor_odom"
        except NotFoundError:
            pass
        except Exception:
            pass
        
        # Fallback to current if motor_odom not available or stale
        if not data or not isinstance(ts, (int, float)) or (time.time() - float(ts)) > 2.0:
            try:
                entry = await kv.get("current")
                if entry:
                    data = json.loads(entry.value.decode("utf-8"))
                    ts = data.get("ts")
                    source = "current"
            except NotFoundError:
                pass
            except Exception:
                pass
        
        if not data:
            raise HTTPException(
                status_code=503,
                detail="Локализация недоступна: ключи loc_state/motor_odom и loc_state/current отсутствуют. Проверьте работу motor_daemon.",
            )
        
        if not isinstance(ts, (int, float)):
            raise HTTPException(
                status_code=503,
                detail="Локализация содержит некорректное поле ts, текущее состояние недоступно.",
            )

        # Check freshness
        age = time.time() - float(ts)
        max_age = 2.0
        if age > max_age:
            raise HTTPException(
                status_code=503,
                detail=f"Локализация не обновлялась {age:.1f} секунд. Проверьте работу motor_daemon.",
            )
        
        # Extract lat/lon (preferred) or x/y (fallback for old data)
        lat = data.get("lat")
        lon = data.get("lon")
        x = data.get("x", 0.0)
        y = data.get("y", 0.0)
        yaw = data.get("yaw", 0.0)
        v = data.get("vx", data.get("speed", 0.0))
        
        # Если lat/lon нет в данных, но есть start_lat/start_lon, вычисляем их из x/y
        if lat is None or lon is None:
            start_lat = data.get("start_lat")
            start_lon = data.get("start_lon")
            if start_lat is not None and start_lon is not None:
                # Конвертируем метры в градусы (приблизительно)
                # 1 градус широты ≈ 111 км, 1 градус долготы ≈ 111 км * cos(latitude)
                lat = start_lat + (y / 111000.0)  # y идет на север (широта)
                lon = start_lon + (x / (111000.0 * abs(start_lat)))  # x идет на восток (долгота)
            else:
                # Fallback для очень старых данных
                lat = x * 1e-5 if abs(x) < 1000 else 0.0
                lon = y * 1e-5 if abs(y) < 1000 else 0.0
        
        # Extract origin from KV data (published by motor_daemon) or config fallback
        start_lat = data.get("start_lat")
        start_lon = data.get("start_lon")
        start_yaw = data.get("start_yaw", 0.0)
        
        # Fallback to config if not in KV data
        if start_lat is None or start_lon is None:
            try:
                app_config = getattr(robot.app_state, "app_config", None)
                if app_config and hasattr(app_config, "start_pose"):
                    start_lat = app_config.start_pose.lat
                    start_lon = app_config.start_pose.lon
                    start_yaw = app_config.start_pose.yaw
                else:
                    # Ultimate fallback
                    start_lat = 55.164441
                    start_lon = 61.436843
                    start_yaw = 0.0
            except Exception:
                # If config access fails, use defaults
                start_lat = 55.164441
                start_lon = 61.436843
                start_yaw = 0.0
        
        # World coordinates: x, y are already in world frame (meters from start_pose)
        # They're the same as robot frame coordinates, but we make it explicit
        world_x = x  # Already in meters from origin
        world_y = y  # Already in meters from origin
        
        return {
            "mode": robot.get_robot_type(),
            "lat": lat,
            "lon": lon,
            "yaw": yaw,
            "v": v,
            "ts": ts,
            # Keep x/y for backward compatibility (but prefer lat/lon)
            "x": x,
            "y": y,
            # New world coordinate system fields
            "world_x": world_x,
            "world_y": world_y,
            "frame": "world",  # Indicates coordinate system
            "origin": {
                "lat": start_lat,
                "lon": start_lon,
                "yaw": start_yaw,
            },
        }
    except NotFoundError:
        # Нет KV bucket или бакета loc_state — это явная ошибка инфраструктуры
        raise HTTPException(
            status_code=503,
            detail="KV bucket loc_state или ключ current не найдены. Проверьте, что motor_daemon и localization_daemon запущены и публикуют локализацию.",
        )
    except HTTPException:
        # HTTPException пробрасываем как есть (не оборачиваем)
        raise
    except (ConnectionError, OSError, TimeoutError, asyncio.TimeoutError, nats_errors.Error, nats_errors.NATSError) as e:
        # Ошибки подключения к NATS (включая специфичные для nats-python)
        error_msg = str(e)
        error_type = type(e).__name__
        if "Connection refused" in error_msg or "No address associated with hostname" in error_msg or "gaierror" in error_msg.lower():
            detail_msg = "Не удалось подключиться к NATS серверу. Проверьте, что контейнер nats запущен и доступен."
        elif "timeout" in error_msg.lower() or "Timeout" in error_type:
            detail_msg = "Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен."
        elif "connection" in error_msg.lower() or "connect" in error_msg.lower():
            detail_msg = f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен."
        else:
            detail_msg = f"Ошибка при работе с NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен."
        raise HTTPException(
            status_code=503,
            detail=detail_msg,
        )
    except Exception as e:
        # Любая другая ошибка при работе с NATS/KV
        error_msg = str(e)
        # Проверяем, не связана ли ошибка с подключением к NATS
        if "connect" in error_msg.lower() or "connection" in error_msg.lower() or "nats" in error_msg.lower():
            raise HTTPException(
                status_code=503,
                detail=f"Не удалось подключиться к NATS. Проверьте, что контейнер nats запущен и доступен. Ошибка: {error_msg}",
            )
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось получить локализацию из NATS/KV: {error_msg}",
        )
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()

@router.get("/debug/planner")
def debug_planner_import(
    robot: RobotService = Depends(get_robot_from_request)
):
    """Debug endpoint to check planner import and config loading"""
    
    # Test import
    try:
        from ...services.navigation.path_planner import HybridPathPlanner, PlannerConfig, LatLon
        import_status = "Import successful"
    except ImportError as e:
        import_status = f"Import failed: {e}"
    
    # Get app_state through robot service
    # Note: We need to pass app_state somehow, let's add it properly
    return {
        "import_status": import_status,
        "robot_type": robot.get_robot_type(),
        "simulator_initialized": robot.init_simulator()
    }