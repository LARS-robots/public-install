from fastapi import APIRouter, Request, Depends, HTTPException
from ...services.motor.robot_service import get_robot_service, RobotService

import asyncio
import json
import time
from typing import Optional
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError
from nats import errors as nats_errors
from .localization_debug import _connect_nats

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])

# Proper dependency function
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

@router.get("/pose")
async def get_pose(
    robot: RobotService = Depends(get_robot_from_request),
):
    """
    Get current robot pose for map visualization.
    
    Читает последнее состояние локализации из KV `loc_state/current`
    (тот же источник, что и /debug/localization/current) и пробрасывает x,y,yaw в UI.
    
    Если запись отсутствует или устарела, отдаёт 503 с понятным описанием причины.
    """
    nc: Optional[NATS] = None
    try:
        # Подключаемся к NATS и KV так же, как /debug/localization/current
        try:
            nc = await _connect_nats()
        except (ConnectionError, OSError) as connect_error:
            # Ошибки подключения к NATS обрабатываем отдельно
            error_msg = str(connect_error)
            error_type = type(connect_error).__name__
            # Если сообщение уже содержит понятное описание (из _connect_nats), используем его
            if "Таймаут подключения к NATS" in error_msg or "недоступен" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail=error_msg,  # Используем сообщение из _connect_nats
                )
            elif "Connection refused" in error_msg or "No address associated with hostname" in error_msg or "gaierror" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail="Не удалось подключиться к NATS серверу. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "timeout" in error_msg.lower() or "Timeout" in error_type:
                raise HTTPException(
                    status_code=503,
                    detail="Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "connection" in error_msg.lower() or "connect" in error_msg.lower() or "Connection" in error_type:
                raise HTTPException(
                    status_code=503,
                    detail=f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
            else:
                raise HTTPException(
                    status_code=503,
                    detail=f"Не удалось подключиться к NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
        except Exception as connect_error:
            # Другие ошибки подключения (например, asyncio.TimeoutError)
            error_msg = str(connect_error)
            error_type = type(connect_error).__name__
            if "timeout" in error_msg.lower() or "Timeout" in error_type or isinstance(connect_error, (asyncio.TimeoutError, TimeoutError)):
                raise HTTPException(
                    status_code=503,
                    detail="Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен.",
                )
            elif "connection" in error_msg.lower() or "connect" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail=f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
            else:
                raise HTTPException(
                    status_code=503,
                    detail=f"Не удалось подключиться к NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен.",
                )
        js = nc.jetstream()
        kv = await js.key_value("loc_state")
        
        # Сначала проверяем, есть ли данные одометрии (motor_daemon работает)
        motor_odom_entry = None
        try:
            motor_odom_entry = await kv.get("motor_odom")
        except NotFoundError:
            pass  # KV bucket может существовать, но ключа motor_odom может не быть
        except Exception:
            pass  # Игнорируем ошибки при проверке motor_odom
        
        entry = await kv.get("current")
        if not entry:
            # Нет локализации - проверяем, какая часть не работает
            if motor_odom_entry:
                detail_msg = "Локализация недоступна: motor_daemon публикует одометрию, но localization_daemon не публикует локализацию. Проверьте работу localization_daemon."
            else:
                detail_msg = "Локализация недоступна: ключ loc_state/current отсутствует. Проверьте работу motor_daemon (должен публиковать одометрию) и localization_daemon (должен публиковать локализацию)."
            raise HTTPException(
                status_code=503,
                detail=detail_msg,
            )
        
        data = json.loads(entry.value.decode("utf-8"))

        ts = data.get("ts")
        if not isinstance(ts, (int, float)):
            raise HTTPException(
                status_code=503,
                detail="Локализация содержит некорректное поле ts, текущее состояние недоступно.",
            )

        # Проверяем «свежесть» позы: если давно не обновлялась, считаем локализацию недоступной.
        age = time.time() - float(ts)
        max_age = 2.0  # c; publish_rate_hz по умолчанию 50 Гц, так что 2 c = устаревшая поза
        if age > max_age:
            # Проверяем, обновляется ли одометрия (чтобы понять, какой демон не работает)
            motor_odom_fresh = False
            if motor_odom_entry:
                try:
                    motor_odom_data = json.loads(motor_odom_entry.value.decode("utf-8"))
                    motor_odom_ts = motor_odom_data.get("ts")
                    if isinstance(motor_odom_ts, (int, float)):
                        motor_odom_age = time.time() - float(motor_odom_ts)
                        motor_odom_fresh = motor_odom_age <= max_age
                except Exception:
                    pass
            
            if motor_odom_fresh:
                detail_msg = f"Локализация не обновлялась {age:.1f} секунд. motor_daemon работает (одометрия свежая), но localization_daemon не публикует локализацию. Проверьте работу localization_daemon."
            else:
                detail_msg = f"Локализация не обновлялась {age:.1f} секунд. Проверьте работу motor_daemon (должен публиковать одометрию) и localization_daemon (должен публиковать локализацию)."
            raise HTTPException(
                status_code=503,
                detail=detail_msg,
            )
        
        return {
            "mode": robot.get_robot_type(),
            "x": data.get("x", 0.0),
            "y": data.get("y", 0.0),
            "yaw": data.get("yaw", 0.0),
            # Скорость вперёд (используется только для HUD)
            "v": data.get("vx", data.get("speed", 0.0)),
            "ts": ts,
        }
    except NotFoundError:
        # Нет KV bucket или бакета loc_state — это явная ошибка инфраструктуры
        raise HTTPException(
            status_code=503,
            detail="KV bucket loc_state или ключ current не найдены. Проверьте, что motor_daemon и localization_daemon запущены и публикуют локализацию.",
        )
    except HTTPException:
        # HTTPException пробрасываем как есть (не оборачиваем)
        raise
    except (ConnectionError, OSError, TimeoutError, asyncio.TimeoutError, nats_errors.Error, nats_errors.NATSError) as e:
        # Ошибки подключения к NATS (включая специфичные для nats-python)
        error_msg = str(e)
        error_type = type(e).__name__
        if "Connection refused" in error_msg or "No address associated with hostname" in error_msg or "gaierror" in error_msg.lower():
            detail_msg = "Не удалось подключиться к NATS серверу. Проверьте, что контейнер nats запущен и доступен."
        elif "timeout" in error_msg.lower() or "Timeout" in error_type:
            detail_msg = "Таймаут при подключении к NATS. Проверьте, что контейнер nats запущен и доступен."
        elif "connection" in error_msg.lower() or "connect" in error_msg.lower():
            detail_msg = f"Ошибка подключения к NATS: {error_msg}. Проверьте, что контейнер nats запущен и доступен."
        else:
            detail_msg = f"Ошибка при работе с NATS ({error_type}): {error_msg}. Проверьте, что контейнер nats запущен и доступен."
        raise HTTPException(
            status_code=503,
            detail=detail_msg,
        )
    except Exception as e:
        # Любая другая ошибка при работе с NATS/KV
        error_msg = str(e)
        # Проверяем, не связана ли ошибка с подключением к NATS
        if "connect" in error_msg.lower() or "connection" in error_msg.lower() or "nats" in error_msg.lower():
            raise HTTPException(
                status_code=503,
                detail=f"Не удалось подключиться к NATS. Проверьте, что контейнер nats запущен и доступен. Ошибка: {error_msg}",
            )
        raise HTTPException(
            status_code=503,
            detail=f"Не удалось получить локализацию из NATS/KV: {error_msg}",
        )
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()

@router.get("/debug/planner")
def debug_planner_import(
    robot: RobotService = Depends(get_robot_from_request)
):
    """Debug endpoint to check planner import and config loading"""
    
    # Test import
    try:
        from ...services.navigation.path_planner import HybridPathPlanner, PlannerConfig, LatLon
        import_status = "Import successful"
    except ImportError as e:
        import_status = f"Import failed: {e}"
    
    # Get app_state through robot service
    # Note: We need to pass app_state somehow, let's add it properly
    return {
        "import_status": import_status,
        "robot_type": robot.get_robot_type(),
        "simulator_initialized": robot.init_simulator()
    }