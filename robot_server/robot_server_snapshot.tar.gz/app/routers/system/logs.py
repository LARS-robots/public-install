# app/routers/logs.py
from __future__ import annotations

import io
import json
import re
import shutil
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import msgpack
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query, BackgroundTasks, HTTPException
from fastapi.responses import Response, FileResponse

# .zst архивы (опционально)
try:
    import zstandard as zstd  # type: ignore
except Exception:  # pragma: no cover
    zstd = None

from ...telemetry import logbus  # твой внутренний шина-логов
from ...services.system.config_loader import get_config

router = APIRouter(prefix="/admin", tags=["Admin"])


# ---------- конфиг путей ----------
def _get_log_backend() -> str:
    """Determine which logging backend to use from config."""
    try:
        config = get_config()
        return config.logging.backend
    except Exception:
        return "sqlite"  # Default to SQLite


def _get_log_config() -> Dict[str, str]:
    """Get logging configuration from centralized config."""
    try:
        config = get_config()
        return {
            "live_dir": config.logging.live_dir,
            "archive_dir": config.logging.archive_dir,
            "sqlite_path": config.logging.sqlite.path if config.logging.sqlite else None,
            "sqlite_partitioning": config.logging.sqlite.partitioning if config.logging.sqlite else "none",
            "sqlite_query_max_months": str(
                getattr(config.logging.sqlite, "query_max_months", 6) if config.logging.sqlite else 6
            ),
        }
    except Exception:
        return {
            "live_dir": "/var/log/lars/live",
            "archive_dir": "/var/log/lars/archive",
            "sqlite_path": "/var/log/lars/sqlite/logs.db",
            "sqlite_partitioning": "none",
            "sqlite_query_max_months": "6",
        }

_log_cfg = _get_log_config()
LIVE_DIR    = Path(_log_cfg["live_dir"])
ARCHIVE_DIR = Path(_log_cfg["archive_dir"])
SQLITE_PATH = Path(_log_cfg["sqlite_path"]) if _log_cfg.get("sqlite_path") else None
SQLITE_PARTITIONING = str(_log_cfg.get("sqlite_partitioning", "none")).lower()
try:
    SQLITE_QUERY_MAX_MONTHS = float(_log_cfg.get("sqlite_query_max_months", "6") or 6)
except Exception:
    SQLITE_QUERY_MAX_MONTHS = 6.0
_FTS_MIGRATED: set[str] = set()
_FTS_MIGRATION_FAILED: set[str] = set()

# ---------- чтение лог-файлов ----------
def _iter_file_events(path: Path) -> Iterable[Dict[str, Any]]:
    """
    Итерация событий из файла логов.
    
    Поддерживает форматы:
    - MessagePack: .msgp, .msgp.zst (legacy формат от MsgpackZstdSegmentHandler)
    - JSONL: .json, .json.zst (новый формат от logger-daemon)
    
    Args:
        path: Путь к файлу логов
        
    Yields:
        Словари с событиями логов
    """
    try:
        # Определяем формат файла по расширению
        is_compressed = path.suffix == ".zst"
        base_name = path.stem if is_compressed else path.name
        is_jsonl = base_name.endswith(".json")
        is_msgpack = base_name.endswith(".msgp")
        
        # Обработка сжатых файлов
        if is_compressed:
            if zstd is None:
                return
            decompressor = zstd.ZstdDecompressor()
            with path.open("rb") as f, decompressor.stream_reader(f) as reader:
                data = reader.read()
            
            if is_jsonl:
                # JSONL из сжатого файла
                text = data.decode("utf-8", errors="ignore")
                for line in text.splitlines():
                    line = line.strip()
                    if line:
                        try:
                            event = json.loads(line)
                            if isinstance(event, dict):
                                yield event
                        except json.JSONDecodeError:
                            continue  # Пропускаем битые строки
            elif is_msgpack:
                # MessagePack из сжатого файла
                unpacker = msgpack.Unpacker(io.BytesIO(data), raw=False)
                for obj in unpacker:
                    if isinstance(obj, dict):
                        yield obj
        else:
            # Несжатые файлы
            if is_jsonl:
                # JSONL формат (logger-daemon): одна строка JSON на событие
                with path.open("r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                event = json.loads(line)
                                if isinstance(event, dict):
                                    yield event
                            except json.JSONDecodeError:
                                continue  # Пропускаем битые строки
            elif is_msgpack:
                # MessagePack формат (legacy)
                unpacker = msgpack.Unpacker(path.open("rb"), raw=False)
                for obj in unpacker:
                    if isinstance(obj, dict):
                        yield obj
    except Exception:
        return  # Битые/обрезанные файлы игнорируем


def _list_log_files(newest_first: bool = True) -> List[Path]:
    """
    Список файлов логов для чтения.
    
    Поддерживает оба формата:
    - MessagePack: robot-*.msgp, robot-*.msgp.zst (legacy, от MsgpackZstdSegmentHandler)
    - JSONL: robot-*.json, robot-*.json.zst (новый формат, от logger-daemon)
    
    Приоритет: JSONL файлы имеют приоритет над MessagePack (если есть оба).
    
    Args:
        newest_first: Сортировать по времени модификации (новые первые)
        
    Returns:
        Список путей к файлам логов, отсортированный по времени модификации
    """
    files: List[Path] = []
    
    # Архивные файлы (сначала JSONL, потом MessagePack)
    if ARCHIVE_DIR.exists():
        # JSONL архивы (новый формат от logger-daemon)
        jsonl_archives = list(ARCHIVE_DIR.glob("robot-*.json.zst"))
        jsonl_archives += list(ARCHIVE_DIR.glob("robot-*.json"))
        files += jsonl_archives
        
        # MessagePack архивы (legacy формат)
        msgpack_archives = list(ARCHIVE_DIR.glob("robot-*.msgp.zst"))
        msgpack_archives += list(ARCHIVE_DIR.glob("robot-*.msgp"))
        files += msgpack_archives
    
    # Текущие файлы (live)
    if LIVE_DIR.exists():
        # Приоритет: JSONL (logger-daemon) над MessagePack (legacy)
        jsonl_current = LIVE_DIR / "robot-current.json"
        msgpack_current = LIVE_DIR / "robot-current.msgp"
        
        if jsonl_current.exists():
            files.append(jsonl_current)
        elif msgpack_current.exists():
            files.append(msgpack_current)
    
    # Сортировка по времени модификации
    files.sort(key=lambda p: p.stat().st_mtime, reverse=newest_first)
    return files


def _collect_log_files() -> List[Path]:
    """Собрать все файлы логов из live и archive директорий."""
    files: List[Path] = []
    patterns = [
        "robot-current.json",
        "robot-current.msgp",
        "robot-*.json",
        "robot-*.json.zst",
        "robot-*.msgp",
        "robot-*.msgp.zst",
    ]
    for base_dir in (LIVE_DIR, ARCHIVE_DIR):
        if not base_dir.exists():
            continue
        for pattern in patterns:
            files.extend(base_dir.glob(pattern))
    # Уникализируем и сортируем по времени изменения (новые первые)
    unique = {p.resolve(): p for p in files}
    out = list(unique.values())
    out.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return out


def _file_kind(path: Path) -> str:
    name = path.name.lower()
    if name.endswith(".json") or name.endswith(".json.zst"):
        return "jsonl"
    if name.endswith(".msgp") or name.endswith(".msgp.zst"):
        return "msgpack"
    if name.endswith(".db"):
        return "sqlite"
    return "file"


def _sqlite_count() -> int:
    paths = _list_sqlite_dbs()
    if not paths:
        return 0
    try:
        total = 0
        for path in paths:
            conn = sqlite3.connect(str(path), timeout=5.0)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM logs")
            row = cursor.fetchone()
            conn.close()
            total += int(row[0] or 0)
        return total
    except Exception:
        return 0


def _list_sqlite_dbs() -> List[Path]:
    """Список SQLite БД (с учетом партиционирования)."""
    if not SQLITE_PATH:
        return []
    if SQLITE_PARTITIONING == "none":
        base_dir = SQLITE_PATH.parent
        base_stem = SQLITE_PATH.stem or "logs"
        pattern = f"{base_stem}-*.db"
        files = list(base_dir.glob(pattern))
        if files:
            files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            # Include logs.db if present (old non-partitioned file)
            if SQLITE_PATH.exists():
                files.append(SQLITE_PATH)
            return files
        return [SQLITE_PATH] if SQLITE_PATH.exists() else []
    
    base_dir = SQLITE_PATH.parent
    base_stem = SQLITE_PATH.stem or "logs"
    pattern = f"{base_stem}-*.db"
    files = list(base_dir.glob(pattern))
    if not files:
        return []
    
    # Сортировка: новые сначала
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    # Ограничение по истории (query_max_months)
    if SQLITE_QUERY_MAX_MONTHS and SQLITE_QUERY_MAX_MONTHS > 0:
        cutoff = time.time() - SQLITE_QUERY_MAX_MONTHS * 30 * 24 * 3600
        filtered: List[Path] = []
        for path in files:
            try:
                ts = _parse_partition_timestamp(path)
                mtime = path.stat().st_mtime
            except Exception:
                continue
            if ts is None:
                if mtime >= cutoff:
                    filtered.append(path)
            else:
                if ts >= cutoff or mtime >= cutoff:
                    filtered.append(path)
        return filtered

    return files


def _parse_partition_timestamp(path: Path) -> Optional[float]:
    if not SQLITE_PATH:
        return None
    base_stem = SQLITE_PATH.stem or "logs"
    stem = path.stem
    prefix = f"{base_stem}-"
    if not stem.startswith(prefix):
        return None
    suffix = stem[len(prefix):]
    for fmt in ("%Y%m%d-%H", "%Y%m%d"):
        try:
            return time.mktime(time.strptime(suffix, fmt))
        except Exception:
            continue
    return None


def _filter_sqlite_dbs_by_hours(hours: int) -> List[Path]:
    if hours <= 0:
        return []
    cutoff = time.time() - hours * 3600
    paths = _list_sqlite_dbs()
    filtered: List[Path] = []
    for path in paths:
        try:
            ts = _parse_partition_timestamp(path)
            mtime = path.stat().st_mtime
        except Exception:
            continue
        if ts is None:
            if mtime >= cutoff:
                filtered.append(path)
        else:
            if ts >= cutoff or mtime >= cutoff:
                filtered.append(path)
    return filtered


def _filter_sqlite_dbs_by_date(date_str: str) -> List[Path]:
    try:
        day = time.strptime(date_str, "%Y-%m-%d")
        start_ts = time.mktime(day)
    except Exception:
        return []
    end_ts = start_ts + 86400
    paths = _list_sqlite_dbs()
    filtered: List[Path] = []
    for path in paths:
        try:
            ts = _parse_partition_timestamp(path)
            mtime = path.stat().st_mtime
        except Exception:
            continue
        if ts is None:
            if start_ts <= mtime < end_ts:
                filtered.append(path)
        else:
            if start_ts <= ts < end_ts or start_ts <= mtime < end_ts:
                filtered.append(path)
    return filtered


def _sqlite_backup(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    src_conn = sqlite3.connect(str(src), timeout=5.0)
    try:
        dest_conn = sqlite3.connect(str(dest))
        try:
            src_conn.backup(dest_conn)
        finally:
            dest_conn.close()
    finally:
        src_conn.close()


def _query_sqlite_latest(limit: int = 10) -> List[Dict[str, Any]]:
    """Return last N log entries from SQLite (minimal fields)."""
    if not SQLITE_PATH or not SQLITE_PATH.exists():
        return []
    try:
        conn = sqlite3.connect(str(SQLITE_PATH), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT ts, level, service, logger, msg
            FROM logs
            ORDER BY ts DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = cursor.fetchall()
        conn.close()
        return [
            {
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
            }
            for row in rows
        ]
    except Exception:
        return []


def _sqlite_db_info(path: Path) -> Dict[str, Any]:
    info = {
        "name": path.name,
        "path": str(path),
        "size_bytes": 0,
        "mtime": 0,
        "records_count": 0,
        "fts_enabled": False,
    }
    try:
        stat = path.stat()
        info["size_bytes"] = stat.st_size
        info["mtime"] = int(stat.st_mtime)
    except Exception:
        return info

    try:
        conn = sqlite3.connect(str(path), timeout=5.0)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='logs' LIMIT 1")
        has_logs = cursor.fetchone() is not None
        if has_logs:
            cursor.execute("SELECT COUNT(*) FROM logs")
            row = cursor.fetchone()
            info["records_count"] = int(row[0] or 0)
        cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='logs_fts' LIMIT 1")
        info["fts_enabled"] = cursor.fetchone() is not None
        conn.close()
    except Exception:
        try:
            conn.close()
        except Exception:
            pass
    return info


def _sqlite_level_counts_last_hours(levels: List[str], hours: int) -> Dict[str, int]:
    counts = {level: 0 for level in levels}
    if hours <= 0:
        return counts
    cutoff_ms = int((time.time() - hours * 3600) * 1000)
    for path in _list_sqlite_dbs():
        try:
            conn = sqlite3.connect(str(path), timeout=5.0)
            cursor = conn.cursor()
            placeholders = ",".join("?" * len(levels))
            cursor.execute(
                f"SELECT level, COUNT(*) FROM logs WHERE ts >= ? AND level IN ({placeholders}) GROUP BY level",
                [cutoff_ms, *levels],
            )
            for row in cursor.fetchall():
                lvl = str(row[0]).upper()
                if lvl in counts:
                    counts[lvl] += int(row[1] or 0)
            conn.close()
        except Exception:
            try:
                conn.close()
            except Exception:
                pass
            continue
    return counts


def _parse_ts(ts: str) -> float:
    # 'YYYY-MM-DDTHH:MM:SS' → epoch (UTC-like)
    try:
        return time.mktime(time.strptime(ts, "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0.0


def _match(
    ev: Dict[str, Any],
    levels: Optional[set] = None,
    sid_sub: Optional[str] = None,
    regex: Optional[re.Pattern] = None,
) -> bool:
    lvl = str(ev.get("level", "INFO")).upper()
    if levels and lvl not in levels:
        return False
    if sid_sub and sid_sub not in str(ev.get("session_id", "")):
        return False
    if regex:
        try:
            s = json.dumps(ev, ensure_ascii=False, separators=(",", ":"))
            if not regex.search(s):
                return False
        except Exception:
            if not regex.search(repr(ev)):
                return False
    return True


# ---------- SQLite query functions ----------
def _parse_event_json(event_json: str) -> Dict[str, Any]:
    """Parse event_json TEXT field back to dict."""
    try:
        return json.loads(event_json)
    except Exception:
        return {}


def _build_fts_query(q: str) -> Optional[str]:
    """Build a safe FTS5 query with prefix matching."""
    tokens = re.findall(r"[^\W_]+", q, flags=re.UNICODE)
    if not tokens:
        return None
    return " AND ".join(f"{t}*" for t in tokens)


def _fts_available(conn: sqlite3.Connection) -> bool:
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='logs_fts' LIMIT 1"
        )
        return cursor.fetchone() is not None
    except Exception:
        return False


def _ensure_fts(conn: sqlite3.Connection, db_path: Path) -> None:
    key = str(db_path)
    if key in _FTS_MIGRATION_FAILED or key in _FTS_MIGRATED:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='logs' LIMIT 1")
        if cursor.fetchone() is None:
            _FTS_MIGRATION_FAILED.add(key)
            return
        cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='logs_fts' LIMIT 1")
        if cursor.fetchone() is not None:
            _FTS_MIGRATED.add(key)
            return
        cursor.execute(
            """
            CREATE VIRTUAL TABLE IF NOT EXISTS logs_fts USING fts5(
                msg,
                event_json,
                logger,
                service,
                level,
                content='logs',
                content_rowid='id'
            )
            """
        )
        cursor.execute(
            """
            CREATE TRIGGER IF NOT EXISTS logs_ai AFTER INSERT ON logs BEGIN
                INSERT INTO logs_fts(rowid, msg, event_json, logger, service, level)
                VALUES (new.id, new.msg, new.event_json, new.logger, new.service, new.level);
            END;
            """
        )
        cursor.execute(
            """
            CREATE TRIGGER IF NOT EXISTS logs_ad AFTER DELETE ON logs BEGIN
                INSERT INTO logs_fts(logs_fts, rowid, msg, event_json, logger, service, level)
                VALUES ('delete', old.id, old.msg, old.event_json, old.logger, old.service, old.level);
            END;
            """
        )
        cursor.execute(
            """
            CREATE TRIGGER IF NOT EXISTS logs_au AFTER UPDATE ON logs BEGIN
                INSERT INTO logs_fts(logs_fts, rowid, msg, event_json, logger, service, level)
                VALUES ('delete', old.id, old.msg, old.event_json, old.logger, old.service, old.level);
                INSERT INTO logs_fts(rowid, msg, event_json, logger, service, level)
                VALUES (new.id, new.msg, new.event_json, new.logger, new.service, new.level);
            END;
            """
        )
        cursor.execute("INSERT INTO logs_fts(logs_fts) VALUES ('rebuild')")
        conn.commit()
        _FTS_MIGRATED.add(key)
    except Exception:
        _FTS_MIGRATION_FAILED.add(key)


def _build_sql_filters(
    want_levels: set,
    sid: Optional[str],
    q: Optional[str],
    *,
    use_fts: bool,
    fts_query: Optional[str],
) -> tuple[str, List[Any]]:
    """Собрать WHERE и параметры для SQLite (фильтры в БД, без пост-фильтрации)."""
    where_parts: List[str] = []
    params: List[Any] = []

    if want_levels:
        placeholders = ",".join("?" * len(want_levels))
        where_parts.append(f"logs.level IN ({placeholders})")
        params.extend(want_levels)

    # session_id хранится в JSON, фильтруем по event_json
    sid_value = (sid or "").strip()
    if sid_value:
        params.append(f'%\"session_id\":\"{sid_value}%')
        where_parts.append("logs.event_json LIKE ?")

    # Поиск: FTS5 если доступен, иначе LIKE
    q_value = (q or "").strip().lower()
    if q_value:
        if use_fts and fts_query:
            where_parts.append("logs_fts MATCH ?")
            params.append(fts_query)
        else:
            pattern = f"%{q_value}%"
            where_parts.append(
                "(LOWER(logs.msg) LIKE ? OR LOWER(logs.event_json) LIKE ? OR "
                "LOWER(logs.logger) LIKE ? OR LOWER(logs.service) LIKE ?)"
            )
            params.extend([pattern, pattern, pattern, pattern])

    where_clause = "WHERE " + " AND ".join(where_parts) if where_parts else ""
    return where_clause, params


def _query_sqlite_tail_single(
    db_path: Path,
    limit: int,
    want_levels: set,
    sid: Optional[str],
    q: Optional[str],
) -> List[Dict[str, Any]]:
    """Query last N logs from SQLite database."""
    if not db_path.exists():
        return []
    
    try:
        conn = sqlite3.connect(str(db_path), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        fts_query = _build_fts_query(q or "") if q else None
        if q:
            _ensure_fts(conn, db_path)
        use_fts = bool(q) and _fts_available(conn) and fts_query is not None
        where_clause, params = _build_sql_filters(
            want_levels, sid, q, use_fts=use_fts, fts_query=fts_query
        )
        
        # Query with limit
        join_clause = "JOIN logs_fts ON logs_fts.rowid = logs.id" if use_fts else ""
        query = f"""
            SELECT logs.* FROM logs
            {join_clause}
            {where_clause}
            ORDER BY logs.ts DESC
            LIMIT ?
        """
        params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        # Convert rows to dicts, parsing event_json
        events = []
        for row in rows:
            # Parse event_json to get full event data
            event = _parse_event_json(row["event_json"]) if row["event_json"] else {}
            
            # Override with indexed columns (they're authoritative)
            event.update({
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
                "hostname": row["hostname"],
                "pid": row["pid"],
                "subject": row["subject"],
            })
            
            events.append(event)
        
        conn.close()
        return events
    
    except Exception as e:
        # Log error but don't crash
        try:
            import sys
            sys.stderr.write(f"[logs.py] SQLite query error: {e}\n")
        except Exception:
            pass
        return []


def _query_sqlite_before_single(
    db_path: Path,
    before_ts: str,
    limit: int,
    want_levels: set,
    sid: Optional[str],
    q: Optional[str],
) -> List[Dict[str, Any]]:
    """Query logs older than before_ts from SQLite database."""
    if not db_path.exists():
        return []
    
    try:
        # Parse before_ts to epoch milliseconds
        cutoff = _parse_ts(before_ts)
        cutoff_ms = int(cutoff * 1000) if cutoff < 1e10 else int(cutoff)
        
        conn = sqlite3.connect(str(db_path), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        fts_query = _build_fts_query(q or "") if q else None
        if q:
            _ensure_fts(conn, db_path)
        use_fts = bool(q) and _fts_available(conn) and fts_query is not None
        where_clause, params = _build_sql_filters(
            want_levels, sid, q, use_fts=use_fts, fts_query=fts_query
        )
        if where_clause:
            where_clause = f"{where_clause} AND logs.ts < ?"
        else:
            where_clause = "WHERE logs.ts < ?"
        params.append(cutoff_ms)
        
        # Query with limit
        join_clause = "JOIN logs_fts ON logs_fts.rowid = logs.id" if use_fts else ""
        query = f"""
            SELECT logs.* FROM logs
            {join_clause}
            {where_clause}
            ORDER BY logs.ts DESC
            LIMIT ?
        """
        params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        # Convert rows to dicts
        events = []
        for row in rows:
            event = _parse_event_json(row["event_json"]) if row["event_json"] else {}
            event.update({
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
                "hostname": row["hostname"],
                "pid": row["pid"],
                "subject": row["subject"],
            })
            
            events.append(event)
        
        conn.close()
        return events
    
    except Exception as e:
        try:
            import sys
            sys.stderr.write(f"[logs.py] SQLite query error: {e}\n")
        except Exception:
            pass
        return []


# ---------- SQLite pagination helpers ----------
def _sqlite_count_filtered_single(
    db_path: Path,
    want_levels: set,
    sid: Optional[str],
    q: Optional[str],
) -> int:
    if not db_path.exists():
        return 0
    try:
        conn = sqlite3.connect(str(db_path), timeout=5.0)
        cursor = conn.cursor()
        fts_query = _build_fts_query(q or "") if q else None
        if q:
            _ensure_fts(conn, db_path)
        use_fts = bool(q) and _fts_available(conn) and fts_query is not None
        where_clause, params = _build_sql_filters(
            want_levels, sid, q, use_fts=use_fts, fts_query=fts_query
        )
        join_clause = "JOIN logs_fts ON logs_fts.rowid = logs.id" if use_fts else ""
        query = f"""
            SELECT COUNT(*) FROM logs
            {join_clause}
            {where_clause}
        """
        cursor.execute(query, params)
        row = cursor.fetchone()
        conn.close()
        return int(row[0] or 0) if row else 0
    except Exception:
        try:
            conn.close()
        except Exception:
            pass
        return 0


def _query_sqlite_page_single(
    db_path: Path,
    limit: int,
    offset: int,
    want_levels: set,
    sid: Optional[str],
    q: Optional[str],
) -> List[Dict[str, Any]]:
    if not db_path.exists():
        return []
    try:
        conn = sqlite3.connect(str(db_path), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        fts_query = _build_fts_query(q or "") if q else None
        if q:
            _ensure_fts(conn, db_path)
        use_fts = bool(q) and _fts_available(conn) and fts_query is not None
        where_clause, params = _build_sql_filters(
            want_levels, sid, q, use_fts=use_fts, fts_query=fts_query
        )
        join_clause = "JOIN logs_fts ON logs_fts.rowid = logs.id" if use_fts else ""
        query = f"""
            SELECT logs.* FROM logs
            {join_clause}
            {where_clause}
            ORDER BY logs.ts DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, params)
        rows = cursor.fetchall()
        events = []
        for row in rows:
            event = _parse_event_json(row["event_json"]) if row["event_json"] else {}
            event.update({
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
                "hostname": row["hostname"],
                "pid": row["pid"],
                "subject": row["subject"],
            })
            events.append(event)
        conn.close()
        return events
    except Exception:
        try:
            conn.close()
        except Exception:
            pass
        return []


# ---------- API: tail / before ----------
@router.get("/logs/tail")
def logs_tail(
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает последние `limit` событий с серверной фильтрацией.
    Использует SQLite или JSONL в зависимости от конфигурации.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None
    
    backend = _get_log_backend()
    
    # Use SQLite if backend is "sqlite" or "both"
    if backend in ("sqlite", "both"):
        events = []
        for path in _list_sqlite_dbs():
            if len(events) >= limit:
                break
            chunk = _query_sqlite_tail_single(path, limit - len(events), want_levels, sid or None, q or None)
            events.extend(chunk)
        if events or backend == "sqlite":
            # If SQLite returned results or backend is sqlite-only, return them
            return Response(
                content=msgpack.packb(events, use_bin_type=True),
                media_type="application/msgpack",
            )
    
    # Fallback to JSONL file reading
    from collections import deque
    ring = deque(maxlen=limit)

    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            if _match(ev, want_levels, sid or None, regex):
                ring.append(ev)
        # ring сам удержит последний хвост
    data = list(ring)
    return Response(
        content=msgpack.packb(data, use_bin_type=True),
        media_type="application/msgpack",
    )


@router.get("/logs/before")
def logs_before(
    before_ts: str = Query(..., description="ISO ts of oldest item in view (YYYY-MM-DDTHH:MM:SS)"),
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает ещё `limit` событий, которые старше `before_ts`.
    Использует SQLite или JSONL в зависимости от конфигурации.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None
    
    backend = _get_log_backend()
    
    # Use SQLite if backend is "sqlite" or "both"
    if backend in ("sqlite", "both"):
        events = []
        for path in _list_sqlite_dbs():
            if len(events) >= limit:
                break
            chunk = _query_sqlite_before_single(path, before_ts, limit - len(events), want_levels, sid or None, q or None)
            events.extend(chunk)
        if events or backend == "sqlite":
            # If SQLite returned results or backend is sqlite-only, return them
            return Response(
                content=msgpack.packb(events, use_bin_type=True),
                media_type="application/msgpack",
            )
    
    # Fallback to JSONL file reading
    cutoff = _parse_ts(before_ts)
    out: List[Dict[str, Any]] = []
    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            ts = _parse_ts(str(ev.get("ts", "")))
            if ts and ts < cutoff and _match(ev, want_levels, sid or None, regex):
                out.append(ev)
                if len(out) >= limit:
                    return Response(
                        content=msgpack.packb(out, use_bin_type=True),
                        media_type="application/msgpack",
                    )
    return Response(
        content=msgpack.packb(out, use_bin_type=True),
        media_type="application/msgpack",
    )


@router.get("/logs/page")
def logs_page(
    page: int = Query(1, ge=1),
    page_size: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает страницу логов по номеру страницы.
    Пагинация выполняется на стороне SQL.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None
    backend = _get_log_backend()

    total_count = 0
    events: List[Dict[str, Any]] = []
    if backend in ("sqlite", "both"):
        skip = (page - 1) * page_size
        remaining = page_size
        for path in _list_sqlite_dbs():
            db_count = _sqlite_count_filtered_single(path, want_levels, sid or None, q or None)
            total_count += db_count
            if skip >= db_count:
                skip -= db_count
                continue
            if remaining <= 0:
                break
            chunk = _query_sqlite_page_single(
                path,
                remaining,
                skip,
                want_levels,
                sid or None,
                q or None,
            )
            events.extend(chunk)
            remaining = page_size - len(events)
            skip = 0
        if events or backend == "sqlite":
            return Response(
                content=msgpack.packb(events, use_bin_type=True),
                media_type="application/msgpack",
                headers={
                    "X-Total-Count": str(total_count),
                    "X-Page": str(page),
                    "X-Page-Size": str(page_size),
                },
            )

    # Fallback to JSONL (best-effort, total unknown)
    offset = (page - 1) * page_size
    out: List[Dict[str, Any]] = []
    skipped = 0
    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            if _match(ev, want_levels, sid or None, regex):
                if skipped < offset:
                    skipped += 1
                    continue
                out.append(ev)
                if len(out) >= page_size:
                    return Response(
                        content=msgpack.packb(out, use_bin_type=True),
                        media_type="application/msgpack",
                        headers={
                            "X-Total-Count": "-1",
                            "X-Page": str(page),
                            "X-Page-Size": str(page_size),
                        },
                    )
    return Response(
        content=msgpack.packb(out, use_bin_type=True),
        media_type="application/msgpack",
        headers={
            "X-Total-Count": "-1",
            "X-Page": str(page),
            "X-Page-Size": str(page_size),
        },
    )

# ---------- WS: live ----------
@router.websocket("/logs/ws")
async def logs_ws(ws: WebSocket) -> None:
    """
    Постоянный поток событий лога через WebSocket.

    Клиент закрывает соединение при нажатии 'Pause' и открывает заново на 'Resume'.
    Тут просто корректно завершаем подписку при разрыве.
    """
    await ws.accept()
    q = await logbus.subscribe()
    try:
        snap = logbus.snapshot()
        if snap:
            await ws.send_bytes(msgpack.packb({"type": "snapshot", "items": snap}, use_bin_type=True))
        while True:
            item = await q.get()
            await ws.send_bytes(msgpack.packb({"type": "evt", "item": item}, use_bin_type=True))
    except WebSocketDisconnect:
        pass
    finally:
        await logbus.unsubscribe(q)


@router.get("/logs/stats")
def logs_stats() -> Dict[str, Any]:
    """
    Статистика логов для UI:
    - список файлов логов и их размер
    - количество записей в SQLite
    """
    files_payload = []
    for path in _collect_log_files():
        try:
            stat = path.stat()
            files_payload.append({
                "name": path.name,
                "path": str(path),
                "size_bytes": stat.st_size,
                "mtime": int(stat.st_mtime),
                "kind": _file_kind(path),
            })
        except Exception:
            continue
    
    sqlite_payload = None
    if SQLITE_PATH:
        try:
            stat = SQLITE_PATH.stat() if SQLITE_PATH.exists() else None
            sqlite_payload = {
                "path": str(SQLITE_PATH),
                "exists": SQLITE_PATH.exists(),
                "size_bytes": stat.st_size if stat else 0,
                "mtime": int(stat.st_mtime) if stat else 0,
            }
        except Exception:
            sqlite_payload = {
                "path": str(SQLITE_PATH),
                "exists": False,
                "size_bytes": 0,
                "mtime": 0,
            }
    
    return {
        "files": files_payload,
        "sqlite": sqlite_payload,
        "sqlite_partitions": [_sqlite_db_info(p) for p in _list_sqlite_dbs()],
        "level_counts_24h": _sqlite_level_counts_last_hours(["ERROR", "WARNING"], 24),
        "records_count": _sqlite_count(),
        "latest_logs": _query_sqlite_latest(10),
    }


@router.get("/logs/dump")
def logs_dump(
    background_tasks: BackgroundTasks,
    hours: int = Query(24, ge=1, le=168),
    date: str = Query("", description="YYYY-MM-DD"),
) -> FileResponse:
    if not SQLITE_PATH:
        raise HTTPException(status_code=404, detail="SQLite logging path is not configured")

    date_value = (date or "").strip()
    if date_value:
        selected = _filter_sqlite_dbs_by_date(date_value)
    else:
        selected = _filter_sqlite_dbs_by_hours(hours)
    if not selected:
        raise HTTPException(status_code=404, detail="No SQLite log partitions found for requested window")

    temp_dir = Path(tempfile.mkdtemp(prefix="logs-dump-"))
    backup_dir = temp_dir / "sqlite"
    backup_dir.mkdir(parents=True, exist_ok=True)

    files_meta: List[Dict[str, Any]] = []
    errors: List[str] = []
    for path in selected:
        try:
            backup_path = backup_dir / path.name
            _sqlite_backup(path, backup_path)
            stat = path.stat()
            files_meta.append(
                {
                    "name": path.name,
                    "path": str(path),
                    "size_bytes": stat.st_size,
                    "mtime": int(stat.st_mtime),
                }
            )
        except Exception as e:
            errors.append(f"{path.name}: {e}")

    if not files_meta:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(status_code=500, detail="Failed to create SQLite backups")

    metadata = {
        "generated_at": int(time.time()),
        "hours": hours,
        "date": date_value or None,
        "files": files_meta,
        "errors": errors,
        "sqlite_path": str(SQLITE_PATH),
    }
    metadata_path = temp_dir / "metadata.json"
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    zip_path = temp_dir / f"logs-dump-{metadata['generated_at']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_path in backup_dir.iterdir():
            if file_path.is_file():
                zf.write(file_path, arcname=f"sqlite/{file_path.name}")
        zf.write(metadata_path, arcname="metadata.json")

    background_tasks.add_task(shutil.rmtree, temp_dir, ignore_errors=True)
    return FileResponse(
        path=str(zip_path),
        filename=zip_path.name,
        media_type="application/zip",
        background=background_tasks,
    )
