# app/routers/logs.py
from __future__ import annotations

import io
import json
import re
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import msgpack
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import Response, FileResponse

# .zst архивы (опционально)
try:
    import zstandard as zstd  # type: ignore
except Exception:  # pragma: no cover
    zstd = None

from ...telemetry import logbus  # твой внутренний шина-логов
from ...services.system.config_loader import get_config

router = APIRouter(prefix="/admin", tags=["Admin"])


# ---------- конфиг путей ----------
def _get_log_backend() -> str:
    """Determine which logging backend to use from config."""
    try:
        config = get_config()
        return config.logging.backend
    except Exception:
        return "sqlite"  # Default to SQLite


def _get_log_config() -> Dict[str, str]:
    """Get logging configuration from centralized config."""
    try:
        config = get_config()
        return {
            "live_dir": config.logging.live_dir,
            "archive_dir": config.logging.archive_dir,
            "sqlite_path": config.logging.sqlite.path if config.logging.sqlite else None,
        }
    except Exception:
        return {
            "live_dir": "/var/log/lars/live",
            "archive_dir": "/var/log/lars/archive",
            "sqlite_path": "/var/log/lars/sqlite/logs.db",
        }

_log_cfg = _get_log_config()
LIVE_DIR    = Path(_log_cfg["live_dir"])
ARCHIVE_DIR = Path(_log_cfg["archive_dir"])
SQLITE_PATH = Path(_log_cfg["sqlite_path"]) if _log_cfg.get("sqlite_path") else None

# ---------- чтение лог-файлов ----------
def _iter_file_events(path: Path) -> Iterable[Dict[str, Any]]:
    """
    Итерация событий из файла логов.
    
    Поддерживает форматы:
    - MessagePack: .msgp, .msgp.zst (legacy формат от MsgpackZstdSegmentHandler)
    - JSONL: .json, .json.zst (новый формат от logger-daemon)
    
    Args:
        path: Путь к файлу логов
        
    Yields:
        Словари с событиями логов
    """
    try:
        # Определяем формат файла по расширению
        is_compressed = path.suffix == ".zst"
        base_name = path.stem if is_compressed else path.name
        is_jsonl = base_name.endswith(".json")
        is_msgpack = base_name.endswith(".msgp")
        
        # Обработка сжатых файлов
        if is_compressed:
            if zstd is None:
                return
            decompressor = zstd.ZstdDecompressor()
            with path.open("rb") as f, decompressor.stream_reader(f) as reader:
                data = reader.read()
            
            if is_jsonl:
                # JSONL из сжатого файла
                text = data.decode("utf-8", errors="ignore")
                for line in text.splitlines():
                    line = line.strip()
                    if line:
                        try:
                            event = json.loads(line)
                            if isinstance(event, dict):
                                yield event
                        except json.JSONDecodeError:
                            continue  # Пропускаем битые строки
            elif is_msgpack:
                # MessagePack из сжатого файла
                unpacker = msgpack.Unpacker(io.BytesIO(data), raw=False)
                for obj in unpacker:
                    if isinstance(obj, dict):
                        yield obj
        else:
            # Несжатые файлы
            if is_jsonl:
                # JSONL формат (logger-daemon): одна строка JSON на событие
                with path.open("r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                event = json.loads(line)
                                if isinstance(event, dict):
                                    yield event
                            except json.JSONDecodeError:
                                continue  # Пропускаем битые строки
            elif is_msgpack:
                # MessagePack формат (legacy)
                unpacker = msgpack.Unpacker(path.open("rb"), raw=False)
                for obj in unpacker:
                    if isinstance(obj, dict):
                        yield obj
    except Exception:
        return  # Битые/обрезанные файлы игнорируем


def _list_log_files(newest_first: bool = True) -> List[Path]:
    """
    Список файлов логов для чтения.
    
    Поддерживает оба формата:
    - MessagePack: robot-*.msgp, robot-*.msgp.zst (legacy, от MsgpackZstdSegmentHandler)
    - JSONL: robot-*.json, robot-*.json.zst (новый формат, от logger-daemon)
    
    Приоритет: JSONL файлы имеют приоритет над MessagePack (если есть оба).
    
    Args:
        newest_first: Сортировать по времени модификации (новые первые)
        
    Returns:
        Список путей к файлам логов, отсортированный по времени модификации
    """
    files: List[Path] = []
    
    # Архивные файлы (сначала JSONL, потом MessagePack)
    if ARCHIVE_DIR.exists():
        # JSONL архивы (новый формат от logger-daemon)
        jsonl_archives = list(ARCHIVE_DIR.glob("robot-*.json.zst"))
        jsonl_archives += list(ARCHIVE_DIR.glob("robot-*.json"))
        files += jsonl_archives
        
        # MessagePack архивы (legacy формат)
        msgpack_archives = list(ARCHIVE_DIR.glob("robot-*.msgp.zst"))
        msgpack_archives += list(ARCHIVE_DIR.glob("robot-*.msgp"))
        files += msgpack_archives
    
    # Текущие файлы (live)
    if LIVE_DIR.exists():
        # Приоритет: JSONL (logger-daemon) над MessagePack (legacy)
        jsonl_current = LIVE_DIR / "robot-current.json"
        msgpack_current = LIVE_DIR / "robot-current.msgp"
        
        if jsonl_current.exists():
            files.append(jsonl_current)
        elif msgpack_current.exists():
            files.append(msgpack_current)
    
    # Сортировка по времени модификации
    files.sort(key=lambda p: p.stat().st_mtime, reverse=newest_first)
    return files


def _parse_ts(ts: str) -> float:
    # 'YYYY-MM-DDTHH:MM:SS' → epoch (UTC-like)
    try:
        return time.mktime(time.strptime(ts, "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0.0


def _match(
    ev: Dict[str, Any],
    levels: Optional[set] = None,
    sid_sub: Optional[str] = None,
    regex: Optional[re.Pattern] = None,
) -> bool:
    lvl = str(ev.get("level", "INFO")).upper()
    if levels and lvl not in levels:
        return False
    if sid_sub and sid_sub not in str(ev.get("session_id", "")):
        return False
    if regex:
        try:
            s = json.dumps(ev, ensure_ascii=False, separators=(",", ":"))
            if not regex.search(s):
                return False
        except Exception:
            if not regex.search(repr(ev)):
                return False
    return True


# ---------- SQLite query functions ----------
def _parse_event_json(event_json: str) -> Dict[str, Any]:
    """Parse event_json TEXT field back to dict."""
    try:
        return json.loads(event_json)
    except Exception:
        return {}


def _query_sqlite_tail(
    limit: int,
    want_levels: set,
    sid: Optional[str],
    regex: Optional[re.Pattern],
) -> List[Dict[str, Any]]:
    """Query last N logs from SQLite database."""
    if not SQLITE_PATH or not SQLITE_PATH.exists():
        return []
    
    try:
        conn = sqlite3.connect(str(SQLITE_PATH), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Build WHERE clause
        where_parts = []
        params = []
        
        if want_levels:
            placeholders = ",".join("?" * len(want_levels))
            where_parts.append(f"level IN ({placeholders})")
            params.extend(want_levels)
        
        where_clause = "WHERE " + " AND ".join(where_parts) if where_parts else ""
        
        # Query with limit
        query = f"""
            SELECT * FROM logs
            {where_clause}
            ORDER BY ts DESC
            LIMIT ?
        """
        params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        # Convert rows to dicts, parsing event_json
        events = []
        for row in rows:
            # Parse event_json to get full event data
            event = _parse_event_json(row["event_json"]) if row["event_json"] else {}
            
            # Override with indexed columns (they're authoritative)
            event.update({
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
                "hostname": row["hostname"],
                "pid": row["pid"],
                "subject": row["subject"],
            })
            
            # Apply filters
            if _match(event, want_levels, sid, regex):
                events.append(event)
        
        conn.close()
        return events
    
    except Exception as e:
        # Log error but don't crash
        try:
            import sys
            sys.stderr.write(f"[logs.py] SQLite query error: {e}\n")
        except Exception:
            pass
        return []


def _query_sqlite_before(
    before_ts: str,
    limit: int,
    want_levels: set,
    sid: Optional[str],
    regex: Optional[re.Pattern],
) -> List[Dict[str, Any]]:
    """Query logs older than before_ts from SQLite database."""
    if not SQLITE_PATH or not SQLITE_PATH.exists():
        return []
    
    try:
        # Parse before_ts to epoch milliseconds
        cutoff = _parse_ts(before_ts)
        cutoff_ms = int(cutoff * 1000) if cutoff < 1e10 else int(cutoff)
        
        conn = sqlite3.connect(str(SQLITE_PATH), timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Build WHERE clause
        where_parts = ["ts < ?"]
        params = [cutoff_ms]
        
        if want_levels:
            placeholders = ",".join("?" * len(want_levels))
            where_parts.append(f"level IN ({placeholders})")
            params.extend(want_levels)
        
        where_clause = "WHERE " + " AND ".join(where_parts)
        
        # Query with limit
        query = f"""
            SELECT * FROM logs
            {where_clause}
            ORDER BY ts DESC
            LIMIT ?
        """
        params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        # Convert rows to dicts
        events = []
        for row in rows:
            event = _parse_event_json(row["event_json"]) if row["event_json"] else {}
            event.update({
                "ts": row["ts"],
                "level": row["level"],
                "service": row["service"],
                "logger": row["logger"],
                "msg": row["msg"],
                "hostname": row["hostname"],
                "pid": row["pid"],
                "subject": row["subject"],
            })
            
            if _match(event, want_levels, sid, regex):
                events.append(event)
        
        conn.close()
        return events
    
    except Exception as e:
        try:
            import sys
            sys.stderr.write(f"[logs.py] SQLite query error: {e}\n")
        except Exception:
            pass
        return []


# ---------- API: tail / before ----------
@router.get("/logs/tail")
def logs_tail(
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает последние `limit` событий с серверной фильтрацией.
    Использует SQLite или JSONL в зависимости от конфигурации.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None
    
    backend = _get_log_backend()
    
    # Use SQLite if backend is "sqlite" or "both"
    if backend in ("sqlite", "both"):
        events = _query_sqlite_tail(limit, want_levels, sid or None, regex)
        if events or backend == "sqlite":
            # If SQLite returned results or backend is sqlite-only, return them
            return Response(
                content=msgpack.packb(events, use_bin_type=True),
                media_type="application/msgpack",
            )
    
    # Fallback to JSONL file reading
    from collections import deque
    ring = deque(maxlen=limit)

    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            if _match(ev, want_levels, sid or None, regex):
                ring.append(ev)
        # ring сам удержит последний хвост
    data = list(ring)
    return Response(
        content=msgpack.packb(data, use_bin_type=True),
        media_type="application/msgpack",
    )


@router.get("/logs/before")
def logs_before(
    before_ts: str = Query(..., description="ISO ts of oldest item in view (YYYY-MM-DDTHH:MM:SS)"),
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает ещё `limit` событий, которые старше `before_ts`.
    Использует SQLite или JSONL в зависимости от конфигурации.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None
    
    backend = _get_log_backend()
    
    # Use SQLite if backend is "sqlite" or "both"
    if backend in ("sqlite", "both"):
        events = _query_sqlite_before(before_ts, limit, want_levels, sid or None, regex)
        if events or backend == "sqlite":
            # If SQLite returned results or backend is sqlite-only, return them
            return Response(
                content=msgpack.packb(events, use_bin_type=True),
                media_type="application/msgpack",
            )
    
    # Fallback to JSONL file reading
    cutoff = _parse_ts(before_ts)
    out: List[Dict[str, Any]] = []
    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            ts = _parse_ts(str(ev.get("ts", "")))
            if ts and ts < cutoff and _match(ev, want_levels, sid or None, regex):
                out.append(ev)
                if len(out) >= limit:
                    return Response(
                        content=msgpack.packb(out, use_bin_type=True),
                        media_type="application/msgpack",
                    )
    return Response(
        content=msgpack.packb(out, use_bin_type=True),
        media_type="application/msgpack",
    )

# ---------- WS: live ----------
@router.websocket("/logs/ws")
async def logs_ws(ws: WebSocket) -> None:
    """
    Постоянный поток событий лога через WebSocket.

    Клиент закрывает соединение при нажатии 'Pause' и открывает заново на 'Resume'.
    Тут просто корректно завершаем подписку при разрыве.
    """
    await ws.accept()
    q = await logbus.subscribe()
    try:
        snap = logbus.snapshot()
        if snap:
            await ws.send_bytes(msgpack.packb({"type": "snapshot", "items": snap}, use_bin_type=True))
        while True:
            item = await q.get()
            await ws.send_bytes(msgpack.packb({"type": "evt", "item": item}, use_bin_type=True))
    except WebSocketDisconnect:
        pass
    finally:
        await logbus.unsubscribe(q)
