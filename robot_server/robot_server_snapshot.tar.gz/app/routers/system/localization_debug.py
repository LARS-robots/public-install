import json
import os
from typing import Optional

from fastapi import APIRouter, HTTPException
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError

router = APIRouter(prefix="/debug/localization", tags=["telemetry"])


async def _connect_nats() -> NATS:
    # Use NATS_URL from environment, fallback to host network default (127.0.0.1)
    # For host network mode (default architecture), use 127.0.0.1
    # For bridge network (Windows testing), use service name 'nats'
    nats_url = os.getenv("NATS_URL", "nats://dev:devpass@127.0.0.1:4222")
    nc = NATS()
    await nc.connect(nats_url)
    return nc


@router.get("/current")
async def get_current_state():
    """
    Вернуть последнее состояние локализации из KV `loc_state/current`.
    """
    nc: Optional[NATS] = None
    try:
        nc = await _connect_nats()
        js = nc.jetstream()
        kv = await js.key_value("loc_state")
        entry = await kv.get("current")
        if not entry:
            raise HTTPException(status_code=404, detail="loc_state/current not found")
        return json.loads(entry.value.decode("utf-8"))
    except NotFoundError:
        raise HTTPException(status_code=404, detail="KV bucket loc_state not found")
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()


@router.get("/diag")
async def get_last_diag():
    """
    Вернуть последнее диагностическое сообщение из `loc.state.diag` (JetStream).
    """
    nc: Optional[NATS] = None
    try:
        nc = await _connect_nats()
        js = nc.jetstream()
        sub = await js.pull_subscribe("loc.state.diag", durable="api_loc_diag_debug")
        msgs = await sub.fetch(1, timeout=0.5)
        if not msgs:
            raise HTTPException(status_code=404, detail="No diag messages yet")
        msg = msgs[-1]
        payload = json.loads(msg.data.decode("utf-8"))
        await msg.ack()
        return payload
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Stream loc.state.diag not found")
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()

