import asyncio
import json
import os
from typing import Optional

from fastapi import APIRouter, HTTPException
from nats.aio.client import Client as NATS
from nats.js.errors import NotFoundError

router = APIRouter(prefix="/debug/localization", tags=["Telemetry"])


async def _connect_nats() -> NATS:
    # Use NATS_URL from environment, fallback to host network default (127.0.0.1)
    # For host network mode (default architecture), use 127.0.0.1
    # For bridge network (Windows testing), use service name 'nats'
    nats_url = os.getenv("NATS_URL", "nats://dev:devpass@127.0.0.1:4222")
    nc = NATS()
    # Используем asyncio.wait_for для принудительного таймаута подключения (2 секунды)
    # Это более надежно, чем полагаться только на connect_timeout
    try:
        await asyncio.wait_for(
            nc.connect(
                servers=[nats_url],
                connect_timeout=2.0,  # Таймаут подключения 2 секунды
                reconnect_time_wait=2,
                max_reconnect_attempts=0,  # Не пытаемся переподключаться в этом контексте
            ),
            timeout=2.5  # Общий таймаут 2.5 секунды (чуть больше, чем connect_timeout)
        )
    except asyncio.TimeoutError:
        # Закрываем клиент при таймауте
        try:
            await nc.close()
        except Exception:
            pass
        raise ConnectionError("Таймаут подключения к NATS (сервер не отвечает). Проверьте, что контейнер nats запущен и доступен.")
    return nc


@router.get("/current")
async def get_current_state():
    """
    Вернуть последнее состояние локализации из KV `loc_state/current`.
    """
    nc: Optional[NATS] = None
    try:
        nc = await _connect_nats()
        js = nc.jetstream()
        kv = await js.key_value("loc_state")
        entry = await kv.get("current")
        if not entry:
            raise HTTPException(status_code=404, detail="loc_state/current not found")
        return json.loads(entry.value.decode("utf-8"))
    except NotFoundError:
        raise HTTPException(status_code=404, detail="KV bucket loc_state not found")
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()


@router.get("/diag")
async def get_last_diag():
    """
    Вернуть последнее диагностическое сообщение из `loc.state.diag` (JetStream).
    """
    nc: Optional[NATS] = None
    try:
        nc = await _connect_nats()
        js = nc.jetstream()
        sub = await js.pull_subscribe("loc.state.diag", durable="api_loc_diag_debug")
        msgs = await sub.fetch(1, timeout=0.5)
        if not msgs:
            raise HTTPException(status_code=404, detail="No diag messages yet")
        msg = msgs[-1]
        payload = json.loads(msg.data.decode("utf-8"))
        await msg.ack()
        return payload
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Stream loc.state.diag not found")
    finally:
        if nc:
            try:
                await nc.drain()
            except Exception:
                await nc.close()

