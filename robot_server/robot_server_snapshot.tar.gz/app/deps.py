import logging
import os
from typing import Optional

from .services.motor.robot_iface import Robot
from .services.motor.robot_stub import StubRobot

logger = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from .services.motor.robot_rpi import RealRobot  # type: ignore[attr-defined]
except Exception:  # noqa: BLE001
    RealRobot = None  # type: ignore[assignment]
    logger.debug("RealRobot driver unavailable; stub fallback will be used")


def _build_real_robot() -> Optional[Robot]:
    if RealRobot is None:  # type: ignore[name-defined]
        return None
    try:
        return RealRobot()  # type: ignore[misc]
    except Exception as exc:  # noqa: BLE001
        logger.warning("RealRobot initialization failed: %s", exc)
        return None


def get_robot() -> Robot:
    mode = os.getenv("ROBOT_MODE", "stub").lower()
    if mode == "real":
        robot = _build_real_robot()
        if robot is not None:
            return robot
        logger.warning("ROBOT_MODE=real but real driver is unavailable; falling back to StubRobot")
    return StubRobot()


__all__ = ["get_robot"]
