from fastapi import APIRouter, Request, Depends
from ..services.robot_service import get_robot_service, RobotService

router = APIRouter(prefix="/telemetry", tags=["telemetry"])

# Proper dependency function
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

@router.get("/pose")
def get_pose(
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Get current robot pose for map visualization.
    Returns position in simulator or real robot mode.
    """
    pose = robot.get_pose()
    
    if not pose:
        return {"mode": robot.get_robot_type()}
    
    return {
        "mode": robot.get_robot_type(),
        "lat": pose.lat,
        "lon": pose.lon,
        "yaw": pose.yaw
    }

@router.get("/debug/planner")
def debug_planner_import(
    robot: RobotService = Depends(get_robot_from_request)
):
    """Debug endpoint to check planner import and config loading"""
    
    # Test import
    try:
        from ..services.path_planner import HybridPathPlanner, PlannerConfig, LatLon
        import_status = "Import successful"
    except ImportError as e:
        import_status = f"Import failed: {e}"
    
    # Get app_state through robot service
    # Note: We need to pass app_state somehow, let's add it properly
    return {
        "import_status": import_status,
        "robot_type": robot.get_robot_type(),
        "simulator_initialized": robot.init_simulator()
    }