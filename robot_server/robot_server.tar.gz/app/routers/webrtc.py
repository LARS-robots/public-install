from fastapi import APIRouter, HTTPException, Request, responses
from aiortc import RTCPeerConnection, RTCSessionDescription
# Совместимый импорт для разных версий aiortc
try:
    from aiortc.rtcconfiguration import RTCConfiguration, RTCIceServer  # aiortc>=1.7
except Exception:  # старые сборки
    from aiortc import RTCConfiguration, RTCIceServer  # type: ignore

from ..services import video
from .. import state
from pathlib import Path
import asyncio

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

# Один лок на все операции старта/остановки/переключения
_stream_lock = asyncio.Lock()


def _strip_bad_candidates(sdp: str) -> str:
    """
    Убираем link-local и «битые» кандидаты (169.254.*, 0.0.0.0),
    чтобы не ловить 'RTCIceTransport is closed' на Windows.
    """
    lines = []
    for line in sdp.splitlines():
        if line.startswith("a=candidate:"):
            if " 169.254." in line or " 0.0.0.0 " in line:
                continue
        lines.append(line)
    return "\r\n".join(lines) + "\r\n"


def _new_pc() -> RTCPeerConnection:
    """
    Создаём RTCPeerConnection с корректным RTCConfiguration.
    """
    cfg = RTCConfiguration(iceServers=[RTCIceServer(urls=["stun:stun.l.google.com:19302"])])
    try:
        return RTCPeerConnection(configuration=cfg)
    except TypeError:
        return RTCPeerConnection(cfg)  # type: ignore


@router.post("/start_stream")
async def start_stream(camera_id: int = 1, record: bool = False):
    """
    Запускаем видеопоток. Флаг стрима поднимаем ТОЛЬКО после успешного старта трека.
    camera_id: 0 = quad, 1 = stereo (или индекс камеры на ПК)
    """
    async with _stream_lock:
        if state.streaming_enabled and state.camera_track is not None:
            return {"detail": "already running"}

        # создаём трек через сервис, state здесь же
        try:
            track = video.create_camera_track(camera_id=camera_id, record=record)
        except Exception as e:
            state.streaming_enabled = False
            raise HTTPException(status_code=500, detail=f"failed to start camera: {e}")

        if track is None:
            state.streaming_enabled = False
            raise HTTPException(status_code=500, detail="camera track is None")

        state.camera_track = track
        state.streaming_enabled = True
        camera = "stereo" if camera_id == 1 else "quad"
        return {"detail": "streaming started", "recording": record, "camera": camera}


@router.post("/offer")
async def offer(request: Request):
    # Безопасная проверка готовности
    if not state.streaming_enabled or state.camera_track is None:
        raise HTTPException(status_code=403, detail="streaming disabled or not ready")

    params = await request.json()
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

    pc = _new_pc()
    state.peer_connections.add(pc)

    # лог ICE-состояний — помогает в полевых отладках
    @pc.on("iceconnectionstatechange")
    async def on_ice_state_change():
        # Можно заменить на нормальный логгер
        print(f"[ICE] state={pc.iceConnectionState}")

    pc.addTrack(state.camera_track)

    @pc.on("connectionstatechange")
    async def on_state_change():
        if pc.connectionState in ("failed", "closed", "disconnected"):
            state.peer_connections.discard(pc)
            await pc.close()

    await pc.setRemoteDescription(offer)
    answer = await pc.createAnswer()

    # чиним SDP перед локальным описанием
    sanitized = _strip_bad_candidates(answer.sdp)
    await pc.setLocalDescription(RTCSessionDescription(sanitized, answer.type))

    return {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}


@router.post("/stop_stream")
async def stop_stream():
    async with _stream_lock:
        state.streaming_enabled = False

        # Закрываем все PC
        for pc in list(state.peer_connections):
            await pc.close()
            state.peer_connections.discard(pc)

        # Останавливаем трек
        if state.camera_track:
            await video.stop_track(state.camera_track)
            state.camera_track = None

        return {"detail": "streaming stopped"}


@router.get("/last_record")
def last_record():
    recordings_dir = Path.home() / "LARS" / "recordings"
    files = sorted(recordings_dir.glob("robot_video_*.mp4"))
    if not files:
        raise HTTPException(status_code=404, detail="no recordings found")
    latest_file = files[-1]
    return responses.FileResponse(latest_file, filename=latest_file.name, media_type="video/mp4")


@router.get("/recordings")
def list_recordings():
    recordings_dir = Path.home() / "LARS" / "recordings"
    files = sorted(recordings_dir.glob("robot_video_*.mp4"))
    recordings = []
    for file in files:
        stat = file.stat()
        recordings.append({
            "filename": file.name,
            "size_mb": round(stat.st_size / (1024 * 1024), 2),
            "created": stat.st_mtime,
            "download_url": f"/webrtc/download/{file.name}"
        })
    return {"recordings": recordings, "count": len(recordings)}


@router.get("/download/{filename}")
def download_recording(filename: str):
    if not filename.startswith("robot_video_") or not filename.endswith(".mp4"):
        raise HTTPException(status_code=400, detail="Invalid filename")
    recordings_dir = Path.home() / "LARS" / "recordings"
    file_path = recordings_dir / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Recording not found")
    return responses.FileResponse(file_path, filename=filename, media_type="video/mp4")


@router.post("/switch_camera")
async def switch_camera(camera_id: int, record: bool = False):
    """
    Горячее переключение камеры с заменой трека у существующих отправителей.
    """
    if camera_id not in (0, 1):
        raise HTTPException(status_code=400, detail="camera_id must be 0 or 1")

    async with _stream_lock:
        # Остановим текущий трек
        if state.camera_track:
            await video.stop_track(state.camera_track)
            state.camera_track = None

        # Запустим новый
        try:
            new_track = video.create_camera_track(camera_id=camera_id, record=record)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"failed to start camera: {e}")

        if new_track is None:
            raise HTTPException(status_code=500, detail="camera track is None")

        # Заменим трек у каждого RTCRtpSender
        for pc in list(state.peer_connections):
            replaced = False
            for sender in pc.getSenders():
                if sender.track and sender.track.kind == "video":
                    await sender.replaceTrack(new_track)
                    replaced = True
            if not replaced:
                pc.addTrack(new_track)

        state.camera_track = new_track
        camera_type = "stereo" if camera_id == 1 else "quad"
        return {"detail": "camera switched", "camera_id": camera_id, "camera_type": camera_type}
