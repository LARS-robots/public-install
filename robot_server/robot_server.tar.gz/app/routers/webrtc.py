# routers/webrtc.py
from fastapi import APIRouter, HTTPException, Request, responses
from aiortc import RTCPeerConnection, RTCSessionDescription
from ..services import video
from .. import state  
import os, pathlib

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

@router.post("/start_stream")
def start_stream(record: bool = False):
    """
    Включаем флаг и создаём CameraVideoTrack (с записью или без).
    """
    if state.streaming_enabled:
        return {"detail": "already running"}
    state.streaming_enabled = True
    video.start_camera_track(record=record)
    return {"detail": "streaming started"}

@router.post("/offer")
async def offer(request: Request):
    if not state.streaming_enabled:
        raise HTTPException(status_code=403, detail="streaming disabled")

    params = await request.json()
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

    pc = RTCPeerConnection()
    state.peer_connections.add(pc)

    pc.addTrack(state.camera_track)

    @pc.on("connectionstatechange")
    async def on_state_change():
        if pc.connectionState in ("failed", "closed", "disconnected"):
            state.peer_connections.discard(pc)
            await pc.close()

    await pc.setRemoteDescription(offer)
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)
    return {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}

@router.post("/stop_stream")
async def stop_stream():
    state.streaming_enabled = False
    for pc in list(state.peer_connections):
        await pc.close()
        state.peer_connections.discard(pc)
    await video.stop_camera_track()
    return {"detail": "streaming stopped"}

@router.get("/last_record")
def last_record():
    """
    Отдаём последний mp4-файл из текущего каталога.
    Вызывайте после /stop_stream, если запись была включена.
    """
    files = sorted(pathlib.Path(".").glob("record_*.mp4"))
    if not files:
        raise HTTPException(status_code=404, detail="no recordings")
    return responses.FileResponse(files[-1])
