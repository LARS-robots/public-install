# routers/webrtc.py
# ============================================================
# FastAPI router for WebRTC streaming & recording (router-only)
# - No filesystem logic (paths/zip/session are owned by service)
# - Records ALWAYS from ALL cameras defined by config/discovery
# ============================================================

import asyncio
import ipaddress
import logging
import shlex
import socket
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration

# Service-layer imports (helpers & manager live in service)
from ..services.video import (
    CameraManager,
    _layout_mode_and_size,
    _load_eis_config,
    enumerate_cameras,
)

log = logging.getLogger("webrtc")
router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

def _elog(action: str, level: int = logging.INFO, **kw):
    try:
        log.log(level, f"webrtc.{action}", extra={"event": {"stage":"webrtc","action":action, **kw}})
    except Exception:
        # fall back to plain text
        log.log(level, f"{action} {kw}")


# ---------------------- App-scoped state (DI) ---------------------- #
class ServerState:
    def __init__(self):
        self.streaming_enabled: bool = False
        self.camera_track: Any | None = None
        self.current_camera: int | None = None
        self.peer_connections: Set[RTCPeerConnection] = set()

def get_app_state(request: Request) -> ServerState:
    if not hasattr(request.app.state, "_server_state"):
        request.app.state._server_state = ServerState()
    return request.app.state._server_state

def get_camera_manager(request: Request) -> CameraManager:
    if not hasattr(request.app.state, "_camera_manager"):
        request.app.state._camera_manager = CameraManager()
    return request.app.state._camera_manager

# ---------------------- Network & ICE helpers ---------------------- #
class NetworkMode(Enum):
    LAN_ONLY = "lan_only"
    INTERNET_FALLBACK = "internet_fallback"

@dataclass
class NetworkInfo:
    mode: NetworkMode
    client_ip: str
    local_interface_ip: str
    allowed_ips: Set[str]
    ice_servers: list

_PRIVATE_RANGES = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("20.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
]

def _is_private_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in _PRIVATE_RANGES)
    except ValueError:
        return False

def _determine_network_mode(client_ip: str) -> NetworkMode:
    return NetworkMode.LAN_ONLY if _is_private_ip(client_ip) or client_ip in ("127.0.0.1", "::1") else NetworkMode.INTERNET_FALLBACK

def _local_ip_for_peer(peer_ip: str) -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.connect((peer_ip, 9))
        local_ip = s.getsockname()[0]
    ipaddress.ip_address(local_ip)
    return local_ip

def _get_network_info(client_ip: str) -> NetworkInfo:
    mode = _determine_network_mode(client_ip)
    if client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1", "localhost"):
        return NetworkInfo(mode=mode, client_ip=client_ip, local_interface_ip="127.0.0.1", allowed_ips={"127.0.0.1"}, ice_servers=[])
    local_if = _local_ip_for_peer(client_ip)
    return NetworkInfo(mode=mode, client_ip=client_ip, local_interface_ip=local_if, allowed_ips={local_if}, ice_servers=[])

async def resolve_mdns_to_ipv4(hostname: str, timeout: float = 1.0, retries: int = 2) -> Optional[str]:
    if not hostname.endswith(".local"):
        try:
            loop = asyncio.get_running_loop()
            infos = await loop.run_in_executor(None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM))
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET:
                    return sa[0]
        except Exception:
            return None
        return None

    async def _try_getaddrinfo() -> Optional[str]:
        try:
            loop = asyncio.get_running_loop()
            infos = await asyncio.wait_for(
                loop.run_in_executor(None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM)),
                timeout=timeout
            )
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET and _is_private_ip(sa[0]):
                    return sa[0]
        except Exception:
            pass
        return None

    async def _try_avahi() -> Optional[str]:
        cmd = f"avahi-resolve -n {shlex.quote(hostname)}"
        try:
            proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if proc.returncode == 0 and out:
                text = out.decode("utf-8", "ignore").strip()
                parts = text.split("\t")
                if len(parts) >= 2 and _is_private_ip(parts[-1].strip()):
                    return parts[-1].strip()
        except Exception:
            return None
        return None

    for _ in range(max(1, retries)):
        ip = await _try_getaddrinfo()
        if ip:
            return ip
        ip = await _try_avahi()
        if ip:
            return ip
        await asyncio.sleep(0.1)
    return None

async def _filter_sdp_for_lan_only(sdp: str, client_ip: str, server_ip: str, is_offer: bool = True) -> tuple[str, int]:
    sdp_lines, kept = [], 0
    DOCKER_PREFIXES = ("172.17.", "172.18.")
    for line in sdp.splitlines():
        if line.startswith("a=candidate:") and "typ host" in line:
            parts = line.split()
            if len(parts) < 5:
                continue
            cand_ip = parts[4]
            if any(cand_ip.startswith(p) for p in DOCKER_PREFIXES):
                continue
            if cand_ip.endswith(".local"):
                resolved = await resolve_mdns_to_ipv4(cand_ip, timeout=1.0, retries=2)
                if resolved:
                    if not _is_private_ip(resolved):
                        continue
                    line = line.replace(cand_ip, resolved)
                    cand_ip = resolved
                else:
                    if _is_private_ip(client_ip):
                        line = line.replace(cand_ip, client_ip)
                        cand_ip = client_ip
                    else:
                        continue
            if cand_ip in (server_ip, client_ip, "127.0.0.1") or _is_private_ip(cand_ip):
                sdp_lines.append(line); kept += 1
        elif line.startswith("c=IN"):
            sdp_lines.append(f"c=IN IP4 {server_ip}")
        else:
            sdp_lines.append(line)
    if not any(l.startswith("a=end-of-candidates") for l in sdp_lines):
        sdp_lines.append("a=end-of-candidates")
    return "\r\n".join(sdp_lines) + "\r\n", kept

def _create_peer_connection(net: NetworkInfo) -> RTCPeerConnection:
    if net.mode == NetworkMode.LAN_ONLY:
        return RTCPeerConnection(RTCConfiguration(iceServers=[]))
    from aiortc import RTCIceServer
    return RTCPeerConnection(RTCConfiguration(iceServers=[RTCIceServer(urls=s["urls"]) for s in net.ice_servers]))

def _get_server_ip_for_client(client_ip: str) -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((client_ip, 9))
            ip = s.getsockname()[0]
            if ip.startswith(("172.17.", "172.18.")):
                return client_ip
            return ip
    except Exception:
        return client_ip

# ---------------------- Connection monitor ---------------------- #
class ConnectionMonitor:
    def __init__(self):
        self.info: Dict[RTCPeerConnection, Dict[str, Any]] = {}

    def add(self, pc: RTCPeerConnection, net: NetworkInfo):
        self.info[pc] = {"created_at": time.time(), "net": net, "last": "new", "changes": []}

    def update(self, pc: RTCPeerConnection, st: str):
        if pc not in self.info: return
        rec = self.info[pc]
        rec["changes"].append({"from": rec["last"], "to": st, "ts": time.time()})
        rec["last"] = st
        _elog("pc_state", state=st, mode=rec["net"].mode.value)

    def remove(self, pc: RTCPeerConnection):
        self.info.pop(pc, None)

    def stats(self):
        return {
            "active": len(self.info),
            "connections": [
                {"state": rec["last"], "duration": time.time() - rec["created_at"], "mode": rec["net"].mode.value,
                 "client_ip": rec["net"].client_ip}
                for rec in self.info.values()
            ]
        }

_connection_monitor = ConnectionMonitor()

async def _cleanup_connections(request: Request):
    state = get_app_state(request)
    removed = 0
    for pc in list(state.peer_connections):
        try:
            st = getattr(pc, "connectionState", None)
            ice = getattr(pc, "iceConnectionState", None)
            if st in ("failed", "closed", "disconnected") or ice in ("failed", "closed", "disconnected"):
                state.peer_connections.discard(pc)
                _connection_monitor.remove(pc)
                try:
                    await pc.close()
                except Exception:
                    pass
                removed += 1
        except Exception:
            try:
                state.peer_connections.discard(pc)
                _connection_monitor.remove(pc)
                await pc.close()
            except Exception:
                pass
            removed += 1

    # If no connections — clean up unused camera source
    if not state.peer_connections:
        _elog("gc", note="no_active_pcs")
        manager = get_camera_manager(request)
        await manager.cleanup_unused_source()
    return removed

# ---------------------- Pydantic models ---------------------- #
class RecordStartRequest(BaseModel):
    # Back-compat only. Ignored (запись идёт всегда со всех камер).
    cameras: Optional[List[int]] = None
    duration_sec: Optional[int] = None
    segment_sec: Optional[int] = None

class RecordStartResponse(BaseModel):
    session_id: str
    started_cameras: List[int]
    files_expected: List[str]
    download_zip_url: str

class RecordStopResponse(BaseModel):
    session_id: str
    files: List[str]
    zip_url: str

# ---------------------- API: streaming ---------------------- #
@router.post("/start_stream")
async def start_stream(request: Request, camera_id: Optional[int] = None):
    state = get_app_state(request)
    manager = get_camera_manager(request)

    if state.streaming_enabled:
        raise HTTPException(409, "Stream already active")

    try:
        eis_cfg = _load_eis_config()
        if camera_id is None:
            # Select from config layout (stereo/quad); fallback 0/1
            # This is config logic (not filesystem), acceptable in router.
            from ..services.video import _load_config_dict
            cfg_data = _load_config_dict()
            layout_cfg = cfg_data.get("layout", {})
            layout_mode = layout_cfg.get("mode", "camera_stereo")
            if layout_mode == "camera_stereo":
                stereo_cfg = layout_cfg.get("stereo", {})
                camera_id = int(stereo_cfg.get("camera_index", 0))
            elif layout_mode == "camera_quad":
                quad_cfg = layout_cfg.get("quad", {})
                camera_id = int(quad_cfg.get("camera_index", 1))
            else:
                camera_id = 0
            _elog("auto_select", camera_id=camera_id, layout_mode=layout_mode)

        try:
            mode, width, height = _layout_mode_and_size(camera_id)
            _elog("resolution_cfg", width=width, height=height, mode=mode)
        except Exception:
            width, height = 640, 480
            _elog("resolution_fallback", width=width, height=height)

        await manager.ensure_source(camera_id=camera_id, width=width, height=height, fps=30)
        track = manager.create_stream_track(overlay=True, eis_cfg=eis_cfg)

        state.camera_track = track
        state.streaming_enabled = True
        state.current_camera = camera_id

        _elog("start", camera_id=camera_id, width=width, height=height)
        return {"status": "started", "camera_id": camera_id, "resolution": f"{width}x{height}"}
    except Exception as e:
        _elog("start_error", level=logging.ERROR, error_message=str(e))
        raise HTTPException(500, f"Stream start failed: {e}")

@router.post("/offer")
async def offer(request: Request):
    state = get_app_state(request)
    if not state.streaming_enabled or state.camera_track is None:
        raise HTTPException(400, "No active stream")

    params = await request.json()
    client_ip = request.client.host
    server_ip = _get_server_ip_for_client(client_ip)
    net = _get_network_info(client_ip)

    await _cleanup_connections(request)

    if state.camera_track is None:
        raise HTTPException(400, "Camera track not available")

    filtered_offer, kept_offer = await _filter_sdp_for_lan_only(params["sdp"], client_ip, server_ip, is_offer=True)
    remote = RTCSessionDescription(sdp=filtered_offer, type=params["type"])

    pc = _create_peer_connection(net)
    state.peer_connections.add(pc)
    _connection_monitor.add(pc, net)

    @pc.on("connectionstatechange")
    async def on_connectionstatechange():
        st = pc.connectionState
        _connection_monitor.update(pc, st)
        if st in ("failed", "closed"):
            state.peer_connections.discard(pc)
            _connection_monitor.remove(pc)

    await pc.setRemoteDescription(remote)
    pc.addTrack(state.camera_track)

    answer = await pc.createAnswer()
    filtered_answer, kept_answer = await _filter_sdp_for_lan_only(answer.sdp, client_ip, server_ip, is_offer=False)
    await pc.setLocalDescription(RTCSessionDescription(filtered_answer, answer.type))

    _elog("offer",
      kept_offer=kept_offer, kept_answer=kept_answer,
      mode=net.mode.value, client_ip=client_ip, server_ip=server_ip)

    return {
        "sdp": pc.localDescription.sdp,
        "type": pc.localDescription.type,
        "mode": net.mode.value,
        "candidates": {"offer": kept_offer, "answer": kept_answer},
    }

@router.post("/switch_camera")
async def switch_camera(request: Request, camera_id: int):
    if camera_id not in (0, 1):
        raise HTTPException(400, "Invalid camera_id")

    state = get_app_state(request)
    if not state.streaming_enabled:
        raise HTTPException(400, "No active stream")

    manager = get_camera_manager(request)
    try:
        try:
            _, width, height = _layout_mode_and_size(camera_id)
        except Exception:
            width, height = 640, 480

        await manager.ensure_source(camera_id=camera_id, width=width, height=height, fps=30)

        if state.camera_track:
            state.camera_track.stop()

        eis_cfg = _load_eis_config()
        state.camera_track = manager.create_stream_track(overlay=True, eis_cfg=eis_cfg)

        state.current_camera = camera_id
        _elog("switch", camera_id=camera_id, width=width, height=height)
        return {"status": "switched", "camera_id": camera_id, "resolution": f"{width}x{height}"}
    except Exception as e:
        _elog("switch_error", level=logging.ERROR, error_message=str(e))
        raise HTTPException(500, f"Switch failed: {e}")

@router.post("/stop_stream")
async def stop_stream(request: Request):
    state = get_app_state(request)
    if not state.streaming_enabled:
        raise HTTPException(400, "No active stream")

    manager = get_camera_manager(request)
    try:
        if state.camera_track:
            state.camera_track.stop()
            state.camera_track = None

        for pc in list(state.peer_connections):
            try:
                await pc.close()
            except Exception:
                pass
        state.peer_connections.clear()
        _connection_monitor.info.clear()

        await manager.cleanup_unused_source()

        state.streaming_enabled = False
        state.current_camera = None

        _elog("stop")
        return {"status": "stopped"}
    except Exception as e:
        _elog("stop_error", level=logging.ERROR, error_message=str(e))
        raise HTTPException(500, f"Stop failed: {e}")

# ---------- Recording API (always-all-cameras) ----------
@router.post("/record/start", response_model=RecordStartResponse)
async def start_recording(request: Request, body: RecordStartRequest):
    """
    Back-compat: request body may contain `cameras`, but it's ignored
    to enforce the architectural rule: запись идёт всегда со всех камер.
    """
    manager = get_camera_manager(request)

    if manager.is_recording():
        raise HTTPException(status_code=409, detail="Recording already active")

    try:
        session_id, output_files, started_cameras = await manager.start_recording(
            session_id=None,
            output_dir=None,
            segment_sec=body.segment_sec,
        )

        expected_files = [f.name for f in output_files]
        zip_url = f"/webrtc/record_{session_id}.zip"

        log.info("📹 Recording started: session=%s, cameras=%s", session_id, started_cameras)
        return RecordStartResponse(
            session_id=session_id,
            started_cameras=started_cameras,
            files_expected=expected_files,
            download_zip_url=zip_url
        )
    except Exception as e:
        log.error("record.start_error", extra={"event":{"stage":"record","action":"start_error","error_message":str(e)}})
        raise HTTPException(500, f"Recording start failed: {e}")

@router.post("/record/stop", response_model=RecordStopResponse)
async def stop_recording(request: Request):
    manager = get_camera_manager(request)

    if not manager.is_recording():
        raise HTTPException(status_code=409, detail="No active recording")

    try:
        session_id, files = await manager.stop_recording()
        zip_path = await manager.build_zip(session_id=session_id, files=files)

        file_names = [f.name for f in files if f.exists()]
        zip_url = f"/webrtc/{zip_path.name}" if zip_path and zip_path.exists() else ""

        log.info("record.stop", extra={"event":{"stage":"record","action":"stop","files_count":len(file_names),"zip_url":zip_url}})
        return RecordStopResponse(session_id=session_id, files=file_names, zip_url=zip_url)
    except Exception as e:
        log.error("record.stop_error", extra={"event":{"stage":"record","action":"stop_error","error_message":str(e)}})
        raise HTTPException(500, f"Recording stop failed: {e}")

@router.get("/record_{session_id}.zip")
def download_recording_zip(request: Request, session_id: str):
    manager = get_camera_manager(request)
    zpath = manager.get_zip_path(session_id)
    if not zpath or not zpath.exists():
        raise HTTPException(status_code=404, detail="ZIP not found")
    return FileResponse(path=zpath, media_type="application/zip", filename=zpath.name)

@router.post("/cleanup")
async def cleanup_client(request: Request):
    """Cleanup cameras when client disconnects/reloads"""
    state = get_app_state(request)
    manager = get_camera_manager(request)
    
    try:
        # Close any active peer connections
        if hasattr(state, 'peer_connections'):
            for pc in list(state.peer_connections):
                try:
                    await pc.close()
                    state.peer_connections.discard(pc)
                except Exception:
                    pass
        
        # Stop camera track if exists
        if hasattr(state, 'camera_track') and state.camera_track:
            try:
                state.camera_track.stop()
                state.camera_track = None
            except Exception:
                pass
        
        # If not recording, cleanup unused camera source
        if not manager.is_recording():
            await manager.cleanup_unused_source()
            if hasattr(state, 'streaming_enabled'):
                state.streaming_enabled = False
        
        return {"status": "cleaned_up"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

# ---------- Status & diagnostics ----------
@router.get("/status")
async def get_status(request: Request):
    state = get_app_state(request)
    manager = get_camera_manager(request)
    return {
        "streaming_enabled": state.streaming_enabled,
        "current_camera": state.current_camera,
        "has_camera_track": state.camera_track is not None,
        "active_connections": len(state.peer_connections),
        "connection_stats": _connection_monitor.stats(),
        "camera_manager": manager.get_status(),
    }

@router.get("/network_info")
async def get_network_info(request: Request):
    net = _get_network_info(request.client.host)
    return {
        "client_ip": net.client_ip,
        "mode": net.mode.value,
        "local_interface": net.local_interface_ip,
        "allowed_ips": list(net.allowed_ips),
        "ice_servers": net.ice_servers
    }

@router.get("/cameras")
def list_cameras():
    cams = enumerate_cameras(probe_open=False)
    return {"cameras": cams, "count": len(cams)}

# ---------- App shutdown hook ----------
async def cleanup_webrtc(request: Request):
    state = get_app_state(request)
    manager = get_camera_manager(request)

    for pc in list(state.peer_connections):
        try:
            await pc.close()
        except Exception:
            pass
    state.peer_connections.clear()

    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            pass
        state.camera_track = None

    try:
        await manager.stop_all()
    except Exception:
        pass
