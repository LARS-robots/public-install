from fastapi import APIRouter, HTTPException, Request, responses
from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration
import socket
import ipaddress
import logging
import asyncio
import time
import cv2
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Set, Dict, Any, List
from pathlib import Path
from aiozeroconf import ServiceBrowser, Zeroconf
from pydantic import BaseModel
import zipfile
from datetime import datetime

from ..services import video
from .. import state

log = logging.getLogger("webrtc")

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

# Один лок на все операции запуска/остановки/переключения
_stream_lock = asyncio.Lock()

# ---------- Network mode detection ----------
class NetworkMode(Enum):
    LAN_ONLY = "lan_only"
    INTERNET_FALLBACK = "internet_fallback"
    AUTO = "auto"


# ---- Pydantic models (place near the top, after imports) ----
class RecordStartRequest(BaseModel):
    cameras: Optional[List[int]] = None      # если None — авто: все найденные
    duration_sec: Optional[int] = None       # опциональный автостоп

class RecordStartResponse(BaseModel):
    session_id: str
    started_cameras: List[int]
    files_expected: List[str]
    download_zip_url: str

class RecordStopResponse(BaseModel):
    session_id: str
    files: List[str]
    zip_url: str

@dataclass
class NetworkInfo:
    mode: NetworkMode
    client_ip: str
    local_interface_ip: str
    allowed_ips: Set[str]
    ice_servers: list

# LAN detection patterns
_PRIVATE_RANGES = [
    ipaddress.ip_network("127.0.0.0/8"),    # loopback
    ipaddress.ip_network("10.0.0.0/8"),     # private A
    ipaddress.ip_network("172.16.0.0/12"),  # private B (ДОБАВЛЕНО)
    ipaddress.ip_network("192.168.0.0/16"), # private C 
    ipaddress.ip_network("144.0.0.0/8"),    # ip address of pc
    ipaddress.ip_network("169.254.0.0/16"), # link-local (ДОБАВЛЕНО)
    ipaddress.ip_network("::1/128"),        # IPv6 loopback
]

async def resolve_mdns_hostname(hostname: str, client_ip: str, timeout: float = 5.0) -> str:
    """Асинхронное разрешение .local имен через aiozeroconf"""
    if not hostname.endswith(".local"):
        return hostname

    # Bypass mDNS for localhost or same-IP cases
    server_ip = _get_server_ip_for_client(client_ip)
    if (client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1") or 
        (_is_private_ip(client_ip) and client_ip == server_ip)):
        log.debug(f"Bypassing mDNS for client {client_ip} (hostname: {hostname}, server_ip: {server_ip})")
        return client_ip

    # Для ICE кандидатов - пытаемся прямой резолв через DNS
    try:
        import socket
        resolved_ip = socket.gethostbyname(hostname)
        if _is_private_ip(resolved_ip):
            log.info(f"✅ DNS resolved {hostname} -> {resolved_ip}")
            return resolved_ip
    except Exception:
        pass

    # Fallback к aiozeroconf
    zeroconf = None
    try:
        from aiozeroconf import Zeroconf
        zeroconf = Zeroconf()
        
        # Простая попытка получить адреса
        async def try_resolve():
            # Попытка найти запись A/AAAA
            try:
                info = await zeroconf.async_get_service_info("_http._tcp.local.", hostname.replace('.local', '._http._tcp.local.'))
                if info and info.addresses:
                    addr = str(ipaddress.ip_address(info.addresses[0]))
                    if _is_private_ip(addr):
                        return addr
            except Exception:
                pass
            return hostname
        
        try:
            resolved = await asyncio.wait_for(try_resolve(), timeout=timeout)
            if resolved != hostname:
                log.info(f"✅ aiozeroconf resolved {hostname} -> {resolved}")
            return resolved
        except asyncio.TimeoutError:
            log.warning(f"mDNS resolve timeout for {hostname}")
            return hostname

    except Exception as e:
        log.error(f"mDNS resolve error for {hostname}: {e}")
        return hostname
    finally:
        if zeroconf:
            try:
                await zeroconf.async_close()
            except Exception:
                pass

async def _cleanup_connections(connections, monitor) -> int:
    """
    Универсальная очистка WebRTC соединений
    Возвращает количество закрытых соединений
    """
    if not connections:
        return 0
    
    old_connections = list(connections)
    connections.clear()
    
    closed_count = 0
    for pc in old_connections:
        try:
            monitor.remove_connection(pc)
            if pc.connectionState not in ("closed", "failed"):
                await pc.close()
                closed_count += 1
                # Небольшая задержка для корректного закрытия
                await asyncio.sleep(0.05)
        except Exception as e:
            log.warning(f"Error closing connection: {e}")
            closed_count += 1  # Считаем как закрытое
    
    if closed_count > 0:
        log.info(f"🧹 Cleaned up {closed_count} connections")
    
    return closed_count


async def _filter_sdp_for_lan_only(sdp: str, client_ip: str, server_ip: str, is_offer: bool = True) -> tuple[str, int]:
    """
    Универсальная фильтрация SDP для LAN-only режима с проверкой приватных IP
    Возвращает (filtered_sdp, candidates_kept)
    """
    sdp_lines = []
    candidates_kept = 0
    
    # Docker интерфейсы для исключения
    DOCKER_PREFIXES = ("172.17.", "172.18.")
    
    log.debug(f"Filtering {'offer' if is_offer else 'answer'} SDP for client {client_ip}, server {server_ip}")
    
    for line in sdp.splitlines():
        if line.startswith("a=candidate:") and "typ host" in line:
            parts = line.split()
            if len(parts) < 5:
                log.debug(f"Skipping invalid candidate line: {line}")
                continue
                
            candidate_ip = parts[4]
            original_candidate = candidate_ip
            
            # Исключаем Docker интерфейсы
            if any(candidate_ip.startswith(prefix) for prefix in DOCKER_PREFIXES):
                log.debug(f"🚫 Filtered out Docker IP: {candidate_ip}")
                continue
            
            # Разрешаем .local имена с проверкой приватности
            if candidate_ip.endswith(".local"):
                resolved_ip = await resolve_mdns_hostname(candidate_ip, client_ip)
                if resolved_ip != candidate_ip:
                    # Проверяем, что разрешенный IP является приватным
                    if not _is_private_ip(resolved_ip):
                        log.warning(f"🚫 .local resolved to public IP: {original_candidate} -> {resolved_ip}, filtered out")
                        continue
                    
                    # Заменяем .local на разрешенный приватный IP
                    line = line.replace(candidate_ip, resolved_ip)
                    candidate_ip = resolved_ip
                    log.debug(f"✅ Resolved .local: {original_candidate} -> {resolved_ip}")
                else:
                    # Не удалось разрешить .local - пропускаем кандидата
                    log.warning(f"🚫 Failed to resolve .local: {original_candidate}, filtered out")
                    continue
            
            # Оставляем только подходящие кандидаты (loopback/сервер/клиент/приватные)
            if candidate_ip in (server_ip, client_ip, "127.0.0.1") or _is_private_ip(candidate_ip):
                sdp_lines.append(line)
                candidates_kept += 1
                log.debug(f"✅ Kept candidate: {candidate_ip}")
            else:
                log.debug(f"🚫 Filtered out candidate: {candidate_ip} (not in allowed IPs)")
                
        elif line.startswith("c=IN"):
            sdp_lines.append(f"c=IN IP4 {server_ip}")
        else:
            sdp_lines.append(line)
    
    # Добавляем end-of-candidates если нет
    if not any(l.startswith("a=end-of-candidates") for l in sdp_lines):
        sdp_lines.append("a=end-of-candidates")
    
    filtered_sdp = "\r\n".join(sdp_lines) + "\r\n"
    log.info(f"SDP {'offer' if is_offer else 'answer'} filtered: kept {candidates_kept} candidates")
    
    return filtered_sdp, candidates_kept


def _create_peer_connection(network_info: NetworkInfo) -> RTCPeerConnection:
    """Создаем RTCPeerConnection с правильной конфигурацией ICE"""
    if network_info.mode == NetworkMode.LAN_ONLY:
        # LAN-only: без ICE серверов
        config = RTCConfiguration(iceServers=[])
    else:
        # Internet fallback: с STUN серверами
        from aiortc import RTCIceServer
        ice_servers = [
            RTCIceServer(urls=server["urls"]) 
            for server in network_info.ice_servers
        ]
        config = RTCConfiguration(iceServers=ice_servers)
    
    return RTCPeerConnection(config)

def _is_private_ip(ip_str: str) -> bool:
    """Проверяем, является ли IP приватным/локальным"""
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in network for network in _PRIVATE_RANGES)
    except ValueError:
        return False

def _determine_network_mode(client_ip: str) -> NetworkMode:
    """Автоматически определяем сетевой режим по IP клиента"""
    if client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1", "localhost"):
        return NetworkMode.LAN_ONLY
    
    if _is_private_ip(client_ip):
        return NetworkMode.LAN_ONLY
        
    return NetworkMode.INTERNET_FALLBACK

def _local_ip_for_peer(peer_ip: str) -> str:
    """Определяем локальный интерфейс для связи с peer"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((peer_ip, 9))
            local_ip = s.getsockname()[0]
        ipaddress.ip_address(local_ip)
        return local_ip
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cannot determine local interface for {peer_ip}: {e}")

def _get_network_info(client_ip: str) -> NetworkInfo:
    """Получаем полную информацию о сетевой конфигурации"""
    mode = _determine_network_mode(client_ip)
    
    if client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1", "localhost"):
        allowed_ips = {"127.0.0.1"}
        local_interface = "127.0.0.1"
    else:
        local_interface = _local_ip_for_peer(client_ip)
        allowed_ips = {local_interface}
    
    ice_servers = []
    
    return NetworkInfo(
        mode=mode,
        client_ip=client_ip,
        local_interface_ip=local_interface,
        allowed_ips=allowed_ips,
        ice_servers=ice_servers
    )


    
def _get_server_ip_for_client(client_ip: str) -> str:
    """Determine server IP for client using interface lookup, excluding Docker"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((client_ip, 9))
            server_ip = s.getsockname()[0]
            
            # ИСКЛЮЧАЕМ Docker интерфейсы
            if server_ip.startswith(("172.17.", "172.18.")):
                log.warning(f"Got Docker IP {server_ip}, using client IP {client_ip} instead")
                return client_ip
            
            log.debug(f"Server IP for client {client_ip}: {server_ip}")
            return server_ip
    except Exception as e:
        log.warning(f"Cannot determine server IP for {client_ip}: {e}")
        return client_ip  # Fallback на client IP


# ---------- Connection monitoring ----------
class ConnectionMonitor:
    def __init__(self):
        self.connections: Dict[RTCPeerConnection, Dict[str, Any]] = {}
        
    def add_connection(self, pc: RTCPeerConnection, network_info: NetworkInfo):
        self.connections[pc] = {
            "created_at": time.time(),
            "network_info": network_info,
            "last_state": "new",
            "state_changes": []
        }
        
    def update_state(self, pc: RTCPeerConnection, new_state: str):
        if pc in self.connections:
            conn_info = self.connections[pc]
            conn_info["state_changes"].append({
                "from": conn_info["last_state"],
                "to": new_state,
                "timestamp": time.time()
            })
            conn_info["last_state"] = new_state
            
            duration = time.time() - conn_info["created_at"]
            log.info(f"WebRTC state: {new_state} (duration: {duration:.1f}s, mode: {conn_info['network_info'].mode.value})")
            
    def remove_connection(self, pc: RTCPeerConnection):
        self.connections.pop(pc, None)
        
    def get_stats(self) -> Dict[str, Any]:
        return {
            "active_connections": len(self.connections),
            "connections": [
                {
                    "state": info["last_state"],
                    "duration": time.time() - info["created_at"],
                    "mode": info["network_info"].mode.value,
                    "client_ip": info["network_info"].client_ip
                }
                for info in self.connections.values()
            ]
        }

_connection_monitor = ConnectionMonitor()

# ---------- Recording sessions management ----------
class RecordingSession:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.started_at = time.time()
        self.files: list[Path] = []
        # треки, которые мы создали только для записи (не стримовые)
        self.extra_tracks: dict[int, Any] = {}  # cam_index -> track

class RecordingManager:
    def __init__(self):
        self.active: Optional[RecordingSession] = None
        self.history: dict[str, RecordingSession] = {}

    def start(self, session_id: str) -> RecordingSession:
        if self.active is not None:
            raise RuntimeError("Recording already active")
        self.active = RecordingSession(session_id)
        return self.active

    def stop(self) -> RecordingSession:
        if self.active is None:
            raise RuntimeError("No active recording")
        s = self.active
        self.history[s.session_id] = s
        self.active = None
        return s

def _recordings(request: Request) -> RecordingManager:
    if not hasattr(request.app.state, "recordings"):
        request.app.state.recordings = RecordingManager()
    return request.app.state.recordings

def _recordings_dir() -> Path:
    d = Path.home() / "LARS" / "recordings"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _now_session_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def _build_zip(session_id: str, files: list[Path]) -> Path:
    zpath = _recordings_dir() / f"record_{session_id}.zip"
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            if f.exists():
                zf.write(f, arcname=f.name)
    return zpath

# ---------- API Routes ----------
@router.post("/start_stream")
async def start_stream(camera_id: int = 0, record: bool = False):
    async with _stream_lock:
        if state.streaming_enabled and state.camera_track is not None:
            # Проверяем, действительно ли трек еще активен
            try:
                # Простая проверка состояния трека
                if hasattr(state.camera_track, 'cap') and state.camera_track.cap:
                    if not state.camera_track.cap.isOpened():
                        log.warning("🔧 Detected dead camera track, cleaning up")
                        await video.stop_track(state.camera_track)
                        state.camera_track = None
                        state.streaming_enabled = False
                    else:
                        return {"detail": "already running"}
                else:
                    return {"detail": "already running"}
            except Exception as e:
                log.warning(f"Error checking camera track state: {e}, recreating")
                await video.stop_track(state.camera_track)
                state.camera_track = None
                state.streaming_enabled = False

        try:
            log.info(f"Starting video stream: camera_id={camera_id}, record={record}")
            
            # Дополнительная очистка перед созданием трека
            cv2.destroyAllWindows()
            await asyncio.sleep(0.2)
            
            track = video.create_camera_track(camera_id=camera_id, record=record)
            
            if track is None:
                raise ValueError("Camera track creation returned None")
                
        except Exception as e:
            state.streaming_enabled = False
            log.error(f"Failed to start camera: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to start camera: {e}")

        state.camera_track = track
        state.streaming_enabled = True
        camera = "stereo" if camera_id == 1 else "quad"
        
        log.info(f"✅ Video stream started successfully: {camera}")
        return {"detail": "streaming started", "recording": record, "camera": camera}

@router.post("/offer")
async def offer(request: Request):
    """Улучшенный offer с использованием новых helper функций"""
    if not state.streaming_enabled or state.camera_track is None:
        raise HTTPException(status_code=503, detail="Streaming not ready")

    try:
        params = await request.json()
        client_ip = request.client.host
        server_ip = _get_server_ip_for_client(client_ip)
        network_info = _get_network_info(client_ip)

        log.info(f"WebRTC offer: {client_ip} -> {server_ip} (mode: {network_info.mode.value})")

        # Очистка старых соединений
        await _cleanup_connections(state.peer_connections, _connection_monitor)

        # Фильтрация входящего offer
        filtered_offer_sdp, offer_candidates = await _filter_sdp_for_lan_only(
            params["sdp"], client_ip, server_ip, is_offer=True
        )

        if offer_candidates == 0:
            log.warning("No candidates kept after offer filtering")

        remote = RTCSessionDescription(sdp=filtered_offer_sdp, type=params["type"])

        # Создание соединения с правильной конфигурацией
        pc = _create_peer_connection(network_info)
        state.peer_connections.add(pc)
        _connection_monitor.add_connection(pc, network_info)

        @pc.on("connectionstatechange")
        async def on_connection_state_change():
            _connection_monitor.update_state(pc, pc.connectionState)
            if pc.connectionState in ("failed", "closed", "disconnected"):
                state.peer_connections.discard(pc)
                _connection_monitor.remove_connection(pc)
                await pc.close()
                
                # Освобождаем камеру если это последнее соединение
                if len(state.peer_connections) == 0:
                    log.info("🧹 Last connection closed, stopping camera track")
                    async with _stream_lock:
                        if state.camera_track:
                            await video.stop_track(state.camera_track)
                            state.camera_track = None
                        state.streaming_enabled = False

        # Добавляем трек и создаем answer
        pc.addTrack(state.camera_track)
        await pc.setRemoteDescription(remote)
        answer = await pc.createAnswer()

        # Фильтрация answer
        filtered_answer_sdp, answer_candidates = await _filter_sdp_for_lan_only(
            answer.sdp, client_ip, server_ip, is_offer=False
        )

        await pc.setLocalDescription(RTCSessionDescription(filtered_answer_sdp, answer.type))

        log.info(f"✅ WebRTC connection established: {network_info.mode.value}")
        return {
            "sdp": pc.localDescription.sdp,
            "type": pc.localDescription.type,
            "mode": network_info.mode.value,
            "candidates": {"offer": offer_candidates, "answer": answer_candidates}
        }

    except Exception as e:
        log.error(f"WebRTC offer error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Connection failed: {e}")

@router.post("/switch_camera")
async def switch_camera(camera_id: int, record: bool = False):
    """Горячее переключение камеры с улучшенной обработкой ошибок"""
    if camera_id not in (0, 1):
        raise HTTPException(status_code=400, detail="camera_id must be 0 or 1")

    async with _stream_lock:
        log.info(f"Switching to camera {camera_id}, record={record}")
        
        # Останавливаем старый трек
        if state.camera_track:
            await video.stop_track(state.camera_track)
            state.camera_track = None

        try:
            # Создаём новый трек
            new_track = video.create_camera_track(camera_id=camera_id, record=record)
            if new_track is None:
                raise ValueError("Camera track creation returned None")

            # Заменяем трек у всех активных соединений
            replaced_count = 0
            for pc in list(state.peer_connections):
                try:
                    track_replaced = False
                    for sender in pc.getSenders():
                        if sender.track and sender.track.kind == "video":
                            await sender.replaceTrack(new_track)
                            track_replaced = True
                            replaced_count += 1
                            break
                    
                    if not track_replaced:
                        pc.addTrack(new_track)
                        replaced_count += 1
                        
                except Exception as e:
                    log.error(f"Failed to replace track for PC: {e}")
                    # Удаляем проблемное соединение
                    state.peer_connections.discard(pc)
                    _connection_monitor.remove_connection(pc)
                    await pc.close()

            state.camera_track = new_track
            camera_type = "stereo" if camera_id == 1 else "quad"
            
            log.info(f"✅ Camera switched to {camera_type}, updated {replaced_count} connections")
            return {
                "detail": "camera switched", 
                "camera_id": camera_id, 
                "camera_type": camera_type,
                "connections_updated": replaced_count
            }
            
        except Exception as e:
            log.error(f"Failed to switch camera: {e}")
            state.streaming_enabled = False
            raise HTTPException(status_code=500, detail=f"Failed to switch camera: {e}")

@router.post("/stop_stream")
async def stop_stream():
    """Остановка стрима с полной очисткой ресурсов"""
    async with _stream_lock:
        await _cleanup_connections(state.peer_connections, _connection_monitor)
        state.streaming_enabled = False

        # Закрываем все соединения
        for pc in list(state.peer_connections):
            _connection_monitor.remove_connection(pc)
            await pc.close()
        state.peer_connections.clear()

        # Останавливаем трек
        if state.camera_track:
            await video.stop_track(state.camera_track)
            state.camera_track = None

        log.info("✅ Video stream stopped")
        return {"detail": "streaming stopped"}

# ---------- Diagnostic endpoints ----------
@router.get("/status")
async def get_status():
    """Статус WebRTC системы"""
    return {
        "streaming_enabled": state.streaming_enabled,
        "has_camera_track": state.camera_track is not None,
        "active_connections": len(state.peer_connections),
        "connection_stats": _connection_monitor.get_stats()
    }

@router.get("/network_info") 
async def get_network_info(request: Request):
    """Информация о сетевой конфигурации"""
    client_ip = request.client.host
    network_info = _get_network_info(client_ip)
    
    return {
        "client_ip": client_ip,
        "mode": network_info.mode.value,
        "local_interface": network_info.local_interface_ip,
        "allowed_ips": list(network_info.allowed_ips),
        "ice_servers": network_info.ice_servers
    }

# ---------- Multi-camera recording endpoints ----------
@router.get("/cameras")
def list_cameras():
    """Список доступных камер"""
    cams = video.enumerate_cameras(probe_open=False)  # НЕ открываем устройства
    return {"cameras": cams, "count": len(cams)}

@router.post("/record/start", response_model=RecordStartResponse)
async def start_recording(request: Request, body: RecordStartRequest):
    """Старт многокамерной записи"""
    async with _stream_lock:
        session_id = _now_session_id()
        mgr = _recordings(request)
        if mgr.active is not None:
            raise HTTPException(status_code=409, detail="Recording already active")

        # По умолчанию (без явного списка камер) — ПИШЕМ ТОЛЬКО ИЗ УЖЕ ИДУЩЕГО WEBRTC-ТРЕКА
        if state.streaming_enabled and state.camera_track is not None and not body.cameras:
            stream_index = video.track_camera_index(state.camera_track)
            if stream_index is None:
                raise HTTPException(status_code=409, detail="Cannot determine stream camera index")
            cams = [stream_index]
        else:
            # если камеры указаны явно → осознанно откроем их; иначе просто перечислим без открытия
            cams = body.cameras or video.enumerate_cameras(probe_open=False)
        if not cams:
            raise HTTPException(status_code=404, detail="No cameras found (stream-only mode)")
        
        s = mgr.start(session_id)
        out_dir = _recordings_dir()

        # если уже есть стримовый трек — попробуем включить на нём запись,
        # чтобы не открыть ту же камеру второй раз.
        used_by_stream = None
        if state.streaming_enabled and state.camera_track is not None:
            # определим индекс камеры стрима
            try:
                stream_index = video.track_camera_index(state.camera_track)
            except Exception:
                stream_index = None

            if stream_index is not None and stream_index in cams:
                # включаем запись на стримовом треке
                video.enable_recording_on_track(
                    state.camera_track,
                    session_id=s.session_id,
                    cam_label=f"cam{stream_index}",
                    output_dir=out_dir
                )
                used_by_stream = stream_index

        # для остальных камер поднимем фоновые треки с record=True
        for cam_idx in cams:
            if used_by_stream is not None and cam_idx == used_by_stream:
                continue
            # Если клиент НЕ передал явный список камер — мы в stream-only режиме
            if not body.cameras:
                log.info(f"Stream-only mode: skip opening cam{cam_idx}")
                continue
            try:
                tr = video.create_camera_track(
                    camera_id=cam_idx, record=True,
                    session_id=s.session_id, cam_label=f"cam{cam_idx}",
                    output_dir=out_dir
                )
                s.extra_tracks[cam_idx] = tr
            except Exception as e:
                log.error(f"Cannot start recording on cam{cam_idx}: {e}")

        # ожидаемые имена файлов (на основе шаблона VideoRecorder)
        expected = [f"robot_video_cam{ci}_{session_id}.mp4" for ci in cams]
        resp = RecordStartResponse(
            session_id=session_id,
            started_cameras=cams,
            files_expected=expected,
            download_zip_url=f"/webrtc/record/{session_id}.zip"
        )

        # опциональный автостоп
        if body.duration_sec and body.duration_sec > 0:
            async def _auto_stop():
                await asyncio.sleep(body.duration_sec)
                try:
                    await stop_recording(request)
                except Exception as e:
                    log.error(f"Auto stop failed: {e}")
            asyncio.create_task(_auto_stop())

        return resp

@router.post("/record/stop", response_model=RecordStopResponse)
async def stop_recording(request: Request):
    """Остановка многокамерной записи"""
    async with _stream_lock:
        mgr = _recordings(request)
        if mgr.active is None:
            raise HTTPException(status_code=409, detail="No active recording")

        s = mgr.active
        files: list[Path] = []

        # 1) Остановить запись на стримовом треке (если включали)
        if state.camera_track is not None:
            f = video.disable_recording_on_track(state.camera_track)
            if f: files.append(f)

        # 2) Остановить фоновые треки и освободить устройства
        for cam_idx, tr in list(s.extra_tracks.items()):
            try:
                f = video.disable_recording_on_track(tr)
                if f: files.append(f)
            except Exception:
                pass
            try:
                await video.stop_track(tr)
            except Exception:
                pass
        s.extra_tracks.clear()

        # зафиксировать список
        s.files = [Path(p) for p in files if p]

        # финализация сессии
        finished = mgr.stop()

        # собрать zip
        zpath = _build_zip(finished.session_id, finished.files)
        return RecordStopResponse(
            session_id=finished.session_id,
            files=[f.name for f in finished.files],
            zip_url=f"/webrtc/record/{finished.session_id}.zip"
        )

@router.get("/record/last_session")
def last_session(request: Request):
    """Метаданные последней сессии записи"""
    mgr = _recordings(request)
    if not mgr.history:
        raise HTTPException(status_code=404, detail="No sessions yet")
    # берём последнюю по времени
    last_id = sorted(mgr.history.keys())[-1]
    s = mgr.history[last_id]
    return {
        "session_id": s.session_id,
        "files": [f.name for f in s.files],
        "zip_url": f"/webrtc/record/{s.session_id}.zip"
    }

@router.get("/record/{session_id}.zip")
def download_session_zip(session_id: str):
    """Скачать ZIP архив сессии записи"""
    zpath = _recordings_dir() / f"record_{session_id}.zip"
    if not zpath.exists():
        raise HTTPException(status_code=404, detail="ZIP not found")
    return responses.FileResponse(zpath, filename=zpath.name, media_type="application/zip")

