from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration
import socket
import ipaddress
import logging
import asyncio
import time
import cv2
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Set, Dict, Any, List
from pathlib import Path
from pydantic import BaseModel
import zipfile
import shlex
from datetime import datetime

from ..services import video
from .. import state

log = logging.getLogger("webrtc")

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

# один лок на все операции запуска/остановки/переключения
_stream_lock = asyncio.Lock()

# ---------- СЕТЕВОЙ РЕЖИМ ----------
class NetworkMode(Enum):
    LAN_ONLY = "lan_only"
    INTERNET_FALLBACK = "internet_fallback"

@dataclass
class NetworkInfo:
    mode: NetworkMode
    client_ip: str
    local_interface_ip: str
    allowed_ips: Set[str]
    ice_servers: list

_PRIVATE_RANGES = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
]

# ---------- Pydantic ----------
class RecordStartRequest(BaseModel):
    cameras: Optional[List[int]] = None
    duration_sec: Optional[int] = None

class RecordStartResponse(BaseModel):
    session_id: str
    started_cameras: List[int]
    files_expected: List[str]
    download_zip_url: str

class RecordStopResponse(BaseModel):
    session_id: str
    files: List[str]
    zip_url: str

# ---------- ЛОКАЛЬНЫЕ ХЕЛПЕРЫ ДЛЯ ТРЕКОВ (без зависимости от video.stop_track) ----------
async def _stop_track(track: Any) -> None:
    """
    Безопасно останавливает любой aiortc VideoStreamTrack/наш кастомный.
    Наши треки (RawYUVCameraTrack/CameraVideoTrack) имеют sync .stop().
    """
    if track is None:
        return
    try:
        # большинство реализаций .stop() синхронные — вызываем напрямую
        track.stop()
    except TypeError:
        # на всякий: если вдруг корутина
        await track.stop()
    except Exception as e:
        log.warning(f"track.stop() raised: {e}")

def _enable_recording_on_track(track: Any, session_id: str, cam_label: str, output_dir: Path) -> None:
    """
    Включает запись, если трек поддерживает RecordingMixin (см. video.RecordingMixin).
    """
    try:
        if hasattr(track, "start_recording"):
            track.start_recording(session_id, cam_label, output_dir)
    except Exception as e:
        log.warning(f"start_recording failed: {e}")

def _disable_recording_on_track(track: Any):
    """
    Отключает запись, если поддерживается. Возвращает путь к файлу или None.
    """
    try:
        if hasattr(track, "stop_recording_only"):
            return track.stop_recording_only()
    except Exception as e:
        log.warning(f"stop_recording_only failed: {e}")
    return None

# ---------- mDNS и сеть ----------
def _is_private_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in _PRIVATE_RANGES)
    except ValueError:
        return False

def _determine_network_mode(client_ip: str) -> NetworkMode:
    return NetworkMode.LAN_ONLY if _is_private_ip(client_ip) or client_ip in ("127.0.0.1", "::1") else NetworkMode.INTERNET_FALLBACK

def _local_ip_for_peer(peer_ip: str) -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.connect((peer_ip, 9))
        local_ip = s.getsockname()[0]
    ipaddress.ip_address(local_ip)  # validate
    return local_ip

def _get_network_info(client_ip: str) -> NetworkInfo:
    mode = _determine_network_mode(client_ip)
    if client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1", "localhost"):
        return NetworkInfo(mode=mode, client_ip=client_ip, local_interface_ip="127.0.0.1", allowed_ips={"127.0.0.1"}, ice_servers=[])
    local_if = _local_ip_for_peer(client_ip)
    return NetworkInfo(mode=mode, client_ip=client_ip, local_interface_ip=local_if, allowed_ips={local_if}, ice_servers=[])

async def resolve_mdns_to_ipv4(hostname: str, timeout: float = 1.0, retries: int = 2) -> Optional[str]:
    if not hostname.endswith(".local"):
        try:
            loop = asyncio.get_running_loop()
            infos = await loop.run_in_executor(None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM))
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET:
                    return sa[0]
        except Exception:
            return None
        return None

    async def _try_getaddrinfo() -> Optional[str]:
        try:
            loop = asyncio.get_running_loop()
            infos = await asyncio.wait_for(
                loop.run_in_executor(None, lambda: socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_DGRAM)),
                timeout=timeout
            )
            for fam, *_rest, sa in infos:
                if fam == socket.AF_INET and _is_private_ip(sa[0]):
                    return sa[0]
        except Exception:
            pass
        return None

    async def _try_avahi() -> Optional[str]:
        cmd = f"avahi-resolve -n {shlex.quote(hostname)}"
        try:
            proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if proc.returncode == 0 and out:
                text = out.decode("utf-8", "ignore").strip()
                parts = text.split("\t")
                if len(parts) >= 2 and _is_private_ip(parts[-1].strip()):
                    return parts[-1].strip()
        except Exception:
            return None
        return None

    for _ in range(max(1, retries)):
        ip = await _try_getaddrinfo()
        if ip:
            return ip
        ip = await _try_avahi()
        if ip:
            return ip
        await asyncio.sleep(0.1)
    return None

async def _filter_sdp_for_lan_only(sdp: str, client_ip: str, server_ip: str, is_offer: bool = True) -> tuple[str, int]:
    sdp_lines, kept = [], 0
    DOCKER_PREFIXES = ("172.17.", "172.18.")
    for line in sdp.splitlines():
        if line.startswith("a=candidate:") and "typ host" in line:
            parts = line.split()
            if len(parts) < 5:
                continue
            cand_ip = parts[4]
            if any(cand_ip.startswith(p) for p in DOCKER_PREFIXES):
                continue
            if cand_ip.endswith(".local"):
                resolved = await resolve_mdns_to_ipv4(cand_ip, timeout=1.0, retries=2)
                if resolved:
                    if not _is_private_ip(resolved):
                        continue
                    line = line.replace(cand_ip, resolved)
                    cand_ip = resolved
                else:
                    if _is_private_ip(client_ip):
                        line = line.replace(cand_ip, client_ip)
                        cand_ip = client_ip
                    else:
                        continue
            if cand_ip in (server_ip, client_ip, "127.0.0.1") or _is_private_ip(cand_ip):
                sdp_lines.append(line); kept += 1
        elif line.startswith("c=IN"):
            sdp_lines.append(f"c=IN IP4 {server_ip}")
        else:
            sdp_lines.append(line)
    if not any(l.startswith("a=end-of-candidates") for l in sdp_lines):
        sdp_lines.append("a=end-of-candidates")
    return "\r\n".join(sdp_lines) + "\r\n", kept

def _create_peer_connection(net: NetworkInfo) -> RTCPeerConnection:
    if net.mode == NetworkMode.LAN_ONLY:
        return RTCPeerConnection(RTCConfiguration(iceServers=[]))
    from aiortc import RTCIceServer
    return RTCPeerConnection(RTCConfiguration(iceServers=[RTCIceServer(urls=s["urls"]) for s in net.ice_servers]))

def _get_server_ip_for_client(client_ip: str) -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((client_ip, 9))
            ip = s.getsockname()[0]
            if ip.startswith(("172.17.", "172.18.")):
                return client_ip
            return ip
    except Exception:
        return client_ip

# ---------- Монитор соединений ----------
class ConnectionMonitor:
    def __init__(self):
        self.info: Dict[RTCPeerConnection, Dict[str, Any]] = {}

    def add(self, pc: RTCPeerConnection, net: NetworkInfo):
        self.info[pc] = {"created_at": time.time(), "net": net, "last": "new", "changes": []}

    def update(self, pc: RTCPeerConnection, st: str):
        if pc not in self.info: return
        rec = self.info[pc]
        rec["changes"].append({"from": rec["last"], "to": st, "ts": time.time()})
        rec["last"] = st
        log.info(f"WebRTC state: {st} (mode: {rec['net'].mode.value})")

    def remove(self, pc: RTCPeerConnection):
        self.info.pop(pc, None)

    def stats(self):
        return {
            "active": len(self.info),
            "connections": [
                {"state": rec["last"], "duration": time.time() - rec["created_at"], "mode": rec["net"].mode.value,
                 "client_ip": rec["net"].client_ip}
                for rec in self.info.values()
            ]
        }

_connection_monitor = ConnectionMonitor()

async def _cleanup_connections(peer_connections: "Set[RTCPeerConnection]"):
    removed = 0
    for pc in list(peer_connections):
        try:
            st = getattr(pc, "connectionState", None)
            ice = getattr(pc, "iceConnectionState", None)
            if st in ("failed", "closed", "disconnected") or ice in ("failed", "closed", "disconnected"):
                peer_connections.discard(pc)
                _connection_monitor.remove(pc)
                try: await pc.close()
                except Exception: pass
                removed += 1
        except Exception:
            try:
                peer_connections.discard(pc)
                _connection_monitor.remove(pc)
                await pc.close()
            except Exception:
                pass
            removed += 1
    if not peer_connections and state.streaming_enabled:
        log.info("🧹 No active PCs → stopping camera")
        try:
            if state.camera_track:
                await _stop_track(state.camera_track)
            state.camera_track = None
        finally:
            state.streaming_enabled = False
    return removed

# ---------- Запись (простая менеджер-обёртка) ----------
class RecordingSession:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.started_at = time.time()
        self.files: list[Path] = []
        self.extra_tracks: dict[int, Any] = {}  # cam_index -> track

class RecordingManager:
    def __init__(self):
        self.active: Optional[RecordingSession] = None
        self.history: dict[str, RecordingSession] = {}

    def start(self, session_id: str) -> RecordingSession:
        if self.active is not None:
            raise RuntimeError("Recording already active")
        self.active = RecordingSession(session_id)
        return self.active

    def stop(self) -> RecordingSession:
        if self.active is None:
            raise RuntimeError("No active recording")
        s = self.active
        self.history[s.session_id] = s
        self.active = None
        return s

def _recordings(request: Request) -> RecordingManager:
    if not hasattr(request.app.state, "recordings"):
        request.app.state.recordings = RecordingManager()
    return request.app.state.recordings

def _recordings_dir() -> Path:
    d = Path.home() / "LARS" / "recordings"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _now_session_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def _build_zip(session_id: str, files: list[Path]) -> Path:
    zpath = _recordings_dir() / f"record_{session_id}.zip"
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            if f.exists():
                zf.write(f, arcname=f.name)
    return zpath

def _track_is_actively_recording(tr: Any) -> bool:
    try:
        rec = getattr(tr, "recorder", None)
        return bool(rec and getattr(rec, "writer", None))
    except Exception:
        return False

async def _finalize_active_recording_locked(mgr: RecordingManager) -> None:
    s = mgr.active
    if s is None: return
    files: list[Path] = []

    if state.camera_track is not None:
        try:
            f = _disable_recording_on_track(state.camera_track)
            if f: files.append(Path(f))
        except Exception:
            pass

    for cam_idx, tr in list(s.extra_tracks.items()):
        try:
            f = _disable_recording_on_track(tr)
            if f: files.append(Path(f))
        except Exception:
            pass
        try:
            await _stop_track(tr)
        except Exception:
            pass
    s.extra_tracks.clear()
    s.files = files
    finished = mgr.stop()
    try:
        _build_zip(finished.session_id, finished.files)
    except Exception:
        log.exception("zip build failed")

# ---------- API: ЭНДПОИНТЫ (НЕ МЕНЯЛИСЬ) ----------

@router.post("/start_stream")
async def start_stream(camera_id: int = 0, record: bool = False):
    async with _stream_lock:
        if state.streaming_enabled and state.camera_track is not None:
            # если старый трек жив — ранний выход
            try:
                if hasattr(state.camera_track, 'cap') and state.camera_track.cap:
                    if state.camera_track.cap.isOpened():
                        return {"detail": "already running"}
            except Exception:
                pass
            # иначе зачистка
            try:
                await _stop_track(state.camera_track)
            finally:
                state.camera_track = None
                state.streaming_enabled = False

        try:
            tr = video.create_camera_track(camera_id=camera_id, record=record)
            if tr is None:
                raise RuntimeError("create_camera_track returned None")
        except Exception as e:
            state.streaming_enabled = False
            raise HTTPException(status_code=500, detail=f"Failed to start camera: {e}")

        state.camera_track = tr
        state.streaming_enabled = True
        state.current_camera_id = camera_id
        cam_type = "stereo" if camera_id == 1 else "quad"
        return {"detail": "streaming started", "recording": record, "camera": cam_type}

@router.post("/offer")
async def offer(request: Request):
    if not state.streaming_enabled or state.camera_track is None:
        raise HTTPException(status_code=503, detail="Streaming not ready")

    params = await request.json()
    client_ip = request.client.host
    server_ip = _get_server_ip_for_client(client_ip)
    net = _get_network_info(client_ip)

    # чистим умершие соединения, камеру не трогаем
    await _cleanup_connections(state.peer_connections)

    if state.camera_track is None:
        async with _stream_lock:
            if state.camera_track is None:
                try:
                    cid = getattr(state, "current_camera_id", 0)
                    tr = video.create_camera_track(camera_id=cid, record=False)
                    if tr is None:
                        raise RuntimeError("create_camera_track returned None")
                    state.camera_track = tr
                    state.streaming_enabled = True
                except Exception as e:
                    raise HTTPException(status_code=503, detail=f"Camera not ready: {e}")

    filtered_offer, kept_offer = await _filter_sdp_for_lan_only(params["sdp"], client_ip, server_ip, is_offer=True)
    remote = RTCSessionDescription(sdp=filtered_offer, type=params["type"])

    pc = _create_peer_connection(net)
    state.peer_connections.add(pc)
    _connection_monitor.add(pc, net)

    @pc.on("connectionstatechange")
    async def _on_state():
        _connection_monitor.update(pc, pc.connectionState)
        if pc.connectionState in ("failed", "closed", "disconnected"):
            state.peer_connections.discard(pc)
            _connection_monitor.remove(pc)
            await pc.close()
            await _cleanup_connections(state.peer_connections)

    await pc.setRemoteDescription(remote)
    pc.addTrack(state.camera_track)

    answer = await pc.createAnswer()
    filtered_answer, kept_answer = await _filter_sdp_for_lan_only(answer.sdp, client_ip, server_ip, is_offer=False)
    await pc.setLocalDescription(RTCSessionDescription(filtered_answer, answer.type))

    return {
        "sdp": pc.localDescription.sdp,
        "type": pc.localDescription.type,
        "mode": net.mode.value,
        "candidates": {"offer": kept_offer, "answer": kept_answer},
    }

@router.post("/switch_camera")
async def switch_camera(camera_id: int, record: bool = False):
    if camera_id not in (0, 1):
        raise HTTPException(status_code=400, detail="camera_id must be 0 or 1")
    async with _stream_lock:
        if state.camera_track:
            await _stop_track(state.camera_track)
            state.camera_track = None
        try:
            new_tr = video.create_camera_track(camera_id=camera_id, record=record)
            if new_tr is None:
                raise RuntimeError("create_camera_track returned None")
        except Exception as e:
            state.streaming_enabled = False
            raise HTTPException(status_code=500, detail=f"Failed to switch camera: {e}")

        replaced = 0
        for pc in list(state.peer_connections):
            try:
                done = False
                for sender in pc.getSenders():
                    if sender.track and sender.track.kind == "video":
                        await sender.replaceTrack(new_tr)
                        done = True
                        replaced += 1
                        break
                if not done:
                    pc.addTrack(new_tr)
                    replaced += 1
            except Exception:
                state.peer_connections.discard(pc)
                _connection_monitor.remove(pc)
                await pc.close()

        state.camera_track = new_tr
        state.streaming_enabled = True
        state.current_camera_id = camera_id
        cam_type = "stereo" if camera_id == 1 else "quad"
        return {"detail": "camera switched", "camera_id": camera_id, "camera_type": cam_type, "connections_updated": replaced}

@router.post("/stop_stream")
async def stop_stream():
    async with _stream_lock:
        await _cleanup_connections(state.peer_connections)
        for pc in list(state.peer_connections):
            _connection_monitor.remove(pc)
            await pc.close()
        state.peer_connections.clear()

        if state.camera_track:
            await _stop_track(state.camera_track)
            state.camera_track = None

        state.streaming_enabled = False
        return {"detail": "streaming stopped"}

# ---------- Диагностика ----------
@router.get("/status")
async def get_status():
    return {
        "streaming_enabled": state.streaming_enabled,
        "has_camera_track": state.camera_track is not None,
        "active_connections": len(state.peer_connections),
        "connection_stats": _connection_monitor.stats()
    }

@router.get("/network_info")
async def get_network_info(request: Request):
    net = _get_network_info(request.client.host)
    return {
        "client_ip": net.client_ip,
        "mode": net.mode.value,
        "local_interface": net.local_interface_ip,
        "allowed_ips": list(net.allowed_ips),
        "ice_servers": net.ice_servers
    }

# ---------- Список камер ----------
@router.get("/cameras")
def list_cameras():
    cams = video.enumerate_cameras(probe_open=False)
    return {"cameras": cams, "count": len(cams)}

# ---------- Запись ----------
@router.post("/record/start", response_model=RecordStartResponse)
async def start_recording(request: Request, body: RecordStartRequest):
    async with _stream_lock:
        mgr = _recordings(request)

        if mgr.active is not None:
            # была активная — проверим жив ли хоть один writer
            live = False
            if state.camera_track is not None and _track_is_actively_recording(state.camera_track):
                live = True
            for tr in list(mgr.active.extra_tracks.values()):
                if _track_is_actively_recording(tr):
                    live = True; break
            if not live:
                await _finalize_active_recording_locked(mgr)
            else:
                raise HTTPException(status_code=409, detail="Recording already active")

        session_id = _now_session_id()
        s = mgr.start(session_id)

        started: list[int] = []
        expected: list[str] = []

        recordings_dir = _recordings_dir()

        # 1) если стрим уже идёт — включим запись на текущем треке
        if state.streaming_enabled and state.camera_track is not None:
            cam_label = f"cam{getattr(state, 'current_camera_id', 0)}"
            _enable_recording_on_track(state.camera_track, session_id, cam_label, recordings_dir)
            started.append(getattr(state, "current_camera_id", 0))
            expected.append(f"{session_id}_{cam_label}.mp4")

        # 2) дополнительные камеры:
        # если список не задан, берём реально доступные устройства
        if body.cameras is None:
            avail = video.enumerate_cameras(probe_open=False)
            # исключим уже стримящуюся камеру (если она есть)
            current = getattr(state, "current_camera_id", None) if state.streaming_enabled else None
            cams = [c for c in avail if c != current]
        else:
            cams = list(sorted(set(int(c) for c in body.cameras)))

        # создаём рекорд-треки только для реально существующих камер
        for cid in cams:
            try:
                tr = video.create_camera_track(camera_id=cid, record=True,
                                               session_id=session_id, cam_label=f"cam{cid}",
                                               output_dir=recordings_dir)
            except Exception as e:
                log.warning(f"record-only track for cam{cid} failed: {e}")
                continue
            s.extra_tracks[cid] = tr
            started.append(cid)
            expected.append(f"{session_id}_cam{cid}.mp4")

        zip_url = f"/webrtc/record/{session_id}.zip"
        return RecordStartResponse(session_id=session_id,
                                   started_cameras=started,
                                   files_expected=expected,
                                   download_zip_url=zip_url)


@router.post("/record/stop", response_model=RecordStopResponse)
async def stop_recording(request: Request):
    async with _stream_lock:
        mgr = _recordings(request)
        if mgr.active is None:
            raise HTTPException(status_code=409, detail="No active recording")
        s = mgr.active

        files: list[Path] = []

        if state.camera_track is not None:
            try:
                f = _disable_recording_on_track(state.camera_track)
                if f: files.append(Path(f))
            except Exception:
                pass

        for cid, tr in list(s.extra_tracks.items()):
            try:
                f = _disable_recording_on_track(tr)
                if f: files.append(Path(f))
            except Exception:
                pass
            try:
                await _stop_track(tr)
            except Exception:
                pass
        s.extra_tracks.clear()

        finished = mgr.stop()
        finished.files = files

        try:
            zip_path = _build_zip(finished.session_id, finished.files)
        except Exception:
            log.exception("zip build failed")
            zip_path = _recordings_dir() / f"record_{finished.session_id}.zip"

        return RecordStopResponse(session_id=finished.session_id, files=[f.name for f in files], zip_url=f"/webrtc/record_{finished.session_id}.zip")
    

@router.get("/record_{session_id}.zip")
def download_recording_zip(session_id: str):
    """
    Serves the ZIP created by _build_zip():
        /home/lars/LARS/recordings/record_<SESSION_ID>.zip

    Supports both URL variants that our endpoints currently emit:
      - /webrtc/record/<SESSION_ID>.zip
      - /webrtc/record_<SESSION_ID>.zip
    """
    base = _recordings_dir()
    # we always store as record_<id>.zip
    zpath = base / f"record_{session_id}.zip"
    if not zpath.exists():
        # small tolerance: maybe client passed "record_..." already?
        alt = base / f"{session_id}.zip"
        if alt.exists():
            zpath = alt
        else:
            raise HTTPException(status_code=404, detail="ZIP not found")

    # Download with a friendly filename
    return FileResponse(
        path=zpath,
        media_type="application/zip",
        filename=zpath.name,
    )

