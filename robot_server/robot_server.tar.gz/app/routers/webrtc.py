# routers/webrtc.py
from fastapi import APIRouter, HTTPException, Request, responses
from aiortc import RTCPeerConnection, RTCSessionDescription
from ..services import video
from .. import state  
import os, pathlib
from pathlib import Path

router = APIRouter(prefix="/webrtc", tags=["WebRTC"])

@router.post("/start_stream")
def start_stream(record: bool = False):
    """
    Включаем флаг и создаём CameraVideoTrack (с записью или без).
    """
    if state.streaming_enabled:
        return {"detail": "already running"}
    state.streaming_enabled = True
    video.start_camera_track(record=record)
    return {"detail": "streaming started", "recording": record}

@router.post("/offer")
async def offer(request: Request):
    if not state.streaming_enabled:
        raise HTTPException(status_code=403, detail="streaming disabled")

    params = await request.json()
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

    pc = RTCPeerConnection()
    state.peer_connections.add(pc)

    pc.addTrack(state.camera_track)

    @pc.on("connectionstatechange")
    async def on_state_change():
        if pc.connectionState in ("failed", "closed", "disconnected"):
            state.peer_connections.discard(pc)
            await pc.close()

    await pc.setRemoteDescription(offer)
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)
    return {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}

@router.post("/stop_stream")
async def stop_stream():
    state.streaming_enabled = False
    for pc in list(state.peer_connections):
        await pc.close()
        state.peer_connections.discard(pc)
    await video.stop_camera_track()
    return {"detail": "streaming stopped"}

@router.get("/last_record")
def last_record():
    """
    Отдаём последний mp4-файл из директории записей.
    """
    recordings_dir = Path.home() / "LARS" / "recordings"
    files = sorted(recordings_dir.glob("robot_video_*.mp4"))
    if not files:
        raise HTTPException(status_code=404, detail="no recordings found")
    
    latest_file = files[-1]
    return responses.FileResponse(
        latest_file, 
        filename=latest_file.name,
        media_type="video/mp4"
    )

@router.get("/recordings")
def list_recordings():
    """
    Список всех записей с информацией о файлах.
    """
    recordings_dir = Path.home() / "LARS" / "recordings"
    files = sorted(recordings_dir.glob("robot_video_*.mp4"))
    
    recordings = []
    for file in files:
        stat = file.stat()
        recordings.append({
            "filename": file.name,
            "size_mb": round(stat.st_size / (1024 * 1024), 2),
            "created": stat.st_mtime,
            "download_url": f"/webrtc/download/{file.name}"
        })
    
    return {"recordings": recordings, "count": len(recordings)}

@router.get("/download/{filename}")
def download_recording(filename: str):
    """
    Скачать конкретную запись по имени файла.
    """
    # Проверяем безопасность имени файла
    if not filename.startswith("robot_video_") or not filename.endswith(".mp4"):
        raise HTTPException(status_code=400, detail="Invalid filename")
    
    recordings_dir = Path.home() / "LARS" / "recordings"
    file_path = recordings_dir / filename
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Recording not found")
    
    return responses.FileResponse(
        file_path,
        filename=filename,
        media_type="video/mp4"
    )
