from fastapi import Body, APIRouter, HTTPException
from ..services.test import set_led_state

router = APIRouter(prefix="/test", tags=["Test"])

@router.post("/action")
def test_action(state: int = Body(...)):
    try:
        set_led_state(state)
        return {"status": "success", "state": state}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal error")