from fastapi import APIRouter, Body, HTTPException
from ..services import test

router = APIRouter(prefix="/robot", tags=["Robot"])

@router.post("/forward")
def api_move_forward(value: int = Body(..., embed=True), number: int = Body(0, embed=True)):
    """Движение вперёд/назад: value -2000..2000"""
    try:
        test.move_forward(value, Number=number)
        return {"status": "success", "action": "forward", "value": value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/turn")
def api_turn(value: int = Body(..., embed=True), number: int = Body(0, embed=True)):
    """Поворот: value -2000..2000"""
    try:
        test.turn(value, Number=number)
        return {"status": "success", "action": "turn", "value": value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/arm")
def api_move_arm(value: int = Body(..., embed=True), number: int = Body(0, embed=True)):
    """Подъём/опускание стрелы: value -2000..2000"""
    try:
        test.move_arm(value, Number=number)
        return {"status": "success", "action": "arm", "value": value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/bucket")
def api_tilt_bucket(value: int = Body(..., embed=True), number: int = Body(0, embed=True)):
    """Наклон ковша: value -2000..2000"""
    try:
        test.tilt_bucket(value, Number=number)
        return {"status": "success", "action": "bucket", "value": value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/brush")
def api_brush_speed(value: int = Body(..., embed=True), number: int = Body(0, embed=True)):
    """Скорость щётки: value -2000..2000"""
    try:
        test.brush_speed(value, Number=number)
        return {"status": "success", "action": "brush", "value": value}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
