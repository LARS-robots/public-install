from fastapi import APIRouter, Depends, Body, HTTPException
from ..deps import get_robot         
from ..services.robot_iface import Robot

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.get("/health")
def healthcheck():
    return {"status": "ok"}
