from fastapi import APIRouter, Depends, Body, HTTPException
from fastapi.responses import StreamingResponse
from ..deps import get_robot
from ..services.robot_iface import Robot

router = APIRouter(prefix="/camera", tags=["Camera"])

@router.post("/pan")
def pan(value: int = Body(..., ge=0, le=180), bot: Robot = Depends(get_robot)):
    bot.pan(value)
    return {"pan": value}

@router.post("/tilt")
def tilt(value: int = Body(..., ge=0, le=110), bot: Robot = Depends(get_robot)):
    bot.tilt(value)
    return {"tilt": value}
