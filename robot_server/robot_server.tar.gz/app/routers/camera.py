from fastapi import APIRouter, Depends, Body, HTTPException
from fastapi.responses import StreamingResponse
from ..deps import get_robot          # вынесем Depends в отдельный модуль
from ..services.robot_iface import Robot

router = APIRouter(prefix="/camera", tags=["Camera"])

@router.get("/snapshot", response_class=StreamingResponse)
def snapshot(bot: Robot = Depends(get_robot)):
    return StreamingResponse(iter([bot.snapshot()]), media_type="image/jpeg")

@router.post("/record/start")
def start_record(bot: Robot = Depends(get_robot)):
    bot.start_record()
    return {"status": "recording"}

@router.post("/record/stop")
def stop_record(bot: Robot = Depends(get_robot)):
    bot.stop_record()
    return {"status": "stopped"}

@router.post("/pan")
def pan(value: int = Body(..., ge=0, le=180), bot: Robot = Depends(get_robot)):
    bot.pan(value)
    return {"pan": value}

@router.post("/tilt")
def tilt(value: int = Body(..., ge=0, le=110), bot: Robot = Depends(get_robot)):
    bot.tilt(value)
    return {"tilt": value}
