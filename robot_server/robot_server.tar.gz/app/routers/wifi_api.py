from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
import asyncio
from ..services import wifi_manager as wm
from .wifi_ws import notify_new_ip

app = APIRouter()

class ConnectReq(BaseModel):
    ssid: str
    password: Optional[str] = None
    iface: str = "wlan0"

class WifiNetworkResp(BaseModel):
    in_use: bool
    ssid: str
    signal: int
    security: str

@app.get("/wifi/scan", response_model=List[WifiNetworkResp])
def wifi_scan(iface: str = "wlan0"):
    try:
        nets = wm.scan(iface)
        return [WifiNetworkResp(**n.__dict__) for n in nets]
    except wm.WifiError as e: raise HTTPException(status_code=500, detail=str(e))

@app.get("/wifi/status")
def wifi_status(iface: str = "wlan0"): return wm.status(iface)

@app.post("/wifi/connect")
def wifi_connect(req: ConnectReq):
    try:
        wm.connect(req.ssid, req.password, req.iface)
        return {"ok": True, "message": "Connecting; network may change"}
    except wm.WifiError as e: raise HTTPException(status_code=500, detail=str(e))

def _schedule_notify():
    # small delay so IP has time to change
    async def _run():
        await asyncio.sleep(2)
        await notify_new_ip()
    asyncio.create_task(_run())

@app.post("/wifi/switch")
def wifi_switch(req: ConnectReq, bg: BackgroundTasks):
    try:
        wm.switch(req.ssid, req.password, req.iface)
        bg.add_task(_schedule_notify)
        return {"ok": True, "message": "Switched; connection may drop"}
    except wm.WifiError as e: raise HTTPException(status_code=500, detail=str(e))