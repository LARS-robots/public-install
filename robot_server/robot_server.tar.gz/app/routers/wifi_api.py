from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from typing import Optional, List
import logging
import asyncio
import threading
import time
from ..services.wifi_manager import WifiManager, WifiError
from .wifi_ws import notify_new_ip, notify_event
from ._wifi_helpers import ensure_visible_and_validate

log = logging.getLogger(__name__)

app = APIRouter(prefix="/wifi", tags=["WiFi"])

def get_wm(request: Request) -> WifiManager:
    """Dependency для получения WifiManager из app.state"""
    return request.app.state.wifi_manager

class ConnectReq(BaseModel):
    """Модель запроса - только SSID и пароль"""
    ssid: str = Field(..., description="SSID сети", min_length=1)
    password: Optional[str] = Field(None, description="Пароль сети")
    
    class Config:
        extra = "ignore"  # игнорируем дополнительные поля

class WifiNetworkResp(BaseModel):
    in_use: bool
    ssid: str
    signal: int
    security: str

@app.get("/scan", response_model=List[WifiNetworkResp])
def wifi_scan(wm: WifiManager = Depends(get_wm)):
    try:
        nets = wm.scan()
        return [WifiNetworkResp(**n.__dict__) for n in nets]
    except WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
def wifi_status(wm: WifiManager = Depends(get_wm)):
    try:
        return wm.status()
    except WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

# def _validate_credentials(wm: WifiManager, ssid: str, password: Optional[str]) -> bool:
#     """Быстрая проверка правильности логина/пароля"""
#     try:
#         log.info(f"Validating credentials for {ssid}")
        
#         # Устанавливаем guard для защиты от автоподъема AP во время валидации
#         wm._write_guard(60)
#         wm._suppress_ap_autoconnect(60)
        
#         # Создаем временное тестовое подключение
#         test_connection_name = f"test-{int(time.time())}"
        
#         # Пытаемся создать подключение с заданными учетными данными
#         cmd = f'sudo nmcli connection add type wifi con-name "{test_connection_name}" ssid {shlex.quote(ssid)}'
#         if password:
#             cmd += f' wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)}'
        
#         try:
#             wm._run(cmd, timeout=10)
            
#             # Пытаемся активировать подключение на короткое время
#             activate_cmd = f'sudo nmcli connection up "{test_connection_name}" ifname wlan0'
#             wm._run(activate_cmd, timeout=15)
            
#             # Проверяем, что подключились к правильной сети
#             time.sleep(2)
#             current_status = wm.status()
#             success = current_status.get("ssid") == ssid
            
#             log.info(f"Credential validation result: {success}")
#             return success
            
#         finally:
#             # Удаляем тестовое подключение
#             try:
#                 wm._run(f'sudo nmcli connection delete "{test_connection_name}"', timeout=5)
#             except Exception:
#                 pass
                
#     except WifiError as e:
#         error_msg = str(e).lower()
        
#         # Проверяем специфичные ошибки аутентификации
#         if any(keyword in error_msg for keyword in [
#             "password", "authentication", "key", "psk", 
#             "secrets were required", "invalid key"
#         ]):
#             log.error(f"Authentication failed: {e}")
#             return False
        
#         # Проверяем ошибки сети
#         if any(keyword in error_msg for keyword in [
#             "not found", "no network", "ssid"
#         ]):
#             log.error(f"Network not found: {e}")
#             return False
            
#         # Другие ошибки также считаем неудачными
#         log.error(f"Connection validation failed: {e}")
#         return False
        
#     except Exception as e:
#         log.exception(f"Unexpected error during validation: {e}")
#         return False
    
#     finally:
#         # Очищаем guard после валидации
#         wm._clear_guard()

def _background_connect(wm: WifiManager, ssid: str, password: Optional[str]):
    """Фоновое подключение к Wi-Fi (только после успешной валидации)"""
    try:
        log.info(f"Background task: final connection to {ssid}")
        
        # Отправляем событие начала подключения
        try:
            asyncio.run(notify_event(event="connecting", ssid=ssid))
        except Exception as e:
            log.warning(f"Failed to send connecting event: {e}")
        
        # Подключаемся с автоматическими параметрами (интерфейс wlan0)
        wm.connect(ssid, password)
        log.info(f"Background task: successfully connected to {ssid}")
        
        # Уведомляем о смене IP через 3 секунды
        time.sleep(3)
        asyncio.run(notify_new_ip(wm))
        
        # Финальное событие успешного подключения
        try:
            st = wm.status()
            asyncio.run(notify_event(event="connected", ssid=st.get("ssid"), ip=st.get("ip4")))
        except Exception as e:
            log.warning(f"Failed to send connected event: {e}")
        
    except Exception as e:
        log.error(f"Background connect failed: {e}")
        try:
            asyncio.run(notify_event(event="failed", ssid=ssid, reason=str(e)))
        except Exception as e2:
            log.warning(f"Failed to send failed event: {e2}")

def _background_switch(wm: WifiManager, ssid: str, password: Optional[str]):
    """Фоновое переключение Wi-Fi"""
    try:
        log.info(f"Background task: switching to {ssid}")
        
        # Отправляем событие начала переключения
        try:
            asyncio.run(notify_event(event="connecting", ssid=ssid))
        except Exception as e:
            log.warning(f"Failed to send connecting event: {e}")
        
        # Переключаемся с автоматическими параметрами
        wm.switch(ssid, password)
        log.info(f"Background task: successfully switched to {ssid}")

        # Уведомляем о смене IP через 3 секунды
        time.sleep(3)
        asyncio.run(notify_new_ip(wm))
        
        # Финальное событие
        try:
            st = wm.status()
            asyncio.run(notify_event(event="connected", ssid=st.get("ssid"), ip=st.get("ip4")))
        except Exception as e:
            log.warning(f"Failed to send connected event: {e}")
        
    except Exception as e:
        log.error(f"Background switch failed: {e}")
        try:
            asyncio.run(notify_event(event="failed", ssid=ssid, reason=str(e)))
        except Exception as e2:
            log.warning(f"Failed to send failed event: {e2}")

@app.post("/connect")
def wifi_connect(req: ConnectReq, wm: WifiManager = Depends(get_wm)):
    """Подключение к Wi-Fi сети с использованием общих helpers"""
    try:
        log.info(f"WiFi connect request: ssid='{req.ssid}', password={'***' if req.password else 'None'}")
        
        # BEGIN FIX: use shared validation helper
        ensure_visible_and_validate(wm, req.ssid, req.password)
        # END FIX
        
        # BEGIN FIX: use public guard context manager
        with wm.switch_guard(60):
            # Credentials are already validated by helper
            thread = threading.Thread(
                target=_background_connect, 
                args=(wm, req.ssid, req.password),
                daemon=True
            )
            thread.start()
        # END FIX
        
        return {
            "ok": True, 
            "message": f"Credentials validated. Connecting to '{req.ssid}' in background.",
            "ssid": req.ssid
        }
        
    except HTTPException:
        raise
    except WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        log.exception("Unexpected error in wifi_connect")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/switch")  
def wifi_switch(req: ConnectReq, wm: WifiManager = Depends(get_wm)):
    """Переключение на другую Wi-Fi сеть с использованием общих helpers"""
    try:
        log.info(f"WiFi switch request: ssid='{req.ssid}', password={'***' if req.password else 'None'}")
        
        # Check if already connected
        current_status = wm.status()
        current_ssid = current_status.get("ssid")
        
        if current_ssid == req.ssid:
            return {
                "ok": True,
                "message": f"Already connected to '{req.ssid}'",
                "ssid": req.ssid
            }
        
        # BEGIN FIX: use shared validation helper (eliminates duplicate code)
        ensure_visible_and_validate(wm, req.ssid, req.password)
        # END FIX
        
        # BEGIN FIX: use public guard context manager
        with wm.switch_guard(60):
            thread = threading.Thread(
                target=_background_switch,
                args=(wm, req.ssid, req.password),
                daemon=True
            )
            thread.start()
        # END FIX
        
        return {
            "ok": True,
            "message": f"Credentials validated. Switching from '{current_ssid}' to '{req.ssid}' in background.",
            "from_ssid": current_ssid,
            "to_ssid": req.ssid
        }
        
    except HTTPException:
        raise
    except WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        log.exception("Unexpected error in wifi_switch")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/disconnect")
def wifi_disconnect(wm: WifiManager = Depends(get_wm)):
    """Отключение от текущей Wi-Fi сети"""
    try:
        current_status = wm.status()
        current_ssid = current_status.get("ssid")
        
        if not current_ssid:
            return {"ok": True, "message": "Not connected to any network"}
        
        # Отключение в фоновом потоке
        def _background_disconnect():
            try:
                wm.disconnect()  # Автоматически использует wlan0
                log.info("Background disconnect completed")
            except Exception as e:
                log.error(f"Background disconnect failed: {e}")
        
        thread = threading.Thread(target=_background_disconnect, daemon=True)
        thread.start()
        
        return {
            "ok": True,
            "message": f"Disconnecting from '{current_ssid}' in background",
            "ssid": current_ssid
        }
        
    except WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        log.exception("Unexpected error in wifi_disconnect")
        raise HTTPException(status_code=500, detail=str(e))

