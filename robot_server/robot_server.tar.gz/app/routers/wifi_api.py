from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import logging
import asyncio
import threading
import time
from ..services import wifi_manager as wm
from .wifi_ws import notify_new_ip

app = APIRouter(prefix="/wifi", tags=["WiFi"])
logging.basicConfig(level=logging.INFO)

class ConnectReq(BaseModel):
    ssid: str
    password: Optional[str] = None

class WifiNetworkResp(BaseModel):
    in_use: bool
    ssid: str
    signal: int
    security: str

@app.get("/scan", response_model=List[WifiNetworkResp])
def wifi_scan():
    try:
        nets = wm.scan()
        return [WifiNetworkResp(**n.__dict__) for n in nets]
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
def wifi_status():
    try:
        return wm.status()
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

def _validate_credentials(ssid: str, password: Optional[str]) -> bool:
    """Быстрая проверка правильности логина/пароля"""
    try:
        logging.info(f"Validating credentials for {ssid}")
        
        # Создаем временное тестовое подключение
        test_connection_name = f"test-{int(time.time())}"
        
        # Пытаемся создать подключение с заданными учетными данными
        cmd = f'sudo nmcli connection add type wifi con-name "{test_connection_name}" ssid {wm.shlex.quote(ssid)}'
        if password:
            cmd += f' wifi-sec.key-mgmt wpa-psk wifi-sec.psk {wm.shlex.quote(password)}'
        
        try:
            wm._run(cmd, timeout=10)
            
            # Пытаемся активировать подключение на короткое время
            activate_cmd = f'sudo nmcli connection up "{test_connection_name}" ifname wlan0'
            wm._run(activate_cmd, timeout=15)
            
            # Проверяем, что подключились к правильной сети
            time.sleep(2)
            current_status = wm.status()
            success = current_status.get("ssid") == ssid
            
            logging.info(f"Credential validation result: {success}")
            return success
            
        finally:
            # Удаляем тестовое подключение
            try:
                wm._run(f'sudo nmcli connection delete "{test_connection_name}"', timeout=5)
            except Exception:
                pass
                
    except wm.WifiError as e:
        error_msg = str(e).lower()
        
        # Проверяем специфичные ошибки аутентификации
        if any(keyword in error_msg for keyword in [
            "password", "authentication", "key", "psk", 
            "secrets were required", "invalid key"
        ]):
            logging.error(f"Authentication failed: {e}")
            return False
        
        # Проверяем ошибки сети
        if any(keyword in error_msg for keyword in [
            "not found", "no network", "ssid"
        ]):
            logging.error(f"Network not found: {e}")
            return False
            
        # Другие ошибки также считаем неудачными
        logging.error(f"Connection validation failed: {e}")
        return False
        
    except Exception as e:
        logging.exception(f"Unexpected error during validation: {e}")
        return False

def _background_connect(ssid: str, password: Optional[str]):
    """Фоновое подключение к Wi-Fi (только после успешной валидации)"""
    try:
        logging.info(f"Background task: final connection to {ssid}")
        
        # Подключаемся с финальным именем подключения
        wm.connect(ssid, password)
        logging.info(f"Background task: successfully connected to {ssid}")
        
        # Уведомляем о смене IP через 3 секунды
        time.sleep(3)
        asyncio.run(notify_new_ip())
        
    except Exception as e:
        logging.error(f"Background connect failed: {e}")

def _background_switch(ssid: str, password: Optional[str]):
    """Фоновое переключение Wi-Fi"""
    try:
        logging.info(f"Background task: switching to {ssid}")
        wm.switch(ssid, password)
        logging.info(f"Background task: successfully switched to {ssid}")

        # Уведомляем о смене IP через 3 секунды
        time.sleep(3)
        asyncio.run(notify_new_ip())
        
    except Exception as e:
        logging.error(f"Background switch failed: {e}")

@app.post("/connect")
def wifi_connect(req: ConnectReq):
    """Подключение к Wi-Fi сети"""
    try:
        # 1. Быстрая проверка видимости сети
        logging.info(f"Checking network visibility: {req.ssid}")
        nets = wm.scan()
        found_network = None
        for net in nets:
            if net.ssid == req.ssid:
                found_network = net
                break
        
        if not found_network:
            available_ssids = [net.ssid for net in nets[:5]]
            raise HTTPException(
                status_code=400, 
                detail=f"Network '{req.ssid}' not found. Available: {available_ssids}"
            )
        
        # 2. Проверяем требования к безопасности
        requires_password = found_network.security and found_network.security.strip() not in ["", "--"]
        if requires_password and not req.password:
            raise HTTPException(
                status_code=400,
                detail=f"Network '{req.ssid}' requires a password (security: {found_network.security})"
            )
        
        # 3. Валидация учетных данных
        logging.info(f"Validating credentials for: {req.ssid}")
        if not _validate_credentials(req.ssid, req.password):
            raise HTTPException(
                status_code=401,  # Unauthorized
                detail=f"Invalid credentials for network '{req.ssid}'. Check SSID and password."
            )
        
        # 4. Учетные данные правильные - запускаем фоновое подключение
        thread = threading.Thread(
            target=_background_connect, 
            args=(req.ssid, req.password),
            daemon=True
        )
        thread.start()
        
        # Возвращаем успешный ответ
        return {
            "ok": True, 
            "message": f"Credentials validated. Connecting to '{req.ssid}' in background.",
            "ssid": req.ssid
        }
        
    except HTTPException:
        raise
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logging.exception("Unexpected error in wifi_connect")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/switch")
def wifi_switch(req: ConnectReq):
    """Переключение на другую Wi-Fi сеть"""
    try:
        # Получаем текущий статус
        current_status = wm.status()
        current_ssid = current_status.get("ssid")
        
        if current_ssid == req.ssid:
            return {
                "ok": True,
                "message": f"Already connected to '{req.ssid}'",
                "ssid": req.ssid
            }
        
        # Проверка видимости сети
        logging.info(f"Checking network visibility: {req.ssid}")
        nets = wm.scan()
        found_network = None
        for net in nets:
            if net.ssid == req.ssid:
                found_network = net
                break
        
        if not found_network:
            available_ssids = [net.ssid for net in nets[:5]]
            raise HTTPException(
                status_code=400,
                detail=f"Network '{req.ssid}' not found. Available: {available_ssids}"
            )
        
        # Проверяем требования к безопасности
        requires_password = found_network.security and found_network.security.strip() not in ["", "--"]
        if requires_password and not req.password:
            raise HTTPException(
                status_code=400,
                detail=f"Network '{req.ssid}' requires a password (security: {found_network.security})"
            )
        
        # Валидация учетных данных
        logging.info(f"Validating credentials for: {req.ssid}")
        if not _validate_credentials(req.ssid, req.password):
            raise HTTPException(
                status_code=401,  # Unauthorized
                detail=f"Invalid credentials for network '{req.ssid}'. Check SSID and password."
            )
        
        # Запускаем переключение в фоновом потоке
        thread = threading.Thread(
            target=_background_switch,
            args=(req.ssid, req.password),
            daemon=True
        )
        thread.start()
        
        return {
            "ok": True,
            "message": f"Credentials validated. Switching from '{current_ssid}' to '{req.ssid}' in background.",
            "from_ssid": current_ssid,
            "to_ssid": req.ssid
        }
        
    except HTTPException:
        raise
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logging.exception("Unexpected error in wifi_switch")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/disconnect")
def wifi_disconnect():
    """Отключение от текущей Wi-Fi сети"""
    try:
        current_status = wm.status()
        current_ssid = current_status.get("ssid")
        
        if not current_ssid:
            return {"ok": True, "message": "Not connected to any network"}
        
        # Отключение в фоновом потоке
        def _background_disconnect():
            try:
                wm.disconnect()
                logging.info("Background disconnect completed")
            except Exception as e:
                logging.error(f"Background disconnect failed: {e}")
        
        thread = threading.Thread(target=_background_disconnect, daemon=True)
        thread.start()
        
        return {
            "ok": True,
            "message": f"Disconnecting from '{current_ssid}' in background",
            "ssid": current_ssid
        }
        
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logging.exception("Unexpected error in wifi_disconnect")
        raise HTTPException(status_code=500, detail=str(e))
