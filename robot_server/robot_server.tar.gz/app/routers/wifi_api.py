from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
import asyncio
from ..services import wifi_manager as wm
from .wifi_ws import notify_new_ip
import subprocess

app = APIRouter(prefix="/wifi", tags=["WiFi"])

class ConnectReq(BaseModel):
    ssid: str
    password: Optional[str] = None

class WifiNetworkResp(BaseModel):
    in_use: bool
    ssid: str
    signal: int
    security: str

def sudo_nmcli(args: list):
    """Обёртка для вызова nmcli с sudo."""
    cmd = ["sudo", "nmcli"] + args
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        raise wm.WifiError(e.stderr.decode())

@app.get("/scan", response_model=List[WifiNetworkResp])
def wifi_scan():
    try:
        # рескан сети перед сканированием
        sudo_nmcli(["device", "wifi", "rescan"])
        nets = wm.scan()
        return [WifiNetworkResp(**n.__dict__) for n in nets]
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
def wifi_status():
    try:
        return wm.status()
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/connect")
def wifi_connect(req: ConnectReq):
    try:
        # рескан перед подключением
        sudo_nmcli(["device", "wifi", "rescan"])
        wm.connect(req.ssid, req.password, use_sudo=True)
        return {"ok": True, "message": "Connecting; network may change"}
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))

def _schedule_notify():
    # маленькая задержка, чтобы IP успел смениться
    async def _run():
        await asyncio.sleep(2)
        await notify_new_ip()
    asyncio.create_task(_run())

@app.post("/switch")
def wifi_switch(req: ConnectReq, bg: BackgroundTasks):
    try:
        # рескан перед переключением
        sudo_nmcli(["device", "wifi", "rescan"])
        wm.switch(req.ssid, req.password, use_sudo=True)
        bg.add_task(_schedule_notify)
        return {"ok": True, "message": "Switched; connection may drop"}
    except wm.WifiError as e:
        raise HTTPException(status_code=500, detail=str(e))
