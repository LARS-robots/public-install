# app/routers/logs.py
from __future__ import annotations

import io
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import msgpack
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import Response, FileResponse

# .zst архивы (опционально)
try:
    import zstandard as zstd  # type: ignore
except Exception:  # pragma: no cover
    zstd = None

from ..telemetry import logbus  # твой внутренний шина-логов

router = APIRouter(prefix="/admin", tags=["admin"])


# ---------- конфиг путей ----------
def _load_cfg() -> Dict[str, Any]:
    for p in [
        Path("~/LARS/robot_server/config.toml").expanduser(),
        Path("config.toml"),
        Path(__file__).resolve().parent / "config.toml",
    ]:
        if p.exists():
            try:
                try:
                    import tomllib as toml_reader  # py311+
                except Exception:
                    import tomli as toml_reader
                with p.open("rb") as f:
                    return toml_reader.load(f) or {}
            except Exception:
                pass
    return {}

_cfg = _load_cfg().get("logging", {}) or {}
LIVE_DIR    = Path(_cfg.get("live_dir", "/var/log/lars/live"))
ARCHIVE_DIR = Path(_cfg.get("archive_dir", "/var/log/lars/archive"))

# Путь к статике (logs.html), предполагаем структуру app/static/logs.html
STATIC_LOGS_HTML = (
    Path(__file__).resolve().parent.parent / "static" / "logs.html"
)


# ---------- чтение лог-файлов ----------
def _iter_file_events(path: Path) -> Iterable[Dict[str, Any]]:
    """Итерация событий в одном .msgp или .msgp.zst файле (в порядке записи)."""
    try:
        if path.suffix == ".zst":
            if zstd is None:
                return
            d = zstd.ZstdDecompressor()
            with path.open("rb") as f, d.stream_reader(f) as r:
                data = r.read()
            unpacker = msgpack.Unpacker(io.BytesIO(data), raw=False)
        else:
            unpacker = msgpack.Unpacker(path.open("rb"), raw=False)
        for obj in unpacker:
            if isinstance(obj, dict):
                yield obj
    except Exception:
        return  # битые/обрезанные хвосты игнорируем


def _list_log_files(newest_first: bool = True) -> List[Path]:
    files: List[Path] = []
    if ARCHIVE_DIR.exists():
        files += list(ARCHIVE_DIR.glob("robot-*.msgp.zst"))
        files += list(ARCHIVE_DIR.glob("robot-*.msgp"))
    if LIVE_DIR.exists():
        live = LIVE_DIR / "robot-current.msgp"
        if live.exists():
            files.append(live)
    files.sort(key=lambda p: p.stat().st_mtime, reverse=newest_first)
    return files


def _parse_ts(ts: str) -> float:
    # 'YYYY-MM-DDTHH:MM:SS' → epoch (UTC-like)
    try:
        return time.mktime(time.strptime(ts, "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0.0


def _match(
    ev: Dict[str, Any],
    levels: Optional[set] = None,
    sid_sub: Optional[str] = None,
    regex: Optional[re.Pattern] = None,
) -> bool:
    lvl = str(ev.get("level", "INFO")).upper()
    if levels and lvl not in levels:
        return False
    if sid_sub and sid_sub not in str(ev.get("session_id", "")):
        return False
    if regex:
        try:
            s = json.dumps(ev, ensure_ascii=False, separators=(",", ":"))
            if not regex.search(s):
                return False
        except Exception:
            if not regex.search(repr(ev)):
                return False
    return True


# ---------- API: tail / before ----------
@router.get("/logs/tail")
def logs_tail(
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает последние `limit` событий (архив + live-сегмент) с серверной фильтрацией.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None

    from collections import deque
    ring = deque(maxlen=limit)

    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            if _match(ev, want_levels, sid or None, regex):
                ring.append(ev)
        # ring сам удержит последний хвост
    data = list(ring)
    return Response(
        content=msgpack.packb(data, use_bin_type=True),
        media_type="application/msgpack",
    )


@router.get("/logs/before")
def logs_before(
    before_ts: str = Query(..., description="ISO ts of oldest item in view (YYYY-MM-DDTHH:MM:SS)"),
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Возвращает ещё `limit` событий, которые старше `before_ts`.
    """
    cutoff = _parse_ts(before_ts)
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None

    out: List[Dict[str, Any]] = []
    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            ts = _parse_ts(str(ev.get("ts", "")))
            if ts and ts < cutoff and _match(ev, want_levels, sid or None, regex):
                out.append(ev)
                if len(out) >= limit:
                    return Response(
                        content=msgpack.packb(out, use_bin_type=True),
                        media_type="application/msgpack",
                    )
    return Response(
        content=msgpack.packb(out, use_bin_type=True),
        media_type="application/msgpack",
    )


# ---------- HTML-вьюер (статика) ----------
@router.get("/logs")
def logs_page():
    """
    Возвращает статическую страницу UI лога.
    """
    # Если важно — можно добавить ETag/Cache-Control через Response, но FileResponse достаточно.
    return FileResponse(STATIC_LOGS_HTML)


# ---------- WS: live ----------
@router.websocket("/logs/ws")
async def logs_ws(ws: WebSocket) -> None:
    """
    Постоянный поток событий лога через WebSocket.

    Клиент закрывает соединение при нажатии 'Pause' и открывает заново на 'Resume'.
    Тут просто корректно завершаем подписку при разрыве.
    """
    await ws.accept()
    q = await logbus.subscribe()
    try:
        snap = logbus.snapshot()
        if snap:
            await ws.send_bytes(msgpack.packb({"type": "snapshot", "items": snap}, use_bin_type=True))
        while True:
            item = await q.get()
            await ws.send_bytes(msgpack.packb({"type": "evt", "item": item}, use_bin_type=True))
    except WebSocketDisconnect:
        pass
    finally:
        await logbus.unsubscribe(q)
