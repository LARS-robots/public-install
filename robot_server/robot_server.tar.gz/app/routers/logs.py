# app/routers/logs.py
from __future__ import annotations

import io
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import msgpack
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import HTMLResponse, Response

# zstd (для чтения архивов .zst) — опционально
try:
    import zstandard as zstd  # type: ignore
except Exception:  # pragma: no cover
    zstd = None

from ..telemetry import logbus

router = APIRouter(prefix="/admin", tags=["admin"])


# ---------- конфиг путей ----------
def _load_cfg() -> Dict[str, Any]:
    for p in [
        Path("~/LARS/robot_server/config.toml").expanduser(),
        Path("config.toml"),
        Path(__file__).resolve().parent / "config.toml",
    ]:
        if p.exists():
            try:
                try:
                    import tomllib as toml_reader  # py311+
                except Exception:
                    import tomli as toml_reader
                with p.open("rb") as f:
                    return toml_reader.load(f) or {}
            except Exception:
                pass
    return {}

_cfg = _load_cfg().get("logging", {}) or {}
LIVE_DIR    = Path(_cfg.get("live_dir", "/var/log/lars/live"))
ARCHIVE_DIR = Path(_cfg.get("archive_dir", "/var/log/lars/archive"))


# ---------- утилиты чтения ----------
def _iter_file_events(path: Path) -> Iterable[Dict[str, Any]]:
    """События из одного файла .msgp или .msgp.zst (по порядку)."""
    try:
        if path.suffix == ".zst":
            if zstd is None:
                return
            d = zstd.ZstdDecompressor()
            with path.open("rb") as f, d.stream_reader(f) as r:
                data = r.read()
            unpacker = msgpack.Unpacker(io.BytesIO(data), raw=False)
        else:
            unpacker = msgpack.Unpacker(path.open("rb"), raw=False)
        for obj in unpacker:
            if isinstance(obj, dict):
                yield obj
    except Exception:
        return  # битый хвост — тихо пропускаем


def _list_log_files(newest_first: bool = True) -> List[Path]:
    files: List[Path] = []
    if ARCHIVE_DIR.exists():
        files += list(ARCHIVE_DIR.glob("robot-*.msgp.zst"))
        files += list(ARCHIVE_DIR.glob("robot-*.msgp"))
    if LIVE_DIR.exists():
        live = LIVE_DIR / "robot-current.msgp"
        if live.exists():
            files.append(live)
    files.sort(key=lambda p: p.stat().st_mtime, reverse=newest_first)
    return files


def _parse_ts(ts: str) -> float:
    # 'YYYY-MM-DDTHH:MM:SS' → epoch
    try:
        return time.mktime(time.strptime(ts, "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0.0


def _match(
    ev: Dict[str, Any],
    levels: Optional[set] = None,
    sid_sub: Optional[str] = None,
    regex: Optional[re.Pattern] = None,
) -> bool:
    lvl = str(ev.get("level", "INFO")).upper()
    if levels and lvl not in levels:
        return False
    if sid_sub and sid_sub not in str(ev.get("session_id", "")):
        return False
    if regex:
        try:
            # быстрый и надёжный сериализатор для поиска: JSON
            s = json.dumps(ev, ensure_ascii=False, separators=(",", ":"))
            if not regex.search(s):
                return False
        except Exception:
            if not regex.search(repr(ev)):
                return False
    return True


# ---------- API: tail / before ----------
@router.get("/logs/tail")
def logs_tail(
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Вернуть последние `limit` событий (архив + текущий сегмент), отфильтрованные на сервере.
    """
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None

    from collections import deque
    ring: deque = deque(maxlen=limit)

    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            if _match(ev, want_levels, sid or None, regex):
                ring.append(ev)
        if len(ring) >= limit:
            # продолжаем — файлы идут от новых к старым; ring удержит только "хвост"
            pass

    data = list(ring)
    return Response(content=msgpack.packb(data, use_bin_type=True),
                    media_type="application/msgpack")


@router.get("/logs/before")
def logs_before(
    before_ts: str = Query(..., description="ISO ts of oldest currently shown event (YYYY-MM-DDTHH:MM:SS)"),
    limit: int = Query(1000, ge=1, le=10000),
    levels: str = Query("INFO,WARNING,ERROR"),
    sid: str = Query(""),
    q: str = Query(""),
):
    """
    Вернуть ещё `limit` событий, которые старше (меньше по ts), чем `before_ts`.
    """
    cutoff = _parse_ts(before_ts)
    want_levels = {s.strip().upper() for s in levels.split(",") if s.strip()}
    regex = re.compile(q, re.I) if q else None

    out: List[Dict[str, Any]] = []
    for path in _list_log_files(newest_first=True):
        for ev in _iter_file_events(path):
            ts = _parse_ts(str(ev.get("ts", "")))
            if ts and ts < cutoff and _match(ev, want_levels, sid or None, regex):
                out.append(ev)
                if len(out) >= limit:
                    return Response(content=msgpack.packb(out, use_bin_type=True),
                                    media_type="application/msgpack")
    return Response(content=msgpack.packb(out, use_bin_type=True),
                    media_type="application/msgpack")


# ---------- HTML-вьюер ----------
@router.get("/logs", response_class=HTMLResponse)
def logs_page() -> str:
    return HTML_PAGE


# ---------- WS: live ----------
@router.websocket("/logs/ws")
async def logs_ws(ws: WebSocket) -> None:
    await ws.accept()
    q = await logbus.subscribe()
    snap = logbus.snapshot()
    if snap:
        await ws.send_bytes(msgpack.packb({"type": "snapshot", "items": snap}, use_bin_type=True))
    try:
        while True:
            item = await q.get()
            await ws.send_bytes(msgpack.packb({"type": "evt", "item": item}, use_bin_type=True))
    except WebSocketDisconnect:
        pass
    finally:
        await logbus.unsubscribe(q)


HTML_PAGE = """<!doctype html><meta charset="utf-8">
<title>Logs</title>
<style>
  :root { color-scheme: dark; }
  *{box-sizing:border-box}
  body{margin:0;font:13px/1.35 system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;background:#202124;color:#e8eaed}
  header{display:flex;align-items:center;gap:8px;justify-content:space-between;padding:8px 10px;border-bottom:1px solid #303134;background:#1f1f1f;position:sticky;top:0;z-index:10}
  header h1{font-size:15px;margin:0;font-weight:600;opacity:.9}
  .toolbar{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:6px 10px;border-bottom:1px solid #303134;background:#1c1c1c;position:sticky;top:40px;z-index:9}
  .lvbar{display:flex;gap:4px}
  .lvbtn{width:26px;height:26px;border-radius:6px;border:1px solid #3c4043;background:#2b2f31;color:#e8eaed;font-weight:700;cursor:pointer;padding:0;display:inline-flex;align-items:center;justify-content:center}
  .lvbtn.on{outline:2px solid #5f9cf7}
  .lvbtn[data-lv="INFO"].on{background:#1b4332}
  .lvbtn[data-lv="WARNING"].on{background:#553d00}
  .lvbtn[data-lv="ERROR"].on{background:#5b1b1b}
  .lvbtn[data-lv="DEBUG"].on{background:#123055}
  .toolbar input{background:#2b2f31;color:#e8eaed;border:1px solid #3c4043;border-radius:8px;padding:5px 8px;min-width:170px}
  .toolbar .btn{background:#3c4043;border:none;color:#fff;border-radius:8px;padding:5px 10px;cursor:pointer}
  #stats{margin-left:auto;opacity:.8;font-size:12px}
  #loglist{height:calc(100vh - 82px);overflow:auto}
  /* контейнер одной записи: первая строка (шапка) + вторая строка (детали) */
  .entry{display:grid;grid-template-columns:auto 1fr auto;grid-auto-rows:auto;gap:8px;border-bottom:1px solid #2b2f31;font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace}
  .entry:hover{background:#111417}
  .lvl{font-weight:700;min-width:48px;text-align:center;border-radius:6px;padding:2px 6px;align-self:center;margin:6px 0 0 10px}
  .lvl.INFO{background:#1b4332}
  .lvl.WARNING{background:#553d00}
  .lvl.ERROR{background:#5b1b1b}
  .lvl.DEBUG{background:#123055}
  .msg{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;align-self:center;margin-top:6px}
  .ts{opacity:.7;margin-right:6px}
  .pill{display:inline-block;margin:0 6px;background:#2b2f31;border:1px solid #3c4043;border-radius:999px;padding:2px 8px}
  .right{display:flex;align-items:center;gap:8px;align-self:center;margin:6px 10px 0 0}
  .logger{opacity:.8;font-size:12px}
  .expbtn{cursor:pointer;opacity:.85;border:1px solid #3c4043;border-radius:6px;padding:0 8px;height:22px;display:inline-flex;align-items:center;justify-content:center;background:#2b2f31}
  .expbtn::after{content:'›';display:inline-block;transform:rotate(0deg);transition:transform .12s ease;font-size:14px}
  .entry.open .expbtn::after{transform:rotate(90deg)}
  .expbody{grid-column:1/-1;padding:6px 10px 10px 10px;background:#131516;border-top:1px dashed #303134;display:none}
  .entry.open .expbody{display:block}
  pre{margin:0;font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;white-space:pre-wrap;word-break:break-word}
</style>
<header>
  <h1>Logs</h1>
  <div id="stats">0 evt/s • 0 shown • 0 queued</div>
</header>
<div class="toolbar">
  <div class="lvbar" title="Toggle levels">
    <button class="lvbtn on" data-lv="INFO"    title="INFO">I</button>
    <button class="lvbtn on" data-lv="WARNING" title="WARNING">W</button>
    <button class="lvbtn on" data-lv="ERROR"   title="ERROR">E</button>
    <button class="lvbtn"     data-lv="DEBUG"  title="DEBUG">D</button>
  </div>
  <input id="sid" placeholder="session_id (optional)" title="Filter by session_id substring">
  <input id="search" placeholder="regex (server: files; client: all in view)" title="Regex over full JSON of each event">
  <button class="btn" id="reload">Reload tail</button>
  <button class="btn" id="older">Load older</button>
  <button class="btn" id="pause">Pause</button>
</div>
<div id="loglist"></div>
<script type="module">
import { decode } from "https://cdn.jsdelivr.net/npm/@msgpack/msgpack@3.0.0/+esm";

const list = document.getElementById('loglist');
let paused=false, shown=0, rateCount=0, lastTS=performance.now();
let re=null;
const levels = {INFO:true, WARNING:true, ERROR:true, DEBUG:false};
const events = []; // единый буфер — и для диска, и для live
const queued = []; // события, пришедшие во время паузы (не отображаются)
const MAX_ROWS = 20000;
const MAX_QUEUED = 50000;

// --- фильтры (живые) ---
for (const b of document.querySelectorAll('.lvbtn')){
  b.addEventListener('click', ()=>{
    b.classList.toggle('on');
    levels[b.dataset.lv] = b.classList.contains('on');
    rerender();
  });
}
for (const id of ['sid','search']) {
  document.getElementById(id).addEventListener('input', ()=>{ setRegex(); rerender(); });
}
function setRegex(){
  const v = document.getElementById('search').value.trim();
  re = v ? new RegExp(v, 'i') : null;
}

const pauseBtn = document.getElementById('pause');
pauseBtn.onclick = () => {
  paused = !paused;
  if (paused){
    pauseBtn.textContent = queued.length ? `Resume (+${queued.length})` : 'Resume';
  } else {
    // при резюме — единоразово подаём накопленное в поток и чистим очередь
    if (queued.length){
      events.push(...queued.splice(0, queued.length));
    }
    pauseBtn.textContent = 'Pause';
    rerender(); // дорисуем то, что добавили
  }
  updateStats(true);
};

document.getElementById('reload').onclick=()=>{ fetchTail(true); };
document.getElementById('older').onclick=()=>{ fetchBefore(); };

// --- предикат видимости (клиент) ---
function keepClient(e){
  const level = e.level || 'INFO';
  if (!levels[level]) return false;
  const sid = document.getElementById('sid').value.trim();
  if (sid && String(e.session_id||'').indexOf(sid)===-1) return false;
  if (re && !re.test(JSON.stringify(e))) return false; // regex по ВСЕМ отображаемым событиям
  return true;
}
function pillText(o){
  const stage = o.stage || o.tag || o.logger || '';
  const action = o.action || '';
  return (stage ? stage : '') + (action ? '/' + action : '');
}

// --- время: отображаем в локальном времени клиента ---
function fmtLocal(tsStr){
  if (!tsStr) return '';
  // сервер присылает 'YYYY-MM-DDTHH:MM:SS' без таймзоны → считаем, что это UTC и показываем локальное
  const d = new Date(tsStr + 'Z');
  if (isNaN(d)) return tsStr;
  const pad = n => String(n).padStart(2,'0');
  const y = d.getFullYear(), m = pad(d.getMonth()+1), day = pad(d.getDate());
  const hh = pad(d.getHours()), mm = pad(d.getMinutes()), ss = pad(d.getSeconds());
  return `${y}-${m}-${day} ${hh}:${mm}:${ss}`;
}

// --- рендер одной записи ---
function entryHTML(o){
  const lvl = o.level||'INFO';
  const ts = o.ts||'';
  const tsLocal = fmtLocal(ts);
  const pill = pillText(o);
  const em = o.error_message?` — ${o.error_message}`:'';
  const msg = o.msg && !o.tag ? ` — ${o.msg}`:'';
  const logger = o.logger || '';
  const json = JSON.stringify(o, null, 2);

  return `<div class="entry">
    <div class="lvl ${lvl}">${lvl}</div>
    <div class="msg"><span class="ts" title="${ts}">${tsLocal}</span> ${pill ? `<span class="pill">${pill}</span>` : ''}${em}${msg}</div>
    <div class="right"><span class="logger">${logger}</span><button class="expbtn" title="details"></button></div>
    <div class="expbody"><pre>${json}</pre></div>
  </div>`;
}

function attachEntryHandlers(node){
  const btn = node.querySelector('.expbtn');
  btn?.addEventListener('click', ()=>{
    node.classList.toggle('open');
  });
}

// --- ререндер всего списка (при смене фильтров) ---
function rerender(){
  list.innerHTML='';
  shown=0;
  for (const e of events) {
    if (keepClient(e)) {
      const tmp = document.createElement('div');
      tmp.innerHTML = entryHTML(e);
      const entry = tmp.firstElementChild;
      list.appendChild(entry);
      attachEntryHandlers(entry);
      shown++;
      if (shown>MAX_ROWS) break;
    }
  }
  autoscroll();
  updateStats();
}

// --- добавление новых событий ---
function ingest(arr, mode="append"){
  if (mode==="replace"){ events.length = 0; list.innerHTML=''; shown=0; }
  // если включена пауза — не рендерим и не добавляем в `events`, а только копим в очереди
  if (paused){
    for (const e of arr){
      if (queued.length < MAX_QUEUED) queued.push(e);
    }
    pauseBtn.textContent = `Resume (+${queued.length})`;
    updateStats(true);
    return;
  }
  for (const e of arr){
    rateCount++;
    events.push(e);
  }
  rerender();
}

// --- утилиты ---
function autoscroll(){
  if (!paused) list.lastElementChild?.scrollIntoView({block:'end'});
}
function updateStats(force=false){
  const now = performance.now();
  const eps = ((rateCount*1000)/(now-lastTS||1)).toFixed(1);
  document.getElementById('stats').textContent = `${eps} evt/s • ${shown} shown • ${queued.length} queued`;
  if (force){ lastTS = now; rateCount = 0; }
}
setInterval(()=>{
  updateStats();
  rateCount=0; lastTS=performance.now();
},1000);

function levelsCSV(){
  return Object.entries(levels).filter(([k,v])=>v).map(([k])=>k).join(',');
}
function earliestTs(){
  let t = Infinity, val = '';
  for (const e of events){
    if (e.ts){
      const ts = e.ts;
      const n = Date.parse(ts.replace('T',' ')+'Z'); // UTC-like
      if (!isNaN(n) && n < t){ t = n; val = e.ts; }
    }
  }
  return val;
}

// --- диск: tail / before ---
async function fetchTail(replace=false){
  const sid = encodeURIComponent(document.getElementById('sid').value.trim());
  const q   = encodeURIComponent(document.getElementById('search').value.trim());
  const lv  = encodeURIComponent(levelsCSV());
  const url = `/admin/logs/tail?limit=2000&levels=${lv}${sid?`&sid=${sid}`:''}${q?`&q=${q}`:''}`;
  const res = await fetch(url, {headers:{"Accept":"application/msgpack"}});
  const buf = await res.arrayBuffer();
  const arr = decode(new Uint8Array(buf));
  ingest(arr, replace?"replace":"append");
}
async function fetchBefore(){
  const ts = earliestTs();
  if (!ts) return;
  const sid = encodeURIComponent(document.getElementById('sid').value.trim());
  const q   = encodeURIComponent(document.getElementById('search').value.trim());
  const lv  = encodeURIComponent(levelsCSV());
  const url = `/admin/logs/before?before_ts=${encodeURIComponent(ts)}&limit=2000&levels=${lv}${sid?`&sid=${sid}`:''}${q?`&q=${q}`:''}`;
  const res = await fetch(url, {headers:{"Accept":"application/msgpack"}});
  const buf = await res.arrayBuffer();
  const arr = decode(new Uint8Array(buf));
  ingest(arr, "append");
}

// --- live WS ---
let ws;
function connect(){
  ws = new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/admin/logs/ws`);
  ws.binaryType = 'arraybuffer';
  ws.onmessage = e => {
    const obj = decode(new Uint8Array(e.data));
    if (obj.type === 'snapshot') ingest(obj.items, events.length? "append" : "replace");
    else if (obj.type === 'evt') ingest([obj.item], "append");
  };
  ws.onclose = ()=> setTimeout(connect, 1000);
}
await fetchTail(true); // стартовый хвост с диска (с серверной фильтрацией)
connect();             // затем — live
</script>
"""
