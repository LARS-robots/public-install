# robot_server/app/routers/motion.py
from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel, Field
from typing import Optional
import logging

from ..services.robot_service import get_robot_service, RobotService, RobotCommand
from ..services.motor_service import MotorService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/motion", tags=["motion"])

class CommandReq(BaseModel):
    throttle: Optional[float] = Field(None, ge=-1.0, le=1.0)
    steer: Optional[float] = Field(None, ge=-1.0, le=1.0)
    vx: Optional[float] = None
    wz: Optional[float] = None

# Proper dependency function
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

@router.post("/command")
def post_command(
    body: CommandReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Send joystick command to robot.
    Supports both joystick mode (throttle/steer) and velocity mode (vx/wz).
    """
    command = RobotCommand(
        throttle=body.throttle,
        steer=body.steer,
        vx=body.vx,
        wz=body.wz
    )
    result = robot.send_command(command)
    logger.debug(f"Motion command executed: {body.dict()}")
    return result


# --- NEW endpoints (keep DI simple, do not break existing routes) ---

@router.post("/permission")
def post_permission(req: Request):
    """
    Dictum ignition/permission (0x20 or as configured).
    Uses MotorService facade, reads config.toml, and writes a 26-byte UART frame.
    """
    svc = MotorService()
    result = svc.send_permission(req.app.state)
    logger.info("motion.permission", extra={"event": {
        "stage": "motion", "action": "permission", "result": result
    }})
    return result


@router.post("/starter")
def post_starter(req: Request):
    """
    Dictum starter + ignition (0x30 or as configured).
    Uses MotorService facade, reads config.toml, and writes a 26-byte UART frame.
    """
    svc = MotorService()
    result = svc.send_starter(req.app.state)
    logger.info("motion.starter", extra={"event": {
        "stage": "motion", "action": "starter", "result": result
    }})
    return result
