# robot_server/app/routers/motion.py
from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel, Field
from typing import Optional
import logging

from ..services.robot_service import get_robot_service, RobotService, RobotCommand
from ..services.motor_service import MotorService, get_motor_service as get_motor_service_instance

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/motion", tags=["motion"])

class CommandReq(BaseModel):
    throttle: Optional[float] = Field(None, ge=-1.0, le=1.0)
    steer: Optional[float] = Field(None, ge=-1.0, le=1.0)
    vx: Optional[float] = None
    wz: Optional[float] = None

def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

def get_motor_from_request(req: Request) -> MotorService:
    return get_motor_service_instance(req.app.state)

@router.post("/command")
def post_command(
    body: CommandReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Send joystick command to robot.
    Supports both joystick mode (throttle/steer) and velocity mode (vx/wz).
    """
    command = RobotCommand(
        throttle=body.throttle,
        steer=body.steer,
        vx=body.vx,
        wz=body.wz
    )
    result = robot.send_command(command)
    logger.debug(f"Motion command executed: {body.dict()}")
    return result


# ---------- per-relay endpoints ----------
class RelayReq(BaseModel):
    on: bool = True

@router.post("/relay/permission")
def relay_permission(req: Request, body: RelayReq, svc: MotorService = Depends(get_motor_from_request)):
    res = svc.send_relay(req.app.state, "permission", body.on)
    logger.info("motion.relay.permission", extra={"event": {
        "stage": "motion", "action": "relay_permission", "on": body.on, "result": res
    }})
    return res

@router.post("/relay/starter")
def relay_starter(req: Request, body: RelayReq, svc: MotorService = Depends(get_motor_from_request)):
    res = svc.send_relay(req.app.state, "starter", body.on)
    logger.info("motion.relay.starter", extra={"event": {
        "stage": "motion", "action": "relay_starter", "on": body.on, "result": res
    }})
    return res

@router.post("/relay/speed2")
def relay_speed2(body: RelayReq, req: Request, svc: MotorService = Depends(get_motor_from_request)):
    """
    Toggle the 'speed2' relay bit on the motor driver.
    Delegates to MotorService so driver logic remains in services/.
    """
    res = svc.send_relay(req.app.state, "speed2", body.on)
    logger.info("motion.relay.speed2", extra={"event": {
        "stage": "motion", "action": "relay_speed2", "on": body.on, "result": res
    }})
    return res

@router.post("/relay/sound")
def relay_sound(req: Request, body: RelayReq, svc: MotorService = Depends(get_motor_from_request)):
    res = svc.send_relay(req.app.state, "sound", body.on)
    logger.info("motion.relay.sound", extra={"event": {
        "stage": "motion", "action": "relay_sound", "on": body.on, "result": res
    }})
    return res

@router.post("/relay/stop")
def relay_stop(req: Request, body: RelayReq, svc: MotorService = Depends(get_motor_from_request)):
    res = svc.send_relay(req.app.state, "stop", body.on)
    logger.info("motion.relay.stop", extra={"event": {
        "stage": "motion", "action": "relay_stop", "on": body.on, "result": res
    }})
    return res
