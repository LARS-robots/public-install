# from fastapi import APIRouter, Depends, Body
# from pydantic import BaseModel, conint
#
# # Replace relative imports with absolute imports
# try:
#     from robot.robot_server.app.deps import get_robot
#     from robot.robot_server.app.services.robot_iface import Robot
# except ImportError:
#     try:
#         from app.deps import get_robot
#         from app.services.robot_iface import Robot
#     except ImportError:
#         from deps import get_robot
#         from services.robot_iface import Robot

from fastapi import APIRouter, Depends, Body
from ..deps import get_robot
from ..services.robot_iface import Robot
from pydantic import BaseModel, conint

class MoveCmd(BaseModel):
    left:  conint(ge=-255, le=255)
    right: conint(ge=-255, le=255)

router = APIRouter(prefix="/motion", tags=["Motion"])

@router.post("/move")
def move(cmd: MoveCmd, bot: Robot = Depends(get_robot)):
    bot.move(cmd.left, cmd.right)
    return cmd
