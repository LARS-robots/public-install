from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from ..services import wifi_manager as wm
import asyncio

router = APIRouter(prefix="/wifi", tags=["WiFi"])
clients: list[WebSocket] = []

@router.websocket("/ws/wifi")
async def wifi_ws(ws: WebSocket):
    await ws.accept()
    clients.append(ws)
    try:
        while True:
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        clients.remove(ws)

async def notify_new_ip():
    ip_info = wm.status()  # теперь wm.status() сам определяет интерфейс
    data = {"ssid": ip_info.get("ssid"), "ip": ip_info.get("ip4")}
    for ws in clients.copy():
        try:
            await ws.send_json(data)
        except:
            clients.remove(ws)
