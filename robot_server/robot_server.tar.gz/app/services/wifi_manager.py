import shlex, subprocess
from dataclasses import dataclass
from typing import List, Optional, Dict

NMCLI = "nmcli"  # run service as root, so no sudo needed

@dataclass
class WifiNetwork:
    in_use: bool
    ssid: str
    signal: int
    security: str

class WifiError(RuntimeError): pass

def _run(cmd: str, timeout: int = 10) -> str:
    try:
        res = subprocess.run(cmd, shell=True, check=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, timeout=timeout)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        raise WifiError(e.stderr.strip() or str(e))
    except subprocess.TimeoutExpired:
        raise WifiError("nmcli timeout")

def scan(iface: str = "wlan0") -> List[WifiNetwork]:
    _run(f"{NMCLI} device wifi rescan ifname {shlex.quote(iface)}")
    out = _run(f"{NMCLI} -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list ifname {shlex.quote(iface)}")
    nets: List[WifiNetwork] = []
    for line in out.splitlines():
        parts = line.split(":")
        if len(parts) > 4:
            # SSID contains colon(s): join middle parts back
            in_use = (parts[0].strip() == "*")
            signal = int(parts[-2] or 0)
            security = parts[-1] or ""
            ssid = ":".join(parts[1:-2]).strip()
        else:
            in_use = (parts[0].strip() == "*")
            ssid = parts[1].strip()
            signal = int(parts[2] or 0)
            security = parts[3].strip()
        nets.append(WifiNetwork(in_use, ssid, signal, security))
    return nets

def status(iface: str = "wlan0") -> Dict[str, Optional[str]]:
    try: ssid = _run(f"{NMCLI} -t -f active,ssid dev wifi | egrep '^yes' | cut -d: -f2")
    except WifiError: ssid = None
    try: ip4 = _run(f"{NMCLI} -g IP4.ADDRESS device show {shlex.quote(iface)}").splitlines()[0]
    except WifiError: ip4 = None
    return {"ssid": ssid, "ip4": ip4, "iface": iface}

def connect(ssid: str, password: Optional[str], iface: str = "wlan0") -> None:
    cmd = f'{NMCLI} device wifi connect {shlex.quote(ssid)}'
    if password: cmd += f' password {shlex.quote(password)}'
    cmd += f' ifname {shlex.quote(iface)}'
    _run(cmd, timeout=30)

def disconnect(iface: str = "wlan0") -> None:
    _run(f"{NMCLI} device disconnect {shlex.quote(iface)}", timeout=10)

def switch(ssid: str, password: Optional[str], iface: str = "wlan0") -> None:
    try: disconnect(iface)
    except WifiError: pass
    connect(ssid, password, iface)