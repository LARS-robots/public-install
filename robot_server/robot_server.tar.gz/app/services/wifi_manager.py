import shlex, subprocess, logging, time
from dataclasses import dataclass
from typing import List, Optional, Dict

log = logging.getLogger(__name__)
NMCLI = "nmcli"

@dataclass
class WifiNetwork:
    in_use: bool
    ssid: str
    signal: int
    security: str

class WifiError(RuntimeError): pass

def _run(cmd: str, timeout: int = 10) -> str:
    """Выполнить команду и вернуть stdout"""
    log.info(f"Executing: {cmd}")
    try:
        res = subprocess.run(cmd, shell=True, check=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, timeout=timeout)
        log.info(f"Command success: {res.stdout.strip()}")
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() or str(e)
        log.error(f"Command failed: {cmd} -> {error_msg}")
        raise WifiError(error_msg)
    except subprocess.TimeoutExpired:
        log.error(f"Command timeout: {cmd}")
        raise WifiError("nmcli timeout")

def scan(iface: str = "wlan0") -> List[WifiNetwork]:
    """Сканирование доступных Wi-Fi сетей"""
    log.info("Starting WiFi scan...")
    
    # Принудительное сканирование
    try:
        _run(f"sudo {NMCLI} device wifi rescan ifname {shlex.quote(iface)}", timeout=15)
        time.sleep(2)  # Даем время на завершение сканирования
    except WifiError as e:
        log.warning(f"Rescan failed: {e}")
    
    # Получение списка сетей
    out = _run(f"sudo {NMCLI} -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list ifname {shlex.quote(iface)}")
    nets: List[WifiNetwork] = []
    
    for line in out.splitlines():
        if not line.strip():
            continue
            
        parts = line.split(":")
        if len(parts) < 4:
            continue
            
        try:
            if len(parts) > 4:
                # Если SSID содержит двоеточия
                in_use = (parts[0].strip() == "*")
                signal = int(parts[-2] or 0)
                security = parts[-1] or ""
                ssid = ":".join(parts[1:-2]).strip()
            else:
                in_use = (parts[0].strip() == "*")
                ssid = parts[1].strip()
                signal = int(parts[2] or 0)
                security = parts[3].strip()
            
            if ssid:  # Игнорируем пустые SSID
                nets.append(WifiNetwork(in_use, ssid, signal, security))
                
        except (ValueError, IndexError) as e:
            log.warning(f"Failed to parse WiFi line: {line} -> {e}")
            continue
    
    log.info(f"Found {len(nets)} WiFi networks")
    return nets

def status(iface: str = "wlan0") -> Dict[str, Optional[str]]:
    """Получение текущего статуса подключения"""
    try:
        # Получаем активное подключение
        out = _run(f"sudo {NMCLI} -t -f active,ssid dev wifi")
        ssid = None
        for line in out.splitlines():
            if line.startswith("yes:"):
                ssid = line[4:].strip()
                break
    except WifiError:
        ssid = None
    
    try:
        # Получаем IP адрес
        ip4 = _run(f"sudo {NMCLI} -g IP4.ADDRESS device show {shlex.quote(iface)}")
        if ip4:
            ip4 = ip4.splitlines()[0].split('/')[0]  # Убираем маску подсети
    except WifiError:
        ip4 = None
    
    return {"ssid": ssid, "ip4": ip4, "iface": iface}

def connect(ssid: str, password: Optional[str], iface: str = "wlan0") -> None:
    """Подключение к сети с заданным SSID и паролем"""
    log.info(f"Connecting to WiFi: {ssid}")
    
    # 1. Принудительное сканирование перед подключением
    log.info("Step 1: Scanning for networks...")
    try:
        _run(f"sudo {NMCLI} device wifi rescan ifname {shlex.quote(iface)}", timeout=15)
        time.sleep(3)  # Даем время на завершение сканирования
    except WifiError as e:
        log.warning(f"Rescan failed, continuing anyway: {e}")
    
    # 2. Проверяем, что сеть видна
    log.info("Step 2: Checking if network is visible...")
    networks = scan(iface)
    target_network = None
    for net in networks:
        if net.ssid == ssid:
            target_network = net
            break
    
    if not target_network:
        available_ssids = [net.ssid for net in networks[:5]]  # Показываем первые 5
        raise WifiError(f"Network '{ssid}' not found. Available: {available_ssids}")
    
    log.info(f"Target network found: {target_network}")
    
    # 3. Удаляем существующее подключение с таким именем (если есть)
    log.info("Step 3: Removing existing connection...")
    try:
        _run(f'sudo {NMCLI} connection delete "home-wifi"', timeout=10)
        log.info("Removed existing 'home-wifi' connection")
    except WifiError:
        log.info("No existing 'home-wifi' connection to remove")
    
    # 4. Подключаемся к сети
    log.info("Step 4: Connecting to network...")
    cmd = f'sudo {NMCLI} dev wifi connect {shlex.quote(ssid)}'
    if password:
        cmd += f' password {shlex.quote(password)}'
    cmd += f' ifname {shlex.quote(iface)} name "home-wifi"'
    
    try:
        _run(cmd, timeout=30)
        log.info("Connection command completed")
    except WifiError as e:
        # Проверяем, удалось ли подключиться несмотря на ошибку
        time.sleep(2)
        current_status = status(iface)
        if current_status["ssid"] == ssid:
            log.info("Connection successful despite error message")
            return
        else:
            raise WifiError(f"Failed to connect to '{ssid}': {e}")
    
    # 5. Проверяем подключение
    log.info("Step 5: Verifying connection...")
    time.sleep(3)
    current_status = status(iface)
    
    if current_status["ssid"] != ssid:
        raise WifiError(f"Connection verification failed. Expected: {ssid}, Got: {current_status['ssid']}")
    
    log.info(f"Successfully connected to {ssid}, IP: {current_status['ip4']}")

def disconnect(iface: str = "wlan0") -> None:
    """Отключение от текущей сети"""
    log.info(f"Disconnecting from WiFi on {iface}")
    try:
        _run(f"sudo {NMCLI} device disconnect {shlex.quote(iface)}", timeout=10)
        time.sleep(2)  # Даем время на отключение
    except WifiError as e:
        log.warning(f"Disconnect failed: {e}")
        # Продолжаем выполнение, так как отключение может завершиться ошибкой

def switch(ssid: str, password: Optional[str], iface: str = "wlan0") -> None:
    """Переключение на другую сеть"""
    log.info(f"Switching WiFi to: {ssid}")
    
    # Получаем текущий статус
    current_status = status(iface)
    current_ssid = current_status.get("ssid")
    
    if current_ssid == ssid:
        log.info(f"Already connected to {ssid}")
        return
    
    # Отключаемся от текущей сети
    if current_ssid:
        log.info(f"Disconnecting from current network: {current_ssid}")
        try:
            disconnect(iface)
        except WifiError as e:
            log.warning(f"Disconnect failed, continuing: {e}")
    
    # Подключаемся к новой сети
    connect(ssid, password, iface)
