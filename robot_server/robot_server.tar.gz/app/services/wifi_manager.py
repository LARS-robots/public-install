import shlex, subprocess, logging, time, os, json
from dataclasses import dataclass
from typing import List, Optional, Dict
from contextlib import contextmanager

@dataclass
class WifiNetwork:
    in_use: bool
    ssid: str
    signal: int
    security: str

class WifiError(RuntimeError): 
    pass

class WifiManager:
    """Менеджер WiFi подключений с guard-механизмом"""
    
    def __init__(self, 
                 nmcli_bin: str = "nmcli",
                 ap_conn_name: str = "LARSrobotTest-AP", 
                 target_conn_name: str = "home-wifi",
                 guard_path: str = "/run/wifi_switch.lock"):
        self.nmcli = nmcli_bin
        self.ap_conn_name = ap_conn_name
        self.target_conn_name = target_conn_name
        self.guard_path = guard_path
        self.log = logging.getLogger(__name__)
    
    def _run(self, cmd: str, timeout: int = 10) -> str:
        """Выполнить команду и вернуть stdout"""
        self.log.info(f"Executing: {cmd}")
        try:
            res = subprocess.run(cmd, shell=True, check=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 text=True, timeout=timeout)
            self.log.info(f"Command success: {res.stdout.strip()}")
            return res.stdout.strip()
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr.strip() or str(e)
            self.log.error(f"Command failed: {cmd} -> {error_msg}")
            raise WifiError(error_msg)
        except subprocess.TimeoutExpired:
            self.log.error(f"Command timeout: {cmd}")
            raise WifiError("nmcli timeout")

    def _write_guard(self, ttl: int = 120) -> None:
        """Создать/обновить guard-файл на время свитча"""
        try:
            payload = {"expires": time.time() + ttl, "pid": os.getpid()}
            os.makedirs(os.path.dirname(self.guard_path), exist_ok=True)
            with open(self.guard_path, "w") as f:
                json.dump(payload, f)
            os.chmod(self.guard_path, 0o644)
            self.log.info(f"Guard set for {ttl}s at {self.guard_path}")
        except Exception as e:
            self.log.warning(f"Guard create failed: {e}")

    def _clear_guard(self) -> None:
        """Очистить guard-файл"""
        try:
            if os.path.exists(self.guard_path):
                os.remove(self.guard_path)
                self.log.info("Guard cleared")
        except Exception as e:
            self.log.warning(f"Guard clear failed: {e}")

    def _set_autoconnect(self, name: str, enabled: bool) -> None:
        """Установить autoconnect для подключения"""
        val = "yes" if enabled else "no"
        try:
            self._run(f'sudo {self.nmcli} connection modify {shlex.quote(name)} connection.autoconnect {val}', timeout=10)
            self.log.info(f"Set autoconnect={val} for {name}")
        except WifiError as e:
            self.log.warning(f"Failed to set autoconnect for {name}: {e}")

    def _set_priority(self, name: str, prio: int) -> None:
        """Установить приоритет автоподключения"""
        try:
            self._run(f'sudo {self.nmcli} connection modify {shlex.quote(name)} connection.autoconnect-priority {int(prio)}', timeout=10)
            self.log.info(f"Set priority={prio} for {name}")
        except WifiError as e:
            self.log.warning(f"Failed to set priority for {name}: {e}")

    def _con_down(self, name: str) -> None:
        """Отключить подключение (без критических ошибок)"""
        try:
            self._run(f'sudo {self.nmcli} connection down {shlex.quote(name)} || true', timeout=10)
            self.log.info(f"Connection {name} brought down")
        except WifiError as e:
            self.log.warning(f"Failed to bring down {name}: {e}")

    def _suppress_ap_autoconnect(self, ttl: int = 120) -> None:
        """Подавить автоподключение AP на время переключения"""
        try:
            self._set_autoconnect(self.ap_conn_name, False)
            self._set_priority(self.ap_conn_name, -999)
            self._con_down(self.ap_conn_name)
            self.log.info(f"AP {self.ap_conn_name} autoconnect suppressed for {ttl}s")
            
            # Ранний watchdog: следим за случайным подъемом AP в первые секунды
            def early_watchdog():
                deadline = time.time() + 8
                while time.time() < deadline:
                    try:
                        active = self._run("sudo nmcli -t -f NAME connection show --active", timeout=4)
                        if self.ap_conn_name in active.splitlines():
                            self.log.warning("AP popped up again during guard window, bringing it down")
                            self._con_down(self.ap_conn_name)
                    except Exception:
                        pass
                    time.sleep(1.5)
            
            # Установим таймер для восстановления через ttl секунд
            def restore_ap():
                time.sleep(ttl)
                try:
                    self._set_autoconnect(self.ap_conn_name, True)
                    self._set_priority(self.ap_conn_name, 100)
                    self.log.info(f"AP {self.ap_conn_name} autoconnect restored")
                except Exception as e:
                    self.log.warning(f"Failed to restore AP autoconnect: {e}")
            
            import threading
            threading.Thread(target=early_watchdog, daemon=True).start()
            threading.Thread(target=restore_ap, daemon=True).start()
            
        except Exception as e:
            self.log.warning(f"Failed to suppress AP autoconnect: {e}")

    def scan(self, iface: str = "wlan0") -> List[WifiNetwork]:
        """Сканирование доступных Wi-Fi сетей"""
        self.log.info("Starting WiFi scan...")
        
        # Принудительное сканирование
        try:
            self._run(f"sudo {self.nmcli} device wifi rescan ifname {shlex.quote(iface)}", timeout=15)
            time.sleep(2)  # Даем время на завершение сканирования
        except WifiError as e:
            self.log.warning(f"Rescan failed: {e}")
        
        # Получение списка сетей
        out = self._run(f"sudo {self.nmcli} -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list ifname {shlex.quote(iface)}")
        nets: List[WifiNetwork] = []
        
        for line in out.splitlines():
            if not line.strip():
                continue
                
            parts = line.split(":")
            if len(parts) < 4:
                continue
                
            try:
                if len(parts) > 4:
                    # Если SSID содержит двоеточия
                    in_use = (parts[0].strip() == "*")
                    signal = int(parts[-2] or 0)
                    security = parts[-1] or ""
                    ssid = ":".join(parts[1:-2]).strip()
                else:
                    in_use = (parts[0].strip() == "*")
                    ssid = parts[1].strip()
                    signal = int(parts[2] or 0)
                    security = parts[3].strip()
                
                if ssid:  # Игнорируем пустые SSID
                    nets.append(WifiNetwork(in_use, ssid, signal, security))
                    
            except (ValueError, IndexError) as e:
                self.log.warning(f"Failed to parse WiFi line: {line} -> {e}")
                continue
        
        self.log.info(f"Found {len(nets)} WiFi networks")
        return nets

    def status(self, iface: str = "wlan0") -> Dict[str, Optional[str]]:
        """Получение текущего статуса подключения"""
        try:
            # Получаем активное подключение
            out = self._run(f"sudo {self.nmcli} -t -f active,ssid dev wifi")
            ssid = None
            for line in out.splitlines():
                if line.startswith("yes:"):
                    ssid = line[4:].strip()
                    break
        except WifiError:
            ssid = None
        
        try:
            # Получаем IP адрес
            ip4 = self._run(f"sudo {self.nmcli} -g IP4.ADDRESS device show {shlex.quote(iface)}")
            if ip4:
                ip4 = ip4.splitlines()[0].split('/')[0]  # Убираем маску подсети
        except WifiError:
            ip4 = None
        
        return {"ssid": ssid, "ip4": ip4, "iface": iface}

    def connect(self, ssid: str, password: Optional[str] = None, iface: str = "wlan0") -> None:
        """Подключение к сети с заданным SSID и паролем"""
        self.log.info(f"Connecting to WiFi: {ssid}")
        self._write_guard(120)
        
        try:
            # Подавляем автоподнятие AP на время свитча (более агрессивно)
            self._suppress_ap_autoconnect(120)
            
            # 1. Принудительное сканирование перед подключением
            self.log.info("Step 1: Scanning for networks...")
            try:
                self._run(f"sudo {self.nmcli} device wifi rescan ifname {shlex.quote(iface)}", timeout=15)
                time.sleep(3)  # Даем время на завершение сканирования
            except WifiError as e:
                self.log.warning(f"Rescan failed, continuing anyway: {e}")
            
            # 2. Проверяем, что сеть видна
            self.log.info("Step 2: Checking if network is visible...")
            networks = self.scan(iface)
            target_network = None
            for net in networks:
                if net.ssid == ssid:
                    target_network = net
                    break
            
            if not target_network:
                available_ssids = [net.ssid for net in networks[:5]]  # Показываем первые 5
                raise WifiError(f"Network '{ssid}' not found. Available: {available_ssids}")
            
            self.log.info(f"Target network found: {target_network}")
            
            # 3. Удаляем существующее подключение с таким именем (если есть)
            self.log.info("Step 3: Removing existing connection...")
            try:
                self._run(f'sudo {self.nmcli} connection delete "{self.target_conn_name}"', timeout=10)
                self.log.info(f"Removed existing '{self.target_conn_name}' connection")
            except WifiError:
                self.log.info(f"No existing '{self.target_conn_name}' connection to remove")
            
            # 4. Подключаемся к сети
            self.log.info("Step 4: Connecting to network...")
            cmd = f'sudo {self.nmcli} dev wifi connect {shlex.quote(ssid)}'
            if password:
                cmd += f' password {shlex.quote(password)}'
            cmd += f' ifname {shlex.quote(iface)} name "{self.target_conn_name}"'
            
            try:
                self._run(cmd, timeout=30)
                self.log.info("Connection command completed")
            except WifiError as e:
                # Проверяем, удалось ли подключиться несмотря на ошибку
                time.sleep(2)
                current_status = self.status(iface)
                if current_status["ssid"] == ssid:
                    self.log.info("Connection successful despite error message")
                else:
                    raise WifiError(f"Failed to connect to '{ssid}': {e}")
            
            # 5. Проверяем подключение (ждём подтверждённый SSID + IP)
            self.log.info("Step 5: Verifying connection...")
            deadline = time.time() + 35
            last_status = None
            
            while time.time() < deadline:
                current_status = self.status(iface)
                last_status = current_status
                
                if current_status.get("ssid") == ssid and current_status.get("ip4"):
                    self.log.info(f"Connection verified: SSID={ssid}, IP={current_status['ip4']}")
                    break
                
                self.log.info(f"Waiting for connection... SSID={current_status.get('ssid')}, IP={current_status.get('ip4')}")
                time.sleep(1.5)
            else:
                raise WifiError(f"Connection verification timeout. Expected: {ssid}, Got: {last_status}")
            
            # Настраиваем автоподключение целевой сети и повышаем её приоритет
            try:
                self._set_autoconnect(self.target_conn_name, True)
                self._set_priority(self.target_conn_name, 200)  # Выше приоритет чем у AP (100)
                self.log.info("Target connection configured for autoconnect with high priority")
            except Exception as e:
                self.log.warning(f"Failed to set autoconnect/priority for target: {e}")
            
            self.log.info(f"Successfully connected to {ssid}, IP: {current_status['ip4']}")
            
        finally:
            self._clear_guard()

    def disconnect(self, iface: str = "wlan0") -> None:
        """Отключение от текущей сети"""
        self.log.info(f"Disconnecting from WiFi on {iface}")
        try:
            self._run(f"sudo {self.nmcli} device disconnect {shlex.quote(iface)}", timeout=10)
            time.sleep(2)  # Даем время на отключение
        except WifiError as e:
            self.log.warning(f"Disconnect failed: {e}")
            # Продолжаем выполнение, так как отключение может завершиться ошибкой

    def switch(self, ssid: str, password: Optional[str] = None, iface: str = "wlan0") -> None:
        """Переключение на другую сеть"""
        self.log.info(f"Switching WiFi to: {ssid}")
        
        # Получаем текущий статус
        current_status = self.status(iface)
        current_ssid = current_status.get("ssid")
        
        if current_ssid == ssid:
            self.log.info(f"Already connected to {ssid}")
            return
        
        # Убираем явный disconnect - сразу подключаемся
        # Это уменьшает окно гонки с автоподъемом AP
        self.connect(ssid, password, iface)

    @contextmanager
    def switch_guard(self, ttl: int = 120):
        """
        Public context manager for WiFi switching operations.
        Manages guard file and AP suppression automatically.
        """
        self.log.info(f"Entering WiFi switch guard (ttl={ttl}s)")
        self._write_guard(ttl)
        self._suppress_ap_autoconnect(ttl)
        try:
            yield
        finally:
            self._clear_guard()
            self.log.info("WiFi switch guard released")