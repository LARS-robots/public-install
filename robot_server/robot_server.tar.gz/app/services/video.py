# services/video.py
"""
Video service for Raspberry Pi 5 streaming & recording.

Key points:
- RPi raw YUV pipeline via rpicam-vid (I420) for streaming.
- EIS is applied ONLY to streaming branch; recording keeps raw frames.
- Resolution comes from config.toml:
    * layout.mode == "camera_stereo" -> 640x480
    * layout.mode == "camera_quad"   -> 640x460
  Per-camera overrides [cameraN] can be used but are optional.
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread, Lock
from typing import Optional, Tuple
from pathlib import Path
import platform
import glob
import re
import asyncio
from collections import deque

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .eis_rt import build_eis_adapter
import tomli as _toml


log = logging.getLogger(__name__)


# ----------------------- config helpers ----------------------- #
def _load_config_dict() -> dict:
    if _toml is None:
        return {}
    candidates: list[Path] = []
    here = Path(__file__).resolve()
    root = here.parent.parent.parent
    candidates.append(root / "config.toml")
    candidates += [Path.cwd() / "config.toml", here.parent / "config.toml", here.parent.parent / "config.toml"]
    for p in candidates:
        try:
            if p.exists():
                with p.open("rb") as f:
                    return _toml.load(f) or {}
        except Exception:
            continue
    return {}


def _layout_mode_and_size(cam_index: int) -> Tuple[str, int, int]:
    """
    Resolves (mode, width, height) with precedence:
      1) [layout] mode + [layout.stereo|layout.quad] sizes (PRIMARY)
      2) [camera{N}] fallback_width/fallback_height (OVERRIDE for that camera)
      3) defaults: stereo 640x480 / quad 640x460
    """
    data = _load_config_dict()
    layout = data.get("layout", {})
    # Try stereo
    stereo = layout.get("stereo", {})
    if isinstance(stereo, dict):
        cam_idx = stereo.get("camera_index")
        if cam_idx is not None and int(cam_index) == int(cam_idx):
            w = int(stereo.get("width", 640))
            h = int(stereo.get("height", 480))
            return "stereo", w, h
    # Try quad
    quad = layout.get("quad", {})
    if isinstance(quad, dict):
        cam_idx = quad.get("camera_index")
        if cam_idx is not None and int(cam_index) == int(cam_idx):
            w = int(quad.get("width", 640))
            h = int(quad.get("height", 640))
            return "quad", w, h
    return "mode isn't found", 640, 480


def _load_eis_config() -> dict:
    """
    Load/validate [eis] and bind explicit layout from [layout].
    No auto-detect.
    """
    data = _load_config_dict()
    eis = dict(data.get("eis", {}) or {})
    layout = dict(data.get("layout", {}) or {})
    mode = str(layout.get("mode", "camera_stereo")).lower()
    if mode == "camera_stereo":
        eis["layout"] = "stereo_h"
    elif mode == "camera_quad":
        # quad стабилизуем как mono (EIS на цельный кадр)
        eis["layout"] = "mono"
    else:
        eis["layout"] = str(eis.get("layout", "mono")).lower()
    if eis.get("layout", "mono") == "auto":
        log.warning("eis.layout=auto is deprecated; forcing mono")
        eis["layout"] = "mono"

    # sanitize bounds
    eis["enabled"] = bool(eis.get("enabled", False))
    eis["cpu_budget_ms"] = int(max(1, min(12, int(eis.get("cpu_budget_ms", 6)))))
    eis["queue_guard_depth"] = int(max(1, min(24, int(eis.get("queue_guard_depth", 6)))))

    algo = dict(eis.get("algorithm", {}) or {})
    algo["downscale_width"]  = int(max(320,  min(1280, int(algo.get("downscale_width", 640)))))
    algo["gftt_max_corners"] = int(max(64,   min(4000, int(algo.get("gftt_max_corners", 800)))))
    algo["lk_win"]           = int(max(9,    min(61,   int(algo.get("lk_win", 21)))))
    algo["ransac_thresh"]    = float(algo.get("ransac_thresh", 3.0))
    algo["ema_alpha_pos"]    = float(algo.get("ema_alpha_pos", 0.20))
    algo["ema_alpha_rot"]    = float(algo.get("ema_alpha_rot", 0.20))
    algo["safety_crop_percent"] = int(max(0, min(20, int(algo.get("safety_crop_percent", eis.get("safety_crop_percent", 8))))))
    eis["algorithm"] = algo

    vg = dict(eis.get("virtual_gimbal", {}) or {})
    vg["enabled"] = bool(vg.get("enabled", False))
    eis["virtual_gimbal"] = vg
    return eis


# ----------------------- camera discovery helpers ----------------------- #
def enumerate_cameras(max_probe: int = 8, probe_open: bool = True) -> list[int]:
    """
    Returns list of available camera indices.
    If probe_open is True, tries to open each device to verify.
    """
    cams: list[int] = []

    if shutil.which("rpicam-hello"):
        try:
            p = subprocess.run(["rpicam-hello", "--list-cameras"],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, timeout=5)
            if p.returncode == 0:
                for line in p.stdout.splitlines():
                    if re.match(r'^\s*\d+\s*:', line):
                        cams.append(int(line.split(':')[0].strip()))
                return sorted(set(cams))
        except Exception as e:
            log.warning(f"rpicam-hello failed: {e}")

    try:
        dev_nodes = sorted({
            int(p.split("/dev/video")[1])
            for p in glob.glob("/dev/video*")
            if p.replace("/dev/video", "").isdigit()
        })
        if not probe_open:
            return dev_nodes
        indices = dev_nodes or list(range(max_probe))
        for i in indices:
            cap = _open_cap_any(i)
            if cap and cap.isOpened():
                cams.append(i)
                cap.release()
    except Exception:
        pass
    return sorted(set(cams))


def _open_cap_any(index: int):
    be = cv2.CAP_DSHOW if platform.system() == "Windows" else 0
    try:
        cap = cv2.VideoCapture(index, be)
        if cap.isOpened():
            return cap
        cap.release()
    except Exception:
        try:
            if cap:
                cap.release()
        except Exception:
            pass
    return None


# ----------------------- Recording helpers ----------------------- #
class VideoRecorder:
    """
    Simple MP4 recorder via OpenCV VideoWriter.
    Uses CFR pacing based on wall-clock time.
    1) Call write_frame(bgr) for each BGR frame (np.ndarray).
    2) Call stop() to finalize and get the filename.
    3) No explicit start() needed; writer is opened in __init__().
    """
    def __init__(self, width: int, height: int, fps: float, output_dir: Path,
                 session_id: str | None = None, cam_label: str | None = None, rec_cfg: dict | None = None):
        from math import isfinite
        output_dir.mkdir(parents=True, exist_ok=True)
        ts = session_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filename = output_dir / f"{ts}{'_' + cam_label if cam_label else ''}.mp4"
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        # quantize fps for stable CFR
        grid = [5.0, 10.0, 15.0, 24.0, 25.0, 30.0, 50.0, 60.0]
        fps = float(max(1.0, min(120.0, fps)))
        fps = min(grid, key=lambda g: abs(g - fps))
        self._target_fps = float((rec_cfg or {}).get("fps", fps))
        self.writer = cv2.VideoWriter(str(self.filename), fourcc, self._target_fps, (int(width), int(height)))
        if not self.writer.isOpened():
            log.error("VideoWriter open failed")
        self._frames = 0
        self._start_mono = time.monotonic()

    def write_frame(self, bgr: np.ndarray):
        if not (self.writer and self.writer.isOpened()):
            return
        # CFR pacing (wall-clock)
        now = time.monotonic()
        due = int((now - self._start_mono) * self._target_fps) - self._frames
        if due <= 0:
            return
        if due > 3:
            due = 3
        for i in range(due):
            self.writer.write(bgr)
            self._frames += 1

    def stop(self) -> Path:
        if self.writer:
            self.writer.release()
            try:
                time.sleep(0.2)  # flush
            except Exception:
                pass
        return self.filename


class RecordingMixin:
    def start_recording(self, session_id, cam_label, output_dir: Path):
        self.session_id = session_id
        self.cam_label = cam_label
        self.output_dir = output_dir
        self.want_record = True

    def stop_recording_only(self) -> Optional[Path]:
        self.want_record = False
        if getattr(self, "recorder", None):
            try:
                fn = self.recorder.stop()
                self.recorder = None
                return fn
            except Exception:
                self.recorder = None
        return None

    def current_recording_filename(self) -> Optional[Path]:
        return getattr(self.recorder, "filename", None) if getattr(self, "recorder", None) else None


# ----------------------- FPS estimation ----------------------- #
def _fps_from_samples(samples: list[float]) -> Optional[float]:
    """
    Estimate FPS from list of recent frame time deltas.
    Uses median/mean hybrid to filter outliers.
    Returns None if not enough data or invalid.
    """
    if len(samples) < 5:
        return None
    recent = samples[-20:]
    if len(recent) >= 3:
        dt_m = float(np.median(recent))
        dt_a = float(np.mean(recent))
        dt = dt_m if abs(dt_m - dt_a) / max(1e-6, dt_a) < 0.2 else dt_a
        if dt > 0:
            return 1.0 / dt
    return None


# ----------------------- Raw YUV camera (RPi) ----------------------- #
class RawYUVCameraTrack(VideoStreamTrack, RecordingMixin):
    """
    rpicam-vid -> yuv420 (I420) to stdout.
    Resolution is taken from config.toml (see _layout_mode_and_size()).
    """

    def __init__(self, *, camera: int = 0, framerate: int = 30,
                 overlay: bool = True, record: bool = False,
                 session_id: str | None = None, cam_label: str | None = None,
                 output_dir: Path | None = None):
        super().__init__()
        self.camera = int(camera)
        self.framerate = int(framerate)
        self.overlay = bool(overlay)
        self.want_record = bool(record)
        self.session_id = session_id
        self.cam_label = cam_label or f"cam{self.camera}"
        self.output_dir = output_dir or Path.cwd()
        self._rec_lock = Lock()

        # layout + size
        mode, W, H = _layout_mode_and_size(self.camera)
        self.layout_mode = mode
        self.width, self.height = int(W), int(H)

        # EIS (streaming-only)
        self._eis = None
        try:
            eis_cfg = _load_eis_config()
            if eis_cfg.get("enabled", False):
                self._eis = build_eis_adapter(self.width, self.height, eis_cfg)
                log.info("EIS enabled for streaming; layout=%s", eis_cfg.get("layout"))
        except Exception as e:
            log.warning(f"EIS init failed: {e}")

        # runtime
        self._rpicam_proc: Optional[subprocess.Popen] = None
        self._running = False
        self._thread: Optional[Thread] = None
        self._frame_queue: deque[np.ndarray] = deque(maxlen=3)
        self._last_frame_time = 0.0
        self._fps_samples: list[float] = []
        self._black_yuv = np.zeros((self.height * 3 // 2, self.width), dtype=np.uint8)

        self._start_processes()

    # --- rpicam-vid management ---
    def _rpicam_cmd(self) -> list[str]:
        """Construct rpicam-vid command line."""
        return [
            "rpicam-vid",
            "--camera", str(self.camera),
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.framerate),
            "--codec", "yuv420",
            "--output", "-",
            "--timeout", "0",
            "--nopreview",
            "--flush",
        ]

    def _start_processes(self):
        """Start rpicam-vid and read thread."""
        self._running = True
        try:
            log.info(f"Starting rpicam-vid cam={self.camera} {self.width}x{self.height}@{self.framerate}")
            self._rpicam_proc = subprocess.Popen(self._rpicam_cmd(),
                                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=10**7)
        except Exception as e:
            if self._rpicam_proc:
                try: self._rpicam_proc.kill()
                except Exception: pass
            raise RuntimeError(f"Failed to start rpicam-vid: {e}")

        def _stderr_logger(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line: break
                    log.debug("rpicam-vid: %s", line.decode(errors="ignore").rstrip())
            except Exception:
                pass
        Thread(target=_stderr_logger, args=(self._rpicam_proc.stderr,), daemon=True).start()

        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_exact(self, size: int) -> Optional[bytes]:
        """Read exactly `size` bytes from rpicam-vid stdout."""
        if not self._rpicam_proc or not self._rpicam_proc.stdout:
            return None
        try:
            buf = b""
            while len(buf) < size and self._running:
                chunk = self._rpicam_proc.stdout.read(size - len(buf))
                if not chunk:
                    return None
                buf += chunk
            return buf if len(buf) == size else None
        except Exception:
            return None

    def _draw_overlay_y(self, y_plane: np.ndarray):
        """Draw overlay text on Y plane in-place."""
        try:
            H, W = self.height, self.width
            mask = np.zeros((H, W), dtype=np.uint8)
            fps = _fps_from_samples(self._fps_samples)
            fps_str = f"{fps:.1f}" if fps is not None else "?"
            txt = f"{datetime.now():%H:%M:%S} | {self.cam_label} | {fps_str} fps | {W}x{H}" 
            cv2.putText(mask, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, 255, 2, cv2.LINE_AA)
            alpha = 0.6
            sel = mask > 0
            y_plane[sel] = np.clip((1 - alpha) * y_plane[sel] + alpha * 235, 0, 255).astype(np.uint8)
        except Exception:
            pass

    def _read_loop(self):
        """Thread: read frames from rpicam-vid, apply EIS, overlay, queue for streaming, record if needed."""
        frame_size = self.width * self.height * 3 // 2
        log.info(f"Reading frames: size={frame_size}")
        try:
            while self._running and self._rpicam_proc:
                raw = self._read_exact(frame_size)
                if not raw or len(raw) != frame_size:
                    continue
                # writable only if we draw overlay
                buf = np.frombuffer(raw, dtype=np.uint8).copy()
                if buf.size != frame_size:
                    continue
                buf2d = buf.reshape(self.height * 3 // 2, self.width)

                # FPS samples
                now = time.time()
                if self._last_frame_time > 0:
                    self._fps_samples.append(now - self._last_frame_time)
                    if len(self._fps_samples) > 100:
                        self._fps_samples.pop(0)
                self._last_frame_time = now

                # overlay on Y
                Y = buf2d[: self.height, : ]
                self._draw_overlay_y(Y)

                # start recorder early when FPS known
                if self.want_record and not getattr(self, "recorder", None):
                    fps = _fps_from_samples(self._fps_samples)
                    if fps:
                        self.recorder = VideoRecorder(self.width, self.height, fps,
                                                      output_dir=self.output_dir,
                                                      session_id=self.session_id, cam_label=self.cam_label,
                                                      rec_cfg=_load_config_dict().get("recording", {}))
                        # no explicit start needed (writer is opened in __init__)

                # write to recorder
                if getattr(self, "recorder", None):
                    try:
                        bgr = cv2.cvtColor(buf2d, cv2.COLOR_YUV2BGR_I420)
                        self.recorder.write_frame(bgr)
                    except Exception:
                        pass

                # STREAMING: apply EIS if enabled
                try:
                    if self._eis is not None:
                        out = self._eis.process_i420(buf2d, queue_len=len(self._frame_queue))
                        self._frame_queue.append(out)
                    else:
                        self._frame_queue.append(buf2d)
                except Exception:
                    self._frame_queue.append(buf2d)
        finally:
            log.info("Read loop finished")

    async def recv(self):
        pts, tb = await self.next_timestamp()
        # wait a bit for a frame
        tries = 0
        while not self._frame_queue and self._running and tries < 10:
            await asyncio.sleep(0.02)
            tries += 1
        if not self._frame_queue:
            v = VideoFrame.from_ndarray(self._black_yuv, format="yuv420p")
            v.pts, v.time_base = pts, tb
            return v
        frame_yuv = self._frame_queue.popleft()
        if isinstance(frame_yuv, np.ndarray) and frame_yuv.ndim == 1:
            exp = self.height * self.width * 3 // 2
            if frame_yuv.size == exp:
                frame_yuv = frame_yuv.reshape(self.height * 3 // 2, self.width)
            else:
                v = VideoFrame.from_ndarray(self._black_yuv, format="yuv420p")
                v.pts, v.time_base = pts, tb
                return v
        v = VideoFrame.from_ndarray(frame_yuv, format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def get_resolution(self) -> Tuple[int, int]:
        return self.width, self.height

    def stop(self):
        self._running = False
        if self._rpicam_proc:
            try:
                self._rpicam_proc.terminate()
                self._rpicam_proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    self._rpicam_proc.kill()
                    self._rpicam_proc.wait(timeout=1)
                except Exception:
                    pass
            self._rpicam_proc = None
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        if getattr(self, "recorder", None):
            try:
                self.recorder.stop()
            except Exception:
                pass
            self.recorder = None
        super().stop()
        log.info(f"RawYUVCameraTrack stopped (cam{self.camera})")


# ----------------------- Desktop OpenCV fallback ----------------------- #
class CameraVideoTrack(VideoStreamTrack, RecordingMixin):
    """Desktop capture via OpenCV; kept for parity/testing."""
    def __init__(self, index=0, overlay=True, record=False,
                 session_id: str | None = None, cam_label: str | None = None,
                 output_dir: Path | None = None):
        super().__init__()
        self.index = int(index)
        self.overlay = bool(overlay)
        self.want_record = bool(record)
        self.session_id = session_id
        self.cam_label = f"cam{self.index}" or cam_label
        self.output_dir = output_dir or Path.cwd()

        be = cv2.CAP_DSHOW if platform.system() == "Windows" else 0
        self.cap = cv2.VideoCapture(self.index, be)
        if not (self.cap and self.cap.isOpened()):
            raise RuntimeError(f"Cannot open camera index={self.index}")

        # warm-up
        for _ in range(2):
            self.cap.read()
        ok, first = self.cap.read()
        if not ok or first is None:
            raise RuntimeError("Failed to read initial frame")
        h, w = first.shape[:2]
        self._res = (w, h)
        self._black = np.zeros((h, w, 3), dtype=np.uint8)
        self._t_prev = time.time()
        self._overlay_fps = 0.0
        self.recorder: Optional[VideoRecorder] = None
        log.info("OpenCV camera %d started, %dx%d", self.index, w, h)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, bgr = self.cap.read()
        if not ret or bgr is None:
            bgr = self._black
        if self.overlay:
            now = time.time()
            dt = max(1e-6, now - self._t_prev)
            self._t_prev = now
            self._overlay_fps = 0.9 * self._overlay_fps + 0.1 * (1.0 / dt)
            cv2.putText(bgr, f"{datetime.now():%H:%M:%S} | {self.cam_label} | {self._overlay_fps:.1f} fps | {self._res[0]}x{self._res[1]}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

        if self.want_record and self.recorder is None:
            fps0 = float(self.cap.get(cv2.CAP_PROP_FPS) or 30.0)
            self.recorder = VideoRecorder(self._res[0], self._res[1], fps0,
                                          output_dir=self.output_dir, session_id=self.session_id, cam_label=self.cam_label)
        if self.recorder is not None:
            self.recorder.write_frame(bgr)

        v = VideoFrame.from_ndarray(bgr, format="bgr24").reformat(format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        try:
            if self.cap: self.cap.release()
        except Exception:
            pass
        if self.recorder:
            try: self.recorder.stop()
            except Exception: pass
            self.recorder = None
        super().stop()
        log.info("OpenCV camera stopped")


# ----------------------- public factory ----------------------- #
def create_camera_track(camera_id: int = 0, record: bool = False,
                        session_id: str | None = None, cam_label: str | None = None,
                        output_dir: Path | None = None):
    """Factory: RawYUVCameraTrack if rpicam-vid exists, else CameraVideoTrack."""
    log.info("Create camera track: id=%s record=%s", camera_id, record)
    if shutil.which("rpicam-vid"):
        return RawYUVCameraTrack(camera=camera_id, framerate=100, record=record,
                                 session_id=session_id, cam_label=cam_label,
                                 output_dir=output_dir)
    # desktop fallback
    return CameraVideoTrack(index=camera_id, record=record,
                            session_id=session_id, cam_label=cam_label,
                            output_dir=output_dir or Path.cwd())
