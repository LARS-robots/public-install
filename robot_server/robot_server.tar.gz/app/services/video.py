# # services/video.py (second debug iteration)
# """Improved diagnostics
# • prints every grab attempt (INFO) – so видно, пытаемся ли читать камеру;
# • без рекурсии – бесконечный цикл внутри recv (опасности переполнения стека нет);
# • отлавливает исключения и завершает трек с сообщением;
# • DEBUG‑уровень остаётся для SEND FRAME, но теперь grab‑attempt → INFO, значит видно даже на обычном log‑level.
# """
# from __future__ import annotations

# import asyncio, logging, os, time
# from datetime import datetime
# from pathlib import Path

# import cv2
# from av import VideoFrame
# from aiortc import VideoStreamTrack
# from .. import state

# log = logging.getLogger(__name__)

# # ──────────────────────────────────────────────────────────────── helpers ── #
# class SimpleOverlay:
#     def __init__(self):
#         self.t0 = time.time()
#         self.fps = 0.0

#     def draw(self, frame):
#         now = time.time(); dt = now - self.t0 or 1e-6; self.t0 = now
#         self.fps = 0.9 * self.fps + 0.1 / dt
#         txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
#         cv2.putText(frame, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8,(0,255,0),2)
#         return frame

# class VideoRecorder:
#     def __init__(self, w:int,h:int,fps:int):
#         ts = datetime.now().strftime('%Y%m%d_%H%M%S')
#         self.filename = Path(f'record_{ts}.mp4')
#         fourcc = cv2.VideoWriter_fourcc(*'avc1')
#         self.wr = cv2.VideoWriter(str(self.filename), fourcc, fps, (w,h))
#         if not self.wr.isOpened(): raise RuntimeError('VideoWriter open fail')
#         log.info('📹 recording to %s', self.filename)

#     def write(self,f): self.wr.write(f)
#     def close(self): self.wr.release(); log.info('💾 saved %s', self.filename)

# # ──────────────────────────────────────────── CameraVideoTrack ── #
# class CameraVideoTrack(VideoStreamTrack):
#     def __init__(self, source=0, *, overlay=True, record=False):
#         super().__init__()
#         self.cap = cv2.VideoCapture(source, cv2.CAP_DSHOW if os.name=='nt' else 0)
#         if not self.cap.isOpened():
#             log.error('❌ camera %s not opened', source)
#             raise RuntimeError('camera open failed')
#         w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
#         h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
#         fps_raw = self.cap.get(cv2.CAP_PROP_FPS) or 30; self.fps = int(fps_raw) if fps_raw>1 else 30
#         self.overlay = SimpleOverlay() if overlay else None
#         self.rec = VideoRecorder(w,h,self.fps) if record else None
#         log.info('🎦 camera started %dx%d@%dfps overlay=%s record=%s', w,h,self.fps,overlay,record)

#     async def recv(self):
#         pts, tb = await self.next_timestamp()
#         try:
#             while True:
#                 ok, frame = self.cap.read()
#                 if not ok:
#                     log.info('⚠️ grab fail – retry'); await asyncio.sleep(1/self.fps); continue
#                 if self.overlay: frame = self.overlay.draw(frame)
#                 if self.rec: self.rec.write(frame)
#                 log.debug('➡️ frame %s', frame.shape)
#                 v = VideoFrame.from_ndarray(frame, format='bgr24'); v.pts, v.time_base = pts, tb
#                 return v
#         except Exception as e:
#             log.exception('recv loop error: %s', e)
#             raise

#     def stop(self):
#         log.info('🛑 CameraVideoTrack.stop')
#         if self.rec: self.rec.close()
#         self.cap.release()
#         super().stop()

# # ──────────────────────────── service helpers ── #

# def start_camera_track(record=False):
#     if state.camera_track is None:
#         state.camera_track = CameraVideoTrack(record=record)
#     else:
#         log.info('reuse camera track')
#     return state.camera_track

# async def stop_camera_track():
#     if state.camera_track:
#         state.camera_track.stop(); state.camera_track=None; log.info('track stopped')
"""Video service using picamera2 for Raspberry Pi 5 camera
• uses picamera2 library with libcamera support for RPi 5
• maintains WebRTC compatibility with aiortc
• includes overlay and recording functionality
"""
from __future__ import annotations

import asyncio, logging, io, time
from datetime import datetime
from pathlib import Path
from threading import Thread, Event
import queue

try:
    from picamera2 import Picamera2
    from picamera2.encoders import H264Encoder
    from picamera2.outputs import FfmpegOutput
    PICAMERA2_AVAILABLE = True
except ImportError:
    PICAMERA2_AVAILABLE = False

try:
    import cv2
    OPENCV_AVAILABLE = True
except ImportError:
    OPENCV_AVAILABLE = False

import numpy as np
from av import VideoFrame
from aiortc import VideoStreamTrack
from .. import state

log = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────── helpers ── #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time(); dt = now - self.t0 or 1e-6; self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        
        if OPENCV_AVAILABLE:
            cv2.putText(frame, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        return frame

class VideoRecorder:
    def __init__(self, w: int, h: int, fps: int):
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.filename = Path(f'record_{ts}.mp4')
        self.fps = fps
        self.encoder = None
        self.output = None
        log.info('📹 recording to %s', self.filename)

    def start_recording(self, picam2):
        """Start H.264 recording with picamera2"""
        try:
            self.encoder = H264Encoder(bitrate=10000000)
            self.output = FfmpegOutput(str(self.filename))
            picam2.start_recording(self.encoder, self.output)
            log.info('📹 H.264 recording started')
        except Exception as e:
            log.error('Failed to start recording: %s', e)

    def stop_recording(self, picam2):
        """Stop recording"""
        try:
            if self.encoder and self.output:
                picam2.stop_recording()
                log.info('💾 recording stopped')
        except Exception as e:
            log.error('Error stopping recording: %s', e)

    def close(self):
        log.info('💾 saved %s', self.filename)

# ──────────────────────────────────────── PiCamera2VideoTrack ── #
class PiCamera2VideoTrack(VideoStreamTrack):
    def __init__(self, *, overlay=True, record=False, resolution=(640, 480), framerate=30):
        super().__init__()
        
        if not PICAMERA2_AVAILABLE:
            raise RuntimeError("picamera2 library not available")
            
        self.picam2 = Picamera2()
        self.w, self.h = resolution
        self.fps = framerate
        
        # Configure camera
        config = self.picam2.create_preview_configuration(
            main={"size": resolution, "format": "RGB888"}
        )
        self.picam2.configure(config)
        
        self.overlay = SimpleOverlay() if overlay else None
        self.rec = VideoRecorder(self.w, self.h, self.fps) if record else None
        
        # Frame capture setup
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        
        # Start camera
        self.picam2.start()
        
        if self.rec:
            self.rec.start_recording(self.picam2)
        
        # Start capture thread
        self.capture_thread = Thread(target=self._capture_loop, daemon=True)
        self.capture_thread.start()
        
        log.info('🎦 PiCamera2 started %dx%d@%dfps overlay=%s record=%s', 
                self.w, self.h, self.fps, overlay, record)

    def _capture_loop(self):
        """Continuous capture loop in separate thread"""
        try:
            while self.running:
                try:
                    # Capture frame as numpy array
                    frame = self.picam2.capture_array()
                    
                    if frame is not None:
                        # Apply overlay if enabled
                        if self.overlay:
                            frame = self.overlay.draw(frame)
                        
                        # Put frame in queue (non-blocking)
                        try:
                            self.frame_queue.put(frame, block=False)
                        except queue.Full:
                            # Remove old frame and add new one
                            try:
                                self.frame_queue.get_nowait()
                            except queue.Empty:
                                pass
                            try:
                                self.frame_queue.put(frame, block=False)
                            except queue.Full:
                                pass
                    
                    # Control framerate
                    time.sleep(1.0 / self.fps)
                    
                except Exception as e:
                    log.error('Error in capture loop: %s', e)
                    time.sleep(0.1)
                    
        except Exception as e:
            log.exception('Capture loop fatal error: %s', e)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        
        try:
            # Try to get frame with timeout
            timeout = 2.0
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                try:
                    frame = self.frame_queue.get_nowait()
                    
                    log.debug('➡️ frame %s', frame.shape)
                    
                    # picamera2 already provides RGB format
                    v = VideoFrame.from_ndarray(frame, format='rgb24')
                    v.pts, v.time_base = pts, tb
                    return v
                    
                except queue.Empty:
                    await asyncio.sleep(0.01)
                    continue
            
            # Timeout - return black frame
            log.warning('⚠️ frame timeout - returning black frame')
            black_frame = np.zeros((self.h, self.w, 3), dtype=np.uint8)
            v = VideoFrame.from_ndarray(black_frame, format='rgb24')
            v.pts, v.time_base = pts, tb
            return v
            
        except Exception as e:
            log.exception('recv error: %s', e)
            raise

    def stop(self):
        log.info('🛑 PiCamera2VideoTrack.stop')
        self.running = False
        
        # Stop recording if active
        if self.rec:
            self.rec.stop_recording(self.picam2)
            self.rec.close()
        
        # Wait for capture thread to finish
        if self.capture_thread.is_alive():
            self.capture_thread.join(timeout=2.0)
        
        # Stop camera
        try:
            self.picam2.stop()
            self.picam2.close()
        except Exception as e:
            log.error('Error stopping picamera2: %s', e)
            
        super().stop()

# ──────────────────────────────────────── Fallback OpenCV Track ── #
class CameraVideoTrack(VideoStreamTrack):
    """Fallback OpenCV implementation for non-RPi systems or when picamera2 unavailable"""
    def __init__(self, source=0, *, overlay=True, record=False):
        super().__init__()
        
        if not OPENCV_AVAILABLE:
            raise RuntimeError("OpenCV not available")
            
        self.cap = cv2.VideoCapture(source)
        if not self.cap.isOpened():
            log.error('❌ camera %s not opened', source)
            raise RuntimeError('camera open failed')
        
        w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
        h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
        fps_raw = self.cap.get(cv2.CAP_PROP_FPS) or 30
        self.fps = int(fps_raw) if fps_raw > 1 else 30
        
        self.overlay = SimpleOverlay() if overlay else None
        self.rec = VideoRecorder(w, h, self.fps) if record else None
        
        log.info('🎦 OpenCV camera started %dx%d@%dfps overlay=%s record=%s', 
                w, h, self.fps, overlay, record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    log.info('⚠️ grab fail – retry')
                    await asyncio.sleep(1/self.fps)
                    continue
                    
                if self.overlay:
                    frame = self.overlay.draw(frame)
                    
                log.debug('➡️ frame %s', frame.shape)
                
                # Convert BGR to RGB for VideoFrame
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                v = VideoFrame.from_ndarray(frame_rgb, format='rgb24')
                v.pts, v.time_base = pts, tb
                return v
                
        except Exception as e:
            log.exception('recv loop error: %s', e)
            raise

    def stop(self):
        log.info('🛑 CameraVideoTrack.stop')
        if self.rec:
            self.rec.close()
        self.cap.release()
        super().stop()

# ──────────────────────────── service helpers ── #

def start_camera_track(record=False):
    if state.camera_track is None:
        try:
            # Try PiCamera2 first for Raspberry Pi 5
            if PICAMERA2_AVAILABLE:
                state.camera_track = PiCamera2VideoTrack(record=record)
                log.info('Using PiCamera2 (Raspberry Pi 5)')
            elif OPENCV_AVAILABLE:
                state.camera_track = CameraVideoTrack(record=record)
                log.info('Using OpenCV camera (PiCamera2 not available)')
            else:
                raise RuntimeError("No camera library available")
        except Exception as e:
            log.warning('PiCamera2 failed, falling back to OpenCV: %s', e)
            if OPENCV_AVAILABLE:
                state.camera_track = CameraVideoTrack(record=record)
            else:
                raise RuntimeError("No working camera implementation available")
    else:
        log.info('reuse camera track')
    return state.camera_track

async def stop_camera_track():
    if state.camera_track:
        state.camera_track.stop()
        state.camera_track = None
        log.info('track stopped')