# services/video.py
"""
Video service with two backends:
 - FFmpeg pipeline (rpicam-vid -> ffmpeg -> yuv420p)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional

import numpy as np
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)

# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        # frame в формате yuv не поддерживает cv2.putText напрямую, наложение только для RGB
        if len(frame.shape) == 3 and frame.shape[2] == 3:
            import cv2
            cv2.putText(frame, txt, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                        (0, 255, 0), 2)
        return frame

# ---------------- FFmpeg pipeline track ---------------- #
class FFmpegCameraTrack(VideoStreamTrack):
    """
    rpicam-vid -> stdout -> ffmpeg -> rawvideo yuv420p
    Чтение stdout ffmpeg в отдельном потоке, кадры в очередь,
    recv() берёт последний.
    """

    def __init__(self, width=640, height=480, framerate=30, *, overlay=True, record=False):
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)

        rpicam = shutil.which("rpicam-vid")
        ffmpeg = shutil.which("ffmpeg")
        if not rpicam or not ffmpeg:
            raise RuntimeError("rpicam-vid или ffmpeg не найдены")

        # rpicam сразу в MJPEG (потом ffmpeg конвертирует в yuv420p)
        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "mjpeg",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "-n"
        ]

        self.ffmpeg_cmd = [
            ffmpeg,
            "-i", "pipe:0",
            "-f", "rawvideo",
            "-pix_fmt", "yuv420p",
            "-an", "-sn", "-"
        ]

        # yuv420p: размер кадра = width*height*1.5
        self.frame_size = int(self.width * self.height * 3 / 2)
        self.frame_queue: queue.Queue = queue.Queue(maxsize=10)
        self.last_frame: Optional[np.ndarray] = None
        self._running = True

        self._rpicam_proc = None
        self._ffmpeg_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 FFmpegCameraTrack started %dx%d@%dfps (record=%s)",
                 self.width, self.height, self.fps, self.record)

    def _start_processes(self):
        try:
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self._ffmpeg_proc = subprocess.Popen(
                self.ffmpeg_cmd,
                stdin=self._rpicam_proc.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**8
            )
        except Exception as e:
            try:
                if self._ffmpeg_proc: self._ffmpeg_proc.kill()
            except Exception: pass
            try:
                if self._rpicam_proc: self._rpicam_proc.kill()
            except Exception: pass
            raise RuntimeError(f"Failed to start rpicam/ffmpeg: {e}")

        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._ffmpeg_proc.stdout
        stderr = self._ffmpeg_proc.stderr

        # drain stderr to avoid blocking
        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line: break
                    log.debug("ffmpeg: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass
        Thread(target=_drain_stderr, args=(stderr,), daemon=True).start()

        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("FFmpeg read incomplete frame: %s bytes", len(raw) if raw else 0)
                continue  # просто пропускаем, не ломаем стрим

            # создаём VideoFrame напрямую из yuv420p
            try:
                frame = np.frombuffer(raw, np.uint8).reshape((int(self.height*1.5), self.width))
            except Exception as e:
                log.exception("Failed to reshape frame: %s", e)
                continue

            if self.overlay:
                try:
                    frame = self.overlay.draw(frame)
                except Exception:
                    log.exception("Overlay failed")

            try:
                self.frame_queue.put(frame, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception: pass
                try:
                    self.frame_queue.put(frame, block=False)
                except Exception: pass

            self.last_frame = frame

        self._running = False
        log.info("FFmpeg read loop exited")
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        frame = None
        try:
            frame = self.frame_queue.get_nowait()
            self.last_frame = frame
        except queue.Empty:
            frame = self.last_frame  # используем последний кадр

        v = VideoFrame.from_ndarray(frame, format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        try:
            if self._ffmpeg_proc: self._ffmpeg_proc.kill()
        except Exception: pass
        try:
            if self._rpicam_proc: self._rpicam_proc.kill()
        except Exception: pass
        super().stop()
        log.info("🛑 FFmpegCameraTrack stopped")

# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        log.info("🎥 OpenCV camera %s started (record=%s)", index, self.record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        v = v.reformat(format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        try:
            if self.cap: self.cap.release()
        except Exception: pass
        super().stop()
        log.info("🛑 OpenCV camera stopped")

# ---------------- start/stop helpers ---------------- #
def start_camera_track(record: bool = False):
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid") and shutil.which("ffmpeg"):
                state.camera_track = FFmpegCameraTrack(record=record)
                log.info("Using FFmpeg pipeline (rpicam-vid)")
            else:
                state.camera_track = CameraVideoTrack(record=record)
                log.info("Using OpenCV fallback camera")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            try:
                if state.camera_track: state.camera_track.stop()
            except Exception: pass
            state.camera_track = None
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track

async def stop_camera_track():
    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            log.exception("Error stopping camera track")
        state.camera_track = None
        log.info("Camera track stopped")
