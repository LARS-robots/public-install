# # services/video.py (second debug iteration)
# """Improved diagnostics
# • prints every grab attempt (INFO) – so видно, пытаемся ли читать камеру;
# • без рекурсии – бесконечный цикл внутри recv (опасности переполнения стека нет);
# • отлавливает исключения и завершает трек с сообщением;
# • DEBUG‑уровень остаётся для SEND FRAME, но теперь grab‑attempt → INFO, значит видно даже на обычном log‑level.
# """
# from __future__ import annotations

# import asyncio, logging, os, time
# from datetime import datetime
# from pathlib import Path

# import cv2
# from av import VideoFrame
# from aiortc import VideoStreamTrack
# from .. import state

# log = logging.getLogger(__name__)

# # ──────────────────────────────────────────────────────────────── helpers ── #
# class SimpleOverlay:
#     def __init__(self):
#         self.t0 = time.time()
#         self.fps = 0.0

#     def draw(self, frame):
#         now = time.time(); dt = now - self.t0 or 1e-6; self.t0 = now
#         self.fps = 0.9 * self.fps + 0.1 / dt
#         txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
#         cv2.putText(frame, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8,(0,255,0),2)
#         return frame

# class VideoRecorder:
#     def __init__(self, w:int,h:int,fps:int):
#         ts = datetime.now().strftime('%Y%m%d_%H%M%S')
#         self.filename = Path(f'record_{ts}.mp4')
#         fourcc = cv2.VideoWriter_fourcc(*'avc1')
#         self.wr = cv2.VideoWriter(str(self.filename), fourcc, fps, (w,h))
#         if not self.wr.isOpened(): raise RuntimeError('VideoWriter open fail')
#         log.info('📹 recording to %s', self.filename)

#     def write(self,f): self.wr.write(f)
#     def close(self): self.wr.release(); log.info('💾 saved %s', self.filename)

# # ──────────────────────────────────────────── CameraVideoTrack ── #
# class CameraVideoTrack(VideoStreamTrack):
#     def __init__(self, source=0, *, overlay=True, record=False):
#         super().__init__()
#         self.cap = cv2.VideoCapture(source, cv2.CAP_DSHOW if os.name=='nt' else 0)
#         if not self.cap.isOpened():
#             log.error('❌ camera %s not opened', source)
#             raise RuntimeError('camera open failed')
#         w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
#         h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
#         fps_raw = self.cap.get(cv2.CAP_PROP_FPS) or 30; self.fps = int(fps_raw) if fps_raw>1 else 30
#         self.overlay = SimpleOverlay() if overlay else None
#         self.rec = VideoRecorder(w,h,self.fps) if record else None
#         log.info('🎦 camera started %dx%d@%dfps overlay=%s record=%s', w,h,self.fps,overlay,record)

#     async def recv(self):
#         pts, tb = await self.next_timestamp()
#         try:
#             while True:
#                 ok, frame = self.cap.read()
#                 if not ok:
#                     log.info('⚠️ grab fail – retry'); await asyncio.sleep(1/self.fps); continue
#                 if self.overlay: frame = self.overlay.draw(frame)
#                 if self.rec: self.rec.write(frame)
#                 log.debug('➡️ frame %s', frame.shape)
#                 v = VideoFrame.from_ndarray(frame, format='bgr24'); v.pts, v.time_base = pts, tb
#                 return v
#         except Exception as e:
#             log.exception('recv loop error: %s', e)
#             raise

#     def stop(self):
#         log.info('🛑 CameraVideoTrack.stop')
#         if self.rec: self.rec.close()
#         self.cap.release()
#         super().stop()

# # ──────────────────────────── service helpers ── #

# def start_camera_track(record=False):
#     if state.camera_track is None:
#         state.camera_track = CameraVideoTrack(record=record)
#     else:
#         log.info('reuse camera track')
#     return state.camera_track

# async def stop_camera_track():
#     if state.camera_track:
#         state.camera_track.stop(); state.camera_track=None; log.info('track stopped')
"""Video service using picamera for Raspberry Pi camera
• uses picamera library for better performance on RPi
• maintains WebRTC compatibility with aiortc
• includes overlay and recording functionality
"""
from __future__ import annotations

import asyncio, logging, io, time
from datetime import datetime
from pathlib import Path
from threading import Thread, Event

try:
    import picamera
    PICAMERA_AVAILABLE = True
except ImportError:
    PICAMERA_AVAILABLE = False
    import cv2

import numpy as np
from av import VideoFrame
from aiortc import VideoStreamTrack
from .. import state

log = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────── helpers ── #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time(); dt = now - self.t0 or 1e-6; self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        # Add text overlay to numpy array
        import cv2
        cv2.putText(frame, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8,(0,255,0),2)
        return frame

class VideoRecorder:
    def __init__(self, w:int, h:int, fps:int):
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.filename = Path(f'record_{ts}.h264')  # H.264 for picamera
        self.fps = fps
        log.info('📹 recording to %s', self.filename)

    def write_h264(self, data):
        """Write raw H.264 data to file"""
        with open(self.filename, 'ab') as f:
            f.write(data)

    def close(self):
        log.info('💾 saved %s', self.filename)

# ──────────────────────────────────────── PiCameraVideoTrack ── #
class PiCameraVideoTrack(VideoStreamTrack):
    def __init__(self, *, overlay=True, record=False, resolution=(640, 480), framerate=30):
        super().__init__()
        
        if not PICAMERA_AVAILABLE:
            raise RuntimeError("picamera library not available")
            
        self.camera = picamera.PiCamera()
        self.camera.resolution = resolution
        self.camera.framerate = framerate
        self.w, self.h = resolution
        self.fps = framerate
        
        self.overlay = SimpleOverlay() if overlay else None
        self.rec = VideoRecorder(self.w, self.h, self.fps) if record else None
        
        # Buffer for capturing frames
        self.stream = io.BytesIO()
        self.frame_ready = Event()
        self.latest_frame = None
        self.running = True
        
        # Start capture thread
        self.capture_thread = Thread(target=self._capture_loop, daemon=True)
        self.capture_thread.start()
        
        log.info('🎦 PiCamera started %dx%d@%dfps overlay=%s record=%s', 
                self.w, self.h, self.fps, overlay, record)

    def _capture_loop(self):
        """Continuous capture loop in separate thread"""
        try:
            # Start recording to capture frames
            self.camera.start_recording(self.stream, format='mjpeg')
            
            while self.running:
                # Wait for a frame
                self.camera.wait_recording(1/self.fps)
                
                # Get the frame data
                self.stream.seek(0)
                frame_data = self.stream.read()
                
                if frame_data:
                    # Decode JPEG to numpy array
                    frame_array = np.frombuffer(frame_data, dtype=np.uint8)
                    frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)
                    
                    if frame is not None:
                        if self.overlay:
                            frame = self.overlay.draw(frame)
                        
                        if self.rec:
                            # For recording, we'd need to re-encode or save raw data
                            pass
                        
                        self.latest_frame = frame
                        self.frame_ready.set()
                
                # Reset stream for next frame
                self.stream.seek(0)
                self.stream.truncate()
                
        except Exception as e:
            log.exception('Capture loop error: %s', e)
        finally:
            try:
                self.camera.stop_recording()
            except:
                pass

    async def recv(self):
        pts, tb = await self.next_timestamp()
        
        try:
            # Wait for frame with timeout
            timeout = 2.0  # seconds
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                if self.frame_ready.wait(timeout=0.1):
                    self.frame_ready.clear()
                    
                    if self.latest_frame is not None:
                        frame = self.latest_frame.copy()
                        log.debug('➡️ frame %s', frame.shape)
                        
                        # Convert BGR to RGB for VideoFrame
                        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        v = VideoFrame.from_ndarray(frame_rgb, format='rgb24')
                        v.pts, v.time_base = pts, tb
                        return v
                
                await asyncio.sleep(0.01)
            
            # Timeout - return black frame
            log.warning('⚠️ frame timeout - returning black frame')
            black_frame = np.zeros((self.h, self.w, 3), dtype=np.uint8)
            v = VideoFrame.from_ndarray(black_frame, format='rgb24')
            v.pts, v.time_base = pts, tb
            return v
            
        except Exception as e:
            log.exception('recv error: %s', e)
            raise

    def stop(self):
        log.info('🛑 PiCameraVideoTrack.stop')
        self.running = False
        
        if self.capture_thread.is_alive():
            self.capture_thread.join(timeout=2.0)
        
        if self.rec:
            self.rec.close()
            
        try:
            self.camera.close()
        except:
            pass
            
        super().stop()

# ──────────────────────────────────────── Fallback OpenCV Track ── #
class CameraVideoTrack(VideoStreamTrack):
    """Fallback OpenCV implementation for non-RPi systems"""
    def __init__(self, source=0, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(source)
        if not self.cap.isOpened():
            log.error('❌ camera %s not opened', source)
            raise RuntimeError('camera open failed')
        
        w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
        h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
        fps_raw = self.cap.get(cv2.CAP_PROP_FPS) or 30
        self.fps = int(fps_raw) if fps_raw > 1 else 30
        
        self.overlay = SimpleOverlay() if overlay else None
        self.rec = VideoRecorder(w, h, self.fps) if record else None
        
        log.info('🎦 OpenCV camera started %dx%d@%dfps overlay=%s record=%s', 
                w, h, self.fps, overlay, record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    log.info('⚠️ grab fail – retry')
                    await asyncio.sleep(1/self.fps)
                    continue
                    
                if self.overlay:
                    frame = self.overlay.draw(frame)
                    
                log.debug('➡️ frame %s', frame.shape)
                
                # Convert BGR to RGB for VideoFrame
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                v = VideoFrame.from_ndarray(frame_rgb, format='rgb24')
                v.pts, v.time_base = pts, tb
                return v
                
        except Exception as e:
            log.exception('recv loop error: %s', e)
            raise

    def stop(self):
        log.info('🛑 CameraVideoTrack.stop')
        if self.rec:
            self.rec.close()
        self.cap.release()
        super().stop()

# ──────────────────────────── service helpers ── #

def start_camera_track(record=False):
    if state.camera_track is None:
        try:
            # Try PiCamera first
            if PICAMERA_AVAILABLE:
                state.camera_track = PiCameraVideoTrack(record=record)
                log.info('Using PiCamera')
            else:
                state.camera_track = CameraVideoTrack(record=record)
                log.info('Using OpenCV camera (PiCamera not available)')
        except Exception as e:
            log.warning('PiCamera failed, falling back to OpenCV: %s', e)
            state.camera_track = CameraVideoTrack(record=record)
    else:
        log.info('reuse camera track')
    return state.camera_track

async def stop_camera_track():
    if state.camera_track:
        state.camera_track.stop()
        state.camera_track = None
        log.info('track stopped')