# services/video.py
"""
Video service with two backends:
 - FFmpeg pipeline (rpicam-vid -> ffmpeg -> raw frames)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)


# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        cv2.putText(frame, txt, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (0, 255, 0), 2)
        return frame


# ---------------- FFmpeg pipeline track ---------------- #
class FFmpegCameraTrack(VideoStreamTrack):
    """
    rpicam-vid -> stdout -> ffmpeg -> rawvideo bgr24
    Чтение stdout ffmpeg в отдельном потоке,
    кадры в очередь, recv() берёт последний.
    """

    def __init__(self, width=640, height=480, framerate=30, *, overlay=True, record=False):
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)

        rpicam = shutil.which("rpicam-vid")
        ffmpeg = shutil.which("ffmpeg")
        if not rpicam or not ffmpeg:
            raise RuntimeError("rpicam-vid или ffmpeg не найдены")

        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "mjpeg",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "-n"
        ]
        self.ffmpeg_cmd = [
            ffmpeg,
            "-i", "pipe:0",
            "-f", "rawvideo",
            "-pix_fmt", "bgr24",
            "-an", "-sn", "-"
        ]

        self.frame_size = self.width * self.height * 3
        self.frame_queue: queue.Queue = queue.Queue(maxsize=2)
        self._running = True

        self._rpicam_proc = None
        self._ffmpeg_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 FFmpegCameraTrack started %dx%d@%dfps (record=%s)",
                 self.width, self.height, self.fps, self.record)

    def _start_processes(self):
        try:
            # оставляем stderr PIPE во время старта, чтобы можно было логировать ошибки
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self._ffmpeg_proc = subprocess.Popen(
                self.ffmpeg_cmd,
                stdin=self._rpicam_proc.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**8
            )
        except Exception as e:
            # если не удалось стартовать процессы — аккуратно завершить и поднять исключение
            try:
                if self._ffmpeg_proc:
                    self._ffmpeg_proc.kill()
            except Exception:
                pass
            try:
                if self._rpicam_proc:
                    self._rpicam_proc.kill()
            except Exception:
                pass
            raise RuntimeError(f"Failed to start rpicam/ffmpeg: {e}")

        # старт чтения stdout в отдельном потоке
        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._ffmpeg_proc.stdout
        stderr = self._ffmpeg_proc.stderr
        # также читателя stderr в фоне (чтобы не блокировать)
        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line:
                        break
                    log.debug("ffmpeg: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass
        Thread(target=_drain_stderr, args=(stderr,), daemon=True).start()

        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("FFmpeg read incomplete frame: %s bytes", len(raw) if raw else 0)
                break
            try:
                frame = np.frombuffer(raw, np.uint8).reshape((self.height, self.width, 3))
            except Exception as e:
                log.exception("Failed to reshape frame: %s", e)
                continue

            # BGR->RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if self.overlay:
                try:
                    frame_rgb = self.overlay.draw(frame_rgb)
                except Exception:
                    log.exception("Overlay failed")

            # push to queue (drop oldest when full)
            try:
                self.frame_queue.put(frame_rgb, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception:
                    pass
                try:
                    self.frame_queue.put(frame_rgb, block=False)
                except Exception:
                    pass

        self._running = False
        log.info("FFmpeg read loop exited")
        # агрессивно закроем процессы (они могли сломаться)
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame = self.frame_queue.get_nowait()
        except queue.Empty:
            frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)

        # create VideoFrame from RGB ndarray then reformat to yuv420p (WebRTC-friendly)
        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            # fallback: try converting via av directly if reformat not available
            # (most aiortc/av versions support reformat)
            pass
        v.pts, v.time_base = pts, tb
        return v


    def stop(self):
        self._running = False
        try:
            if self._ffmpeg_proc:
                self._ffmpeg_proc.kill()
        except Exception:
            pass
        try:
            if self._rpicam_proc:
                self._rpicam_proc.kill()
        except Exception:
            pass
        super().stop()
        log.info("🛑 FFmpegCameraTrack stopped")


# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        log.info("🎥 OpenCV camera %s started (record=%s)", index, self.record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            pass
        v.pts, v.time_base = pts, tb
        return v


    def stop(self):
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        super().stop()
        log.info("🛑 OpenCV camera stopped")


# ---------------- start/stop helpers ---------------- #
def start_camera_track(record: bool = False):
    """
    Start camera track. record parameter is accepted (may be no-op depending on backend).
    """
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid") and shutil.which("ffmpeg"):
                state.camera_track = FFmpegCameraTrack(record=record)
                log.info("Using FFmpeg pipeline (rpicam-vid)")
            else:
                state.camera_track = CameraVideoTrack(record=record)
                log.info("Using OpenCV fallback camera")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            # Если запуск не удался — освободим state и пробросим ошибку дальше
            try:
                if state.camera_track:
                    state.camera_track.stop()
            except Exception:
                pass
            state.camera_track = None
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track


async def stop_camera_track():
    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            log.exception("Error stopping camera track")
        state.camera_track = None
        log.info("Camera track stopped")
