"""
Video service with two backends:
 - Raw YUV pipeline (rpicam-vid with yuv420 -> raw frames)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional
from pathlib import Path

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)

# Добавляем директорию для записей
RECORDINGS_DIR = Path.home() / "LARS" / "recordings"
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------- Видео рекордер ---------------- #
class VideoRecorder:
    def __init__(self, width: int, height: int, fps: int):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filename = RECORDINGS_DIR / f"robot_video_{timestamp}.mp4"
        self.writer = None
        self.width = width
        self.height = height
        self.fps = fps
        log.info(f"📹 Запись видео: {self.filename}")

    def start(self):
        """Инициализация видео writer"""
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.writer = cv2.VideoWriter(
            str(self.filename), 
            fourcc, 
            self.fps, 
            (self.width, self.height)
        )
        return self.writer.isOpened()

    def write_frame(self, frame):
        """Запись кадра (ожидается BGR формат)"""
        if self.writer and self.writer.isOpened():
            self.writer.write(frame)

    def stop(self):
        """Остановка записи"""
        if self.writer:
            self.writer.release()
            self.writer = None
        log.info(f"💾 Видео сохранено: {self.filename}")
        return self.filename

# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        cv2.putText(frame, txt, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (0, 255, 0), 2)
        return frame

# ---------------- Raw YUV pipeline track ---------------- #
class RawYUVCameraTrack(VideoStreamTrack):
    """
    rpicam-vid with yuv420 codec -> stdout raw yuv420p frames.
    Чтение stdout в отдельном потоке,
    кадры в очередь, recv() берёт последний.
    Для overlay: конверт YUV -> BGR -> draw -> back to YUV.
    """

    def __init__(self, width=640, height=480, framerate=300, *, overlay=True, record=False, camera=0):
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        self.camera = camera
        
        # Инициализация рекордера
        self.recorder = VideoRecorder(width, height, framerate) if record else None
        if self.recorder and not self.recorder.start():
            log.error("Не удалось инициализировать запись видео")
            self.recorder = None

        rpicam = shutil.which("rpicam-vid")
        if not rpicam:
            raise RuntimeError("rpicam-vid не найден")

        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "yuv420",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "--low-latency",
            "--camera", str(self.camera),
            "-n"
        ]

        self.frame_size = self.width * self.height * 3 // 2  # YUV420: 1.5 bytes per pixel
        self.frame_queue: queue.Queue = queue.Queue(maxsize=2)
        self._running = True

        self._rpicam_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 RawYUVCameraTrack started %dx%d@%dfps (record=%s)",
                 self.width, self.height, self.fps, self.record)

    def _start_processes(self):
        try:
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**8
            )
        except Exception as e:
            try:
                if self._rpicam_proc:
                    self._rpicam_proc.kill()
            except Exception:
                pass
            raise RuntimeError(f"Failed to start rpicam-vid: {e}")

        # Start reading stdout in a separate thread
        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._rpicam_proc.stdout
        stderr = self._rpicam_proc.stderr
        # Background stderr reader to avoid blocking
        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line:
                        break
                    log.debug("rpicam-vid: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass
        Thread(target=_drain_stderr, args=(stderr,), daemon=True).start()

        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("rpicam-vid read incomplete frame: %s bytes", len(raw) if raw else 0)
                break
            try:
                frame = np.frombuffer(raw, np.uint8).reshape((self.height * 3 // 2, self.width))
            except Exception as e:
                log.exception("Failed to reshape frame: %s", e)
                continue

            # Конвертация YUV420 -> BGR для обработки и записи
            frame_bgr = None
            if self.overlay or self.recorder:
                try:
                    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_YUV2BGR_I420)
                    
                    if self.overlay:
                        frame_bgr = self.overlay.draw(frame_bgr)
                    
                    # ✅ ДОБАВИТЬ ЗАПИСЬ КАДРА
                    if self.recorder:
                        self.recorder.write_frame(frame_bgr)
                    
                    # Конвертация обратно в YUV для WebRTC
                    frame = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2YUV_I420)
                    
                except Exception:
                    log.exception("Frame processing failed")

            # Push to queue (drop oldest when full)
            try:
                self.frame_queue.put(frame, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception:
                    pass
                try:
                    self.frame_queue.put(frame, block=False)
                except Exception:
                    pass

        self._running = False
        log.info("rpicam-vid read loop exited")
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame = self.frame_queue.get_nowait()
        except queue.Empty:
            frame = np.zeros((self.height * 3 // 2, self.width), dtype=np.uint8)

        # Create VideoFrame directly from YUV420 ndarray (WebRTC-friendly)
        v = VideoFrame.from_ndarray(frame, format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        
        # Остановка записи
        if self.recorder:
            filename = self.recorder.stop()
            log.info(f"📹 Запись сохранена: {filename}")
        
        try:
            if self._rpicam_proc:
                self._rpicam_proc.kill()
        except Exception:
            pass
        super().stop()
        log.info("🛑 RawYUVCameraTrack stopped")

# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        log.info("🎥 OpenCV camera %s started (record=%s)", index, self.record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            pass
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        super().stop()
        log.info("🛑 OpenCV camera stopped")

# ---------------- start/stop helpers ---------------- #
def start_camera_track(camera_id: int = 0, record: bool = False):
    """
    Start camera track. record parameter is accepted (may be no-op depending on backend).
    """
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid"):
                state.camera_track = RawYUVCameraTrack(record=record, camera=camera_id)
                log.info(f"Using Raw YUV pipeline (rpicam-vid) with camera {camera_id}")
            else:
                state.camera_track = CameraVideoTrack(record=record, camera=camera_id)
                log.info(f"Using OpenCV fallback camera with camera {camera_id}")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            # Если запуск не удался — освободим state и пробросим ошибку дальше
            try:
                if state.camera_track:
                    state.camera_track.stop()
            except Exception:
                pass
            state.camera_track = None
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track

async def stop_camera_track():
    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            log.exception("Error stopping camera track")
        state.camera_track = None
        log.info("Camera track stopped")