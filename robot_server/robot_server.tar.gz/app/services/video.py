"""
Video service with two backends:
 - Raw YUV pipeline (rpicam-vid, yuv420 I420)               [Raspberry Pi]
 - OpenCV fallback (cv2.VideoCapture)                        [Desktop/Windows/Linux]

Принципы:
 - fps определяется динамически по приходу кадров (обе ветки);
 - запись создаётся лениво после оценки fps;
 - на RPi оверлей рисуется прямо на Y-плоскости (монохром) без YUV<->BGR конвертаций;
 - конвертация YUV->BGR делается только при записи.
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional
from pathlib import Path
import math
import platform

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

log = logging.getLogger(__name__)

# ---------------- storage ---------------- #
RECORDINGS_DIR = Path.home() / "LARS" / "recordings"
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)


# ---------------- recorder ---------------- #
class VideoRecorder:
    def __init__(self, width: int, height: int, fps: float):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filename = RECORDINGS_DIR / f"robot_video_{timestamp}.mp4"
        self.writer = None
        self.width = int(width)
        self.height = int(height)
        self.fps = float(max(5.0, min(120.0, fps)))
        log.info(f"📹 Запись: {self.filename} @ {self.fps:.1f}fps")

    def start(self):
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.writer = cv2.VideoWriter(str(self.filename), fourcc, self.fps, (self.width, self.height))
        ok = self.writer.isOpened()
        if not ok:
            log.error("❌ Не удалось открыть VideoWriter")
        return ok

    def write_frame(self, frame_bgr: np.ndarray):
        if self.writer and self.writer.isOpened():
            self.writer.write(frame_bgr)

    def stop(self):
        if self.writer:
            self.writer.release()
            self.writer = None
        log.info(f"💾 Сохранено: {self.filename}")
        return self.filename


# ---------------- utils ---------------- #
def _fps_from_samples(samples: list[float]) -> Optional[float]:
    if len(samples) < 10:
        return None
    dt = float(np.median(samples[-30:]))
    if not math.isfinite(dt) or dt <= 0:
        return None
    return 1.0 / dt


# ---------------- Raw YUV pipeline (Raspberry Pi) ---------------- #
class RawYUVCameraTrack(VideoStreamTrack):
    """
    rpicam-vid -> yuv420 to stdout.
    Читаем кадры в отдельном потоке; рисуем монохромный оверлей по Y-плоскости.
    Для записи (если включена) конвертируем в BGR и пишем в MP4.
    """
    kind = "video"

    def __init__(
        self,
        width: int = 640,
        height: int = 480,
        framerate: Optional[int] = None,  # если None — не указывать --framerate
        *,
        overlay: bool = True,
        record: bool = False,
        camera: int = 0
    ):
        super().__init__()
        self.width = int(width)
        self.height = int(height)
        self.overlay_enabled = bool(overlay)

        # запись — лениво, после оценки реального fps
        self.want_record = bool(record)
        self.recorder: Optional[VideoRecorder] = None

        self._running = True
        self._fps_samples: list[float] = []
        self._t_prev = time.time()
        self._overlay_fps = 0.0  # EMA для показа на экране

        rpicam = shutil.which("rpicam-vid")
        if not rpicam:
            raise RuntimeError("rpicam-vid не найден")

        # Формируем команду; fps динамический — не указываем, если не задан.
        self.rpicam_cmd = [
            rpicam, "-t", "0", "-o", "-", "--codec", "yuv420",
            "--width", str(self.width), "--height", str(self.height),
            "--low-latency", "--camera", str(int(camera)), "-n"
        ]
        if framerate is not None:
            self.rpicam_cmd.extend(["--framerate", str(int(framerate))])

        # размеры плоскостей для I420
        self.y_size = self.width * self.height
        self.uv_w = self.width // 2
        self.uv_h = self.height // 2
        self.uv_size = self.uv_w * self.uv_h
        self.frame_size = self.y_size + 2 * self.uv_size  # H*W + 2*(H/2*W/2)

        self.frame_queue: queue.Queue = queue.Queue(maxsize=2)
        self._rpicam_proc: Optional[subprocess.Popen] = None
        self._thread: Optional[Thread] = None

        self._start_processes()
        log.info("🎦 RawYUVCameraTrack %dx%d (record=%s)", self.width, self.height, self.want_record)

    def _start_processes(self):
        try:
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**7
            )
        except Exception as e:
            if self._rpicam_proc:
                try:
                    self._rpicam_proc.kill()
                except Exception:
                    pass
            raise RuntimeError(f"Failed to start rpicam-vid: {e}")

        # Отводим stderr, чтобы не блокировался stdout
        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line:
                        break
                    log.debug("rpicam-vid: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass

        Thread(target=_drain_stderr, args=(self._rpicam_proc.stderr,), daemon=True).start()
        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _draw_overlay_y(self, buf: np.ndarray):
        """
        Рисуем дату/время и FPS (монохром) на Y-плоскости I420.
        """
        H, W = self.height, self.width
        # Представление плоскостей
        Yp = buf[:self.y_size].reshape(H, W)
        # Маска для текста
        mask = np.zeros((H, W), dtype=np.uint8)
        # EMA FPS
        now = time.time()
        dt = max(1e-6, now - self._t_prev)
        self._t_prev = now
        self._overlay_fps = 0.9 * self._overlay_fps + 0.1 * (1.0 / dt)
        txt = f"{datetime.now():%H:%M:%S} | {self._overlay_fps:4.1f} fps"
        cv2.putText(mask, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, 255, 2, cv2.LINE_AA)

        # Лёгкое осветление по маске (альфа-смешивание к «белому»)
        alpha = 0.6
        sel = mask > 0
        if np.any(sel):
            Yp[sel] = np.clip((1 - alpha) * Yp[sel] + alpha * 235, 0, 255).astype(np.uint8)

    def _read_loop(self):
        stdout = self._rpicam_proc.stdout
        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("rpicam-vid read incomplete frame: %s bytes", len(raw) if raw else 0)
                break

            # оценка fps по приходу кадров
            t_now = time.time()
            self._fps_samples.append(t_now - self._t_prev)
            # _t_prev обновляется в _draw_overlay_y (там же считаем EMA для оверлея)

            # Буфер кадра I420 (плоский)
            buf = np.frombuffer(raw, dtype=np.uint8).copy()  # copy т.к. модифицируем Y

            # Рисуем оверлей на Y, если включён
            if self.overlay_enabled:
                self._draw_overlay_y(buf)

            # Ленивая инициализация записи, когда появился внятный fps
            fps_est = _fps_from_samples(self._fps_samples)
            if self.want_record and self.recorder is None and fps_est:
                self.recorder = VideoRecorder(self.width, self.height, fps_est)
                if not self.recorder.start():
                    self.recorder = None
                    self.want_record = False  # больше не пытаться

            # Если пишем, конвертируем в BGR и отдаём в writer
            if self.recorder is not None:
                frame_yuv = buf.reshape(self.height * 3 // 2, self.width)
                try:
                    frame_bgr = cv2.cvtColor(frame_yuv, cv2.COLOR_YUV2BGR_I420)
                    self.recorder.write_frame(frame_bgr)
                except Exception:
                    log.exception("Frame conversion/write failed")

            # В очередь кладём I420 как (H*3//2, W)
            frame_yuv = buf.reshape(self.height * 3 // 2, self.width)
            try:
                self.frame_queue.put(frame_yuv, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception:
                    pass
                try:
                    self.frame_queue.put(frame_yuv, block=False)
                except Exception:
                    pass

        self._running = False
        log.info("rpicam-vid read loop exited")
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame_yuv = self.frame_queue.get_nowait()
        except queue.Empty:
            frame_yuv = np.zeros((self.height * 3 // 2, self.width), dtype=np.uint8)

        v = VideoFrame.from_ndarray(frame_yuv, format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        # запись
        if self.recorder:
            try:
                self.recorder.stop()
            except Exception:
                log.exception("Recorder stop failed")
            self.recorder = None
        # процесс камеры
        try:
            if self._rpicam_proc:
                try:
                    self._rpicam_proc.terminate()
                    self._rpicam_proc.wait(timeout=1.0)
                except Exception:
                    pass
                try:
                    self._rpicam_proc.kill()
                except Exception:
                    pass
        except Exception:
            pass
        super().stop()
        log.info("🛑 RawYUVCameraTrack stopped")


# ---------------- OpenCV fallback (Desktop) ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    """
    Захват с камеры через OpenCV. На Windows используем DirectShow.
    При серии неудачных чтений — авто-переоткрытие/переключение индекса.
    Отдаём сразу BGR->YUV (без лишней конвертации в RGB).
    """
    kind = "video"

    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.index = int(index)
        use_backend = cv2.CAP_DSHOW if platform.system() == "Windows" else 0
        self.cap = cv2.VideoCapture(self.index, use_backend)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(width))
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(height))

        self.overlay = bool(overlay)
        self.want_record = bool(record)
        self.recorder: Optional[VideoRecorder] = None

        self.bad_reads = 0
        self._t_prev = time.time()
        self._overlay_fps = 0.0

        log.info("🎥 OpenCV camera index=%s (backend=%s) started", self.index, "CAP_DSHOW" if use_backend else "default")

    def _reopen_or_switch(self):
        try:
            self.cap.release()
        except Exception:
            pass

        use_backend = cv2.CAP_DSHOW if platform.system() == "Windows" else 0

        # пробуем тот же индекс
        if not self.cap.open(self.index, use_backend):
            # fallback: попробуем 0/1
            probes = [0, 1] if self.index != 0 else [1]
            for p in probes:
                if self.cap.open(p, use_backend):
                    self.index = p
                    break

        self.bad_reads = 0
        log.warning("🔁 Reopened camera, current index=%s", self.index)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame_bgr = self.cap.read()
        if not ret or frame_bgr is None:
            self.bad_reads += 1
            if self.bad_reads in (1, 10):
                log.warning("⚠️ Camera read failed (count=%d)", self.bad_reads)
            if self.bad_reads >= 15:
                self._reopen_or_switch()
            frame_bgr = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            self.bad_reads = 0

        # overlay (EMA FPS)
        if self.overlay:
            now = time.time()
            dt = max(1e-6, now - self._t_prev)
            self._t_prev = now
            self._overlay_fps = 0.9 * self._overlay_fps + 0.1 * (1.0 / dt)
            txt = f"{self._overlay_fps:4.1f} fps | {datetime.now():%H:%M:%S}"
            cv2.putText(frame_bgr, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

        # запись: лениво на первом валидном кадре
        if self.want_record and self.recorder is None:
            fps0 = float(self.cap.get(cv2.CAP_PROP_FPS) or 0.0)
            fps = fps0 if math.isfinite(fps0) and fps0 > 1.0 else 30.0
            h, w = frame_bgr.shape[:2]
            rec = VideoRecorder(w, h, fps)
            if rec.start():
                self.recorder = rec
            else:
                self.want_record = False

        if self.recorder is not None:
            self.recorder.write_frame(frame_bgr)

        # Отдаём как yuv420
        v = VideoFrame.from_ndarray(frame_bgr, format="bgr24")
        v = v.reformat(format="yuv420p")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        if self.recorder:
            try:
                self.recorder.stop()
            except Exception:
                log.exception("Recorder stop failed")
            self.recorder = None
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        super().stop()
        log.info("🛑 OpenCV camera stopped")


# ---------------- public helpers (не трогаем state!) ---------------- #
def create_camera_track(camera_id: int = 0, record: bool = False):
    """
    Унифицированный старт: если есть rpicam-vid — берём его; иначе OpenCV.
    На ПК camera_id трактуем как index.
    """
    try:
        if shutil.which("rpicam-vid"):
            track = RawYUVCameraTrack(record=record, camera=camera_id, framerate=None)
            log.info("Using Raw YUV pipeline (rpicam-vid), camera=%s", camera_id)
        else:
            track = CameraVideoTrack(index=camera_id, record=record)
            log.info("Using OpenCV fallback, index=%s", camera_id)
        return track
    except Exception as e:
        log.exception("Failed to create camera track: %s", e)
        raise


async def stop_track(track: VideoStreamTrack):
    try:
        track.stop()
    except Exception:
        log.exception("Error stopping camera track")
    log.info("Camera track stopped")
