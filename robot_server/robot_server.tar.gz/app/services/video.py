"""
Video service with two backends:
 - FFmpeg pipeline (rpicam-vid -> ffmpeg -> raw frames)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)


# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        cv2.putText(frame, txt, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (0, 255, 0), 2)
        return frame


# ---------------- FFmpeg pipeline track ---------------- #
class FFmpegCameraTrack(VideoStreamTrack):
    """
    rpicam-vid -> stdout -> ffmpeg -> rawvideo bgr24
    Чтение stdout ffmpeg в отдельном потоке,
    кадры в очередь, recv() берёт последний.
    """

    def __init__(self, width=640, height=480, framerate=30, *, overlay=True):
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None

        rpicam = shutil.which("rpicam-vid")
        ffmpeg = shutil.which("ffmpeg")
        if not rpicam or not ffmpeg:
            raise RuntimeError("rpicam-vid или ffmpeg не найдены")

        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "mjpeg",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "-n"
        ]
        self.ffmpeg_cmd = [
            ffmpeg,
            "-i", "pipe:0",
            "-f", "rawvideo",
            "-pix_fmt", "bgr24",
            "-an", "-sn", "-"
        ]

        self.frame_size = self.width * self.height * 3
        self.frame_queue: queue.Queue = queue.Queue(maxsize=2)
        self._running = True

        self._rpicam_proc = None
        self._ffmpeg_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 FFmpegCameraTrack started %dx%d@%dfps",
                 self.width, self.height, self.fps)

    def _start_processes(self):
        self._rpicam_proc = subprocess.Popen(
            self.rpicam_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL
        )
        self._ffmpeg_proc = subprocess.Popen(
            self.ffmpeg_cmd,
            stdin=self._rpicam_proc.stdout,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=10**8
        )
        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._ffmpeg_proc.stdout
        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("FFmpeg read incomplete frame")
                break
            frame = np.frombuffer(raw, np.uint8).reshape((self.height, self.width, 3))
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if self.overlay:
                frame_rgb = self.overlay.draw(frame_rgb)
            try:
                self.frame_queue.put(frame_rgb, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put(frame_rgb, block=False)
        self._running = False
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame = self.frame_queue.get_nowait()
        except queue.Empty:
            frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        v = VideoFrame.from_ndarray(frame, format="rgb24")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        try:
            if self._ffmpeg_proc:
                self._ffmpeg_proc.kill()
            if self._rpicam_proc:
                self._rpicam_proc.kill()
        except Exception:
            pass
        super().stop()
        log.info("🛑 FFmpegCameraTrack stopped")


# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        log.info("🎥 OpenCV camera %s started", index)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)
        v = VideoFrame.from_ndarray(frame, format="rgb24")
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        if self.cap:
            self.cap.release()
        super().stop()
        log.info("🛑 OpenCV camera stopped")


# ---------------- start/stop helpers ---------------- #
def start_camera_track():
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid") and shutil.which("ffmpeg"):
                state.camera_track = FFmpegCameraTrack()
                log.info("Using FFmpeg pipeline (rpicam-vid)")
            else:
                state.camera_track = CameraVideoTrack()
                log.info("Using OpenCV fallback camera")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track


async def stop_camera_track():
    if state.camera_track:
        state.camera_track.stop()
        state.camera_track = None
        log.info("Camera track stopped")
