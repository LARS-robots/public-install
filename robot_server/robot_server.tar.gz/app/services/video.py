# services/video.py (second debug iteration)
"""Improved diagnostics
• prints every grab attempt (INFO) – so видно, пытаемся ли читать камеру;
• без рекурсии – бесконечный цикл внутри recv (опасности переполнения стека нет);
• отлавливает исключения и завершает трек с сообщением;
• DEBUG‑уровень остаётся для SEND FRAME, но теперь grab‑attempt → INFO, значит видно даже на обычном log‑level.
"""
from __future__ import annotations

import asyncio, logging, os, time
from datetime import datetime
from pathlib import Path
from typing import Optional

import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state  # local project‑level singleton

log = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────── helpers ── #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time(); dt = now - self.t0 or 1e-6; self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        cv2.putText(frame, txt, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8,(0,255,0),2)
        return frame

class VideoRecorder:
    def __init__(self, w:int,h:int,fps:int):
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.filename = Path(f'record_{ts}.mp4')
        fourcc = cv2.VideoWriter_fourcc(*'avc1')
        self.wr = cv2.VideoWriter(str(self.filename), fourcc, fps, (w,h))
        if not self.wr.isOpened(): raise RuntimeError('VideoWriter open fail')
        log.info('📹 recording to %s', self.filename)

    def write(self,f): self.wr.write(f)
    def close(self): self.wr.release(); log.info('💾 saved %s', self.filename)

# ──────────────────────────────────────────── CameraVideoTrack ── #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, source=0, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(source, cv2.CAP_DSHOW if os.name=='nt' else 0)
        if not self.cap.isOpened():
            log.error('❌ camera %s not opened', source)
            raise RuntimeError('camera open failed')
        w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
        h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
        fps_raw = self.cap.get(cv2.CAP_PROP_FPS) or 30; self.fps = int(fps_raw) if fps_raw>1 else 30
        self.overlay = SimpleOverlay() if overlay else None
        self.rec = VideoRecorder(w,h,self.fps) if record else None
        log.info('🎦 camera started %dx%d@%dfps overlay=%s record=%s', w,h,self.fps,overlay,record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    log.info('⚠️ grab fail – retry'); await asyncio.sleep(1/self.fps); continue
                if self.overlay: frame = self.overlay.draw(frame)
                if self.rec: self.rec.write(frame)
                log.debug('➡️ frame %s', frame.shape)
                v = VideoFrame.from_ndarray(frame, format='bgr24'); v.pts, v.time_base = pts, tb
                return v
        except Exception as e:
            log.exception('recv loop error: %s', e)
            raise

    def stop(self):
        log.info('🛑 CameraVideoTrack.stop')
        if self.rec: self.rec.close()
        self.cap.release()
        super().stop()

# ──────────────────────────── service helpers ── #

def start_camera_track(record=False):
    if state.camera_track is None:
        state.camera_track = CameraVideoTrack(record=record)
    else:
        log.info('reuse camera track')
    return state.camera_track

async def stop_camera_track():
    if state.camera_track:
        state.camera_track.stop(); state.camera_track=None; log.info('track stopped')
