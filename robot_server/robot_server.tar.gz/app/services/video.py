"""
Video service with two backends:
 - Raw YUV pipeline (rpicam-vid with yuv420 -> raw frames)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional

import numpy as np
import cv2
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)


# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        cv2.putText(frame, txt, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (0, 255, 0), 2)
        return frame


# ---------------- Raw YUV pipeline track ---------------- #
class RawYUVCameraTrack(VideoStreamTrack):
    """
    rpicam-vid with yuv420 codec -> stdout raw yuv420p frames.
    Чтение stdout в отдельном потоке,
    кадры в очередь, recv() берёт последний.
    Для overlay: конверт YUV -> BGR -> draw -> back to YUV.
    Добавлено handling stride/padding для Pi 5.
    """

    def __init__(self, width=640, height=480, framerate=30, *, overlay=False, record=False):  # overlay=False по default
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)

        rpicam = shutil.which("rpicam-vid")
        if not rpicam:
            raise RuntimeError("rpicam-vid не найден")

        # Предполагаемый stride для Pi 5 YUV420: roundup(width, 128)
        self.stride_y = ((width + 127) // 128) * 128
        self.stride_uv = self.stride_y // 2
        self.frame_size = (self.stride_y * height) + (self.stride_uv * height // 2) * 2  # Y + U + V с padding

        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "yuv420",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "--low-latency",
            "-n"
        ]

        self.frame_queue: queue.Queue = queue.Queue(maxsize=5)  # Увеличено для буферизации
        self._running = True

        self._rpicam_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 RawYUVCameraTrack started %dx%d@%dfps (record=%s, stride_y=%d)",
                 self.width, self.height, self.fps, self.record, self.stride_y)

    def _start_processes(self):
        try:
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**8
            )
        except Exception as e:
            try:
                if self._rpicam_proc:
                    self._rpicam_proc.kill()
            except Exception:
                pass
            raise RuntimeError(f"Failed to start rpicam-vid: {e}")

        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._rpicam_proc.stdout
        stderr = self._rpicam_proc.stderr
        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line:
                        break
                    log.debug("rpicam-vid: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass
        Thread(target=_drain_stderr, args=(stderr,), daemon=True).start()

        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("rpicam-vid read incomplete frame: %s bytes", len(raw) if raw else 0)
                continue  # Изменено на continue вместо break, чтобы не убивать loop

            try:
                # Copy to tight buffer без padding
                frame = np.frombuffer(raw, np.uint8)
                y = frame[:self.stride_y * self.height].reshape((self.height, self.stride_y))[:, :self.width]
                uv_offset = self.stride_y * self.height
                u = frame[uv_offset:uv_offset + self.stride_uv * (self.height // 2)].reshape((self.height // 2, self.stride_uv))[:, :self.width // 2]
                v = frame[uv_offset + self.stride_uv * (self.height // 2):].reshape((self.height // 2, self.stride_uv))[:, :self.width // 2]
                frame_tight = np.concatenate((y, u, v)).reshape((self.height * 3 // 2, self.width))
            except Exception as e:
                log.exception("Failed to reshape/copy frame: %s", e)
                continue

            # Check валидности (skip если кадр "тёмный" или corrupted)
            y_mean = np.mean(frame_tight[:self.height * self.width])
            if y_mean < 10:  # Arbitrary threshold для чёрных/мусорных
                log.debug("Skipping invalid frame (y_mean=%.2f)", y_mean)
                continue

            if self.overlay:
                try:
                    frame_bgr = cv2.cvtColor(frame_tight, cv2.COLOR_YUV2BGR_I420)
                    frame_bgr = self.overlay.draw(frame_bgr)
                    frame_tight = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2YUV_I420)
                except Exception:
                    log.exception("Overlay failed")

            try:
                self.frame_queue.put(frame_tight, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception:
                    pass
                try:
                    self.frame_queue.put(frame_tight, block=False)
                except Exception:
                    pass

        self._running = False
        log.info("rpicam-vid read loop exited")
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame = self.frame_queue.get_nowait()
        except queue.Empty:
            frame = np.zeros((self.height * 3 // 2, self.width), dtype=np.uint8)

        v = VideoFrame.from_ndarray(frame, format="yuv420p")
        # Set colorspace explicitly (если камера BT.709)
        # v.colorspace = 'bt709'  # Uncomment если цвета wrong; test BT.601/BT.709
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        try:
            if self._rpicam_proc:
                self._rpicam_proc.kill()
        except Exception:
            pass
        super().stop()
        log.info("🛑 RawYUVCameraTrack stopped")


# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        log.info("🎥 OpenCV camera %s started (record=%s)", index, self.record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            pass
        v.pts, v.time_base = pts, tb
        return v


    def stop(self):
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        super().stop()
        log.info("🛑 OpenCV camera stopped")


# ---------------- start/stop helpers ---------------- #
def start_camera_track(record: bool = False):
    """
    Start camera track. record parameter is accepted (may be no-op depending on backend).
    """
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid"):
                state.camera_track = RawYUVCameraTrack(record=record)
                log.info("Using Raw YUV pipeline (rpicam-vid)")
            else:
                state.camera_track = CameraVideoTrack(record=record)
                log.info("Using OpenCV fallback camera")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            # Если запуск не удался — освободим state и пробросим ошибку дальше
            try:
                if state.camera_track:
                    state.camera_track.stop()
            except Exception:
                pass
            state.camera_track = None
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track


async def stop_camera_track():
    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            log.exception("Error stopping camera track")
        state.camera_track = None
        log.info("Camera track stopped")