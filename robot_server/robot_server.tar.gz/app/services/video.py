# services/video.py
"""
Video service with two backends:
 - H264 FFmpeg pipeline (rpicam-vid -> ffmpeg -> RTP/H.264)
 - OpenCV fallback (cv2.VideoCapture)
"""

import logging
import subprocess
import shutil
import time
from datetime import datetime
from threading import Thread
import queue
from typing import Optional

import numpy as np
from av import VideoFrame
from aiortc import VideoStreamTrack

from .. import state

log = logging.getLogger(__name__)

# ---------------- Overlay ---------------- #
class SimpleOverlay:
    def __init__(self):
        self.t0 = time.time()
        self.fps = 0.0

    def draw(self, frame):
        now = time.time()
        dt = now - self.t0 or 1e-6
        self.t0 = now
        self.fps = 0.9 * self.fps + 0.1 / dt
        txt = f"{self.fps:4.1f} fps | {datetime.now():%H:%M:%S}"
        try:
            import cv2
            cv2.putText(frame, txt, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                        (0, 255, 0), 2)
        except Exception:
            pass
        return frame

# ---------------- H.264 FFmpeg pipeline track ---------------- #
class FFmpegH264CameraTrack(VideoStreamTrack):
    """
    H.264 encoded pipeline from rpicam-vid.
    Чтение stdout ffmpeg в отдельном потоке, кадры в очередь.
    """

    def __init__(self, width=640, height=480, framerate=30, *, overlay=True, record=False):
        super().__init__()
        self.width = width
        self.height = height
        self.fps = framerate
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)

        rpicam = shutil.which("rpicam-vid")
        if not rpicam:
            raise RuntimeError("rpicam-vid не найден")

        # Используем H.264, inline stream
        self.rpicam_cmd = [
            rpicam,
            "-t", "0",
            "-o", "-",
            "--codec", "h264",
            "--width", str(self.width),
            "--height", str(self.height),
            "--framerate", str(self.fps),
            "-n"
        ]

        # ffmpeg для конвертации в raw yuv420p
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            raise RuntimeError("ffmpeg не найден")

        self.ffmpeg_cmd = [
            ffmpeg,
            "-i", "pipe:0",
            "-f", "rawvideo",
            "-pix_fmt", "yuv420p",
            "-an", "-sn", "-"
        ]

        self.frame_size = self.width * self.height * 3  # для BGR fallback
        self.frame_queue: queue.Queue = queue.Queue(maxsize=20)  # больше буфер
        self.last_frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        self._running = True

        self._rpicam_proc = None
        self._ffmpeg_proc = None
        self._thread: Optional[Thread] = None
        self._start_processes()
        log.info("🎦 FFmpegH264CameraTrack started %dx%d@%dfps (record=%s)",
                 self.width, self.height, self.fps, self.record)

    def _start_processes(self):
        try:
            self._rpicam_proc = subprocess.Popen(
                self.rpicam_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self._ffmpeg_proc = subprocess.Popen(
                self.ffmpeg_cmd,
                stdin=self._rpicam_proc.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10**8
            )
        except Exception as e:
            if self._ffmpeg_proc:
                self._ffmpeg_proc.kill()
            if self._rpicam_proc:
                self._rpicam_proc.kill()
            raise RuntimeError(f"Failed to start rpicam/ffmpeg: {e}")

        self._thread = Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        stdout = self._ffmpeg_proc.stdout
        stderr = self._ffmpeg_proc.stderr

        def _drain_stderr(pipe):
            try:
                for line in iter(pipe.readline, b''):
                    if not line:
                        break
                    log.debug("ffmpeg: %s", line.decode(errors='ignore').rstrip())
            except Exception:
                pass

        Thread(target=_drain_stderr, args=(stderr,), daemon=True).start()

        while self._running:
            raw = stdout.read(self.frame_size)
            if not raw or len(raw) != self.frame_size:
                log.warning("FFmpeg read incomplete frame: %s bytes", len(raw) if raw else 0)
                continue
            try:
                frame = np.frombuffer(raw, np.uint8).reshape((self.height, self.width, 3))
            except Exception as e:
                log.exception("Failed to reshape frame: %s", e)
                continue

            if self.overlay:
                frame = self.overlay.draw(frame)

            self.last_frame = frame
            try:
                self.frame_queue.put(frame, block=False)
            except queue.Full:
                try:
                    _ = self.frame_queue.get_nowait()
                except Exception:
                    pass
                self.frame_queue.put(frame, block=False)

        self._running = False
        log.info("FFmpeg read loop exited")
        self.stop()

    async def recv(self):
        pts, tb = await self.next_timestamp()
        try:
            frame = self.frame_queue.get_nowait()
            self.last_frame = frame
        except queue.Empty:
            frame = self.last_frame

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            pass
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        self._running = False
        if self._ffmpeg_proc:
            self._ffmpeg_proc.kill()
        if self._rpicam_proc:
            self._rpicam_proc.kill()
        super().stop()
        log.info("🛑 FFmpegH264CameraTrack stopped")


# ---------------- OpenCV fallback track ---------------- #
class CameraVideoTrack(VideoStreamTrack):
    def __init__(self, index=0, width=640, height=480, *, overlay=True, record=False):
        super().__init__()
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.overlay = SimpleOverlay() if overlay else None
        self.record = bool(record)
        log.info("🎥 OpenCV camera %s started (record=%s)", index, self.record)

    async def recv(self):
        pts, tb = await self.next_timestamp()
        ret, frame = self.cap.read()
        if not ret:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.overlay:
            frame = self.overlay.draw(frame)

        v = VideoFrame.from_ndarray(frame, format="rgb24")
        try:
            v = v.reformat(format="yuv420p")
        except Exception:
            pass
        v.pts, v.time_base = pts, tb
        return v

    def stop(self):
        if self.cap:
            self.cap.release()
        super().stop()
        log.info("🛑 OpenCV camera stopped")


# ---------------- start/stop helpers ---------------- #
def start_camera_track(record: bool = False):
    if state.camera_track is None:
        try:
            if shutil.which("rpicam-vid") and shutil.which("ffmpeg"):
                state.camera_track = FFmpegH264CameraTrack(record=record)
                log.info("Using FFmpeg H264 pipeline (rpicam-vid)")
            else:
                state.camera_track = CameraVideoTrack(record=record)
                log.info("Using OpenCV fallback camera")
        except Exception as e:
            log.exception("Failed to start camera: %s", e)
            if state.camera_track:
                state.camera_track.stop()
            state.camera_track = None
            raise
    else:
        log.info("Reusing existing camera track")
    return state.camera_track


async def stop_camera_track():
    if state.camera_track:
        try:
            state.camera_track.stop()
        except Exception:
            log.exception("Error stopping camera track")
        state.camera_track = None
        log.info("Camera track stopped")
