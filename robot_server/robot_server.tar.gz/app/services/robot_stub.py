import cv2
from .robot_iface import Robot

class StubRobot(Robot):
    def __init__(self):
        self.cap = cv2.VideoCapture(0)

    # ---------- Camera ----------
    def snapshot(self):
        ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("No camera")
        _, jpeg = cv2.imencode(".jpg", frame)
        return jpeg.tobytes()

    def start_record(self):
        print("[STUB] start video recording")

    def stop_record(self):
        print("[STUB] stop video recording")

    def pan(self, value: int):
        print(f"[STUB] pan camera to {value}")

    def tilt(self, value: int):
        print(f"[STUB] tilt camera to {value}")

    # ---------- Motion ----------
    def move(self, left: int, right: int):
        print(f"[STUB] move L={left} R={right}")
