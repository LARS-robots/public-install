"""
Map download service - fetches OSM data and builds GeoJSON.
Uses the build_site_geojson.py script logic.
"""
import json
import math
import logging
import subprocess
import tomli
from pathlib import Path
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)

class MapDownloadService:
    """Service for downloading and building map data from OSM"""
    
    def __init__(self):
        # Load config.toml to get the GeoJSON path
        robot_root = Path(__file__).parent.parent.parent.parent  # Gets to robot/ directory
        config_path = robot_root / "robot_server" / "config.toml"
        
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'rb') as f:
            config = tomli.load(f)
        
        # Get relative path from config and convert to absolute
        relative_path = config.get("map", {}).get("path_to_geojson", "app/static/cache/chelybinsk.geojson")
        self.geojson_path = robot_root / "robot_server" / relative_path
        
        logger.info(f"📁 GeoJSON path from config: {self.geojson_path}")
    
    def download_map(
        self, 
        south: float, 
        west: float, 
        north: float, 
        east: float
    ) -> Dict[str, Any]:
        """
        Download map data using build_site_geojson.py script.
        
        Args:
            south, west, north, east: Bounding box coordinates
            
        Returns:
            Dict with status and message
        """
        try:
            # Validate coordinates
            if south >= north or west >= east:
                return {
                    "ok": False,
                    "message": "Invalid coordinates: south must be < north, west must be < east"
                }
            
            # Calculate area
            lat_span = north - south
            lon_span = east - west
            area_km2 = (lat_span * 111) * (lon_span * 111 * math.cos(math.radians((south+north)/2)))
            
            logger.info(f"📍 Downloading map area: ({south:.4f},{west:.4f}) → ({north:.4f},{east:.4f})")
            logger.info(f"📏 Area: ~{area_km2:.0f} km²")
            
            # Find script path
            script_path = Path(__file__).parent.parent.parent.parent / "scripts" / "build_site_geojson.py"
            
            if not script_path.exists():
                return {
                    "ok": False,
                    "message": f"Script not found: {script_path}"
                }
            
            # Ensure output directory exists
            self.geojson_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Run script as subprocess with output path argument
            coords = f"{south},{west},{north},{east}"
            logger.info(f"Running: python {script_path} \"{coords}\" --output \"{self.geojson_path}\"")
            
            result = subprocess.run(
                ["python3", str(script_path), coords, "--output", str(self.geojson_path)],
                capture_output=True,
                text=True,
                timeout=1800,  # 30 minutes timeout
                cwd=script_path.parent.parent  # Run from robot/ directory
            )
            
            if result.returncode != 0:
                logger.error(f"❌ Script failed: {result.stderr}")
                return {
                    "ok": False,
                    "message": f"Download failed: {result.stderr[:200]}"
                }
            
            # Log script output for debugging
            logger.info(f"Script stdout:\n{result.stdout}")
            if result.stderr:
                logger.warning(f"Script stderr:\n{result.stderr}")
            
            # Parse output to get stats
            output_lines = result.stdout.strip().split('\n')
            stats = {
                "area_km2": area_km2,
                "bounds": {
                    "south": south,
                    "west": west, 
                    "north": north,
                    "east": east
                }
            }
            
            # Extract stats from output
            for line in output_lines:
                if "Roads:" in line:
                    try:
                        stats["roads"] = int(line.split("Roads:")[1].strip().replace(",", ""))
                    except:
                        pass
                elif "Obstacles:" in line:
                    try:
                        stats["obstacles"] = int(line.split("Obstacles:")[1].strip().replace(",", ""))
                    except:
                        pass
                elif "File size:" in line:
                    try:
                        stats["file_size_mb"] = float(line.split("File size:")[1].strip().split("MB")[0].strip())
                    except:
                        pass
            
            logger.info(f"✅ Map downloaded successfully: {stats}")
            
            # CRITICAL: Give the filesystem time to sync
            import time
            time.sleep(0.5)
            
            # Use the path from config
            logger.info(f"Checking for file at: {self.geojson_path}")
            logger.info(f"File absolute path: {self.geojson_path.absolute()}")
            logger.info(f"File exists: {self.geojson_path.exists()}")
            
            if self.geojson_path.exists():
                file_size_bytes = self.geojson_path.stat().st_size
                file_size_mb = file_size_bytes / (1024 * 1024)
                logger.info(f"📊 File size: {file_size_bytes} bytes ({file_size_mb:.3f} MB)")
                
                # Parse GeoJSON to count features
                try:
                    with open(self.geojson_path, 'r') as f:
                        geojson = json.load(f)
                        feature_count = len(geojson.get('features', []))
                        logger.info(f"✅ Parsed GeoJSON: {feature_count} features")
                except Exception as e:
                    logger.error(f"Failed to parse GeoJSON: {e}")
                    feature_count = 0
                
                # Merge stats with file info (show KB if < 1 MB)
                if file_size_mb < 1.0:
                    size_display = f"{file_size_bytes / 1024:.1f} KB"
                else:
                    size_display = f"{file_size_mb:.1f} MB"
                
                result = {
                    "ok": True,
                    "file": str(self.geojson_path.name),
                    "path": str(self.geojson_path),
                    "size_mb": round(file_size_mb, 2) if file_size_mb >= 0.01 else file_size_mb,
                    "size_display": size_display,  # Human-readable size
                    "features": feature_count,
                    **stats
                }
                
                logger.info(f"📊 Final result: {result}")
                return result
            
            logger.error(f"❌ File not found at: {self.geojson_path}")
            return {
                "ok": False, 
                "message": f"File not created at expected location: {self.geojson_path}"
            }
            
        except subprocess.TimeoutExpired:
            logger.error("❌ Download timeout (30 minutes)")
            return {
                "ok": False,
                "message": "Download timeout - area too large or API unavailable"
            }
        except Exception as e:
            logger.error(f"❌ Download failed: {e}", exc_info=True)
            return {
                "ok": False,
                "message": f"Download error: {str(e)}"
            }