# robot_server/app/services/motor_service.py
# ... keep the existing imports and classes untouched ...
import logging
import time
import math
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, Union
from pydantic import BaseModel
from threading import Lock, Thread

from .motor_iface import MotorIface
from .motor_diktum import DiktumMotor
from .motor_raspbot import RaspbotMotor
from .motor_simulator import SimulatorMotor

logger = logging.getLogger(__name__)


def get_motor_service(app_state) -> "MotorService":
    """Factory for getting a singleton MotorService instance."""
    if not hasattr(app_state, "motor_service"):
        app_state.motor_service = MotorService()
        logger.info("motor.service.created", extra={"event": {
            "stage": "motion", "action": "service_create"
        }})
    return app_state.motor_service


class SimulatorPose(BaseModel):
    lat: float
    lon: float
    yaw: float
    timestamp: float

class MotionConfig(BaseModel):
    speed_mps: float
    max_yaw_rate: float
    orient_then_move: bool = True
    dead_zone: float = 0.12

class MotorService:
    """
    Facade for handling motor control.
    Delegates to specific driver implementations (simulator, raspbot, diktum).
    """
    def __init__(self):
        self._config_cache: Optional[Dict[str, Any]] = None
        self._config_cache_time: float = 0
        self._config_cache_ttl: float = 5.0
        self._driver: Optional[MotorIface] = None
        self._driver_type: Optional[str] = None
        self._last_frame: bytes | None = None
        self._keepalive_lock = Lock()
        self._keepalive_flag = False
        self._keepalive_thread: Thread | None = None
        self._keepalive_app_state = None

        logger.info(f"🤖 Robot type configured: {self.get_robot_type()}")

    # ---------- Config loading ----------
    def _load_config(self) -> Dict[str, Any]:
        now = time.time()
        if (self._config_cache is not None and
            now - self._config_cache_time < self._config_cache_ttl):
            return self._config_cache

        candidates = [
            Path("~/LARS/robot_server/config.toml").expanduser(),
            Path("config.toml"),
            Path(__file__).resolve().parents[2] / "config.toml",
        ]
        config: Dict[str, Any] = {}
        for cfg_path in candidates:
            logger.info(f"🔍 Trying config path: {cfg_path} (exists: {cfg_path.exists()})")
            if cfg_path.exists():
                try:
                    try:
                        import tomllib as toml_reader
                    except Exception:
                        import tomli as toml_reader
                    with cfg_path.open("rb") as f:
                        config = toml_reader.load(f) or {}
                        logger.info(f"✅ Loaded config from {cfg_path}")
                        logger.info(f"🗺️ Config sections: {list(config.keys())}")
                        if 'map' in config:
                            logger.info(f"📍 Map config: {config['map']}")
                        break
                except Exception as e:
                    logger.warning(f"❌ Failed to load config from {cfg_path}: {e}")

        if not config:
            logger.warning("❌ No config file found! Using defaults.")

        self._config_cache = config
        self._config_cache_time = now
        return config

    def get_robot_type(self) -> str:
        cfg = self._load_config()
        return (cfg.get("default") or {}).get("robot_type", "unknown")

    def _get_motion_config(self, cfg: Dict[str, Any]) -> MotionConfig:
        motion_section = cfg.get("motion", {})
        try:
            speed_mps = float(motion_section.get("speed_mps", 0.6))
        except (ValueError, TypeError):
            speed_mps = 0.6

        try:
            turn_speed_dps = float(motion_section.get("turn_speed_dps", 90.0))
            turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
            max_yaw_rate = turn_speed_dps * math.pi / 180.0
            logger.info(f"Turn speed: {turn_speed_dps}°/s = {max_yaw_rate} rad/s")
        except (ValueError, TypeError):
            max_yaw_rate = math.pi / 2.0

        try:
            orient_then_move = bool(motion_section.get("orient_then_move", True))
        except (ValueError, TypeError):
            orient_then_move = True

        try:
            dead_zone = float(motion_section.get("dead_zone", 0.12))
            dead_zone = max(0.0, min(0.4, dead_zone))
        except (ValueError, TypeError):
            dead_zone = 0.12

        return MotionConfig(
            speed_mps=speed_mps,
            max_yaw_rate=max_yaw_rate,
            orient_then_move=orient_then_move,
            dead_zone=dead_zone
        )

    # ---------- Driver factory ----------
    def _ensure_driver(self, app_state) -> Optional[MotorIface]:
        rtype = self.get_robot_type()

        # Return cached driver if already created for this type
        if self._driver and self._driver_type == rtype:
            return self._driver

        # (Re)create driver
        try:
            if rtype == "simulator":
                self._driver = SimulatorMotor()
            elif rtype == "diktum":
                self._driver = DiktumMotor()
            elif rtype == "raspbot":
                self._driver = RaspbotMotor()
            else:
                logger.warning("motor.factory", extra={"event": {
                    "stage": "motion", "action": "factory_unknown_type", "robot_type": rtype
                }})
                self._driver = None
                self._driver_type = None
                return None

            self._driver_type = rtype
            self._driver.connect(app_state)
            logger.info("motor.factory", extra={"event": {
                "stage": "motion", "action": "factory_bind", "robot_type": rtype, "driver": self._driver.name
            }})
            return self._driver
        except Exception as e:
            logger.error("motor.factory_error", extra={"event": {
                "stage": "motion", "action": "factory_error",
                "robot_type": rtype, "error": str(e)
            }}, exc_info=True)
            self._driver = None
            self._driver_type = None
            return None

    # ---------- Helpers ----------
    def _apply_deadzone(self, value: float, dead_zone: float) -> float:
        return 0.0 if abs(value) < dead_zone else value

    # ---------- Public API ----------
    def init_simulator_pose(self, app_state) -> bool:
        
        rtype = self.get_robot_type()
        if rtype != "simulator":
            return False
        driver = self._ensure_driver(app_state)
        return driver is not None and isinstance(driver, SimulatorMotor)

    def execute_joystick_command(
        self,
        app_state,
        throttle: Optional[float] = None,
        steer: Optional[float] = None,
        vx: Optional[float] = None,
        wz: Optional[float] = None
    ) -> Dict[str, Any]:
        rtype = self.get_robot_type()
        driver = self._ensure_driver(app_state)
        if not driver:
            logger.warning("motion.command.no_driver", extra={"event": {
                "stage": "motion", "action": "no_driver", "robot_type": rtype
            }})
            return {"ok": False, "mode": rtype, "error": "No driver available"}

        cfg = self._get_motion_config(self._load_config())

        if vx is not None or wz is not None:
            effective_vx = float(vx or 0.0)
            effective_wz = float(wz or 0.0)
        else:
            thr = self._apply_deadzone(float(throttle or 0.0), cfg.dead_zone)
            ste = self._apply_deadzone(float(steer or 0.0), cfg.dead_zone)
            if cfg.orient_then_move and throttle is None:
                effective_vx = cfg.speed_mps if abs(ste) > 0.0 else 0.0
                effective_wz = ste * cfg.max_yaw_rate
            else:
                effective_vx = thr * cfg.speed_mps
                effective_wz = ste * cfg.max_yaw_rate

        try:
            driver.command_velocity(effective_vx, effective_wz)
            if isinstance(driver, SimulatorMotor):
                pose = driver.get_pose()
                return {"ok": True, "mode": "simulator", "simulator": True, "pose": pose}
            return {"ok": True, "mode": rtype, "simulator": False}
        except Exception as e:
            logger.error("motion.command.error", extra={"event": {
                "stage": "motion", "action": "command_error",
                "driver": getattr(driver, "name", "?"),
                "error": str(e)
            }}, exc_info=True)
            return {"ok": False, "mode": rtype, "simulator": False, "error": str(e)}

    def get_current_pose(self, app_state) -> Optional[SimulatorPose]:
        rtype = self.get_robot_type()
        if rtype != "simulator":
            return None
        driver = self._ensure_driver(app_state)
        if not isinstance(driver, SimulatorMotor):
            return None
        pose = driver.get_pose()
        if not pose:
            return None
        try:
            return SimulatorPose(
                lat=float(pose["lat"]),
                lon=float(pose["lon"]),
                yaw=float(pose["yaw"]),
                timestamp=float(pose["t"])
            )
        except (KeyError, ValueError, TypeError):
            return None

    # ---------- Public API ----------
    def send_permission(self, app_state) -> Dict[str, Any]:
        """
        Send Dictum 'permission' control. Uses config.toml [diktum].command_bytes.permission.
        No-op / error for non-Diktum robot types.
        """
        rtype = self.get_robot_type()
        driver = self._ensure_driver(app_state)
        if not driver:
            return {"ok": False, "mode": rtype, "error": "No driver available"}
        if not isinstance(driver, DiktumMotor):
            return {"ok": False, "mode": rtype, "error": "Permission is available only for 'diktum' robot_type"}
        try:
            result = driver.send_permission(app_state)
            packet = getattr(driver, "get_last_packet", lambda: None)()
            if packet:
                with self._keepalive_lock:
                    self._last_frame = bytes(packet)
            self._ensure_keepalive(True, app_state)
            return result
        except Exception as e:
            logger.error("diktum.permission.error", extra={"event": {
                "stage": "motion", "action": "permission_error", "error": str(e)
            }}, exc_info=True)
            return {"ok": False, "mode": rtype, "error": str(e)}

    def send_starter(self, app_state) -> Dict[str, Any]:
        """
        Send Dictum 'starter' control. Uses config.toml [diktum].command_bytes.starter.
        No-op / error for non-Diktum robot types.
        """
        rtype = self.get_robot_type()
        driver = self._ensure_driver(app_state)
        if not driver:
            return {"ok": False, "mode": rtype, "error": "No driver available"}
        if not isinstance(driver, DiktumMotor):
            return {"ok": False, "mode": rtype, "error": "Starter is available only for 'diktum' robot_type"}
        try:
            result = driver.send_starter(app_state)
            packet = getattr(driver, "get_last_packet", lambda: None)()
            if packet:
                with self._keepalive_lock:
                    self._last_frame = bytes(packet)
            return result
        except Exception as e:
            logger.error("diktum.starter.error", extra={"event": {
                "stage": "motion", "action": "starter_error", "error": str(e)
            }}, exc_info=True)
            return {"ok": False, "mode": rtype, "error": str(e)}

    # ---------- Per-relay facade ----------
    def send_relay(self, app_state, relay: str, on: bool) -> Dict[str, Any]:
        """
        Flip a single relay bit and send a UART frame (computed from binary -> hex).
        Works only for 'diktum' robot_type.
        """
        rtype = self.get_robot_type()
        driver = self._ensure_driver(app_state)
        if not driver:
            return {"ok": False, "mode": rtype, "error": "No driver available"}
        if not isinstance(driver, DiktumMotor):
            return {"ok": False, "mode": rtype, "error": "Relays are available only for 'diktum' robot_type"}
        try:
            result = driver.set_relay(app_state, relay, bool(on))
            packet = getattr(driver, "get_last_packet", lambda: None)()
            if packet:
                with self._keepalive_lock:
                    self._last_frame = bytes(packet)
            if relay == "permission":
                self._ensure_keepalive(bool(on), app_state)
            elif relay == "stop":
                self._ensure_keepalive(False, app_state)
            return result
        except Exception as e:
            logger.error("diktum.relay.error", extra={"event": {
                "stage": "motion", "action": "relay_error", "relay": relay, "error": str(e)
            }}, exc_info=True)
            return {"ok": False, "mode": rtype, "relay": relay, "error": str(e)}

    def _keepalive_loop(self):
        while True:
            with self._keepalive_lock:
                if not self._keepalive_flag:
                    break
                frame = self._last_frame
                app_state = self._keepalive_app_state
            if frame and app_state is not None:
                self._write_frame(app_state, frame)
            time.sleep(0.079)

    def _ensure_keepalive(self, enabled: bool, app_state=None):
        with self._keepalive_lock:
            if enabled:
                if app_state is not None:
                    self._keepalive_app_state = app_state
                if not self._keepalive_flag:
                    self._keepalive_flag = True
                    self._keepalive_thread = Thread(target=self._keepalive_loop, daemon=True)
                    self._keepalive_thread.start()
            elif self._keepalive_flag:
                self._keepalive_flag = False
                self._keepalive_app_state = None
                self._last_frame = None
        if not enabled and self._keepalive_thread:
            self._keepalive_thread.join(timeout=1.0)
            self._keepalive_thread = None

    def _write_frame(self, app_state, frame: bytes) -> None:
        if not frame:
            return
        driver = self._ensure_driver(app_state)
        if not driver or not isinstance(driver, DiktumMotor):
            return
        try:
            driver.write_packet(app_state, frame)
        except Exception as exc:
            logger.error("diktum.keepalive.error", extra={"event": {
                "stage": "motion", "action": "keepalive_write",
                "driver": getattr(driver, "name", "?"), "error": str(exc)
            }}, exc_info=True)
