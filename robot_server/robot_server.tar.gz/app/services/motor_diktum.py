# robot_server/app/services/motor_diktum.py
import logging
from typing import Dict, Any, Optional
from pathlib import Path

from .motor_iface import MotorIface

log = logging.getLogger(__name__)

try:
    import tomllib as toml_reader   # py311+
except Exception:  # pragma: no cover
    import tomli as toml_reader     # py310 / backport

try:
    import serial  # pyserial
except Exception:  # pragma: no cover
    serial = None


class DiktumMotor(MotorIface):
    """
    Diktum motor driver with UART-based relay control.
    - Reuses app.state to persist the serial handle (no globals).
    - Reads all parameters from config.toml ([diktum] section).
    """
    name = "diktum"

    def __init__(self):
        self._connected = False
        self._cfg: Dict[str, Any] = {}

    # ---------- config ----------
    def _load_config(self) -> Dict[str, Any]:
        if self._cfg:
            return self._cfg

        candidates = [
            Path("~/LARS/robot_server/config.toml").expanduser(),
            Path("config.toml"),
            Path(__file__).resolve().parents[2] / "config.toml",
        ]
        cfg: Dict[str, Any] = {}
        for p in candidates:
            try:
                if p.exists():
                    with p.open("rb") as f:
                        cfg = toml_reader.load(f) or {}
                        break
            except Exception as e:
                log.warning(f"[diktum] failed to load config from {p}: {e}")

        self._cfg = cfg
        return cfg

    def _cfg_diktum(self) -> Dict[str, Any]:
        return (self._load_config().get("diktum") or {})

    # ---------- serial ----------
    def _ensure_serial(self, app_state):
        """
        Open and cache serial connection in app.state to avoid globals.
        """
        if getattr(app_state, "diktum_serial", None):
            return app_state.diktum_serial

        if serial is None:
            raise RuntimeError("pyserial is not installed. Install with: uv pip install pyserial")

        dcfg = self._cfg_diktum()
        device = dcfg.get("serial_device") or "/dev/ttyAMA0"
        baud = int(dcfg.get("baudrate", 115200))

        ser = serial.Serial(device, baud)
        app_state.diktum_serial = ser
        log.info("motor.connect", extra={"event": {
            "stage": "motion", "action": "serial_open",
            "driver": self.name, "device": device, "baud": baud
        }})
        return ser

    # ---------- helper: assemble and send 26-byte command ----------
    @staticmethod
    def _hex_to_bytes(hex_str: str) -> bytearray:
        # Accepts "AA BB CC ..." or "AABBCC..."
        cleaned = "".join(hex_str.split())
        return bytearray.fromhex(cleaned)

    def _build_command_with_control(self, control_hex: str) -> bytearray:
        dcfg = self._cfg_diktum()
        base_hex = (dcfg.get("base_command") or "").strip()
        if not base_hex:
            raise ValueError("[diktum] base_command is missing in config.toml")

        pkt = self._hex_to_bytes(base_hex)
        if len(pkt) < 26:
            raise ValueError(f"[diktum] base_command must be 26 bytes, got {len(pkt)}")

        try:
            control_val = int(control_hex, 16)  # e.g., "20" or "30"
        except Exception:
            raise ValueError(f"[diktum] invalid control hex: {control_hex}")

        # Replace the 9th byte (index 8) with the desired control byte.
        pkt[8] = control_val
        return pkt

    def _send_named_control(self, app_state, name: str) -> Dict[str, Any]:
        dcfg = self._cfg_diktum()
        mapping: Dict[str, str] = (dcfg.get("command_bytes") or {})
        if name not in mapping:
            raise ValueError(f"[diktum] command_bytes.{name} is missing in config.toml")

        control_hex = mapping[name]
        pkt = self._build_command_with_control(control_hex)
        ser = self._ensure_serial(app_state)

        n = ser.write(pkt)
        log.info("diktum.control", extra={"event": {
            "stage": "motion", "action": "uart_write",
            "driver": self.name, "command": name,
            "control_hex": control_hex, "bytes": n
        }})
        return {"ok": True, "driver": self.name, "command": name, "bytes_written": int(n)}

    # ---------- MotorIface ----------
    def connect(self, app_state) -> None:
        self._load_config()            # prime self._cfg
        self._ensure_serial(app_state) # open serial once
        self._connected = True
        log.info("motor.connect", extra={"event": {
            "stage": "motion", "action": "connect", "driver": self.name, "result": "ok"
        }})

    def set_throttle(self, value: float) -> None:
        # Dictum throttle is hydraulic—handled by speed/solenoid channels in the 26-byte frame.
        log.info("motor.throttle", extra={"event": {
            "stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)
        }})

    def set_steer(self, value: float) -> None:
        log.info("motor.steer", extra={"event": {
            "stage": "motion", "action": "steer", "driver": self.name, "value": float(value)
        }})

    def command_velocity(self, vx: float, wz: float) -> None:
        # Placeholder: your full 26-byte packer for speed/solenoids can be added here later.
        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity", "driver": self.name,
            "effective": {"vx": float(vx), "wz": float(wz)}
        }})

    def stop(self) -> None:
        log.info("motor.stop", extra={"event": {
            "stage": "motion", "action": "stop", "driver": self.name
        }})

    def shutdown(self) -> None:
        log.info("motor.shutdown", extra={"event": {
            "stage": "motion", "action": "shutdown", "driver": self.name
        }})

    # ---------- Public control helpers for MotorService ----------
    def send_permission(self, app_state) -> Dict[str, Any]:
        """Send ignition/permission (e.g., 0x20) defined in config.toml."""
        return self._send_named_control(app_state, "permission")

    def send_starter(self, app_state) -> Dict[str, Any]:
        """Send starter+ignition (e.g., 0x30) defined in config.toml."""
        return self._send_named_control(app_state, "starter")
