import struct
import serial
import time

# Формат структуры
FMT = "<IIBh6h"

def make_packet(TransiveMicrosCurrent, Number, BattensCondition, Speed, JoysrikPosition):
    if len(JoysrikPosition) != 6:
        raise ValueError("JoysrikPosition должен содержать ровно 6 значений")
    return struct.pack(FMT, TransiveMicrosCurrent, Number, BattensCondition, Speed, *JoysrikPosition)

def send_packet(JoysrikPosition, Speed=0, BattensCondition=1, Number=0):
    packet = make_packet(
        TransiveMicrosCurrent=int(time.time() * 1_000_000),
        Number=Number,
        BattensCondition=BattensCondition,
        Speed=Speed,
        JoysrikPosition=JoysrikPosition
    )

    # Открываем UART порт /dev/ttyAMA10
    with serial.Serial(
        port="/dev/ttyAMA10",
        baudrate=115200,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=1
    ) as ser:
        ser.write(packet)
        ser.flush()
        print(f"Пакет отправлен: {packet.hex()}")
