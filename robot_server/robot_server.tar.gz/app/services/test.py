import serial
import time
import struct

def make_control_packet(
    number: int,
    buttons: int,
    engine_speed: int = 0,
    forward_back: int = 0,
    turn: int = 0,
    boom: int = 0,
    bucket: int = 0,
    attachment: int = 0,
    reserved: int = 0
) -> bytes:
    current_time = int(time.time() * 1_000_000) & 0xFFFFFFFF
    packet_data = struct.pack(
        "<IIBh6h",
        current_time,
        number,
        buttons,
        engine_speed,
        forward_back,
        turn,
        boom,
        bucket,
        attachment,
        reserved
    )
    return packet_data + b'\r\n'

def send_command(ser, command, packet_number):
    if command == "1":
        buttons = 0x20  # Разрешение работы
    elif command == "2":
        buttons = 0x30  # Включение стартера
    elif command == "3":
        buttons = 0x1C  # Вторая скорость
    elif command == "4":
        buttons = 0x1E  # Звуковой сигнал
    else:
        print("Неизвестная команда. Доступные команды: '1 - разрешение работы', '2 - включение стартера', '3 - вторая скорость', '4 - звуковой сигнал'")
        return packet_number

    packet = make_control_packet(
        number=packet_number,
        buttons=buttons
    )
    ser.write(packet)
    print(f"Sent packet (number={packet_number}): {packet.hex()}")
    return packet_number + 1

def read_response(ser, timeout=1.0):
    start_time = time.time()
    while time.time() - start_time < timeout:
        if ser.in_waiting > 0:
            received_data = ser.readline().decode('utf-8', errors='ignore').strip()
            if received_data:
                print(f"Received: {received_data}")
                return
        time.sleep(0.1)  # Небольшая пауза для снижения нагрузки
    print("No response received within 1 second.")

def main():
    try:
        ser = serial.Serial(
            port='/dev/ttyAMA0',
            baudrate=115200,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=1
        )
        print("UART opened successfully on /dev/ttyAMA0")
        print("Введите команду ('1 - разрешение работы', '2 - включение стартера', '3 - вторая скорость', '4 - звуковой сигнал') или 'выход' для завершения:")
    except serial.SerialException as e:
        print(f"Failed to open UART: {e}")
        return

    packet_number = 1

    try:
        while True:
            # Чтение входящих данных перед вводом команды
            read_response(ser)

            # Обработка команды от пользователя
            command = input("> ").strip()
            if command.lower() == "выход":
                break
            packet_number = send_command(ser, command, packet_number)
            time.sleep(1.0)  # Задержка 1 секунда перед чтением ответа
            read_response(ser)  # Чтение ответа после отправки

    except KeyboardInterrupt:
        print("\nВыход по Ctrl+C")
    finally:
        ser.close()
        print("UART closed, program terminated")

if __name__ == "__main__":
    main()