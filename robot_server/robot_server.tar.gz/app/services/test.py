from gpiozero import LED
import logging

log = logging.getLogger(__name__)

# Глобальный объект LED
_led = None

def _get_led():
    """Получить объект LED, создать если не существует"""
    global _led
    if _led is None:
        try:
            _led = LED(17)
            log.info("LED на GPIO 17 инициализирован")
        except Exception as e:
            log.error(f"Ошибка инициализации LED: {e}")
            raise
    return _led

def set_led_state(state: int):
    """Установить состояние LED (0 = выкл, 1 = вкл)"""
    if state not in (0, 1):
        raise ValueError("Invalid state: must be 0 or 1")
    
    try:
        led = _get_led()
        
        if state == 1:
            led.on()
            log.info("LED включен")
        else:
            led.off()
            log.info("LED выключен")
            
    except Exception as e:
        log.error(f"Ошибка управления LED: {e}")
        raise

def cleanup_led():
    """Очистка ресурсов LED"""
    global _led
    if _led is not None:
        try:
            _led.close()
            _led = None
            log.info("LED ресурсы очищены")
        except Exception as e:
            log.error(f"Ошибка очистки LED: {e}")