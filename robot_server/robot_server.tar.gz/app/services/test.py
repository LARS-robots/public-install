from gpiozero import LED

def set_led_state(state: int):
    if state not in (0, 1):
        raise ValueError("Invalid state: must be 0 or 1")
    
    led = LED(17)
    
    if state == 1:
        led.on()
    else:
        led.off()