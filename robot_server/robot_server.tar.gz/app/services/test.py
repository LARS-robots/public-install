from gpiozero import LED

def set_led_state(state: int):
    led = LED(17)  # GPIO17 (физический пин 11)

    if state == 1:
        led.on()
    else:
        led.off()
