import struct
import serial
import time

# ---------------- Настройки протокола ----------------
FMT = "<IIBh6h"  # <IIBh6h = little-endian, uint32, uint32, uint8, int16, 6*int16

def make_packet(TransiveMicrosCurrent, Number, BattensCondition, Speed, JoysrikPosition):
    if len(JoysrikPosition) != 6:
        raise ValueError("JoysrikPosition должен содержать ровно 6 значений")
    return struct.pack(FMT, TransiveMicrosCurrent, Number, BattensCondition, Speed, *JoysrikPosition)

def send_packet(JoysrikPosition, Speed=0, BattensCondition=1, Number=0):
    """Отправка пакета на UART /dev/ttyAMA10"""
    packet = make_packet(
        TransiveMicrosCurrent=int(time.time() * 1_000_000),
        Number=Number,
        BattensCondition=BattensCondition,
        Speed=Speed,
        JoysrikPosition=JoysrikPosition
    )
    with serial.Serial(
        port="/dev/ttyAMA10",
        baudrate=115200,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=1
    ) as ser:
        ser.write(packet)
        ser.flush()
        print(f"Пакет отправлен: {packet.hex()}")

# ---------------- Плавное движение ----------------
def smooth_move(target_values, duration=2.0, steps=20, Number_start=0):
    """
    target_values: список из 6 значений JoysrikPosition [движение, поворот, стрела, ковш, щётка, доп]
    duration: общее время движения (сек)
    steps: количество шагов интерполяции
    """
    current_values = [0] * 6
    step_time = duration / steps
    step_delta = [(t - c)/steps for t, c in zip(target_values, current_values)]
    Number = Number_start

    for i in range(steps):
        current_values = [c + delta for c, delta in zip(current_values, step_delta)]
        send_packet([int(v) for v in current_values], Speed=int(max(abs(v) for v in current_values)), Number=Number)
        Number += 1
        time.sleep(step_time)

    # Постепенно остановить
    for i in range(steps):
        current_values = [c - delta for c, delta in zip(current_values, step_delta)]
        send_packet([int(v) for v in current_values], Speed=int(max(abs(v) for v in current_values)), Number=Number)
        Number += 1
        time.sleep(step_time)

# ---------------- Удобные функции для движения ----------------
def move_forward(value=1000, Number=0):
    smooth_move([value, 0, 0, 0, 0, 0], Number_start=Number)

def turn(value=1000, Number=0):
    smooth_move([0, value, 0, 0, 0, 0], Number_start=Number)

def move_arm(value=1000, Number=0):
    smooth_move([0, 0, value, 0, 0, 0], Number_start=Number)

def tilt_bucket(value=1000, Number=0):
    smooth_move([0, 0, 0, value, 0, 0], Number_start=Number)

def brush_speed(value=1000, Number=0):
    smooth_move([0, 0, 0, 0, value, 0], Number_start=Number)

# ---------------- Пример использования ----------------
if __name__ == "__main__":
    move_forward(1000)
    time.sleep(1)
    turn(800)
    time.sleep(1)
    move_arm(500)
    time.sleep(1)
    tilt_bucket(600)
    time.sleep(1)
    brush_speed(1500)
