# services/virtual_gimbal.py
from dataclasses import dataclass
import math

def _wrap_pi(a: float) -> float:
    """ Wrap angle to [-pi, pi]. """
    return (a + math.pi) % (2.0 * math.pi) - math.pi

def _angle_err(a: float, b: float) -> float:
    """ Compute the shortest difference between two angles. """
    return _wrap_pi(a - b)

@dataclass
class AxisState:
    """State of a single axis of the virtual gimbal."""
    s: float = 0.0
    v: float = 0.0
    lock: bool = True
    lock_counter: int = 0

@dataclass
class VGParams:
    """Parameters for a single axis of the virtual gimbal."""
    omega: float = 6.0
    zeta:  float = 1.0
    vmax: float = 0.0
    amax: float = 0.0
    enter: float = 0.0
    exit:  float = 0.0
    lock_hold_frames: int = 3

class VirtualGimbal:
    def __init__(self, p_xy: VGParams, p_th: VGParams):
        """ Initialize the virtual gimbal with parameters for XY and TH axes. """
        self.x = AxisState()
        self.y = AxisState()
        self.th = AxisState()
        self.px = p_xy
        self.py = VGParams(**p_xy.__dict__)
        self.pth = p_th

    @staticmethod
    def _deadzone(e: float, st: AxisState, p: VGParams):
        """ Apply deadzone logic to the error. """
        ae = abs(e)
        if st.lock:
            if ae <= p.exit:
                st.lock_counter += 1
                return 0.0, True
            else:
                st.lock = False
                st.lock_counter = 0
        else:
            if ae <= p.enter:
                return 0.0, False
        
        eff = math.copysign(max(0.0, ae - p.exit), e)
        st.lock_counter = 0
        return eff, False

    @staticmethod
    def _step(st: AxisState, p: VGParams, e_eff: float, dt: float):
        """ Update the state of the axis based on the effective error and time step. """
        acc_cmd = p.omega * p.omega * e_eff - 2.0 * p.zeta * p.omega * st.v
        if p.amax and p.amax > 0.0:
            acc_cmd = max(-p.amax, min(p.amax, acc_cmd))
        st.v += acc_cmd * dt
        if p.vmax and p.vmax > 0.0:
            st.v = max(-p.vmax, min(p.vmax, st.v))
        st.s += st.v * dt

    def update(self, traj_x: float, traj_y: float, traj_th: float, dt: float):
        """ Update the virtual gimbal state based on the target trajectory and time step. """
        ex  = traj_x - self.x.s
        ey  = traj_y - self.y.s
        eth = _angle_err(traj_th, self.th.s)

        ex_eff, x_locked  = self._deadzone(ex,  self.x,  self.px)
        ey_eff, y_locked  = self._deadzone(ey,  self.y,  self.py)
        eth_eff, th_locked = self._deadzone(eth, self.th, self.pth)

        self._step(self.x,  self.px,  ex_eff,  dt)
        self._step(self.y,  self.py,  ey_eff,  dt)
        self._step(self.th, self.pth, eth_eff, dt)

        if x_locked  and self.x.lock_counter  >= self.px.lock_hold_frames:  self.x.lock  = True
        if y_locked  and self.y.lock_counter  >= self.py.lock_hold_frames:  self.y.lock  = True
        if th_locked and self.th.lock_counter >= self.pth.lock_hold_frames: self.th.lock = True

        diff_x  = self.x.s  - traj_x
        diff_y  = self.y.s  - traj_y
        diff_th = _wrap_pi(self.th.s - traj_th)
        return diff_x, diff_y, diff_th
