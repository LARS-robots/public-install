import serial
import time

# Открываем UART
ser = serial.Serial('/dev/ttyAMA0', 115200, timeout=1)

print("Raspberry Pi is ready. Please enter a message:")

# HEX-последовательность для отправки
hex_msg = "22 C8 30 00 05 00 00 00 20 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0D 0A"
data_to_send = bytes.fromhex(hex_msg)

# Отправляем один раз при старте
ser.write(data_to_send)
print("[TX] ->", hex_msg)

received_message = ""

try:
    while True:
        if ser.in_waiting > 0:
            incoming_char = ser.read().decode('utf-8', errors='ignore')
            
            if incoming_char == '\n':
                print("[RX] <-", received_message)
                received_message = ""  # очистка буфера
            else:
                received_message += incoming_char

except KeyboardInterrupt:
    print("\nВыход по Ctrl+C")
finally:
    ser.close()
