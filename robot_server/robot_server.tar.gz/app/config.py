from __future__ import annotations
import os
import pathlib
import tomllib  # stdlib в Python 3.11+
from pydantic import BaseModel, Field
from typing import Literal


# Конфигурация приложения
class AppConfig(BaseModel):
    app_name: str = Field(default="Raspbot API")
    version: str = Field(default="0.0.1")
    robot_type: str = "pc"
    port: int = 8000

    @property
    def enable_test_api(self) -> bool:
        # test_api доступен только для диктума
        return self.robot_type == "diktum"


def _load_toml() -> dict:
    """Читает config/raspbot.toml и мержит default + env.*"""
    root = pathlib.Path(__file__).resolve().parents[2]  # корень проекта
    cfg_path = root / "config" / "raspbot.toml"
    data: dict = {}
    if cfg_path.exists():
        with open(cfg_path, "rb") as f:
            raw = tomllib.load(f)
        data.update(raw.get("default", {}))
        env = os.getenv("APP_ENV", "dev").lower()
        data.update(raw.get("env", {}).get(env, {}))
    return data


def load_config() -> AppConfig:
    data = _load_toml()
    return AppConfig(**data)


# Единый экземпляр настроек
settings = load_config()