# app/telemetry.py
from __future__ import annotations

import asyncio
from collections import deque
from typing import Any, Dict, List, Set


class LogBus:
    """
    Лёгкий внутрипроцессный pub/sub для live-событий логов.
    - Кольцевой буфер для "снепшота при подключении"
    - Подписчики получают asyncio.Queue
    - Умеет безопасно публиковать из фоновых потоков (publish_threadsafe)
    """
    def __init__(self, ring: int = 10_000, sub_queue_max: int = 2000) -> None:
        self._subs: Set[asyncio.Queue] = set()
        self._ring: deque = deque(maxlen=ring)
        self._lock = asyncio.Lock()
        self._sub_queue_max = sub_queue_max
        self.loop: asyncio.AbstractEventLoop | None = None  # привяжем в main.py на старте

    async def publish(self, event: Dict[str, Any]) -> None:
        """Публикация из корутины (в главном loop)."""
        async with self._lock:
            self._ring.append(event)
            # Разослать подписчикам (best effort, без блокировок)
            for q in list(self._subs):
                if q.qsize() < self._sub_queue_max:
                    try:
                        q.put_nowait(event)
                    except Exception:
                        pass

    def publish_threadsafe(self, event: Dict[str, Any]) -> None:
        """
        Потокобезопасная публикация из worker-потоков.
        Прокидывает корутину publish(...) в привязанный event loop.
        """
        if self.loop is None:
            return
        try:
            asyncio.run_coroutine_threadsafe(self.publish(event), self.loop)
        except Exception:
            pass

    async def subscribe(self) -> asyncio.Queue:
        """Создать подписку: вернём очередь событий для читателя (WS)."""
        q: asyncio.Queue = asyncio.Queue(maxsize=self._sub_queue_max)
        async with self._lock:
            self._subs.add(q)
        return q

    async def unsubscribe(self, q: asyncio.Queue) -> None:
        """Отписаться и убрать очередь из списка подписчиков."""
        async with self._lock:
            self._subs.discard(q)

    def snapshot(self) -> List[Dict[str, Any]]:
        """Вернуть копию последних N событий из кольцевого буфера."""
        return list(self._ring)

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Привязать главный event loop (вызовем на старте FastAPI)."""
        self.loop = loop


# Глобальная шина
logbus = LogBus()
