from fastapi import FastAPI
from .routers import admin, camera, motion, webrtc, wifi_api, wifi_ws
from fastapi.staticfiles import StaticFiles

import logging

#logging.basicConfig(
#    level=logging.DEBUG,               # DEBUG для всего
#    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
#)

tags_metadata = [
    {"name": "Admin", "description": "Управление подключением"},
    {"name": "Camera", "description": "Операции с камерой"},
    {"name": "Motion", "description": "Движение робота"},
    {"name": "WebRTC", "description": 
        ("Обработка и трансляция видео"
        "Для тестирования видео откройте [HTML-клиент ↗](/static/webrtc_client.html)."
        ),
    },
]

app = FastAPI(
    title="Raspbot API",
    version="0.0.1",
    description="Управление камерой и движением робота ЛАРС",
    openapi_tags=tags_metadata,
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.include_router(admin.router)
app.include_router(camera.router)
app.include_router(motion.router)
app.include_router(webrtc.router)
app.include_router(wifi_api.app)
app.include_router(wifi_ws.router)