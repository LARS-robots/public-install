import os
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .config import settings
from .routers import admin, camera, motion, webrtc, wifi_api, wifi_ws, logs
from .services.wifi_manager import WifiManager
from .logging_setup import setup_logging
from .telemetry import logbus


# ---- загрузка конфигурации (включая [logging]) ----
def _load_cfg():
    candidates = [
        Path("~/LARS/robot_server/config.toml").expanduser(),
        Path("config.toml"),
        Path(__file__).resolve().parent / "config.toml",
    ]
    for cfg_path in candidates:
        if cfg_path.exists():
            try:
                try:
                    import tomllib as toml_reader  # Py 3.11+
                except Exception:
                    import tomli as toml_reader     # fallback
                with cfg_path.open("rb") as f:
                    return toml_reader.load(f) or {}
            except Exception:
                pass
    return {}

_cfg = _load_cfg()
_log = (_cfg.get("logging") or {})

# ---- единый пайплайн логирования включаем рано ----
setup_logging(
    level=logging.INFO,
    live_dir        = _log.get("live_dir", "/var/log/lars/live"),
    archive_dir     = _log.get("archive_dir", "/var/log/lars/archive"),
    segment_size_mb = int(_log.get("segment_size_mb", 64)),
    segment_max_sec = int(_log.get("segment_max_sec", 1800)),
    zstd_level      = int(_log.get("zstd_level", 9)),
    max_total_bytes = _log.get("max_total_bytes", "8GiB"),
    max_age_days    = int(_log.get("max_age_days", 14)),
)

# ---- lifespan: привязываем event loop к pub/sub (вместо @app.on_event) ----
@asynccontextmanager
async def lifespan(app: FastAPI):
    import asyncio
    logbus.bind_loop(asyncio.get_running_loop())
    yield
    # при необходимости тут можно освободить ресурсы
    # (например, logbus.bind_loop(None) или закрыть фоновые задачи)


tags_metadata = [
    {"name": "Admin", "description": "Управление подключением"},
    {"name": "Camera", "description": "Операции с камерой"},
    {"name": "Motion", "description": "Движение робота"},
    {"name": "WebRTC", "description":
        ("Обработка и трансляция видео. "
         "Для тестирования видео откройте [HTML-клиент ↗](/static/webrtc_client.html).")
    },
    {"name": "WiFi", "description": "Настройка WiFi через API и WebSocket"},
    {"name": "admin", "description":
        ("Для просмотра логов откройте [HTML-клиент ↗](/admin/logs).")
    },    
]

app = FastAPI(
    title="Raspbot API",
    version="0.0.1",
    description="Управление камерой и движением робота ЛАРС",
    openapi_tags=tags_metadata,
    lifespan=lifespan,
)

# DI: общий WifiManager
app.state.wifi_manager = WifiManager()

# Static files
current_dir = os.path.dirname(os.path.abspath(__file__))
static_path = os.path.join(current_dir, "static")
app.mount("/static", StaticFiles(directory=static_path), name="static")

# Routers
app.include_router(admin.router)
app.include_router(camera.router)
app.include_router(motion.router)
app.include_router(webrtc.router)
app.include_router(wifi_api.app)
app.include_router(wifi_ws.router)
app.include_router(logs.router)

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
