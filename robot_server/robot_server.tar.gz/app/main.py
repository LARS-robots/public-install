import asyncio
import time
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from .routers import admin, camera, motion, telemetry_router, webrtc, wifi_api, wifi_ws, logs, route_routers
from .services.wifi_manager import WifiManager
from .services.robot_service import get_robot_service
from .logging_setup import setup_logging, start_observers
from .telemetry import logbus

logger = logging.getLogger(__name__)

# ---- Load configuration (including [logging]) ----
def _load_cfg():
    candidates = [
        Path("~/LARS/robot_server/config.toml").expanduser(),
        Path("config.toml"),
        Path(__file__).resolve().parent / "config.toml",
    ]
    for cfg_path in candidates:
        if cfg_path.exists():
            try:
                try:
                    import tomllib as toml_reader  # Py 3.11+
                except Exception:
                    import tomli as toml_reader     # fallback
                with cfg_path.open("rb") as f:
                    return toml_reader.load(f) or {}
            except Exception:
                pass
    return {}

_cfg = _load_cfg()
_log = (_cfg.get("logging") or {})

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    logbus.bind_loop(asyncio.get_running_loop())
    
    # Start log observers
    interval_s = 10
    logging.getLogger("startup").info(f"Starting observers with interval {interval_s}s")
    start_observers(asyncio.get_running_loop(), interval_s=interval_s)
    
    # Start navigation tick task
    async def navigation_tick_loop():
        """Background task for autonomous navigation - runs at ~12Hz"""
        while True:
            try:
                robot = get_robot_service(app.state)
                robot.tick_navigation()
            except Exception as e:
                logger.error(f"❌ Navigation tick error: {e}", exc_info=True)
            await asyncio.sleep(0.08)  # ~12Hz
    
    tick_task = asyncio.create_task(navigation_tick_loop())
    logger.info("✅ Navigation tick loop started")
    
    yield
    
    # Cleanup
    logger.info("🛑 Shutting down navigation tick loop")
    tick_task.cancel()
    try:
        await tick_task
    except asyncio.CancelledError:
        pass

def create_app() -> FastAPI:
    # Setup logging with config parameters (CRITICAL: must be called before creating app)
    setup_logging(
        level=logging.INFO,
        live_dir        = _log.get("live_dir", "/var/log/lars/live"),
        archive_dir     = _log.get("archive_dir", "/var/log/lars/archive"),
        segment_size_mb = int(_log.get("segment_size_mb", 64)),
        segment_max_sec = int(_log.get("segment_max_sec", 1800)),
        zstd_level      = int(_log.get("zstd_level", 9)),
        max_total_bytes = _log.get("max_total_bytes", "8GiB"),
        max_age_days    = int(_log.get("max_age_days", 14)),
    )

    tags_metadata = [
        {"name": "Admin", "description": "Управление подключением"},
        {"name": "Camera", "description": "Операции с камерой"},
        {"name": "motion", "description": "Движение робота"},
        {"name": "telemetry", "description": "Телеметрия и навигация робота"},
        {"name": "route", "description": "Планирование и следование маршрутам"},
        {"name": "WebRTC", "description":
            ("Обработка и трансляция видео. "
             "Для тестирования видео откройте [HTML-клиент ↗](/static/webrtc_client.html).")
        },
        {"name": "WiFi", "description": "Настройка WiFi через API и WebSocket"},
        {"name": "Logs", "description":
            ("Для просмотра логов откройте [HTML-клиент ↗](/admin/logs).")
        },    
    ]
    
    app = FastAPI(
        title="LARS Robot Server",
        version="1.0.0",
        description="Управление камерой, движением и навигацией робота ЛАРС",
        lifespan=lifespan,
        openapi_tags=tags_metadata
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Initialize app state
    app.state.wifi_manager = WifiManager()
    app.state.sim_pose = None
    app.state.motion_cfg = None
    app.state.route_state = None
    app.state.manual_override_until = 0.0
    
    # Access logging middleware (CRITICAL: logs all HTTP requests)
    @app.middleware("http")
    async def access_log_mw(request: Request, call_next):
        t0 = time.perf_counter()
        resp = await call_next(request)
        dt_ms = int((time.perf_counter() - t0) * 1000)
        logging.getLogger("http").info(
            "request",
            extra={"event": {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
                "src": "http",
                "evt": "request",
                "method": request.method,
                "path": request.url.path,
                "status": resp.status_code,
                "ms": dt_ms
            }},
        )
        return resp
    
    # Register routers
    app.include_router(admin.router)
    app.include_router(camera.router)
    app.include_router(motion.router)
    app.include_router(telemetry_router.router)
    app.include_router(webrtc.router)
    app.include_router(wifi_api.router)
    app.include_router(wifi_ws.router)
    app.include_router(logs.router)
    app.include_router(route_routers.router)
    
    # Mount static files
    static_path = Path(__file__).parent / "static"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
        logger.info(f"✅ Static files mounted: {static_path}")
    else:
        logger.warning(f"⚠️ Static directory not found: {static_path}")
    
    return app

app = create_app()

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)