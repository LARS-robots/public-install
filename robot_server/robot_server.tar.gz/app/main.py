# import os
# import sys
# from fastapi import FastAPI
# from fastapi.staticfiles import StaticFiles
#
# # Add the project root to Python path for proper imports
# current_dir = os.path.dirname(os.path.abspath(__file__))
# project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
# if project_root not in sys.path:
#     sys.path.insert(0, project_root)
#
# # Now import the routers - try different import paths
# try:
#     # When running as installed package
#     from robot.robot_server.app.routers import admin, camera, motion, webrtc, wifi_api, wifi_ws
# except ImportError:
#     try:
#         # When running from robot_server directory
#         from app.routers import admin, camera, motion, webrtc, wifi_api, wifi_ws
#     except ImportError:
#         # When running directly from app directory
#         from routers import admin, camera, motion, webrtc, wifi_api, wifi_ws
import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .routers import admin, camera, motion, webrtc, wifi_api, wifi_ws

app = FastAPI(
    title="Raspbot API",
    version="0.0.1",
    description="Управление камерой и движением робота ЛАРС",
)

# Get absolute path to the static folder
current_dir = os.path.dirname(os.path.abspath(__file__))
static_path = os.path.join(current_dir, "static")

app.mount("/static", StaticFiles(directory=static_path), name="static")

app.include_router(admin.router)
app.include_router(camera.router)
app.include_router(motion.router)
app.include_router(webrtc.router)
app.include_router(wifi_api.app)
app.include_router(wifi_ws.router)

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)