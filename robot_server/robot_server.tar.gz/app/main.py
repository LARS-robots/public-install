import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .routers import admin, camera, motion, webrtc, wifi_api, wifi_ws

app = FastAPI(
    title="Raspbot API",
    version="0.0.1",
    description="Управление камерой и движением робота ЛАРС",
)

# Get absolute path to the static folder
current_dir = os.path.dirname(os.path.abspath(__file__))
static_path = os.path.join(current_dir, "static")

app.mount("/static", StaticFiles(directory=static_path), name="static")

app.include_router(admin.router)
app.include_router(camera.router)
app.include_router(motion.router)
app.include_router(webrtc.router)
app.include_router(wifi_api.app)
app.include_router(wifi_ws.router)

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
