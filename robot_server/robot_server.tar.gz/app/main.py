import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .routers import admin, camera, motion, webrtc, wifi_api, wifi_ws, test_api

tags_metadata = [
    {"name": "Admin", "description": "Управление подключением"},
    {"name": "Camera", "description": "Операции с камерой"},
    {"name": "Motion", "description": "Движение робота"},
    {"name": "WebRTC", "description":
        ("Обработка и трансляция видео"
        "Для тестирования видео откройте [HTML-клиент ↗](/static/webrtc_client.html)."
        ),
    },
]
app = FastAPI(
    title="Raspbot API",
    version="0.0.1",
    description="Управление камерой и движением робота ЛАРС",
    openapi_tags=tags_metadata,
)

# Get absolute path to the static folder
current_dir = os.path.dirname(os.path.abspath(__file__))
static_path = os.path.join(current_dir, "static")

app.mount("/static", StaticFiles(directory=static_path), name="static")

app.include_router(admin.router)
app.include_router(camera.router)
app.include_router(motion.router)
app.include_router(webrtc.router)
app.include_router(wifi_api.app)
app.include_router(wifi_ws.router)
app.include_router(test_api.router)

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)