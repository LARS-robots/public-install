# app/logging_setup.py
from __future__ import annotations

import logging
import sys
import time
import os
import threading
from pathlib import Path

# Требуются зависимости:
#   pip install msgpack zstandard
import msgpack
try:
    import zstandard as zstd
except Exception:
    zstd = None  # позволим работать без компрессии (dev-окружение)


def record_to_event(record: logging.LogRecord) -> dict:
    """
    Преобразуем LogRecord в структурное событие.
    Если лог вызывали как log.info(..., extra={"event": {...}}), берём этот dict за основу.
    """
    ev = getattr(record, "event", None)
    if isinstance(ev, dict):
        out = ev.copy()
    else:
        out = {"msg": record.getMessage()}
    out.setdefault("logger", record.name)
    out.setdefault("level", record.levelname)
    out.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)))
    return out


class MsgpackZstdSegmentHandler(logging.Handler):
    """
    Основное хранилище логов: бинарный поток MessagePack с ротацией.
    Текущий сегмент хранится нежатым (для live-вьюера), закрытые сегменты — сжимаются в .zst.
    После каждой компрессии запускается "reaper" (лимиты по объёму/возрасту).
    """
    def __init__(
        self,
        live_dir: str = "/var/log/lars/live",
        archive_dir: str = "/var/log/lars/archive",
        segment_size_mb: int = 64,
        segment_max_sec: int = 1800,
        zstd_level: int = 9,
        max_total_bytes: int | str = 8_589_934_592,  # 8 GiB
        max_age_days: int = 14,
    ) -> None:
        super().__init__()
        self.live_dir = Path(live_dir); self.live_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir = Path(archive_dir); self.archive_dir.mkdir(parents=True, exist_ok=True)
        self.seg_bytes = int(segment_size_mb) * 1024 * 1024
        self.seg_secs  = int(segment_max_sec)
        self.zstd_level = int(zstd_level)
        self.max_total_bytes = self._parse_size(max_total_bytes)
        self.max_age_days = int(max_age_days)

        self.cur_path = self.live_dir / "robot-current.msgp"
        self._f = open(self.cur_path, "ab", buffering=0)
        self._opened_at = time.time()
        self._bytes = self._f.tell()
        self._lock = threading.Lock()

    @staticmethod
    def _parse_size(v):
        if isinstance(v, int):
            return v
        s = str(v).strip().lower().replace(" ", "")
        mul = 1
        if s.endswith(("k", "kb")): mul, s = 1024, s.rstrip("kb").rstrip("k")
        elif s.endswith(("m", "mb")): mul, s = 1024**2, s.rstrip("mb").rstrip("m")
        elif s.endswith(("g", "gb")): mul, s = 1024**3, s.rstrip("gb").rstrip("g")
        elif s.endswith(("t", "tb")): mul, s = 1024**4, s.rstrip("tb").rstrip("t")
        elif s.endswith("kib"): mul, s = 1024, s[:-3]
        elif s.endswith("mib"): mul, s = 1024**2, s[:-3]
        elif s.endswith("gib"): mul, s = 1024**3, s[:-3]
        elif s.endswith("tib"): mul, s = 1024**4, s[:-3]
        try:
            return int(float(s) * mul)
        except Exception:
            return 8_589_934_592  # дефолт 8 GiB

    def emit(self, record: logging.LogRecord) -> None:
        try:
            event = record_to_event(record)
            data = msgpack.packb(event, use_bin_type=True)
            with self._lock:
                self._f.write(data)
                self._bytes += len(data)
                if self._need_rotate():
                    self._rotate_async()
        except Exception as e:
            try:
                sys.stderr.write(f"[logging_setup] emit error: {e}\n")
            except Exception:
                pass  # не роняем приложение из-за логгера

    def _need_rotate(self) -> bool:
        return (self._bytes >= self.seg_bytes) or ((time.time() - self._opened_at) >= self.seg_secs)

    def _rotate_async(self) -> None:
        # закрыть текущий
        try:
            self._f.flush()
            self._f.close()
        except Exception:
            pass

        ts = time.strftime("%Y%m%d-%H%M%S", time.localtime(self._opened_at))
        final = self.live_dir / f"robot-{ts}.msgp"
        os.replace(self.cur_path, final)

        # открыть новый
        self._f = open(self.cur_path, "ab", buffering=0)
        self._opened_at = time.time()
        self._bytes = 0

        # компрессия в фоне (если есть zstd)
        if zstd is not None:
            t = threading.Thread(target=self._compress_then_delete, args=(final,), daemon=True)
            t.start()

    def _compress_then_delete(self, src: Path) -> None:
        try:
            dst = self.archive_dir / (src.name + ".zst")
            c = zstd.ZstdCompressor(level=self.zstd_level) if zstd else None
            if c is not None:
                with open(src, "rb") as fi, open(dst, "wb") as fo:
                    c.copy_stream(fi, fo)
        except Exception as e:
            try:
                sys.stderr.write(f"[logging_setup] compress error: {e}\n")
            except Exception:
                pass
            return
        # удаляем исходный сегмент после успешной компрессии
        try:
            src.unlink()
        except Exception:
            pass
        # применяем ретеншн-правила
        try:
            self._reap()
        except Exception:
            pass

    def _reap(self) -> None:
        """
        Лимиты по возрасту (max_age_days) и общему объёму (max_total_bytes) в archive_dir.
        Удаляем самые старые сегменты.
        """
        import time as _t
        files = list(self.archive_dir.glob("robot-*.msgp.zst")) + list(self.archive_dir.glob("robot-*.msgp"))
        files.sort(key=lambda p: p.stat().st_mtime)

        # по возрасту
        cutoff = _t.time() - self.max_age_days * 86400
        for f in files:
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink(missing_ok=True)
            except FileNotFoundError:
                pass

        # по общему размеру
        files = list(self.archive_dir.glob("robot-*.msgp.zst")) + list(self.archive_dir.glob("robot-*.msgp"))
        files.sort(key=lambda p: p.stat().st_mtime)
        total = 0
        sized = []
        for f in files:
            try:
                sz = f.stat().st_size
            except FileNotFoundError:
                continue
            total += sz
            sized.append((f, sz))
        i = 0
        while total > self.max_total_bytes and i < len(sized):
            f, sz = sized[i]
            try:
                f.unlink(missing_ok=True)
                total -= sz
            except FileNotFoundError:
                pass
            i += 1


class PublishToBusHandler(logging.Handler):
    """
    Публикация событий в live-вьюер через внутрипроцессную шину (logbus).
    Умеет работать из главного loop и из фоновых потоков (thread-safe).
    """
    def __init__(self) -> None:
        super().__init__()
        try:
            from .telemetry import logbus  # type: ignore
            self._bus = logbus
        except Exception:
            self._bus = None

    def emit(self, record: logging.LogRecord) -> None:
        if self._bus is None:
            return
        event = record_to_event(record)
        try:
            import asyncio
            try:
                # если код исполняется в главном loop
                loop = asyncio.get_running_loop()
                loop.create_task(self._bus.publish(event))
            except RuntimeError:
                # мы в рабочем потоке — используем thread-safe путь
                self._bus.publish_threadsafe(event)  # type: ignore
        except Exception:
            pass


def setup_logging(
    level: int = logging.INFO,
    live_dir: str = "/var/log/lars/live",
    archive_dir: str = "/var/log/lars/archive",
    segment_size_mb: int = 64,
    segment_max_sec: int = 1800,
    zstd_level: int = 9,
    max_total_bytes: int | str = 8_589_934_592,
    max_age_days: int = 14,
) -> None:
    """
    Единый пайплайн логирования:
      1) StreamHandler(stdout) — WARNING+ (минимум, аварийный канал для journald)
      2) MsgpackZstdSegmentHandler — основное бинарное хранилище (сегменты + .zst архив)
      3) PublishToBusHandler — live-поток для /admin/logs (WebSocket)
    """
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    root.setLevel(level)

    # 1) тонкий stdout
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.WARNING)
    sh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root.addHandler(sh)

    # 2) бинарные сегменты (и архив)
    root.addHandler(MsgpackZstdSegmentHandler(
        live_dir=live_dir,
        archive_dir=archive_dir,
        segment_size_mb=segment_size_mb,
        segment_max_sec=segment_max_sec,
        zstd_level=zstd_level,
        max_total_bytes=max_total_bytes,
        max_age_days=max_age_days,
    ))

    # 3) публикация в live-вьюер
    root.addHandler(PublishToBusHandler())

    # uvicorn → прокидываем наверх, чтобы не было дублей
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        lg = logging.getLogger(name)
        lg.handlers[:] = []
        lg.propagate = True

    # предупреждения stdlib в logging
    try:
        import warnings
        logging.captureWarnings(True)
        warnings.filterwarnings("default")
    except Exception:
        pass

    logging.getLogger(__name__).warning(
        "Unified logging enabled: stdout(minimal) + msgpack-segments(+zstd) + WS/live viewer"
    )
