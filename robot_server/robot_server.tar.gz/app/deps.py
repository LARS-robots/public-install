import os
from .services.robot_stub import StubRobot
# from .services.robot_rpi import RealRobot

def get_robot():
    return StubRobot() if os.getenv("ROBOT_MODE", "stub") == "stub" else RealRobot()
