# state.py
from typing import Set
from aiortc import RTCPeerConnection

# общий флаг «идёт ли трансляция?»
streaming_enabled: bool = False

# активные PeerConnection-ы (для корректного закрытия)
peer_connections: Set[RTCPeerConnection] = set()

# активный объект CameraVideoTrack (нужен, чтобы останавливать запись/overlay)
camera_track = None
current_camera_id: int = 1  # сохраняем текущий camera_id для переиспользования
