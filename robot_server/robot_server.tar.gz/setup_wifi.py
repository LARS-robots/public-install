import subprocess
import sys

def run_cmd(cmd: str):
    print(f"▶ Выполняю: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print("❌ Ошибка:", result.stderr.strip())
        return False
    else:
        print("✅ Успешно")
        return True

def get_wifi_config():
    """Получает конфигурацию WiFi от пользователя"""
    print("\n🔧 Настройка WiFi точки доступа")
    print("=" * 50)
    print("1. Основной робот (LARSrobot-AP)")
    print("2. Тестовый робот (LARSrobotTEST-AP)")
    print("3. Пользовательская настройка")
    
    while True:
        choice = input("\nВыберите тип конфигурации (1-3): ").strip()
        
        if choice == "1":
            return {
                "con_name": "LARSrobot-AP",
                "ssid": "LARSrobot",
                "password": "LARSrobot1234",
                "ip": "10.42.0.13/24"
            }
        elif choice == "2":
            return {
                "con_name": "LARSrobotTEST-AP",
                "ssid": "LARSrobotTEST", 
                "password": "LARStest1234",
                "ip": "10.42.0.23/24"
            }
        elif choice == "3":
            print("\n📝 Пользовательская конфигурация:")
            con_name = input("Имя подключения: ").strip()
            ssid = input("SSID (название сети): ").strip()
            password = input("Пароль (минимум 8 символов): ").strip()
            ip = input("IP адрес с маской (например, 10.42.0.15/24): ").strip()
            
            if len(password) < 8:
                print("❌ Пароль должен быть минимум 8 символов!")
                continue
                
            return {
                "con_name": con_name,
                "ssid": ssid,
                "password": password,
                "ip": ip
            }
        else:
            print("❌ Неверный выбор! Выберите 1, 2 или 3")

def setup_wifi():
    # Получаем конфигурацию от пользователя
    config = get_wifi_config()
    
    print(f"\n🚀 Настраиваю WiFi точку доступа:")
    print(f"   Имя подключения: {config['con_name']}")
    print(f"   SSID: {config['ssid']}")
    print(f"   IP адрес: {config['ip']}")
    print(f"   Пароль: {'*' * len(config['password'])}")
    
    confirm = input("\nПродолжить? (y/N): ").strip().lower()
    if confirm not in ['y', 'yes', 'да']:
        print("❌ Настройка отменена")
        return False

    print("\n🔧 Начинаю настройку...")
    
    # 1. Отключаем dhcpcd и wpa_supplicant
    print("\n1️⃣ Отключаю старые сервисы WiFi...")
    if not run_cmd("sudo systemctl disable --now dhcpcd wpa_supplicant"):
        print("⚠️ Предупреждение: не удалось отключить старые сервисы")

    # 2. Включаем NetworkManager
    print("\n2️⃣ Включаю NetworkManager...")
    if not run_cmd("sudo systemctl enable --now NetworkManager"):
        print("❌ Критическая ошибка: не удалось запустить NetworkManager")
        return False

    # 3. Удаляем существующее подключение (если есть)
    print(f"\n3️⃣ Удаляю существующее подключение {config['con_name']}...")
    run_cmd(f"sudo nmcli con delete '{config['con_name']}' 2>/dev/null || true")

    # 4. Создаём подключение
    print(f"\n4️⃣ Создаю новое подключение {config['con_name']}...")
    cmd = f"sudo nmcli con add type wifi ifname wlan0 mode ap con-name '{config['con_name']}' ssid '{config['ssid']}'"
    if not run_cmd(cmd):
        print("❌ Критическая ошибка: не удалось создать подключение")
        return False

    # 5. Настраиваем подключение
    print(f"\n5️⃣ Настраиваю параметры подключения...")
    cmd = f"""sudo nmcli con mod '{config['con_name']}' \
        wifi.band bg wifi.channel 6 802-11-wireless.powersave 2 \
        wifi-sec.key-mgmt wpa-psk wifi-sec.psk '{config['password']}' \
        connection.autoconnect yes connection.autoconnect-priority 100 \
        ipv4.method shared ipv4.addresses {config['ip']} \
        ipv6.method ignore"""
    if not run_cmd(cmd):
        print("❌ Ошибка настройки параметров")
        return False

    # 6. Включаем автоподключение и бесконечные ретраи
    print(f"\n6️⃣ Настраиваю автоподключение...")
    cmd = f"""sudo nmcli con mod '{config['con_name']}' \
        connection.autoconnect yes \
        connection.autoconnect-priority 100 \
        connection.autoconnect-retries -1"""
    if not run_cmd(cmd):
        print("⚠️ Предупреждение: не удалось настроить автоподключение")

    # 7. Перезагружаем конфигурацию соединений
    print(f"\n7️⃣ Перезагружаю конфигурацию...")
    if not run_cmd("sudo nmcli connection reload"):
        print("⚠️ Предупреждение: не удалось перезагрузить конфигурацию")

    # 8. Активируем соединение
    print(f"\n8️⃣ Активирую соединение...")
    if not run_cmd(f"sudo nmcli con up '{config['con_name']}'"):
        print("❌ Ошибка активации соединения")
        return False

    # 9. Активируем SSH
    print(f"\n9️⃣ Включаю SSH...")
    run_cmd("sudo systemctl enable --now ssh")
    run_cmd("sudo systemctl restart ssh")

    print(f"\n🎉 Настройка завершена!")
    print(f"📶 WiFi точка доступа: {config['ssid']}")
    print(f"🔐 Пароль: {config['password']}")
    print(f"🌐 IP адрес робота: {config['ip'].split('/')[0]}")
    print(f"🔗 Web интерфейс: http://{config['ip'].split('/')[0]}:8081")
    print(f"💻 SSH подключение: ssh lars@{config['ip'].split('/')[0]}")
    
    return True

def main():
    try:
        if setup_wifi():
            print("\n✅ Настройка успешно завершена!")
            print("🔄 Рекомендуется перезагрузить систему: sudo reboot")
        else:
            print("\n❌ Настройка завершилась с ошибками")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⚠️ Настройка прервана пользователем")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Неожиданная ошибка: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
