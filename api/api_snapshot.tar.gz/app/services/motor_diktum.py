import logging
from .motor_iface import MotorIface

log = logging.getLogger(__name__)

class DiktumMotor(MotorIface):
    """
    Diktum motor driver (placeholder).
    Insert real serial / SDK calls where indicated by 'pass'.
    """
    name = "diktum"

    def __init__(self):
        self._connected = False

    def connect(self, app_state) -> None:
        # TODO: open serial / init SDK for Diktum here
        # pass
        self._connected = True
        log.info("motor.connect", extra={"event": {
            "stage": "motion",
            "action": "connect",
            "driver": self.name,
            "result": "ok"
        }})

    def set_throttle(self, value: float) -> None:
        # TODO: send throttle to Diktum
        # pass
        log.info("motor.throttle", extra={"event": {
            "stage": "motion", "action": "throttle", "driver": self.name, "value": float(value)
        }})

    def set_steer(self, value: float) -> None:
        # TODO: send steer to Diktum
        # pass
        log.info("motor.steer", extra={"event": {
            "stage": "motion", "action": "steer", "driver": self.name, "value": float(value)
        }})

    def command_velocity(self, vx: float, wz: float) -> None:
        # TODO: send velocity command to Diktum
        # pass
        log.info("motor.velocity", extra={"event": {
            "stage": "motion", "action": "velocity", "driver": self.name,
            "effective": {"vx": float(vx), "wz": float(wz)}
        }})

    def stop(self) -> None:
        # TODO: command stop
        # pass
        log.info("motor.stop", extra={"event": {
            "stage": "motion", "action": "stop", "driver": self.name
        }})

    def shutdown(self) -> None:
        # TODO: cleanup/close serial
        # pass
        log.info("motor.shutdown", extra={"event": {
            "stage": "motion", "action": "shutdown", "driver": self.name
        }})
