import logging
import time
import math
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, Union
from pydantic import BaseModel

from .motor_iface import MotorIface
from .motor_diktum import DiktumMotor
from .motor_raspbot import RaspbotMotor
from .motor_simulator import SimulatorMotor

logger = logging.getLogger(__name__)

class SimulatorPose(BaseModel):
    lat: float
    lon: float
    yaw: float
    timestamp: float

class MotionConfig(BaseModel):
    speed_mps: float
    max_yaw_rate: float
    orient_then_move: bool = True
    dead_zone: float = 0.12

class MotorService:
    """
    Facade for handling motor control.
    Delegates to specific driver implementations (simulator, raspbot, diktum).
    """
    def __init__(self):
        self._config_cache: Optional[Dict[str, Any]] = None
        self._config_cache_time: float = 0
        self._config_cache_ttl: float = 5.0
        self._driver: Optional[MotorIface] = None
        self._driver_type: Optional[str] = None

        logger.info(f"🤖 Robot type configured: {self.get_robot_type()}")

    # ---------- Config loading ----------
    def _load_config(self) -> Dict[str, Any]:
        now = time.time()
        if (self._config_cache is not None and
            now - self._config_cache_time < self._config_cache_ttl):
            return self._config_cache

        # Candidate locations (first match wins)
        here = Path(__file__).resolve()
        candidates = [
            Path("~/LARS/robot_server/config.toml").expanduser(),
            # repo layout: services/api/src/config/config.toml
            here.parents[2] / "config" / "config.toml",
            # Common container mounts
            Path("/app/src/config/config.toml"),
            Path("/app/config/config.toml"),
            # CWD and system path
            Path.cwd() / "config.toml",
            Path("/etc/lars/config.toml"),
        ]
        # Best-effort repo root fallback
        try:
            candidates.append(here.parents[4] / "config.toml")
        except Exception:
            pass

        config: Dict[str, Any] = {}
        for cfg_path in candidates:
            logger.debug("🔍 Trying config path: %s (exists=%s)", cfg_path, cfg_path.exists())
            if not cfg_path.exists():
                continue
            try:
                try:
                    import tomllib as toml_reader  # Py3.11+
                except Exception:
                    import tomli as toml_reader  # type: ignore
                with cfg_path.open("rb") as f:
                    config = toml_reader.load(f) or {}
                    logger.info("✅ Loaded config from %s", cfg_path)
                    logger.debug("🗺️ Config sections: %s", list(config.keys()))
                    if "map" in config:
                        logger.debug("📍 Map config: %s", config["map"])
                    break
            except Exception as e:
                logger.debug("Failed to load config from %s: %s", cfg_path, e)

        if not config:
            logger.warning("❌ No config file found! Using defaults.")

        self._config_cache = config
        self._config_cache_time = now
        return config

    def get_robot_type(self) -> str:
        cfg = self._load_config()
        return (cfg.get("default") or {}).get("robot_type", "unknown")

    def _get_motion_config(self, cfg: Dict[str, Any]) -> MotionConfig:
        motion_section = cfg.get("motion", {})
        try:
            speed_mps = float(motion_section.get("speed_mps", 0.6))
        except (ValueError, TypeError):
            speed_mps = 0.6

        try:
            turn_speed_dps = float(motion_section.get("turn_speed_dps", 90.0))
            turn_speed_dps = max(10.0, min(360.0, turn_speed_dps))
            max_yaw_rate = turn_speed_dps * math.pi / 180.0
            logger.info(f"Turn speed: {turn_speed_dps}°/s = {max_yaw_rate} rad/s")
        except (ValueError, TypeError):
            max_yaw_rate = math.pi / 2.0

        try:
            orient_then_move = bool(motion_section.get("orient_then_move", True))
        except (ValueError, TypeError):
            orient_then_move = True

        try:
            dead_zone = float(motion_section.get("dead_zone", 0.12))
            dead_zone = max(0.0, min(0.4, dead_zone))
        except (ValueError, TypeError):
            dead_zone = 0.12

        return MotionConfig(
            speed_mps=speed_mps,
            max_yaw_rate=max_yaw_rate,
            orient_then_move=orient_then_move,
            dead_zone=dead_zone
        )

    # ---------- Driver factory ----------
    def _ensure_driver(self, app_state) -> Optional[MotorIface]:
        rtype = self.get_robot_type()

        # Return cached driver if already created for this type
        if self._driver and self._driver_type == rtype:
            return self._driver

        # (Re)create driver
        try:
            if rtype == "simulator":
                self._driver = SimulatorMotor()
            elif rtype == "diktum":
                self._driver = DiktumMotor()
            elif rtype == "raspbot":
                self._driver = RaspbotMotor()
            else:
                logger.warning("motor.factory", extra={"event": {
                    "stage": "motion", "action": "factory_unknown_type", "robot_type": rtype
                }})
                self._driver = None
                self._driver_type = None
                return None

            self._driver_type = rtype
            self._driver.connect(app_state)
            logger.info("motor.factory", extra={"event": {
                "stage": "motion", "action": "factory_bind", "robot_type": rtype, "driver": self._driver.name
            }})
            return self._driver
        except Exception as e:
            logger.error("motor.factory_error", extra={"event": {
                "stage": "motion", "action": "factory_error",
                "robot_type": rtype, "error": str(e)
            }}, exc_info=True)
            self._driver = None
            self._driver_type = None
            return None

    # ---------- Helpers ----------
    def _apply_deadzone(self, value: float, dead_zone: float) -> float:
        return 0.0 if abs(value) < dead_zone else value

    # ---------- Public API ----------
    def init_simulator_pose(self, app_state) -> bool:
        """
        Initialize simulator driver if needed.
        Returns True if simulator mode and initialized.
        """
        rtype = self.get_robot_type()
        if rtype != "simulator":
            return False

        # Ensure driver is created and connected
        driver = self._ensure_driver(app_state)
        return driver is not None and isinstance(driver, SimulatorMotor)

    def execute_joystick_command(
        self,
        app_state,
        throttle: Optional[float] = None,
        steer: Optional[float] = None,
        vx: Optional[float] = None,
        wz: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Execute joystick/velocity command through appropriate driver.
        """
        rtype = self.get_robot_type()
        driver = self._ensure_driver(app_state)
        
        if not driver:
            logger.warning("motion.command.no_driver", extra={"event": {
                "stage": "motion", "action": "no_driver", "robot_type": rtype
            }})
            return {"ok": False, "mode": rtype, "error": "No driver available"}

        cfg = self._get_motion_config(self._load_config())

        # Compute effective velocities
        if vx is not None or wz is not None:
            effective_vx = float(vx or 0.0)
            effective_wz = float(wz or 0.0)
        else:
            thr = self._apply_deadzone(float(throttle or 0.0), cfg.dead_zone)
            ste = self._apply_deadzone(float(steer or 0.0), cfg.dead_zone)
            if cfg.orient_then_move and throttle is None:
                effective_vx = cfg.speed_mps if abs(ste) > 0.0 else 0.0
                effective_wz = ste * cfg.max_yaw_rate
            else:
                effective_vx = thr * cfg.speed_mps
                effective_wz = ste * cfg.max_yaw_rate

        # Send command to driver
        try:
            driver.command_velocity(effective_vx, effective_wz)
            
            # For simulator, return pose
            if isinstance(driver, SimulatorMotor):
                pose = driver.get_pose()
                return {
                    "ok": True,
                    "mode": "simulator",
                    "simulator": True,
                    "pose": pose
                }
            
            return {"ok": True, "mode": rtype, "simulator": False}
        except Exception as e:
            logger.error("motion.command.error", extra={"event": {
                "stage": "motion", "action": "command_error",
                "driver": getattr(driver, "name", "?"),
                "error": str(e)
            }}, exc_info=True)
            return {"ok": False, "mode": rtype, "simulator": False, "error": str(e)}

    def get_current_pose(self, app_state) -> Optional[SimulatorPose]:
        """Get current pose (simulator only)"""
        rtype = self.get_robot_type()
        if rtype != "simulator":
            return None
            
        driver = self._ensure_driver(app_state)
        if not isinstance(driver, SimulatorMotor):
            return None
            
        pose = driver.get_pose()
        if not pose:
            return None
            
        try:
            return SimulatorPose(
                lat=float(pose["lat"]),
                lon=float(pose["lon"]),
                yaw=float(pose["yaw"]),
                timestamp=float(pose["t"])
            )
        except (KeyError, ValueError, TypeError):
            return None
