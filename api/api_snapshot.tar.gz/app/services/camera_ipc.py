"""
Camera Daemon IPC Client
Communicates with the camera_daemon process via TCP sockets.
"""
import asyncio
import json
import logging
import struct
from typing import AsyncGenerator, Optional, Tuple

log = logging.getLogger(__name__)

# IPC configuration
CONTROL_HOST = "127.0.0.1"
CONTROL_PORT = 8765
FRAME_BASE_PORT = 8800

# Frame header format: length(4) + width(2) + height(2) + pts_us(8) + format(1)
FRAME_HEADER_FMT = ">IHHQB"
FRAME_HEADER_SIZE = struct.calcsize(FRAME_HEADER_FMT)

FMT_I420 = 1


class CameraDaemonClient:
    """Client for communicating with camera daemon control socket."""
    
    def __init__(self, host: str = CONTROL_HOST, port: int = CONTROL_PORT):
        self.host = host
        self.port = port
    
    async def send_command(self, cmd: str, **params) -> dict:
        """Send a command to the daemon and return response."""
        try:
            reader, writer = await asyncio.open_connection(self.host, self.port)
            
            request = {"cmd": cmd, **params}
            request_line = json.dumps(request) + "\n"
            
            writer.write(request_line.encode())
            await writer.drain()
            
            response_line = await reader.readline()
            writer.close()
            await writer.wait_closed()
            
            if not response_line:
                return {"error": "no_response"}
            
            return json.loads(response_line.decode().strip())
        except Exception as e:
            log.error("Failed to send command to daemon: %s", e)
            return {"error": "connection_failed", "details": str(e)}
    
    async def start_camera(self, cam_id: int, width: int, height: int, fps: int) -> dict:
        """Request daemon to start a camera."""
        return await self.send_command("start", id=cam_id, w=width, h=height, fps=fps)
    
    async def stop_camera(self, cam_id: int) -> dict:
        """Request daemon to stop a camera."""
        return await self.send_command("stop", id=cam_id)
    
    async def get_status(self) -> dict:
        """Get daemon status."""
        return await self.send_command("status")


class FrameReader:
    """Reads frames from camera daemon frame socket."""
    
    def __init__(self, cam_id: int, host: str = "127.0.0.1"):
        self.cam_id = cam_id
        self.host = host
        self.port = FRAME_BASE_PORT + cam_id
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
    
    async def connect(self) -> None:
        """Connect to the frame socket."""
        if self.reader is not None:
            return
        
        try:
            self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
            log.info("Connected to frame socket for camera %d on port %d", self.cam_id, self.port)
        except Exception as e:
            log.error("Failed to connect to frame socket for camera %d: %s", self.cam_id, e)
            raise
    
    async def disconnect(self) -> None:
        """Disconnect from frame socket."""
        if self.writer:
            self.writer.close()
            await self.writer.wait_closed()
        self.reader = None
        self.writer = None
        log.info("Disconnected from frame socket for camera %d", self.cam_id)
    
    async def read_frames(self) -> AsyncGenerator[Tuple[int, int, int, int, bytes], None]:
        """
        Read frames from the socket.
        
        Yields:
            (width, height, pts_us, format, payload)
        """
        if self.reader is None:
            await self.connect()
        
        try:
            while True:
                # Read frame header
                header_bytes = await self.reader.readexactly(FRAME_HEADER_SIZE)
                length, width, height, pts_us, fmt = struct.unpack(FRAME_HEADER_FMT, header_bytes)
                
                # Read frame payload
                payload = await self.reader.readexactly(length)
                
                yield width, height, pts_us, fmt, payload
        except asyncio.IncompleteReadError:
            log.warning("Frame socket for camera %d closed", self.cam_id)
        except Exception as e:
            log.error("Error reading frames from camera %d: %s", self.cam_id, e)
        finally:
            await self.disconnect()
