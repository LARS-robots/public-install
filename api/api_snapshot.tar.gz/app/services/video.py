# services/video.py
# ============================================================
# Video service with CameraSource/Streaming/Recorder/Manager
# - Owns camera enumeration, session/output dirs, ZIP building
# - ALWAYS records from ALL configured/discovered cameras
# - Cross-platform capture backends:
#     * Raspberry Pi: rpicam-vid → I420 via stdout
#     * Linux (V4L2): ffmpeg -f v4l2 → I420 via stdout
#     * Windows/macOS/Other: OpenCV → I420 in worker thread
# ============================================================

from __future__ import annotations

import asyncio
import glob
import logging
import os
import platform as _py_platform
import re
import shutil
import subprocess
import time
import weakref
from collections import deque
from datetime import datetime
from pathlib import Path
from threading import Event, Lock, Thread
from typing import Optional, Tuple
from weakref import WeakSet
from zipfile import ZipFile, ZIP_STORED

import cv2
import numpy as np
from functools import lru_cache
from aiortc import VideoStreamTrack
from av import VideoFrame

# EIS (если доступен в проекте)
from .eis_rt import build_eis_adapter
from .aspect_ops import ensure_aspect_i420

# TOML loader (Py3.11+/older)
try:
    import tomllib  # Python 3.11+
except Exception:  # pragma: no cover
    import tomli as tomllib

log = logging.getLogger(__name__)

eis_log = logging.getLogger("eis_rt")
eis_log.setLevel(logging.DEBUG)


# ------------------------ helpers ------------------------ #
def _clamp_fps(label: str, fps: int | None, fallback: int) -> int:
    max_fps = 60
    eff = int(fps or fallback)
    if eff > max_fps:
        log.warning("%s fps=%s too high; clamping to %s", label, eff, max_fps)
        eff = max_fps
    if eff < 10:
        log.warning("%s fps=%s too low; raising to 10", label, eff)
        eff = 10
    return eff


def _jlog(tag: str, **kw):
    log.info(tag, extra={"event": {"tag": tag, **kw}})


@lru_cache(maxsize=1)
def _load_config_dict() -> dict:
    """
    Robust config loader with a single cached lookup to avoid repeated FS hits/log spam.

    Search order (first match wins):
      1) <repo>/services/api/src/config/config.toml
      2) /app/src/config/config.toml        (common container mount when PYTHONPATH=/app/src)
      3) /app/config/config.toml            (common container mount)
      4) CWD/config.toml
      5) /etc/lars/config.toml
      6) <repo_root>/config.toml

    Returns parsed dict or empty dict.
    """
    candidates = []
    here = Path(__file__).resolve()

    # 1) services/api/src/config/config.toml
    try:
        candidates.append(here.parents[2] / "config" / "config.toml")
    except Exception:
        pass

    # 2) container layout when code is mounted to /app/src
    candidates.append(Path("/app/src/config/config.toml"))

    # 3) container common mount
    candidates.append(Path("/app/config/config.toml"))

    # 4) current working directory
    candidates.append(Path.cwd() / "config.toml")

    # 5) system path
    candidates.append(Path("/etc/lars/config.toml"))

    # 6) repo root (best-effort)
    try:
        candidates.append(here.parents[4] / "config.toml")
    except Exception:
        pass

    for p in candidates:
        try:
            if p.exists() and p.is_file():
                with p.open("rb") as fh:
                    data = tomllib.load(fh)
                    log.info("Loaded config from %s", str(p))
                    return data or {}
        except Exception as e:
            log.debug("Failed to load config from %s: %s", str(p), e)

    # Only warn once (because function is cached by lru_cache)
    log.warning("No config file found in known locations; using defaults.")
    return {}


def _get_aspect_config() -> dict:
    cfg = _load_config_dict().get("aspect", {})
    if not isinstance(cfg, dict):
        return {"enabled": False}
    
    def parse_ratio(s: str) -> Tuple[int, int]:
        try:
            h, w = map(int, s.split(':'))
            return h, w
        except (ValueError, AttributeError):
            return 0, 0

    return {
        "enabled": bool(cfg.get("enabled", False)),
        "mode": str(cfg.get("mode", "center_crop")),
        "stereo_left": parse_ratio(cfg.get("stereo_left")),
        "mono": parse_ratio(cfg.get("mono")),
        "quad": parse_ratio(cfg.get("quad")),
    }


def _apply_aspect_correction(buf: np.ndarray, width: int, height: int, layout_mode: str) -> Tuple[np.ndarray, int, int]:
    aspect_cfg = _get_aspect_config()
    if not aspect_cfg.get("enabled"):
        return buf, width, height

    # Detect if running on a PC/Laptop and force mono layout if so
    is_pc_server = (
        _py_platform.system() in ("Windows", "Darwin") or
        (_py_platform.system() == "Linux" and not shutil.which("rpicam-hello"))
    )
    
    effective_layout_mode = "mono" if is_pc_server else layout_mode
    if is_pc_server and layout_mode != "mono":
        log.info("PC platform detected, forcing mono aspect correction for layout '%s'", layout_mode)


    target_h, target_w = 0, 0
    src_buf, src_w, src_h = buf, width, height

    if effective_layout_mode == "stereo":
        target_h, target_w = aspect_cfg.get("stereo_left", (0, 0))
        if not (target_h > 0 and target_w > 0 and width % 2 == 0 and height % 2 == 0):
            return buf, width, height

        # 1. Split original frame into left and right halves
        half_w = width // 2
        y_size = width * height
        uv_size = y_size // 4
        
        y_plane = buf[:y_size].reshape(height, width)
        u_plane = buf[y_size : y_size + uv_size].reshape(height // 2, width // 2)
        v_plane = buf[y_size + uv_size :].reshape(height // 2, width // 2)

        # Create contiguous buffers for left and right frames
        left_y, right_y = y_plane[:, :half_w], y_plane[:, half_w:]
        left_u, right_u = u_plane[:, :half_w // 2], u_plane[:, half_w // 2:]
        left_v, right_v = v_plane[:, :half_w // 2], v_plane[:, half_w // 2:]

        left_buf = np.concatenate([left_y.ravel(), left_u.ravel(), left_v.ravel()])
        right_buf = np.concatenate([right_y.ravel(), right_u.ravel(), right_v.ravel()])

        # 2. Process both halves independently
        mode = aspect_cfg["mode"]
        processed_left, new_w, new_h = ensure_aspect_i420(left_buf, half_w, height, target_h, target_w, mode)
        processed_right, _, _ = ensure_aspect_i420(right_buf, half_w, height, target_h, target_w, mode)

        # If no change was made, return original buffer
        if new_w == half_w and new_h == height:
            return buf, width, height

        # 3. Stitch the processed frames back together
        final_w, final_h = new_w * 2, new_h
        
        # Extract YUV planes from processed buffers
        new_y_size = new_w * new_h
        new_uv_size = new_y_size // 4
        
        pleft_y = processed_left[:new_y_size].reshape(new_h, new_w)
        pleft_u = processed_left[new_y_size : new_y_size + new_uv_size].reshape(new_h // 2, new_w // 2)
        pleft_v = processed_left[new_y_size + new_uv_size:].reshape(new_h // 2, new_w // 2)

        pright_y = processed_right[:new_y_size].reshape(new_h, new_w)
        pright_u = processed_right[new_y_size : new_y_size + new_uv_size].reshape(new_h // 2, new_w // 2)
        pright_v = processed_right[new_y_size + new_uv_size:].reshape(new_h // 2, new_w // 2)

        # Create final combined planes
        final_y = np.hstack((pleft_y, pright_y))
        final_u = np.hstack((pleft_u, pright_u))
        final_v = np.hstack((pleft_v, pright_v))

        final_buf = np.concatenate([final_y.ravel(), final_u.ravel(), final_v.ravel()])
        return final_buf, final_w, final_h

    elif effective_layout_mode == "quad":
        target_h, target_w = aspect_cfg.get("quad", (0, 0))
    else: # default/mono
        target_h, target_w = aspect_cfg.get("mono", (0, 0))

    if target_h > 0 and target_w > 0:
        return ensure_aspect_i420(src_buf, src_w, src_h, target_h, target_w, aspect_cfg["mode"])

    return buf, width, height


def _layout_mode_and_size(cam_index: int) -> Tuple[str, int, int]:
    """
    Returns (mode, width, height) from config or defaults (640x480).
    Prefers layout.stereo / layout.quad blocks by camera_index.
    """
    data = _load_config_dict()
    layout = data.get("layout", {})
    stereo = layout.get("stereo", {})
    if isinstance(stereo, dict) and int(stereo.get("camera_index", -1)) == int(cam_index):
        return "stereo", int(stereo.get("width", 640)), int(stereo.get("height", 480))
    quad = layout.get("quad", {})
    if isinstance(quad, dict) and int(quad.get("camera_index", -1)) == int(cam_index):
        return "quad", int(quad.get("width", 640)), int(quad.get("height", 480))
    return "default", 640, 480


def _load_eis_config() -> dict:
    data = _load_config_dict()
    eis = dict(data.get("eis", {}) or {})
    layout = dict(data.get("layout", {}) or {})
    mode = str(layout.get("mode", "camera_stereo")).lower()

    # Auto-detect platform and override mode for PC
    is_pc_server = (
            _py_platform.system() in ("Windows", "Darwin", "Linux") or  # Windows/macOS
            (not shutil.which("rpicam-hello"))  # Linux without rpicam (likely PC)
    )

    if is_pc_server:
        eis["layout"] = "mono"
        log.info("PC platform detected, forcing mono layout mode")
    elif mode == "camera_stereo":
        eis["layout"] = "stereo_h"
    elif mode == "camera_quad":
        eis["layout"] = "mono"
    else:
        eis["layout"] = str(eis.get("layout", "mono")).lower()

    eis["enabled"] = bool(eis.get("enabled", False))
    eis["cpu_budget_ms"] = int(max(1, min(12, int(eis.get("cpu_budget_ms", 6)))))
    eis["queue_guard_depth"] = int(max(1, min(24, int(eis.get("queue_guard_depth", 6)))))

    algo = dict(eis.get("algorithm", {}) or {})
    algo["downscale_width"] = int(max(320, min(1280, int(algo.get("downscale_width", 640)))))
    algo["gftt_max_corners"] = int(max(64, min(4000, int(algo.get("gftt_max_corners", 800)))))
    algo["lk_win"] = int(max(9, min(61, int(algo.get("lk_win", 21)))))
    algo["ransac_thresh"] = float(algo.get("ransac_thresh", 3.0))
    algo["ema_alpha_pos"] = float(algo.get("ema_alpha_pos", 0.20))
    algo["ema_alpha_rot"] = float(algo.get("ema_alpha_rot", 0.20))
    algo["safety_crop_percent"] = int(
        max(0, min(20, int(algo.get("safety_crop_percent", eis.get("safety_crop_percent", 8)))))
    )
    eis["algorithm"] = algo

    vg = dict(eis.get("virtual_gimbal", {}) or {})
    vg["enabled"] = bool(vg.get("enabled", False))
    eis["virtual_gimbal"] = vg
    return eis


def enumerate_cameras(max_probe: int = 8, probe_open: bool = True) -> list[int]:
    cams: list[int] = []
    # Raspberry Pi (libcamera)
    if shutil.which("rpicam-hello"):
        try:
            p = subprocess.run(
                ["rpicam-hello", "--list-cameras"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5,
            )
            if p.returncode == 0:
                for line in p.stdout.splitlines():
                    if re.match(r"^\s*\d+\s*:", line):
                        cams.append(int(line.split(":")[0].strip()))
                return sorted(set(cams))
        except Exception as e:
            log.warning(f"rpicam-hello failed: {e}")

    # V4L2 + generic OpenCV probe
    try:
        dev_nodes = sorted(
            {
                int(p.split("/dev/video")[1])
                for p in glob.glob("/dev/video*")
                if p.replace("/dev/video", "").isdigit()
            }
        )
        if not probe_open:
            return dev_nodes
        indices = dev_nodes or list(range(max_probe))
        be = (
            cv2.CAP_DSHOW
            if _py_platform.system() == "Windows"
            else cv2.CAP_AVFOUNDATION
            if _py_platform.system() == "Darwin"
            else 0
        )
        for i in indices:
            cap = cv2.VideoCapture(i, be)
            if cap and cap.isOpened():
                cams.append(i)
                cap.release()
    except Exception:
        pass
    return sorted(set(cams))


def _cameras_from_config() -> list[int]:
    """
    Cameras for ALWAYS-ON recording. Precedence:
    1) [cameras].list
    2) layout.*.camera_index
    3) discovery / fallback [0]
    """
    cfg = _load_config_dict()
    cams: list[int] = []

    cam_sec = cfg.get("cameras", {}) or {}
    lst = cam_sec.get("list")
    if isinstance(lst, list) and lst:
        try:
            cams = sorted({int(x) for x in lst})
            return cams
        except Exception:
            log.warning("Invalid [cameras].list in config, falling back...")

    layout = cfg.get("layout", {}) or {}
    for k in ("stereo", "quad"):
        d = layout.get(k, {}) or {}
        if "camera_index" in d:
            try:
                cams.append(int(d["camera_index"]))
            except Exception:
                pass
    cams = sorted(set(cams))
    if cams:
        return cams

    disc = enumerate_cameras(probe_open=False)
    if disc:
        return disc

    return [0]


# ----------------------- session & zip ----------------------- #
def new_session_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _recordings_root() -> Path:
    base = os.getenv("RECORDINGS_DIR", "data/recordings")
    p = Path(base).resolve()
    p.mkdir(parents=True, exist_ok=True)
    return p


def _session_dir(session_id: str) -> Path:
    d = _recordings_root() / session_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _zip_path(session_id: str) -> Path:
    return _recordings_root() / f"record_{session_id}.zip"


def _sorted_zip_members(files: list[Path]) -> list[Path]:
    def _parse_cam_ts(path: Path):
        name = path.name
        cam = 9999
        ts = 0
        if "_cam" in name:
            try:
                tail = name.split("_cam", 1)[1]
                cam_str = "".join(ch for ch in tail.split("_", 1)[0] if ch.isdigit())
                if cam_str.isdigit():
                    cam = int(cam_str)
            except Exception:
                pass
        digits = "".join(ch for ch in name if ch.isdigit())
        if digits.isdigit():
            ts = int(digits[-10:]) if len(digits) >= 10 else int(digits)
        return (cam, ts, name)

    return sorted(files, key=_parse_cam_ts)


# ----------------------- CameraSource ----------------------- #
class CameraSource:
    """
    Single-producer source:
      - Raspberry Pi: spawns rpicam-vid → I420
      - Linux V4L2 :  ffmpeg -f v4l2 → I420
      - Other (Win/mac/Linux w/o v4l2): OpenCV thread → I420
    Drops old frames under backpressure.
    """

    def __init__(
        self, camera_index: int, width: int, height: int, fps: int, queue_size: int = 4, platform: Optional[str] = None
    ):
        self.camera_index = int(camera_index)
        self.width = int(width)
        self.height = int(height)
        self.fps = int(fps)

        # Platform detection with override via CONFIG_PLATFORM env or arg
        platform = (platform or os.getenv("CONFIG_PLATFORM") or "").strip().lower()
        if not platform:
            if shutil.which("rpicam-vid"):
                platform = "rpi"
            elif _py_platform.system() == "Linux" and Path(f"/dev/video{self.camera_index}").exists():
                platform = "v4l2"
            else:
                platform = "opencv"
        self.platform = platform

        self.frame_size = self.width * self.height * 3 // 2

        # Subprocess path (rpi/v4l2)
        self._proc: Optional[subprocess.Popen] = None
        self._stdout_thread: Optional[Thread] = None
        self._stderr_thread: Optional[Thread] = None

        # OpenCV path
        self._cv_cap: Optional[cv2.VideoCapture] = None
        self._cv_thread: Optional[Thread] = None

        self._stop_evt = Event()

        self._frames = deque(maxlen=queue_size)
        self._frames_lock = Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # stats
        self._frames_ok = 0
        self._short_reads = 0
        self._eof_hits = 0
        self._last_ok_ts = 0.0
        self._hb_last = 0.0

    def _build_cmd(self) -> list[str]:
        if self.platform == "rpi":
            return [
                "rpicam-vid",
                "--camera",
                str(self.camera_index),
                "--width",
                str(self.width),
                "--height",
                str(self.height),
                "--codec",
                "yuv420",
                "--nopreview",
                "--timeout",
                "0",
                "--flush",
                "-o",
                "-",
            ]
        # Linux V4L2 via ffmpeg → rawvideo yuv420p
        input_dev = f"/dev/video{self.camera_index}"
        return [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "warning",
            "-f",
            "v4l2",
            "-video_size",
            f"{self.width}x{self.height}",
            "-i",
            input_dev,
            "-f",
            "rawvideo",
            "-pix_fmt",
            "yuv420p",
            "-",
        ]

    async def start(self) -> None:
        if self._proc or self._cv_thread:
            return
        self._loop = asyncio.get_running_loop()
        self._stop_evt.clear()

        if self.platform == "opencv":
            be = (
                cv2.CAP_DSHOW
                if _py_platform.system() == "Windows"
                else cv2.CAP_AVFOUNDATION
                if _py_platform.system() == "Darwin"
                else 0
            )
            cap = cv2.VideoCapture(self.camera_index, be)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            if not cap or not cap.isOpened():
                log.error(
                    "capture.open_error",
                    extra={"event": {"stage": "capture", "action": "open_error", "camera_id": self.camera_index, "platform": "opencv"}},
                )
                return
            self._cv_cap = cap
            log.info(
                "capture.start",
                extra={
                    "event": {
                        "stage": "capture",
                        "action": "start",
                        "camera_id": self.camera_index,
                        "width": self.width,
                        "height": self.height,
                        "fps": self.fps,
                        "platform": "opencv",
                    }
                },
            )
            self._cv_thread = Thread(target=self._cv_reader, name="CameraSource-cv2", daemon=True)
            self._cv_thread.start()
            return

        # rpi/v4l2
        cmd = self._build_cmd()
        log.info(
            "capture.start",
            extra={
                "event": {
                    "stage": "capture",
                    "action": "start",
                    "camera_id": self.camera_index,
                    "width": self.width,
                    "height": self.height,
                    "fps": self.fps,
                    "platform": self.platform,
                    "cmd": " ".join(cmd),
                }
            },
        )
        self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self._stdout_thread = Thread(target=self._stdout_reader, name="CameraSource-stdout", daemon=True)
        self._stdout_thread.start()
        self._stderr_thread = Thread(target=self._stderr_reader, name="CameraSource-stderr", daemon=True)
        self._stderr_thread.start()

    def _read_exact(self, pipe, n: int) -> Optional[bytes]:
        chunks = bytearray()
        while len(chunks) < n and not self._stop_evt.is_set():
            try:
                part = pipe.read(n - len(chunks))
                if not part:
                    return None
                chunks += part
            except Exception:
                return None
        return bytes(chunks) if len(chunks) == n else None

    def _stdout_reader(self) -> None:
        assert self._proc and self._proc.stdout
        stdout = self._proc.stdout
        fs = self.frame_size
        exit_reason = "unknown"
        try:
            while not self._stop_evt.is_set():
                buf = self._read_exact(stdout, fs)
                now = time.time()
                if not buf:
                    self._eof_hits += 1
                    exit_reason = "eof_or_shortread"
                    break
                frame = np.frombuffer(buf, dtype=np.uint8)
                if frame.size != fs:
                    self._short_reads += 1
                    continue
                with self._frames_lock:
                    self._frames.append(frame)
                self._frames_ok += 1
                self._last_ok_ts = now

                # heartbeat every ~1s
                if now - self._hb_last >= 1.0:
                    self._hb_last = now
                    with self._frames_lock:
                        qlen = len(self._frames)
                    _jlog(
                        "SRC",
                        cam=self.camera_index,
                        w=self.width,
                        h=self.height,
                        fps=self.fps,
                        frames_ok=self._frames_ok,
                        short=self._short_reads,
                        eof=self._eof_hits,
                        qlen=qlen,
                    )
        except Exception as e:
            exit_reason = f"exception:{type(e).__name__}"
            log.error(
                "CameraSource stdout error: %s",
                e,
                extra={"event": {"stage": "capture", "action": "stdout_error", "camera_id": self.camera_index, "error_message": str(e)}},
            )
        finally:
            try:
                stdout.close()
            except Exception:
                pass
            _jlog(
                "SRC_EXIT",
                cam=self.camera_index,
                frames_ok=self._frames_ok,
                short=self._short_reads,
                eof=self._eof_hits,
                reason=exit_reason,
            )

    def _stderr_reader(self) -> None:
        assert self._proc and self._proc.stderr
        stderr = self._proc.stderr
        try:
            for line in iter(stderr.readline, b""):
                if not line or self._stop_evt.is_set():
                    break
                msg = line.decode(errors="ignore").rstrip()
                if not msg:
                    continue
                low = msg.lower()
                level = log.info
                if any(k in low for k in ("no such file", "device", "cannot", "error", "failed")):
                    level = log.warning
                level(
                    "ffmpeg[%d] %s",
                    self.camera_index,
                    msg,
                    extra={"event": {"stage": "capture", "action": "stderr", "camera_id": self.camera_index, "msg": msg}},
                )
        except Exception as e:
            log.debug("CameraSource stderr error: %s", e)
        finally:
            try:
                stderr.close()
            except Exception:
                pass

    def _cv_reader(self) -> None:
        cap = self._cv_cap
        if not cap:
            return
        fs = self.frame_size
        exit_reason = "cv2_closed"
        try:
            while not self._stop_evt.is_set():
                ok, bgr = cap.read()
                now = time.time()
                if not ok or bgr is None:
                    time.sleep(0.01)
                    continue
                # resize to target
                h, w = bgr.shape[:2]
                if w != self.width or h != self.height:
                    bgr = cv2.resize(bgr, (self.width, self.height), interpolation=cv2.INTER_LINEAR)
                # BGR → I420 (YUV420p)
                yuv = cv2.cvtColor(bgr, cv2.COLOR_BGR2YUV_I420)
                frame = np.frombuffer(yuv, dtype=np.uint8)
                if frame.size != fs:
                    continue
                with self._frames_lock:
                    self._frames.append(frame)
                self._frames_ok += 1
                self._last_ok_ts = now
                # heartbeat ~1s
                if now - self._hb_last >= 1.0:
                    self._hb_last = now
                    with self._frames_lock:
                        qlen = len(self._frames)
                    _jlog(
                        "SRC",
                        cam=self.camera_index,
                        w=self.width,
                        h=self.height,
                        fps=self.fps,
                        frames_ok=self._frames_ok,
                        short=self._short_reads,
                        eof=self._eof_hits,
                        qlen=qlen,
                    )
        except Exception as e:
            exit_reason = f"cv2_exception:{type(e).__name__}"
            log.error(
                "CameraSource cv2 error: %s",
                e,
                extra={"event": {"stage": "capture", "action": "cv2_error", "camera_id": self.camera_index, "error_message": str(e)}},
            )
        finally:
            try:
                cap.release()
            except Exception:
                pass
            _jlog(
                "SRC_EXIT",
                cam=self.camera_index,
                frames_ok=self._frames_ok,
                short=self._short_reads,
                eof=self._eof_hits,
                reason=exit_reason,
            )

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    def _wait_proc(self, timeout: float) -> None:
        if not self._proc:
            return
        try:
            self._proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                self._proc.kill()
                self._proc.wait(timeout=1.0)
            except Exception:
                pass

    async def stop(self, timeout: float = 3.0) -> None:
        # OpenCV path
        if self._cv_thread:
            self._stop_evt.set()
            try:
                self._cv_thread.join(timeout=timeout)
            except Exception:
                pass
            self._cv_thread = None
            if self._cv_cap:
                try:
                    self._cv_cap.release()
                except Exception:
                    pass
            with self._frames_lock:
                self._frames.clear()
            return

        # Subprocess path
        if not self._proc:
            return
        self._stop_evt.set()
        try:
            self._proc.terminate()
        except Exception:
            pass

        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, self._wait_proc, timeout)
        except Exception:
            pass
        finally:
            if self._stdout_thread and self._stdout_thread.is_alive():
                try:
                    self._stdout_thread.join(timeout=1.0)
                except Exception:
                    pass
            if self._stderr_thread and self._stderr_thread.is_alive():
                try:
                    self._stderr_thread.join(timeout=1.0)
                except Exception:
                    pass
            self._stdout_thread = None
            self._stderr_thread = None
            self._proc = None
            with self._frames_lock:
                self._frames.clear()


# ----------------------- Daemon IPC Source ----------------------- #
class CameraSourceDaemon:
    """
    Camera source using external GStreamer daemon via IPC.
    Communicates with camera_daemon process over TCP sockets.
    """

    def __init__(
        self, camera_index: int, width: int, height: int, fps: int, queue_size: int = 4
    ):
        self.camera_index = int(camera_index)
        self.width = int(width)
        self.height = int(height)
        self.fps = int(fps)
        self.platform = "gstreamer-daemon"

        self.frame_size = self.width * self.height * 3 // 2

        self._frames = deque(maxlen=queue_size)
        self._frames_lock = Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._reader_task: Optional[asyncio.Task] = None
        self._frame_reader = None
        self._daemon_client = None

        # stats
        self._frames_ok = 0
        self._last_ok_ts = 0.0
        self._hb_last = 0.0

    async def start(self) -> None:
        """Start camera via daemon and begin frame reading."""
        from .camera_ipc import CameraDaemonClient, FrameReader

        if self._reader_task:
            return

        self._loop = asyncio.get_running_loop()

        # Connect to daemon
        self._daemon_client = CameraDaemonClient()
        result = await self._daemon_client.start_camera(
            self.camera_index, self.width, self.height, self.fps
        )

        if result.get("status") != "started" and result.get("status") != "already_running":
            error_msg = result.get("error", "unknown")
            log.error(
                "capture.daemon_start_error",
                extra={
                    "event": {
                        "stage": "capture",
                        "action": "daemon_start_error",
                        "camera_id": self.camera_index,
                        "error_message": error_msg,
                    }
                },
            )
            raise RuntimeError(f"Failed to start camera {self.camera_index} via daemon: {error_msg}")

        log.info(
            "capture.start",
            extra={
                "event": {
                    "stage": "capture",
                    "action": "start",
                    "camera_id": self.camera_index,
                    "width": self.width,
                    "height": self.height,
                    "fps": self.fps,
                    "platform": "gstreamer-daemon",
                }
            },
        )

        # Start frame reader
        self._frame_reader = FrameReader(self.camera_index)
        self._reader_task = asyncio.create_task(self._read_frames())

    async def _read_frames(self) -> None:
        """Background task reading frames from daemon."""
        try:
            await self._frame_reader.connect()

            async for width, height, pts_us, fmt, payload in self._frame_reader.read_frames():
                now = time.time()

                # Validate frame dimensions
                if width != self.width or height != self.height:
                    log.warning(
                        "Frame size mismatch: expected %dx%d, got %dx%d",
                        self.width,
                        self.height,
                        width,
                        height,
                    )
                    continue

                # Convert to numpy array
                frame = np.frombuffer(payload, dtype=np.uint8)
                if frame.size != self.frame_size:
                    continue

                with self._frames_lock:
                    self._frames.append(frame)

                self._frames_ok += 1
                self._last_ok_ts = now

                # heartbeat every ~1s
                if now - self._hb_last >= 1.0:
                    self._hb_last = now
                    with self._frames_lock:
                        qlen = len(self._frames)
                    _jlog(
                        "SRC_DAEMON",
                        cam=self.camera_index,
                        w=self.width,
                        h=self.height,
                        fps=self.fps,
                        frames_ok=self._frames_ok,
                        qlen=qlen,
                    )
        except Exception as e:
            log.error(
                "Daemon frame reader error: %s",
                e,
                extra={
                    "event": {
                        "stage": "capture",
                        "action": "daemon_reader_error",
                        "camera_id": self.camera_index,
                        "error_message": str(e),
                    }
                },
            )
        finally:
            _jlog(
                "SRC_DAEMON_EXIT",
                cam=self.camera_index,
                frames_ok=self._frames_ok,
            )

    def get_frame_nowait(self) -> Optional[np.ndarray]:
        """Get latest frame without blocking."""
        with self._frames_lock:
            return None if not self._frames else self._frames[-1]

    async def stop(self, timeout: float = 3.0) -> None:
        """Stop camera via daemon."""
        # Cancel reader task
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await asyncio.wait_for(self._reader_task, timeout=timeout)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            self._reader_task = None

        # Disconnect frame reader
        if self._frame_reader:
            await self._frame_reader.disconnect()
            self._frame_reader = None

        # Stop camera in daemon
        if self._daemon_client:
            await self._daemon_client.stop_camera(self.camera_index)
            self._daemon_client = None

        with self._frames_lock:
            self._frames.clear()


# ----------------------- Source Factory ----------------------- #
def create_camera_source(camera_index: int, width: int, height: int, fps: int, platform: Optional[str] = None) -> CameraSource | CameraSourceDaemon:
    """
    Factory to create appropriate camera source based on configuration.
    
    Uses daemon if USE_CAMERA_DAEMON=1 env var is set, otherwise falls back to direct capture.
    """
    use_daemon = os.getenv("USE_CAMERA_DAEMON", "0").strip() == "1"
    
    if use_daemon:
        log.info(
            "USE_CAMERA_DAEMON=1 detected. Initializing GStreamer daemon source for camera %d.",
            camera_index
        )
        return CameraSourceDaemon(camera_index, width, height, fps)
    else:
        log.info(
            "USE_CAMERA_DAEMON is not '1'. Initializing direct capture source for camera %d.",
            camera_index
        )
        return CameraSource(camera_index, width, height, fps, platform=platform)


# ----------------------- Streaming Track ----------------------- #
def _fps_from_samples(samples: list[float]) -> Optional[float]:
    if len(samples) < 5:
        return None
    recent = samples[-20:]
    if len(recent) >= 3:
        dt_m = float(np.median(recent))
        dt_a = float(np.mean(recent))
        dt = dt_m if abs(dt_m - dt_a) / max(1e-6, dt_a) < 0.2 else dt_a
        if dt > 0:
            return 1.0 / dt
    return None


class CameraStreamingTrack(VideoStreamTrack):
    """WebRTC track that reads I420 frames from CameraSource; independent from recording."""

    def __init__(self, source: CameraSource, overlay: bool = True, eis_cfg: dict | None = None):
        super().__init__()
        self._source = source
        self._overlay = overlay
        self._stopped = False

        self._consec_black = 0
        self._last_hb = 0.0
        self._delivered_frames = 0

        log.info("eis.config", extra={"event": {"stage": "webrtc", "action": "eis_config", "cfg": eis_cfg}})
        self._eis = None
        if eis_cfg and eis_cfg.get("enabled", False):
            try:
                log.info("eis.init", extra={"event": {"stage": "webrtc", "action": "eis_init", "cfg": eis_cfg}})
                self._eis = build_eis_adapter(source.width, source.height, eis_cfg)
                log.info("eis.init_ok", extra={"event": {"stage": "webrtc", "action": "eis_init_ok", "layout": eis_cfg.get("layout")}})
            except Exception as e:
                log.error("eis.init_error", extra={"event": {"stage": "webrtc", "action": "eis_init_error", "error_message": str(e)}})

        self._layout_mode, _, _ = _layout_mode_and_size(self._source.camera_index)
        self._black_frame_cache: dict[str, np.ndarray] = {}

        self._last_frame_time = 0.0
        self._fps_samples: list[float] = []
        self._frame_counter = 0

    def _make_black_i420(self, width: int, height: int) -> np.ndarray:
        key = f"{width}x{height}"
        if key not in self._black_frame_cache:
            y = np.zeros(width * height, dtype=np.uint8)
            uv = np.full((width * height) // 4, 128, dtype=np.uint8)
            self._black_frame_cache[key] = np.concatenate([y, uv, uv])
        return self._black_frame_cache[key]

    def _draw_overlay_on_i420(self, frame_buf: np.ndarray, width: int, height: int) -> np.ndarray:
        if not self._overlay:
            return frame_buf
        try:
            W, H = width, height
            y_size = W * H
            frame_copy = frame_buf.copy()
            y_plane = frame_copy[:y_size].reshape(H, W)
            now = time.time()
            if self._last_frame_time > 0:
                self._fps_samples.append(now - self._last_frame_time)
                if len(self._fps_samples) > 50:
                    self._fps_samples.pop(0)
            self._last_frame_time = now
            fps = _fps_from_samples(self._fps_samples)
            fps_str = f"{fps:.1f}" if fps else "?"
            text = f"{datetime.now():%H:%M:%S} | cam{self._source.camera_index} | {fps_str} fps | {W}x{H}"
            import cv2  # local import

            mask = np.zeros((H, W), dtype=np.uint8)
            cv2.putText(mask, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2, cv2.LINE_AA)
            alpha = 0.6
            sel = mask > 0
            y_plane[sel] = np.clip((1 - alpha) * y_plane[sel] + alpha * 235, 0, 255).astype(np.uint8)
            return frame_copy
        except Exception as e:
            log.warning("eis.overlay_error", extra={"event": {"stage": "webrtc", "action": "overlay_error", "error_message": str(e)}})
            return frame_buf

    async def recv(self) -> VideoFrame:
        pts, time_base = await self.next_timestamp()
        now = time.time()

        # Use ORIGINAL dimensions for source frame reading
        src_width, src_height = self._source.width, self._source.height
        
        if self._stopped:
            black_frame_buf = self._make_black_i420(src_width, src_height)
            # Apply aspect correction to black frame too
            black_frame_buf, corrected_w, corrected_h = _apply_aspect_correction(
                black_frame_buf, src_width, src_height, self._layout_mode
            )
            frame = VideoFrame.from_ndarray(
                black_frame_buf.reshape(corrected_h * 3 // 2, corrected_w), format="yuv420p"
            )
            frame.pts, frame.time_base = pts, time_base
            return frame

        buf = self._source.get_frame_nowait()
        if buf is None:
            self._consec_black += 1
            if self._consec_black in (30, 120, 300):
                log.warning(
                    "webrtc.black_no_buf",
                    extra={
                        "event": {
                            "stage": "webrtc",
                            "action": "black_no_buf",
                            "camera_id": self._source.camera_index,
                            "width": self._source.width,
                            "height": self._source.height,
                            "black_consec": self._consec_black,
                        }
                    },
                )
            if now - self._last_hb >= 1.0:
                self._last_hb = now
                fps = _fps_from_samples(self._fps_samples)
                log.info(
                    "webrtc.recv_heartbeat",
                    extra={
                        "event": {
                            "stage": "webrtc",
                            "action": "recv_hb",
                            "camera_id": self._source.camera_index,
                            "fps_est": round(fps, 1) if fps else None,
                            "black_consec": self._consec_black,
                        }
                    },
                )
            
            black_frame_buf = self._make_black_i420(src_width, src_height)
            # Apply aspect correction here too
            black_frame_buf, corrected_w, corrected_h = _apply_aspect_correction(
                black_frame_buf, src_width, src_height, self._layout_mode
            )
            frame = VideoFrame.from_ndarray(
                black_frame_buf.reshape(corrected_h * 3 // 2, corrected_w), format="yuv420p"
            )
            frame.pts, frame.time_base = pts, time_base
            return frame
        else:
            if self._consec_black >= 30:
                log.info(
                    "webrtc.recovered",
                    extra={
                        "event": {
                            "stage": "webrtc",
                            "action": "recovered",
                            "camera_id": self._source.camera_index,
                            "black_consec": self._consec_black,
                        }
                    },
                )
            self._consec_black = 0
            self._delivered_frames += 1

        # Apply aspect correction - THIS CHANGES DIMENSIONS
        buf, corrected_width, corrected_height = _apply_aspect_correction(
            buf, src_width, src_height, self._layout_mode
        )

        if self._eis is not None:
            try:
                # EIS expects and returns (H*3/2, W) shaped buffer
                buf2d = buf.reshape(corrected_height * 3 // 2, corrected_width)
                buf = self._eis.process_i420(buf2d, queue_len=0)
                if isinstance(buf, np.ndarray) and buf.ndim == 2:
                    buf = buf.ravel()
            except Exception as e:
                log.error("eis.process_error", extra={"event": {"stage": "webrtc", "action": "process_error", "error_message": str(e)}})

        # Use CORRECTED dimensions for overlay and final frame
        buf = self._draw_overlay_on_i420(buf, corrected_width, corrected_height)
        frame_2d = buf.reshape(corrected_height * 3 // 2, corrected_width)
        frame = VideoFrame.from_ndarray(frame_2d, format="yuv420p")
        frame.pts, frame.time_base = pts, time_base
        self._frame_counter += 1

        if now - self._last_hb >= 1.0:
            self._last_hb = now
            fps = _fps_from_samples(self._fps_samples)
            log.info(
                "webrtc.recv_heartbeat",
                extra={
                    "event": {
                        "stage": "webrtc",
                        "action": "recv_hb",
                        "camera_id": self._source.camera_index,
                        "fps_est": round(fps, 1) if fps else None,
                        "delivered_frames": self._delivered_frames,
                    }
                },
            )

        return frame

    def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        try:
            super().stop()
        except Exception as e:
            log.warning("VideoStreamTrack.stop failed: %s", e)
        log.info("CameraStreamingTrack stopped (cam%d)", self._source.camera_index)


# ----------------------- Recorder ----------------------- #
class CameraRecorder:
    """Records I420 frames from CameraSource to MP4 via FFmpeg subprocess."""

    def __init__(
        self, source: CameraSource, path: Path, width: int, height: int, fps: int, segment_sec: Optional[int] = None
    ):
        self._source = source
        self._output_path = Path(path)
        self._width, self._height, self._fps = width, height, fps
        self._segment_sec = segment_sec
        self._output_path.parent.mkdir(parents=True, exist_ok=True)

        self._proc: Optional[subprocess.Popen] = None
        self._worker_thread: Optional[Thread] = None
        self._stop_evt = Event()
        self._recording = False

        self._layout_mode, _, _ = _layout_mode_and_size(self._source.camera_index)
        self._current_segment = 0
        self._segment_start_time = 0.0
        self._output_files: list[Path] = []

        # stats
        self._frames_written = 0
        self._write_errors = 0
        self._blocked_ms = 0.0
        self._behind_ms_max = 0.0
        self._hb_last = 0.0
        self._last_stderr = deque(maxlen=20)

        log.info(
            "record.init",
            extra={
                "event": {"stage": "record", "action": "init", "path": str(path), "width": width, "height": height, "fps": fps}
            },
        )

    def _build_ffmpeg_cmd(self, output_file: Path, width: int, height: int) -> list[str]:
        gop = max(10, min(2 * self._fps, 240))  # ~2s GOP
        return [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "warning",
            "-f",
            "rawvideo",
            "-pix_fmt",
            "yuv420p",
            "-s",
            f"{width}x{height}",
            "-r",
            str(self._fps),
            "-i",
            "-",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-tune",
            "zerolatency",
            "-g",
            str(gop),
            "-bf",
            "0",
            "-pix_fmt",
            "yuv420p",
            "-y",
            str(output_file),
        ]

    def _get_segment_path(self, segment: int) -> Path:
        if self._segment_sec is None:
            return self._output_path
        stem, suffix, parent = self._output_path.stem, self._output_path.suffix, self._output_path.parent
        return parent / f"{stem}_seg{segment:03d}{suffix}"

    async def start(self) -> None:
        if self._recording:
            return
        self._recording = True
        self._stop_evt.clear()
        self._current_segment = 0
        self._segment_start_time = time.time()
        self._output_files = []
        self._worker_thread = Thread(target=self._recording_worker, name="CameraRecorder", daemon=True)
        self._worker_thread.start()
        log.info(
            "record.segment_start",
            extra={"event": {"stage": "record", "action": "segment_start", "path": str(self._output_path), "segment": self._current_segment}},
        )

    def _stderr_reader(self, stderr_pipe, segment_name: str) -> None:
        try:
            if not stderr_pipe:
                return
            for line in iter(stderr_pipe.readline, b""):
                if not line:
                    break
                msg = line.decode(errors="ignore").rstrip()
                if msg:
                    self._last_stderr.append(msg)
                    log.debug("FFmpeg[%s]: %s", segment_name, msg)
        except Exception as e:
            log.debug("FFmpeg stderr reader error (%s): %s", segment_name, e)
        finally:
            try:
                stderr_pipe.close()
            except Exception:
                pass

    def _recording_worker(self) -> None:
        try:
            while self._recording and not self._stop_evt.is_set():
                current_output = self._get_segment_path(self._current_segment)
                
                # FFmpeg command is now built inside the loop to handle dynamic resolution
                # from aspect correction. We build it with initial params and will create a new
                # process if resolution changes, though the current logic doesn't support that mid-segment.
                # For now, we assume resolution is fixed per segment.
                
                # Peek at the first frame to get corrected dimensions
                first_frame_buf = self._source.get_frame_nowait()
                if first_frame_buf is None:
                    time.sleep(0.1) # Wait for a frame
                    continue
                
                corrected_buf, rec_w, rec_h = _apply_aspect_correction(
                    first_frame_buf, self._width, self._height, self._layout_mode
                )

                cmd = self._build_ffmpeg_cmd(current_output, rec_w, rec_h)
                log.debug("FFmpeg cmd: %s", " ".join(cmd))
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)

                stderr_thread = Thread(
                    target=self._stderr_reader, args=(proc.stderr, f"seg{self._current_segment}"), daemon=True
                )
                stderr_thread.start()

                segment_end = self._segment_start_time + self._segment_sec if self._segment_sec else None

                target_dt = 1.0 / max(1, self._fps)
                next_t = time.time()

                frames_written_local = 0

                try:
                    while self._recording and not self._stop_evt.is_set():
                        if segment_end and time.time() >= segment_end:
                            log.info("Segment %d time limit reached", self._current_segment)
                            break

                        now = time.time()
                        if now < next_t:
                            time.sleep(min(0.002, next_t - now))
                            continue

                        frame_buf = self._source.get_frame_nowait()
                        if frame_buf is None:
                            next_t += target_dt
                            continue
                        
                        # Apply aspect correction to every frame
                        corrected_frame_buf, _, _ = _apply_aspect_correction(
                            frame_buf, self._width, self._height, self._layout_mode
                        )

                        t0 = time.time()
                        try:
                            proc.stdin.write(corrected_frame_buf.tobytes())
                            frames_written_local += 1
                            self._frames_written += 1
                        except (BrokenPipeError, OSError) as e:
                            self._write_errors += 1
                            log.warning("FFmpeg stdin write failed: %s", e)
                            break
                        blocked = (time.time() - t0) * 1000.0
                        if blocked > 0.1:
                            self._blocked_ms += blocked

                        next_t += target_dt
                        lag_ms = (now - next_t) * 1000.0
                        if lag_ms > self._behind_ms_max:
                            self._behind_ms_max = lag_ms
                        if lag_ms > 250.0:
                            next_t = now + target_dt  # realign

                        if proc.poll() is not None:
                            log.warning("FFmpeg died (segment %d)", self._current_segment)
                            break

                        # heartbeat each ~1s
                        if now - self._hb_last >= 1.0:
                            self._hb_last = now
                            _jlog(
                                "REC",
                                cam=self._source.camera_index,
                                w=rec_w,
                                h=rec_h,
                                fps_target=self._fps,
                                frames_written=self._frames_written,
                                blocked_ms=int(self._blocked_ms),
                                behind_ms_max=int(self._behind_ms_max),
                                poll=proc.poll(),
                            )
                except Exception as e:
                    log.error("Recording worker error (segment %d): %s", self._current_segment, e)
                finally:
                    try:
                        if proc.stdin:
                            proc.stdin.close()
                    except Exception:
                        pass
                    try:
                        proc.wait(timeout=5.0)
                        rc = proc.returncode
                        if rc == 0:
                            self._output_files.append(current_output)
                            log.info("Segment %d done: %s frames -> %s", self._current_segment, frames_written_local, current_output)
                        else:
                            log.warning("FFmpeg failed, rc=%s", rc)
                        _jlog(
                            "REC_EXIT",
                            cam=self._source.camera_index,
                            seg=self._current_segment,
                            rc=rc,
                            frames_written=self._frames_written,
                            write_errors=self._write_errors,
                            blocked_ms=int(self._blocked_ms),
                            behind_ms_max=int(self._behind_ms_max),
                            last_stderr=" | ".join(list(self._last_stderr)),
                        )
                    except subprocess.TimeoutExpired:
                        log.warning("FFmpeg timeout, killing")
                        _jlog(
                            "REC_EXIT",
                            cam=self._source.camera_index,
                            seg=self._current_segment,
                            rc="TIMEOUT",
                            frames_written=self._frames_written,
                            write_errors=self._write_errors,
                            blocked_ms=int(self._blocked_ms),
                            behind_ms_max=int(self._behind_ms_max),
                            last_stderr=" | ".join(list(self._last_stderr)),
                        )
                        try:
                            proc.kill()
                            proc.wait(timeout=2.0)
                        except Exception:
                            pass
                    try:
                        stderr_thread.join(timeout=1.0)
                    except Exception:
                        pass

                if self._segment_sec and self._recording and not self._stop_evt.is_set():
                    self._current_segment += 1
                    self._segment_start_time = time.time()
                else:
                    break
        except Exception as e:
            log.error("Recording worker fatal: %s", e)
        finally:
            self._recording = False
            log.info("record.worker_finished", extra={"event": {"stage": "record", "action": "worker_finished"}})

    async def stop(self, timeout: float = 10.0) -> list[Path]:
        if not self._recording:
            return self._output_files
        log.info("record.stop", extra={"event": {"stage": "record", "action": "stop"}})
        self._recording = False
        self._stop_evt.set()
        if self._worker_thread and self._worker_thread.is_alive():
            loop = asyncio.get_running_loop()
            try:
                await loop.run_in_executor(None, self._worker_thread.join, timeout)
            except Exception as e:
                log.warning("Worker join failed: %s", e)
        self._worker_thread = None
        log.info(
            "record.stopped",
            extra={"event": {"stage": "record", "action": "stopped", "files": [str(f) for f in self._output_files]}},
        )
        return self._output_files.copy()

    def is_recording(self) -> bool:
        return self._recording

    def get_output_files(self) -> list[Path]:
        return self._output_files.copy()


# ----------------------- Manager ----------------------- #
class CameraManager:
    """Coordinator for source/streams/recorders; owns session/zip/paths."""

    def __init__(self):
        self._lock = asyncio.Lock()
        self._source: Optional[CameraSource] = None
        self._source_params: Optional[Tuple[int, int, int, int]] = None  # (camera_id, width, height, fps)
        self._stream_tracks: WeakSet[CameraStreamingTrack] = weakref.WeakSet()
        self._recorders: list[CameraRecorder] = []
        self._aux_sources: list[CameraSource] = []
        self._current_session_id: Optional[str] = None

        log.info("CameraManager initialized")

    # ---------- streaming ----------
    async def ensure_source(self, camera_id: int, width: int, height: int, fps: int) -> CameraSource:
        async with self._lock:
            clamped_fps = _clamp_fps("stream", fps, fallback=30)
            new_params = (camera_id, width, height, clamped_fps)
            if self._source and self._source_params == new_params:
                log.debug("Reusing camera: cam%d %dx%d@%dfps", camera_id, width, height, clamped_fps)
                return self._source

            if self._source:
                log.info("Stopping camera to change params")
                await self._source.stop()
                self._source = None
                self._source_params = None

            self._source = create_camera_source(camera_index=camera_id, width=width, height=height, fps=clamped_fps)
            await self._source.start()
            self._source_params = new_params
            log.info("Camera started: cam%d (%s)", camera_id, self._source.platform)
            return self._source

    def create_stream_track(self, overlay: bool = True, eis_cfg: dict | None = None) -> CameraStreamingTrack:
        if not self._source:
            raise RuntimeError("No camera source. Call ensure_source() first.")
        track = CameraStreamingTrack(source=self._source, overlay=overlay, eis_cfg=eis_cfg)
        self._stream_tracks.add(track)
        log.info("Streaming track created for cam%d", self._source.camera_index)
        return track
    

    async def cleanup_client_session(self) -> dict:
        """
        Service logic: cleanup streaming resources when client disconnects.
        Only stops source if no recording is active.
        """
        async with self._lock:
            streams_cleared = len(self._stream_tracks)
            source_stopped = False
            
            # Clear streaming tracks
            self._stream_tracks.clear()
            
            # Only stop source if not recording (preserves recording functionality)
            if not self.is_recording() and self._source:
                log.info("cleanup.stop_source", extra={
                    "event": {"stage": "capture", "action": "cleanup_stop_source", 
                            "reason": "no_active_streams_or_recording"}
                })
                await self._source.stop()
                self._source = None
                self._source_params = None
                source_stopped = True
            
            log.info("cleanup.client_session", extra={
                "event": {"stage": "system", "action": "cleanup_client_session",
                        "streams_cleared": streams_cleared, "source_stopped": source_stopped,
                        "is_recording": self.is_recording()}
            })
            
            return {
                "streams_cleared": streams_cleared,
                "source_stopped": source_stopped
            }
    
    # ---------- recording ----------
    async def start_recording(
        self,
        session_id: Optional[str] = None,
        output_dir: Optional[Path] = None,
        segment_sec: Optional[int] = None,
    ) -> tuple[str, list[Path], list[int]]:
        """Start recording from ALL configured/discovered cameras (ignores per-request subsets)."""
        async with self._lock:
            if self.is_recording():
                raise RuntimeError("Recording already active")

            # session & paths
            session_id = session_id or new_session_id()
            self._current_session_id = session_id
            session_dir = output_dir or _session_dir(session_id)

            # Enumerate camera IDs (ALWAYS-ON rule)
            target_cameras = _cameras_from_config()
            log.info("ALWAYS-ON recording from cameras: %s", target_cameras)

            # FPS for recording from config (optional)
            cfg = _load_config_dict()
            rec_cfg_fps = None
            try:
                rec_cfg_fps = int(cfg.get("recording", {}).get("fps"))
            except Exception:
                pass

            files: list[Path] = []
            ts = int(time.time())

            # Start recorders (reuse the active streaming source if matches)
            for i, cam_id in enumerate(sorted(set(target_cameras))):
                if i > 0:
                    await asyncio.sleep(0.15)  # reduce CPU burst

                if self._source and self._source_params and self._source_params[0] == cam_id:
                    width, height = self._source_params[1], self._source_params[2]
                    base_fps = self._source_params[3] or 30
                    fps = _clamp_fps("record", rec_cfg_fps, fallback=base_fps)
                    out = session_dir / f"{session_id}_cam{cam_id}_{ts}.mp4"
                    rec = CameraRecorder(self._source, out, width, height, fps, segment_sec=segment_sec)
                    await rec.start()
                    self._recorders.append(rec)
                    files.append(out)
                    log.info("Recording started (active cam%d): %s", cam_id, out)
                else:
                    # Aux source for additional camera
                    try:
                        _, w, h = _layout_mode_and_size(cam_id)
                    except Exception:
                        w, h = 640, 480
                    base_fps = self._source_params[3] if self._source_params else 30
                    capture_fps = _clamp_fps("capture", rec_cfg_fps or base_fps, fallback=30)
                    aux = create_camera_source(camera_index=cam_id, width=w, height=h, fps=capture_fps)
                    await aux.start()
                    self._aux_sources.append(aux)

                    fps = _clamp_fps("record", rec_cfg_fps, fallback=capture_fps)
                    out = session_dir / f"{session_id}_cam{cam_id}_{ts}.mp4"
                    rec = CameraRecorder(aux, out, w, h, fps, segment_sec=segment_sec)
                    await rec.start()
                    self._recorders.append(rec)
                    files.append(out)
                    log.info("Recording started (aux cam%d %dx%d@%dfps): %s", cam_id, w, h, fps, out)

            return session_id, files, sorted(set(target_cameras))

    async def stop_recording(self) -> tuple[str, list[Path]]:
        """Stop all recorders; return (session_id, files)."""
        async with self._lock:
            sid = self._current_session_id or new_session_id()
            all_files: list[Path] = []
            if self._recorders:
                log.info("Stopping %d recording(s)...", len(self._recorders))
                for rec in self._recorders:
                    try:
                        files = await rec.stop()
                        all_files.extend(files)
                    except Exception as e:
                        log.error("record.stop_error", extra={"event": {"stage": "record", "action": "stop_error", "error_message": str(e)}})
                self._recorders.clear()

            if self._aux_sources:
                for src in list(self._aux_sources):
                    try:
                        await src.stop()
                    except Exception:
                        pass
                self._aux_sources.clear()

            log.info("All recordings stopped: %d file(s)", len(all_files))
            return sid, all_files

    async def build_zip(self, session_id: str, files: list[Path]) -> Path:
        """Create ZIP with ZIP_STORED (no compression), deterministic ordering."""
        zpath = _zip_path(session_id)
        ordered = _sorted_zip_members([f for f in files if f.exists()])
        with ZipFile(zpath, "w", compression=ZIP_STORED) as zf:
            for f in ordered:
                zf.write(f, arcname=f.name)
        log.info("zip.done", extra={"event": {"stage": "mux", "action": "stop", "path": str(zpath), "entries": len(ordered)}})
        return zpath

    def get_zip_path(self, session_id: str) -> Optional[Path]:
        p = _zip_path(session_id)
        return p if p.exists() else None

    # ---------- lifecycle ----------
    async def cleanup_unused_source(self) -> None:
        async with self._lock:
            if not self._source:
                return
            active_streams = len(self._stream_tracks)
            active_recordings = len(self._recorders)
            if active_streams == 0 and active_recordings == 0:
                log.info("capture.stop_idle", extra={"event": {"stage": "capture", "action": "stop_idle"}})
                await self._source.stop()
                self._source = None
                self._source_params = None

    async def stop_all(self) -> None:
        async with self._lock:
            log.info("system.stop_manager", extra={"event": {"stage": "system", "action": "stop_manager"}})
            sid, _ = await self.stop_recording()
            if self._source:
                await self._source.stop()
                self._source = None
                self._source_params = None
            self._stream_tracks.clear()
            log.info("CameraManager stopped (session=%s cleanup done)", sid)

    # ---------- status ----------
    def is_recording(self) -> bool:
        return any(rec.is_recording() for rec in self._recorders)

    def get_status(self) -> dict:
        return {
            "source_active": self._source is not None,
            "source_params": self._source_params,
            "active_streams": len(self._stream_tracks),
            "active_recordings": len(self._recorders),
            "is_recording": self.is_recording(),
            "current_session_id": self._current_session_id,
            "recording_files": sum(len(rec.get_output_files()) for rec in self._recorders),
        }


# Re-exports for router
__all__ = [
    "CameraManager",
    "_layout_mode_and_size",
    "_load_eis_config",
    "enumerate_cameras",
    "_load_config_dict",
    "_get_aspect_config",
]
