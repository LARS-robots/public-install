from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel, Field
from typing import Optional
import logging

from ..services.robot_service import get_robot_service, RobotService, RobotCommand

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/motion", tags=["motion"])

class CommandReq(BaseModel):
    throttle: Optional[float] = Field(None, ge=-1.0, le=1.0)
    steer: Optional[float] = Field(None, ge=-1.0, le=1.0)
    vx: Optional[float] = None
    wz: Optional[float] = None

# Proper dependency function
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

@router.post("/command")
def post_command(
    body: CommandReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Send joystick command to robot.
    Supports both joystick mode (throttle/steer) and velocity mode (vx/wz).
    """
    command = RobotCommand(
        throttle=body.throttle,
        steer=body.steer,
        vx=body.vx,
        wz=body.wz
    )
    
    result = robot.send_command(command)
    logger.debug(f"Motion command executed: {body.dict()}")
    
    return result