from fastapi import APIRouter, Request, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import List, Annotated, Dict, Any
import logging

from ..services.robot_service import get_robot_service, RobotService
from ..services.route_service import Waypoint
from ..services.map_download_service import MapDownloadService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/route", tags=["route"])

# Dependency injection
def get_robot_from_request(req: Request) -> RobotService:
    return get_robot_service(req.app.state)

# Map download request model
class MapDownloadRequest(BaseModel):
    south: float = Field(..., ge=-90, le=90)
    west: float = Field(..., ge=-180, le=180)
    north: float = Field(..., ge=-90, le=90)
    east: float = Field(..., ge=-180, le=180)

class FollowReq(BaseModel):
    path: Annotated[List[Waypoint], Field(min_length=2, max_length=2048)]

class RouteCreate(BaseModel):
    waypoints: Annotated[List[Waypoint], Field(min_length=1, max_length=100)]
    mode: str | None = "simulator"

class PlanReq(BaseModel):
    start: Waypoint
    goal: Waypoint

class MapUpload(BaseModel):
    """GeoJSON map upload request"""
    geojson: Dict[str, Any]
    version: str | None = None

@router.post("")
def post_route(
    req: Request,
    body: RouteCreate,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Start route following waypoints."""
    if robot.get_robot_type() != "simulator":
        raise HTTPException(status_code=400, detail="not_simulator")
    
    route_state = robot.route_service.get_state(req.app.state)
    if route_state:
        raise HTTPException(status_code=409, detail="route_active")
    
    if not robot.init_simulator():
        raise HTTPException(status_code=400, detail="simulator_not_initialized")
    
    return robot.start_route(body.waypoints)

@router.get("")
def get_route(
    req: Request,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Get active route status"""
    return robot.get_route_status()

@router.post("/cancel")
def cancel_route(
    req: Request,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Cancel active route"""
    return robot.cancel_route()

@router.post("/plan")
def plan_route(
    req: Request,
    body: PlanReq,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Plan route with A* pathfinding.
    Returns planned path but DOESN'T start navigation.
    """
    logger.info(f"📍 Planning route: ({body.start.lat:.6f}, {body.start.lon:.6f}) → "
                f"({body.goal.lat:.6f}, {body.goal.lon:.6f})")
    
    if robot.get_robot_type() != "simulator":
        raise HTTPException(status_code=400, detail="not_simulator")
    
    if not robot.init_simulator():
        raise HTTPException(status_code=400, detail="simulator_not_initialized")
    
    result = robot.plan_route(body.start, body.goal)
    
    if not result.get("ok"):
        logger.warning(f"⚠️  Planning failed: {result.get('reason')}")
        return {"ok": False, "reason": result.get("reason")}
    
    logger.info(f"✅ Route planned: {len(result['path'])} waypoints, "
                f"planner: {result.get('planner_used', 'unknown')}")
    return result

@router.post("/follow")
def follow_path(
    req: Request, 
    body: FollowReq,
    robot: RobotService = Depends(get_robot_from_request)  # Use RobotService
):
    """
    Start following a pre-planned path.
    This is called by the frontend after /route/plan succeeds.
    """
    logger.info(f"🚀 Starting to follow path with {len(body.path)} waypoints")
    
    if robot.get_robot_type() != "simulator":
        raise HTTPException(status_code=400, detail="not_simulator")
    
    # Check if route already active
    if robot.route_service.get_state(req.app.state):
        raise HTTPException(status_code=409, detail="route_active")
    
    if not robot.init_simulator():
        raise HTTPException(status_code=400, detail="simulator_not_initialized")
    
    # Start navigation
    st = robot.route_service.start(req.app.state, body.path)
    
    logger.info(f"✅ Navigation started: {len(st.path)} waypoints")
    return {"ok": True, "active": True, "count": len(st.path)}

@router.post("/map/download")
def download_map(
    body: MapDownloadRequest,
    robot: RobotService = Depends(get_robot_from_request)
):
    """
    Download map from OpenStreetMap and build GeoJSON.
    Runs build_site_geojson.py script in background.
    
    This will:
    1. Fetch OSM data from Overpass API
    2. Build GeoJSON with roads (is_road=true) and obstacles (blocked=true)
    3. Save to robot_server/app/static/cache/chelybinsk.geojson
    4. Auto-reload planner
    """
    logger.info(f"📥 Map download requested: ({body.south},{body.west}) → ({body.north},{body.east})")
    
    # Use service to download
    download_service = MapDownloadService()
    result = download_service.download_map(
        south=body.south,
        west=body.west,
        north=body.north,
        east=body.east
    )
    
    if result["ok"]:
        # Invalidate planner cache to force reload
        robot.route_service._invalidate_planner_cache(robot.app_state)
        logger.info("Map downloaded, planner cache invalidated")
    
    return result

@router.post("/map/upload")
def upload_map(
    body: MapUpload,
    robot: RobotService = Depends(get_robot_from_request)
):
    """Upload GeoJSON map for navigation."""
    logger.info(f"📥 Receiving map upload (version: {body.version})...")
    
    # Delegate to route service
    result = robot.route_service.handle_map_upload(robot.app_state, body.geojson)
    
    if result.get("ok"):
        logger.info(f"{result['message']}")
    else:
        logger.error(f"{result.get('message', 'Upload failed')}")
    
    return {
        **result,
        "version": body.version
    }

@router.get("/map/status")
def map_status(
    robot: RobotService = Depends(get_robot_from_request)
):
    """Check if uploaded map exists and get planner status."""
    return robot.route_service.get_map_status(robot.app_state)