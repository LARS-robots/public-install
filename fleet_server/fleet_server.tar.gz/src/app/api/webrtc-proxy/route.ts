import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const action = searchParams.get('action');
    const body = await request.json();
    const { robotUrl, offer } = body;

    console.log('WebRTC Proxy:', { action, robotUrl });

    // Проверяем обязательные параметры
    if (!robotUrl) {
      return NextResponse.json(
        { error: 'Missing robotUrl parameter' },
        { status: 400 }
      );
    }

    let fetchOptions: RequestInit = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      // Таймаут 10 секунд
      signal: AbortSignal.timeout(10000),
    };

    let targetUrl = robotUrl;

    // Для разных действий разные настройки
    if (action === 'offer' && offer) {
      fetchOptions.body = JSON.stringify(offer);
    } else if (action === 'start' || action === 'stop') {
      // Для start/stop используем переданный URL как есть
      fetchOptions.method = 'POST';
    }

    console.log('Making request to:', targetUrl);
    console.log('Request options:', {
      method: fetchOptions.method,
      hasBody: !!fetchOptions.body
    });

    const response = await fetch(targetUrl, fetchOptions);
    const responseText = await response.text();

    console.log('Response status:', response.status);
    console.log('Response text:', responseText);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}\nResponse: ${responseText}`);
    }

    // Пытаемся парсить JSON, но если не получается - возвращаем текст
    try {
      const data = responseText ? JSON.parse(responseText) : { status: 'success' };
      return NextResponse.json(data);
    } catch (jsonError) {
      return NextResponse.json({ 
        message: 'Request successful but non-JSON response',
        response: responseText 
      });
    }

  } catch (error) {
    console.error('WebRTC Proxy Error:', error);

    let errorMessage = 'Unknown error';
    let statusCode = 500;

    if (error instanceof Error) {
      if (error.name === 'TimeoutError') {
        errorMessage = 'Timeout: Server did not respond within 10 seconds';
        statusCode = 408;
      } else if (error.message.includes('Failed to fetch')) {
        errorMessage = 'Network error: Cannot connect to server. Check if server is running and accessible.';
        statusCode = 503;
      } else if (error.message.includes('ENOTFOUND')) {
        errorMessage = 'DNS error: Cannot resolve hostname. Check the server address.';
        statusCode = 404;
      } else {
        errorMessage = error.message;
      }
    }

    return NextResponse.json(
      { 
        error: errorMessage,
        details: 'Check: 1) Server is running 2) Correct IP:port 3) Network connectivity',
        timestamp: new Date().toISOString()
      },
      { status: statusCode }
    );
  }
}