'use client';

import { useState } from 'react';
import RobotView from '@/components/RobotView';

interface Stream {
  id: number;
  ip: string;
}

export default function Home() {
  const [robotIp, setRobotIp] = useState('');
  const [streams, setStreams] = useState<Stream[]>([]);

  const addStream = () => {
    if (robotIp.trim()) {
      // Добавляем http:// если нет протокола
      let url = robotIp.trim();
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = `http://${url}`;
      }

      const newStream = { id: Date.now(), ip: url };
      setStreams([...streams, newStream]);
      setRobotIp('');
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Сервер флота ЛАРС: Мониторинг роботов</h1>
      
      <div className="mb-6 p-4 bg-blue-50 rounded">
        <p className="text-sm text-blue-800">
          💡 Введите адрес робота (например: <code>127.0.0.1:8000</code> или <code>192.168.1.100:8000</code>)
        </p>
      </div>

      <div className="mb-6 flex gap-2">
        <input
          type="text"
          placeholder="IP:port сервера (например: 127.0.0.1:8000)"
          value={robotIp}
          onChange={(e) => setRobotIp(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addStream()}
          className="flex-1 border border-gray-300 p-2 rounded"
        />
        <button 
          onClick={addStream}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
        >
          Добавить поток
        </button>
      </div>

      {streams.length === 0 && (
        <div className="text-center text-gray-500 py-8">
          Нет активных потоков. Добавьте первый поток выше.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {streams.map(stream => (
          <RobotView
            key={stream.id}
            robotUrl={stream.ip}
            onClose={() => setStreams(streams.filter(s => s.id !== stream.id))}
          />
        ))}
      </div>
    </div>
  );
}