'use client';

import { useRef, useEffect, useState } from 'react';

interface RobotViewProps {
  robotUrl: string;
  onClose: () => void;
}

interface ConnectionStatus {
  type: 'idle' | 'connecting' | 'connected' | 'error' | 'disconnected';
  message: string;
  details?: string;
}

export default function RobotView({ robotUrl, onClose }: RobotViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const logRef = useRef<HTMLPreElement>(null);
  const [pc, setPc] = useState<RTCPeerConnection | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>({
    type: 'idle',
    message: 'Готов к подключению'
  });

  const log = (...args: any[]) => {
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg
    ).join(' ');
    
    if (logRef.current) {
      const timestamp = new Date().toLocaleTimeString();
      logRef.current.textContent += `[${timestamp}] ${message}\n`;
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
    console.log(...args);
  };

  const updateStatus = (type: ConnectionStatus['type'], message: string, details?: string) => {
    setStatus({ type, message, details });
    log(`STATUS: ${message}`, details || '');
  };

  const testServerConnection = async (): Promise<boolean> => {
    try {
      updateStatus('connecting', 'Проверка доступности сервера...');
      
      // Проверяем базовую доступность сервера
      const testResponse = await fetch(`/api/webrtc-proxy?action=test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          robotUrl: `${robotUrl}/webrtc/start_stream?record=false` 
        }),
        signal: AbortSignal.timeout(5000)
      });

      if (testResponse.ok) {
        updateStatus('connecting', 'Сервер доступен, запускаем поток...');
        return true;
      } else {
        const errorData = await testResponse.json();
        updateStatus('error', 'Сервер недоступен', errorData.error || `HTTP ${testResponse.status}`);
        return false;
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      updateStatus('error', 'Ошибка подключения к серверу', errorMessage);
      return false;
    }
  };

  const startStream = async () => {
    log('='.repeat(50));
    log('🚀 Запуск потока к:', robotUrl);
    
    // Проверяем доступность сервера перед началом
    const isServerAvailable = await testServerConnection();
    if (!isServerAvailable) {
      return;
    }

    // Останавливаем предыдущее соединение
    if (pc) {
      pc.close();
      setPc(null);
    }

    try {
      // 1. Запускаем поток на сервере
      updateStatus('connecting', 'Отправка запроса на запуск потока...');
      const startResponse = await fetch(`/api/webrtc-proxy?action=start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          robotUrl: `${robotUrl}/webrtc/start_stream?record=false` 
        })
      });

      if (!startResponse.ok) {
        const errorData = await startResponse.json();
        throw new Error(errorData.error || `HTTP ${startResponse.status}`);
      }

      updateStatus('connecting', 'Поток запущен, инициализируем WebRTC...');

      // 2. Инициализируем PeerConnection
      const newPc = new RTCPeerConnection({
        iceServers: [
          { urls: "stun:stun.l.google.com:19302" },
          { urls: "stun:global.stun.twilio.com:3478" }
        ]
      });
      setPc(newPc);

      const video = videoRef.current;
      if (video) video.srcObject = null;

      // 3. Настраиваем обработчики
      newPc.onicecandidate = (e) => {
        if (e?.candidate) {
          log('ICE кандидат получен');
        }
      };

      newPc.oniceconnectionstatechange = () => {
        const state = newPc.iceConnectionState;
        log('ICE состояние:', state);
        
        switch (state) {
          case 'connected':
            updateStatus('connected', 'Подключение установлено');
            break;
          case 'disconnected':
            updateStatus('disconnected', 'Соединение прервано');
            break;
          case 'failed':
            updateStatus('error', 'Ошибка подключения');
            break;
          case 'checking':
            updateStatus('connecting', 'Установка соединения...');
            break;
        }
      };

      newPc.onsignalingstatechange = () => {
        log('Signaling state:', newPc.signalingState);
      };

      newPc.ontrack = (event) => {
        log('Получен видеотрек');
        if (videoRef.current) {
          if (event.streams && event.streams.length > 0) {
            videoRef.current.srcObject = event.streams[0];
          } else {
            const mediaStream = new MediaStream([event.track]);
            videoRef.current.srcObject = mediaStream;
          }
          
          videoRef.current.play()
            .then(() => log('Воспроизведение начато'))
            .catch(e => log('Ошибка воспроизведения:', e));
        }
      };

      // 4. Добавляем transceiver
      newPc.addTransceiver('video', { direction: 'recvonly' });

      // 5. Создаем offer
      updateStatus('connecting', 'Создание WebRTC offer...');
      const offer = await newPc.createOffer();
      await newPc.setLocalDescription(offer);

      // Ждем завершения сбора ICE-кандидатов
      await new Promise<void>((resolve, reject) => {
        if (newPc.iceGatheringState === 'complete') {
          resolve();
        } else {
          const timeout = setTimeout(() => {
            reject(new Error('ICE gathering timeout'));
          }, 10000);

          newPc.onicegatheringstatechange = () => {
            if (newPc.iceGatheringState === 'complete') {
              clearTimeout(timeout);
              resolve();
            }
          };
        }
      });

      // 6. Отправляем offer через прокси
      updateStatus('connecting', 'Отправка offer серверу...');
      const offerResponse = await fetch('/api/webrtc-proxy?action=offer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          robotUrl: `${robotUrl}/webrtc/offer`,
          offer: newPc.localDescription
        })
      });

      if (!offerResponse.ok) {
        const errorData = await offerResponse.json();
        throw new Error(errorData.error || `Offer failed: HTTP ${offerResponse.status}`);
      }

      const answer = await offerResponse.json();
      await newPc.setRemoteDescription(answer);
      log('✅ WebRTC соединение установлено');

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      log('❌ Критическая ошибка:', errorMessage);
      updateStatus('error', 'Ошибка подключения', errorMessage);
      
      // Очищаем ресурсы при ошибке
      if (pc) {
        pc.close();
        setPc(null);
      }
    }
  };

  const stopStream = async () => {
    try {
      updateStatus('disconnected', 'Остановка потока...');
      await fetch(`/api/webrtc-proxy?action=stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ robotUrl: `${robotUrl}/webrtc/stop_stream` })
      });
    } catch (error) {
      log('Ошибка при остановке:', error);
    }

    if (pc) {
      pc.close();
      setPc(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    updateStatus('idle', 'Поток остановлен');
    log('🛑 Соединение закрыто');
  };

  // Автозапуск при монтировании
  useEffect(() => {
    startStream();
    return () => {
      if (pc) {
        pc.close();
      }
    };
  }, [robotUrl]);

  const statusColors = {
    idle: 'bg-gray-100 text-gray-800',
    connecting: 'bg-yellow-100 text-yellow-800',
    connected: 'bg-green-100 text-green-800',
    error: 'bg-red-100 text-red-800',
    disconnected: 'bg-orange-100 text-orange-800'
  };

  return (
    <div className="border rounded-lg p-4 bg-white shadow">
      <div className="flex justify-between items-center mb-3">
        <div className="flex-1">
          <div className="font-mono text-sm text-gray-600 mb-1">{robotUrl}</div>
          <div className="flex items-center gap-2">
            <span className={`px-2 py-1 rounded text-xs font-medium ${statusColors[status.type]}`}>
              {status.message}
            </span>
            {status.details && (
              <span className="text-xs text-gray-500">({status.details})</span>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={startStream}
            disabled={status.type === 'connecting'}
            className="bg-blue-500 text-white px-2 py-1 rounded text-xs disabled:opacity-50"
          >
            ↻
          </button>
          <button 
            onClick={stopStream}
            className="bg-red-500 text-white px-2 py-1 rounded text-xs"
          >
            Стоп
          </button>
          <button 
            onClick={onClose}
            className="bg-gray-500 text-white px-2 py-1 rounded text-xs"
          >
            ×
          </button>
        </div>
      </div>

      <video 
        ref={videoRef} 
        muted 
        autoPlay 
        playsInline 
        className="w-full h-48 bg-black rounded mb-2"
      />

      <div className="bg-black rounded p-2">
        <pre 
          ref={logRef}
          className="text-green-400 text-xs h-20 overflow-auto font-mono whitespace-pre-wrap"
        ></pre>
      </div>
    </div>
  );
}