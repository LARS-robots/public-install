Fleet-server — это веб-приложение на Next.js, которое выполняет роль централизованного сервера управления флотом роботов. Это промежуточное звено между оператором и роботами.

Структура подпроекта:

```
fleet-server/
├── src/
│   ├── app/                 # СТРАНИЦЫ САЙТА
│   │   ├── globals.css
│   │   ├── layout.tsx       # Общий layout
│   │   └── page.tsx         # Главная страница 
│   ├── components/          # Ваши компоненты
│   └── lib/                 # Утилиты и конфиги
├── public/                  # Статические файлы
├── .next/                  # Сборка (не редактировать)
└── node_modules/           # Зависимости
```

# Установка npm и node.js

[Инструкция для Windows](docs/windows_instllation.md)

[Инструкция для Linux](docs/linux_installation.md)

# Запуск приложения
**Установка зависимостей**

```bash
npm install
```

**Запуск в режиме разработки**

```bash
npm run dev
```

**Сборка и запуск production версии**

```bash
npm run build
npm start
```