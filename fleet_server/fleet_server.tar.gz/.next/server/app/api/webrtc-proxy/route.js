var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/webrtc-proxy/route.js")
R.c("server/chunks/[root-of-the-server]__e16b9c32._.js")
R.c("server/chunks/node_modules_next_0439eed1._.js")
R.m(37949)
R.m(86998)
module.exports=R.m(86998).exports
