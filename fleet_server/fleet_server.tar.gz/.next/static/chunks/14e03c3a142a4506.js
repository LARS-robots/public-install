__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/1f080edc3f09ad50.js",
  "static/chunks/turbopack-672a349d532a79e9.js"
])
