__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/1f080edc3f09ad50.js",
  "static/chunks/turbopack-5b4bc728d26a11f4.js"
])
