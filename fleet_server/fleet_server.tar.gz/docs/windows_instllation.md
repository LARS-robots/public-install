# Через PowerShell

Download and install Chocolatey:
```powershell
powershell -c "irm https://community.chocolatey.org/install.ps1|iex"
```

Скачивание и усатновка Node.js и npm:
```powershell
choco install nodejs --version="22.19.0"
```

# Через установщик

Скачате [файл](https://nodejs.org/dist/v22.19.0/node-v22.19.0-x64.msi) и следуйте инструкциям установщика.

 # Проверка установки:
```powershell
node -v
npm -v
```
Должно вывести версию **node.js** v22.19.0 и **npm** 10.9.3

# Примечание
Если **powershell** не видит npm и node.js

Проверьте 
```powershell
Get-ExecutionPolicy
```
Если пишет Rstricted, то введите команды
```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Если не работает, то просто испльзуйте **cmd** для работы с node.js