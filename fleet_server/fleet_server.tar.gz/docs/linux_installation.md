# Ubuntu/Debian
```bash
sudo apt update
sudo apt install nodejs npm
```

# Arch Linux
```bash
sudo pacman -S nodejs npm
```

# Проверка установки
```bash
node -v
npm -v
```